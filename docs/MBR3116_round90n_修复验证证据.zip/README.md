# round90n frozen production regressions

No serial access. All sensor values and clocks are fakes. Firmware was built but not deployed.
Prerequisites: Windows, Python 3, installed LLVM and kernel32.lib paths from tools/test_mbr_distance_pipeline.py, Pico SDK2.2.0 at D:/pico-sdk. No dependency installation is required on the original workstation.
Run from the extracted package root. Use the original Python launcher/executable. Give each --output its own temporary directory.

After: python tools/test_mpr_read_contract.py --output RESULTS/driver_after (24/24)
After: python tools/test_mbr_distance_pipeline.py --output RESULTS/pipeline_after (124/124)
After: python tools/test_round50_migration.py (164/164)
Before: python tools/test_mpr_read_contract.py --source before/mpr121.cpp --header before/mpr121.h --output RESULTS/driver_before (11/24; exit 1 is expected)
Before: python tools/test_mbr_distance_pipeline.py --source before/hw_devices.cpp --output RESULTS/pipeline_before (102/124; exit 1 is expected)

Inspect scenarios and fragment hashes rather than full JSON byte identity: generated paths, #line filenames and compile commands change after extraction. Complete historical generated C++ is also retained. Validate manifest.json member bytes/SHA256 and ZIP CRC first. No real I2C/HID timing or gameplay outcome is established by these tests.
