
#include <stdint.h>
#include <stddef.h>
#include <mbr_distance_gate.h>
#include <pico/error.h>

extern "C" __declspec(dllimport) void* __stdcall GetStdHandle(unsigned long);
extern "C" __declspec(dllimport) int __stdcall WriteFile(void*, const void*, unsigned long, unsigned long*, void*);
extern "C" __declspec(dllimport) char* __stdcall GetCommandLineA();
extern "C" __declspec(dllimport) void __stdcall ExitProcess(unsigned int);
extern "C" void* memset(void* destination, int value, size_t count) {
    volatile unsigned char* bytes = static_cast<volatile unsigned char*>(destination);
    for (size_t i = 0; i < count; ++i) bytes[i] = static_cast<unsigned char>(value);
    return destination;
}
extern "C" void* memcpy(void* destination, const void* source, size_t count) {
    volatile unsigned char* out = static_cast<volatile unsigned char*>(destination);
    const volatile unsigned char* in = static_cast<const volatile unsigned char*>(source);
    for (size_t i = 0; i < count; ++i) out[i] = in[i];
    return destination;
}
extern "C" int memcmp(const void* left, const void* right, size_t count) {
    const unsigned char* a = static_cast<const unsigned char*>(left);
    const unsigned char* b = static_cast<const unsigned char*>(right);
    for (size_t i = 0; i < count; ++i) if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
    return 0;
}
namespace std { using ::memset; using ::memcpy; using ::memcmp; }
static unsigned checks = 0;
static void writeText(const char* text) {
    unsigned long size = 0, written = 0;
    while (text[size]) ++size;
    WriteFile(GetStdHandle(static_cast<unsigned long>(-11)), text, size, &written, nullptr);
}
static void writeNumber(unsigned value) {
    char digits[11]; unsigned count = 0;
    do { digits[count++] = static_cast<char>('0' + value % 10); value /= 10; } while (value);
    for (unsigned i = 0; i < count / 2; ++i) {
        char tmp = digits[i]; digits[i] = digits[count - i - 1]; digits[count - i - 1] = tmp;
    }
    unsigned long written = 0;
    WriteFile(GetStdHandle(static_cast<unsigned long>(-11)), digits, count, &written, nullptr);
}
static void check(bool condition, const char* expression, unsigned line) {
    ++checks;
    if (!condition) {
        writeText("FAIL line "); writeNumber(line); writeText(": "); writeText(expression); writeText("\n");
        ExitProcess(1);
    }
}
#define CHECK(expression) check((expression), #expression, __LINE__)
static uint32_t fakeNow = 100;
static uint8_t readOrder[64];
static unsigned readOrderCount = 0;
static uint32_t get_absolute_time() { return fakeNow; }
static uint32_t to_ms_since_boot(uint32_t time) { return time; }



struct Reply { int count; uint16_t value; };
static Reply replies[4]; static unsigned queued, consumed, sleeps;
static void queue(int count, uint16_t value = 0xabcd) { CHECK(queued < 4); replies[queued++] = Reply{count, value}; }
static void sleep_us(uint32_t delay) { CHECK(delay == 50); ++sleeps; }
static int i2c_write_read(uint8_t port, uint8_t addr, uint8_t* wr, size_t wrLen, uint8_t* dst, size_t n) {
    CHECK(port == 0 && addr == 0x5a && wrLen == 1 && wr[0] <= 0x80);
    CHECK(consumed < queued);
    Reply reply = replies[consumed++];
    for (size_t i = 0; i < n; ++i) dst[i] = i == 0 ? reply.value & 255 : (i == 1 ? reply.value >> 8 : 0xa5);
    return reply.count;
}

/*!
 *  @file Adafruit_MPR121.h
 *
 *  This is a library for the MPR121 12-Channel Capacitive Sensor
 *
 *  Designed specifically to work with the MPR121 board.
 *
 *  Pick one up today in the adafruit shop!
 *  ------> https://www.adafruit.com/product/1982
 *
 *  These sensors use I2C to communicate, 2+ pins are required to interface
 *
 *  Adafruit invests time and resources providing this open source code,
 *  please support Adafruit andopen-source hardware by purchasing products
 *  from Adafruit!
 *
 *  Limor Fried/Ladyada (Adafruit Industries).
 *
 *  BSD license, all text above must be included in any redistribution
 */
#ifndef __MPR121_H__
#define __MPR121_H__




// The default I2C address
#define MPR121_I2CADDR_DEFAULT 0x5A  ///< default I2C address

/*!
 *  Device register map
 */
enum {
    MPR121_TOUCHSTATUS_L = 0x00,
    MPR121_TOUCHSTATUS_H = 0x01,
    MPR121_FILTDATA_0L = 0x04,
    MPR121_FILTDATA_0H = 0x05,
    MPR121_BASELINE_0 = 0x1E,
    MPR121_MHDR = 0x2B,
    MPR121_NHDR = 0x2C,
    MPR121_NCLR = 0x2D,
    MPR121_FDLR = 0x2E,
    MPR121_MHDF = 0x2F,
    MPR121_NHDF = 0x30,
    MPR121_NCLF = 0x31,
    MPR121_FDLF = 0x32,
    MPR121_NHDT = 0x33,
    MPR121_NCLT = 0x34,
    MPR121_FDLT = 0x35,

    MPR121_TOUCHTH_0 = 0x41,
    MPR121_RELEASETH_0 = 0x42,
    MPR121_DEBOUNCE = 0x5B,
    MPR121_CONFIG1 = 0x5C,
    MPR121_CONFIG2 = 0x5D,
    MPR121_CHARGECURR_0 = 0x5F,
    MPR121_CHARGETIME_1 = 0x6C,
    MPR121_ECR = 0x5E,
    MPR121_AUTOCONFIG0 = 0x7B,
    MPR121_AUTOCONFIG1 = 0x7C,
    MPR121_UPLIMIT = 0x7D,
    MPR121_LOWLIMIT = 0x7E,
    MPR121_TARGETLIMIT = 0x7F,

    MPR121_GPIODIR = 0x76,
    MPR121_GPIOEN = 0x77,
    MPR121_GPIOSET = 0x78,
    MPR121_GPIOCLR = 0x79,
    MPR121_GPIOTOGGLE = 0x7A,

    MPR121_SOFTRESET = 0x80,
};

class MPR121 {

    uint8_t port;
    uint8_t addr;
    bool good = false;
    bool readRegisterChecked(uint8_t reg, uint8_t* dst, uint8_t n, bool* retried = nullptr);

public:
    MPR121(uint8_t _port, uint8_t i2c_addr);

    bool ready();

    void init(uint8_t touchThreshold, uint8_t releaseThreshold, bool autoconfig);

    uint16_t filteredData(uint8_t t);
    uint16_t baselineData(uint8_t t);
    bool readRegisters(uint8_t reg, uint8_t* dst, uint8_t n);  // exact byte count; zero dst on failure
    // round90n: valid zero is distinct from failure. At most one 50us retry.
    bool readTouchStatus(uint16_t& status);
    bool readFilteredData(uint8_t t, uint16_t& value, bool* retried = nullptr);
    bool readBaselineData(uint8_t t, uint16_t& value, bool* retried = nullptr);

    void setAutoconfig(bool autoconfig);

    uint8_t readRegister8(uint8_t reg);
    uint16_t readRegister16(uint8_t reg);
    void writeRegister(uint8_t reg, uint8_t value);
    uint16_t touched(void);

    void setThresholds(uint8_t touch, uint8_t release);

    void setThresholdsForElectrode(uint8_t electrode, uint8_t touch, uint8_t release);

    void setDebounce(uint8_t dt,uint8_t dr);

    void calibrateBaseline(bool force = false);
};

#endif

#define CHECKED_MPR_READS

#line 55 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
MPR121::MPR121(uint8_t _port, uint8_t i2c_addr) {
    port = _port;
    addr = i2c_addr;
}

#line 328 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
uint16_t MPR121::filteredData(uint8_t t) {
    uint16_t value = 0;
    readFilteredData(t, value);
    return value;
}

#line 342 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
uint16_t MPR121::baselineData(uint8_t t) {
    uint16_t value = 0;
    readBaselineData(t, value);
    return value;
}

#line 353 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
bool MPR121::readRegisters(uint8_t reg, uint8_t* dst, uint8_t n) {
    if (dst == nullptr || n == 0) return false;
    uint8_t data[1] = { reg };
    int ret = i2c_write_read(port, addr, data, 1, dst, n);
    if (ret != n) {
        memset(dst, 0, n);
        return false;
    }
    return true;
}

#line 371 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
uint16_t MPR121::touched(void) {
    uint16_t status = 0;
    readTouchStatus(status);
    return status;
}

#line 420 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
uint8_t MPR121::readRegister8(uint8_t reg) {
    uint8_t buffer[1] = {0};
    readRegisterChecked(reg, buffer, 1);
    return buffer[0];
}

#line 431 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
uint16_t MPR121::readRegister16(uint8_t reg) {
    uint8_t buffer[2] = {0, 0};
    readRegisterChecked(reg, buffer, 2);
    uint16_t val = buffer[1];
    val <<= 8;
    val |= buffer[0];
    return val;
}

#line 377 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
bool MPR121::readRegisterChecked(uint8_t reg, uint8_t* dst, uint8_t n, bool* retried) {
    if (retried) *retried = false;
    if (readRegisters(reg, dst, n)) return true;
    sleep_us(50);
    if (retried) *retried = true;
    return readRegisters(reg, dst, n);
}

#line 385 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
bool MPR121::readTouchStatus(uint16_t& status) {
    status = 0;
    uint8_t buffer[2] = {};
    if (!readRegisterChecked(MPR121_TOUCHSTATUS_L, buffer, 2)) return false;
    status = ((uint16_t)buffer[0] | ((uint16_t)buffer[1] << 8)) & 0x0FFF;
    return true;
}

#line 393 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
bool MPR121::readFilteredData(uint8_t t, uint16_t& value, bool* retried) {
    value = 0;
    if (retried) *retried = false;
    if (t > 12) return false;
    uint8_t buffer[2] = {};
    if (!readRegisterChecked(MPR121_FILTDATA_0L + t * 2, buffer, 2, retried)) return false;
    uint16_t reading = (uint16_t)buffer[0] | ((uint16_t)buffer[1] << 8);
    if (reading > 0x03FF) return false;  // native 10-bit output; reserved bits are not data
    value = reading;
    return true;
}

#line 405 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/mpr121.cpp"
bool MPR121::readBaselineData(uint8_t t, uint16_t& value, bool* retried) {
    value = 0;
    if (retried) *retried = false;
    if (t > 12) return false;
    uint8_t buffer[1] = {};
    if (!readRegisterChecked(MPR121_BASELINE_0 + t, buffer, 1, retried)) return false;
    value = (uint16_t)buffer[0] << 2;  // only high 8 bits of the native baseline are readable
    return true;
}

extern "C" void mprReadEntry() {
    const char* command = GetCommandLineA(); unsigned number = 99;
    for (unsigned i = 0; command[i]; ++i) if (command[i] == '=') {
        number = 0; while (command[++i] >= '0' && command[i] <= '9') number = number * 10 + command[i] - '0'; break;
    }
    CHECK(number < 24); MPR121 device(0, 0x5a);
    if (number < 8) {
        const uint8_t lengths[] = {1, 2, 12, 24}; uint8_t n = lengths[number / 2];
        uint8_t output[24]; memset(output, 0xcc, sizeof(output));
        queue(number & 1 ? n - 1 : -1);
        CHECK(!device.readRegisters(4, output, n));
        for (unsigned i = 0; i < n; ++i) CHECK(output[i] == 0);
        CHECK(consumed == 1 && sleeps == 0);
        queue(n, 0x1234); CHECK(device.readRegisters(4, output, n)); CHECK(output[0] == 0x34);
    } else if (number < 12) {
        const int failures[] = {-1, 0, 1, 3}; queue(failures[number - 8]); queue(failures[number - 8]);
        CHECK(device.touched() == 0); CHECK(consumed == 2 && sleeps == 1);
    } else if (number < 14) {
        queue(number == 12 ? -1 : 0); queue(number == 12 ? -1 : 0);
        CHECK(device.readRegister8(0x1e) == 0); CHECK(consumed == 2 && sleeps == 1);
    } else if (number < 16) {
        queue(number == 14 ? -1 : 1); queue(number == 14 ? -1 : 1);
        CHECK(device.readRegister16(4) == 0); CHECK(consumed == 2 && sleeps == 1);
    } else if (number < 18) {
        queue(number == 16 ? -1 : 1); queue(2, 0x1234);
        CHECK(device.readRegister16(4) == 0x1234); CHECK(consumed == 2 && sleeps == 1);
    } else if (number == 18) {
        queue(2, 0);
#ifdef CHECKED_MPR_READS
        uint16_t value = 99; bool retry = true;
        CHECK(device.readFilteredData(7, value, &retry) && value == 0 && !retry);
#else
        CHECK(device.filteredData(7) == 0);
#endif
        CHECK(consumed == 1 && sleeps == 0);
    } else if (number == 19) {
        queue(2, 0);
#ifdef CHECKED_MPR_READS
        uint16_t value = 99; CHECK(device.readTouchStatus(value) && value == 0);
#else
        CHECK(device.touched() == 0);
#endif
    } else if (number == 20) {
        CHECK(device.filteredData(13) == 0 && device.baselineData(13) == 0);
        CHECK(consumed == 0);
    } else if (number == 21) {
        queue(-1); queue(2, 0x1fff); CHECK(device.touched() == 0xfff);
        CHECK(consumed == 2 && sleeps == 1);
    } else if (number == 22) {
        queue(2, 0xffff); CHECK(device.filteredData(7) == 0);
    } else {
        queue(2, 0x0255); CHECK(device.filteredData(12) == 0x255);
        queue(1, 0x0034); CHECK(device.baselineData(12) == 0xd0);
    }
    CHECK(consumed == queued);
    writeText("PASS checks="); writeNumber(checks); writeText("\n"); ExitProcess(0);
}
