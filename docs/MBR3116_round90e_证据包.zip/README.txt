Executed round90e evidence. Read the report, manifest and production-source tests.
Hardware helpers record an executed update and must not be automatically rerun.
Old baseline tests are genuine failing regression runs, not current device observations.
User feedback: normal feel, hover remains; no anti-hover cure claimed.
