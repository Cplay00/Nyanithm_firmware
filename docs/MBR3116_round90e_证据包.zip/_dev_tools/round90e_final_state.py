"""Confirm deployed identity, normal binary mode and disabled history; close port."""
import json
from pathlib import Path

import round89_live as live
import round90a_history as history

history.SIGNATURE = 'NYANFW1;1.6.6-beta10;hw_v1;BID=round90e'
port, info = history.checked()
try:
    report = {'usb_serial': info.serial_number, 'version': live.version(port),
              'raw_status': 'RAW=0', 'history': history.status(port),
              'persistent_config_writes': False}
    assert report['history']['state'] == 0 and report['history']['pending'] == 0
finally:
    port.close()
report['port_closed_after_check'] = True
path = Path(__file__).resolve().parent / 'round90e_final_state_20261003.json'
assert not path.exists()
path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
