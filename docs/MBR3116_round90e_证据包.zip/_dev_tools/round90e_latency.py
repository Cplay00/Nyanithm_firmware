"""Bounded identical normal-mode observations before/after the round90e UF2.

C1 loop counters measure the whole input loop, not independent MBR scans or
physical contact-to-HID latency. Posture is uncontrolled; no acceptance claim.
Only read commands are sent; no persistent or diagnostic-mode writes.
"""
import argparse
import json
import statistics
import time
from pathlib import Path

import round89_live as live
from round89g_latency_probe import connect_target, telemetry


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--signature', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise RuntimeError('Refuse to overwrite evidence')
    port, info = connect_target()
    report = {'completed': False, 'usb_serial': info.serial_number,
              'pose_controlled': False, 'commands': ['BD', 'C4', 'C1', 'B1', 'C0'],
              'semantics': 'whole input loop; not independent sensor scans or contact-to-HID latency',
              'frames': []}
    try:
        report['version'] = live.version(port)
        if args.signature not in report['version']:
            raise RuntimeError('Firmware signature changed')
        port.write(b'\xc4')
        report['raw_status'] = live.tail(port)
        if report['raw_status'] != 'RAW=0':
            raise RuntimeError('Requires normal RAW=0 mode')
        report['before'] = telemetry(port)
        started = time.perf_counter()
        while time.perf_counter() - started < 6:
            tick = time.perf_counter()
            port.write(b'\xb1')
            inputs = live.exact(port, 33)
            port.write(b'\xc0')
            chain = live.exact(port, 46)
            if chain[:2] != b'\xaa\x55':
                raise RuntimeError('Chain sync mismatch')
            report['frames'].append({'elapsed_s': time.perf_counter() - started,
                                     'host_transaction_ms': (time.perf_counter() - tick) * 1000,
                                     'input': inputs.hex(), 'chain': chain.hex()})
            time.sleep(max(0, .05 - (time.perf_counter() - tick)))
        report['after'] = telemetry(port)
        report['elapsed_s'] = time.perf_counter() - started
        delta = {k: (report['after'][k] - report['before'][k]) & 0xFFFFFFFF
                 for k in ('uptime_ms', 'sum_us', 'count', 'gate_failures', 'edges')}
        if not delta['count'] or not delta['uptime_ms']:
            raise RuntimeError('No input-loop progress')
        report['delta'] = delta
        report['mean_loop_us'] = delta['sum_us'] / delta['count']
        report['loop_hz'] = delta['count'] * 1000 / delta['uptime_ms']
        report['host_median_ms'] = statistics.median(f['host_transaction_ms'] for f in report['frames'])
        # These min/max are accumulated since boot, not interval percentiles.
        report['since_boot_loop_min_us'] = report['after']['min_us']
        report['since_boot_loop_max_us'] = report['after']['max_us']
        report['completed'] = True
    except Exception as error:
        report['error'] = repr(error)
        raise
    finally:
        port.close()
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'frames'}, indent=2))


if __name__ == '__main__':
    main()
