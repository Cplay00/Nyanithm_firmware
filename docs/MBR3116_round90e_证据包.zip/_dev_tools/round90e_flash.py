"""Identity-checked beta9->beta10 UF2 update, preserving all four config blocks."""
import round89c_flash_probe as probe
from round89g_latency_probe import connect_target

probe.live.connect = connect_target
probe.OUT = probe.WORKSPACE / '_dev_tools/round90e_flash_20261003'
probe.UF2 = probe.WORKSPACE / 'Nyanithm_firmware_hw_v1/build_round90e/Nyanithm.uf2'
probe.EXPECTED_SHA256 = '9cc627e90abec0b45cd1695b477a5b04718baa74e76934eb6c29df191943128b'
probe.SIGNATURE = 'NYANFW1;1.6.6-beta10;hw_v1;BID=round90e'
probe.BASELINE_BUILD_ID = 'round90d'
probe.DEVICE_BACKUP = probe.WORKSPACE / '_dev_archive/round90e_flash_before_20261003'

if __name__ == '__main__':
    probe.main()
