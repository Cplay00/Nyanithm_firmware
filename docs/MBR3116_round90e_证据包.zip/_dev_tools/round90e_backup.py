"""Back up the identified beta9 target and matching local source/UF2 before edits."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import round90d_readonly as read

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_archive/round90e_before_20261003'
read.history.SIGNATURE = 'NYANFW1;1.6.6-beta9;hw_v1;BID=round90d'
report = read.take_snapshot(OUT)
assert report['profile'][2] == 0
firmware = ROOT / 'Nyanithm_firmware_hw_v1/build_round90d/Nyanithm.uf2'
assert hashlib.sha256(firmware.read_bytes()).hexdigest() == 'd39a458f35a5532f5d64d5fb42345b271411aeeca7746ed540e2ecddbdb55530'
shutil.copy2(firmware, OUT / 'round90d.uf2')
subprocess.run(['git', '-C', str(ROOT / 'Nyanithm_firmware_hw_v1'), 'archive', '--format=zip', '-o', str(OUT / 'source.zip'), 'HEAD'], check=True)
print(json.dumps({'serial': report['usb_serial'], 'version': report['version'], 'profile': report['profile'],
                  'config_sha256': report['verified_sha256'], 'backup': str(OUT)}, ensure_ascii=True, indent=2))
