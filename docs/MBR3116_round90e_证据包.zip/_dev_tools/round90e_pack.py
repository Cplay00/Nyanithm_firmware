"""Verify and package executed round90e evidence. No device operations."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'Nyanithm_firmware_hw_v1'
CHECKS = ROOT / '_dev_tools/round90e_checks_20261003'
BASE = ROOT / '_dev_archive/round90e_before_20261003'
FLASHED = ROOT / '_dev_tools/round90e_flash_20261003'
PREFIX = 'MBR3116_round90e_'
SIGNATURE = 'NYANFW1;1.6.6-beta10;hw_v1;BID=round90e'
CONFIGS = ('controller_config.bin', 'chip_40.bin', 'chip_41.bin', 'chip_42.bin')
CHANGED = ('src/hw_devices.cpp', 'include/share/nyanithm_shared.h',
           'tools/test_mbr_distance_pipeline.py', 'tools/test_round50_migration.py')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    flash = read(FLASHED / 'flash_probe.json')
    final = read(ROOT / '_dev_tools/round90e_final_state_20261003.json')
    feedback_path = ROOT / '_dev_tools/round90e_gameplay_feedback_20261003.json'
    feedback = read(feedback_path)
    assert flash['completed'] and flash['signature'] == SIGNATURE
    assert flash['controller_config_equal'] and all(flash['chips_equal'].values())
    assert SIGNATURE in final['version'] and final['usb_serial'] == '5303284739002C9C'
    assert final['raw_status'] == 'RAW=0' and final['port_closed_after_check']
    assert final['history']['state'] == final['history']['pending'] == 0
    assert flash['profile_after'][2] == 0 and flash['raw_status_final'] == 'RAW=0'
    assert feedback['firmware'] == SIGNATURE and feedback['user_reply_exact'] == '手感正常，隔空仍存在'
    config_hashes = {}
    for name in CONFIGS:
        original = (BASE / name).read_bytes()
        for folder in (FLASHED / 'before', FLASHED / 'after', ROOT / '_dev_archive/round90e_flash_before_20261003'):
            assert (folder / name).read_bytes() == original
        config_hashes[name] = sha(BASE / name)
    uf2 = REPO / 'build_round90e/Nyanithm.uf2'
    assert uf2.stat().st_size == flash['uf2_size'] == 200192
    assert sha(uf2) == flash['uf2_sha256'] == '9cc627e90abec0b45cd1695b477a5b04718baa74e76934eb6c29df191943128b'
    assert sha(BASE / 'round90d.uf2') == 'd39a458f35a5532f5d64d5fb42345b271411aeeca7746ed540e2ecddbdb55530'

    pipeline_paths = [ROOT / f'_dev_tools/round90e_pipeline_{stage}_20261003' for stage in ('before', 'red', 'final')]
    before, red, after = [read(path / 'results.json') for path in pipeline_paths]
    assert len(before['results']) == 42 and all(row['passed'] for row in before['results'])
    assert len(red['results']) == 78 and sum(row['passed'] for row in red['results']) == 56
    assert all(row['passed'] for row in red['results'][:42])
    assert before['source_sha256'] == red['source_sha256']
    assert len(after['results']) == 84 and all(row['passed'] for row in after['results'])
    assert sum(row['checks'] for row in after['results']) == 118538
    for name, key in (('src/hw_devices.cpp', 'source_sha256'), ('src/cy8cmbr3116.cpp', 'driver_sha256')):
        assert hashlib.sha256((REPO / name).read_text(encoding='utf-8').encode()).hexdigest() == after[key]
    for path, digest in after['header_sha256'].items():
        assert sha(Path(path)) == digest
    for name, marker in (
        ('migration_before.txt', 'All 138 tests PASSED'), ('migration_after.txt', 'All 153 tests PASSED'),
        ('pipeline_red.txt', '56/78 scenarios'), ('pipeline_final.txt', '84/84 scenarios, 118538 checks'),
        ('driver_final.txt', '27/27 production driver tests passed'),
        ('readers_final.txt', '28/28 production-reader scenarios passed'),
        ('build_final.txt', 'UF2: 200192 bytes'),
    ):
        assert marker in (CHECKS / name).read_text(encoding='utf-8-sig'), name
    timing = [read(CHECKS / ('latency_' + stage + '.json')) for stage in ('before', 'after')]
    assert all(report['completed'] and report['raw_status'] == 'RAW=0' for report in timing)

    source_before = ROOT / '_dev_tools/round90e_source_before_20261003'
    with zipfile.ZipFile(BASE / 'source.zip') as archive:
        old_hw = archive.read('src/hw_devices.cpp').decode('utf-8').replace('\r\n', '\n')
        assert hashlib.sha256(old_hw.encode()).hexdigest() == before['source_sha256']
        for name in CHANGED:
            target = source_before / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(name))
    patch = ROOT / '_dev_tools/round90e_firmware_diff.patch'
    diff = subprocess.run(['git', '-C', str(REPO), 'diff', '--', *CHANGED], capture_output=True, check=True)
    patch.write_bytes(diff.stdout)

    included = set()
    for folder in (BASE, FLASHED, CHECKS, source_before, *pipeline_paths):
        included.update(path for path in folder.rglob('*')
                        if path.is_file() and path.suffix not in ('.exe', '.obj') and path.name != 'source.zip')
    included.update((uf2, feedback_path, ROOT / '_dev_tools/round90e_final_state_20261003.json',
                     ROOT / '_dev_tools/round90e_readonly_review_20261003.txt', patch))
    for folder in (REPO / 'src', REPO / 'include'):
        included.update(path for path in folder.rglob('*') if path.is_file())
    included.update(REPO / 'tools' / name for name in
                    ('test_round50_migration.py', 'test_mbr_distance_pipeline.py',
                     'test_mbr3116_difference_counts.py', 'test_touch_snapshot_readers.py', 'build_firmware.ps1'))
    included.update(REPO / 'docs' / name for name in
                    ('MBR3116_round90e_故障准入修复与基线研究.md', 'MBR3116_算法与驱动重构计划_20261003.md',
                     'MBR3116_round90d_原理核查与一致读取修复.md'))
    included.add(REPO / '更新日志_固件.md')
    pending = [ROOT / '_dev_tools' / name for name in
               ('round90e_backup.py', 'round90e_flash.py', 'round90e_latency.py', 'round90e_final_state.py', 'round90e_pack.py')]
    visited = set()
    while pending:
        path = pending.pop()
        if path in visited:
            continue
        visited.add(path)
        included.add(path)
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig'))):
            modules = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) else []
            for module in modules:
                if module:
                    dependency = ROOT / '_dev_tools' / (module.split('.')[0] + '.py')
                    if dependency.is_file() and dependency not in visited:
                        pending.append(dependency)
    file_map = {path.relative_to(ROOT).as_posix(): {'size': path.stat().st_size, 'sha256': sha(path)}
                for path in sorted(included)}
    manifest = {'date': '2026-10-03', 'baseline_head': '06dcc2f', 'firmware': SIGNATURE,
                'full_source_backup_local_only': {'path': str(BASE / 'source.zip'), 'sha256': sha(BASE / 'source.zip'),
                                                   'reason': 'Avoid recursively repacking old evidence archives; affected old source included.'},
                'config_sha256_before_after': config_hashes, 'profile_enabled': False, 'persistent_config_writes': False,
                'tests': {'migration_before_after': [138, 153], 'original_pipeline_scenarios': 42,
                          'red_pass_total': [56, 78], 'red_failures': 22, 'pipeline_scenarios': 84,
                          'pipeline_checks': 118538, 'driver_tests': 27, 'reader_tests': 28,
                          'tested_source_hashes_match': True},
                'flash': flash, 'normal_loop_observations': timing, 'final_device_state': final, 'gameplay': feedback,
                'limits': ['Hover not cured; no new classifier or NVRAM table deployed.',
                           'Held ON with valid timely native status does not reread DIFF each frame.',
                           'No whole-chip 50ms release guarantee for another new lane group-DIFF failure.',
                           '50ms fault expiry is evaluated when processing resumes; no hard HID latency guarantee.',
                           'Host age is not chip scan age; separate BUTTON_STAT and DIFF are not guaranteed atomic.',
                           'No live MPR snapshot; FDL=255 comment is not verified hardware baseline disable.',
                           'Timing windows have uncontrolled posture; profile-off errors excluded from gate counter.',
                           'Gameplay feedback is qualitative, without counted trials or fault injection.'], 'files': file_map}
    package = REPO / 'docs' / (PREFIX + '证据包.zip')
    with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(included):
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        archive.writestr('README.txt', 'Executed round90e evidence. Read the report, manifest and production-source tests.\nHardware helpers record an executed update and must not be automatically rerun.\nOld baseline tests are genuine failing regression runs, not current device observations.\nUser feedback: normal feel, hover remains; no anti-hover cure claimed.\n')
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None
        for name, entry in file_map.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == entry['sha256']
    manifest['archive'] = {'filename': package.name, 'size': package.stat().st_size,
                           'sha256': sha(package), 'verified_entries': len(file_map)}
    (REPO / 'docs' / (PREFIX + '证据核对.json')).write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'archive': manifest['archive'], 'tests': manifest['tests'],
                      'config_equal_4_of_4': True, 'feedback': feedback['user_reply_exact']}, ensure_ascii=True, indent=2))


if __name__ == '__main__':
    main()
