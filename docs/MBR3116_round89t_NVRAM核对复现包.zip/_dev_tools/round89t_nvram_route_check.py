import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FW = ROOT / "Nyanithm_firmware_hw_v1"
DOCS = FW / "docs"
DATA = ROOT / "_dev_tools/round89q_no_autoreset_20261002"
hardware_source = (FW / "src/hw_devices.cpp").read_text(encoding="utf-8-sig")


def lanes(name):
    match = re.search(r"static const uint8_t " + name + r"\[32\] = \{([^}]+)\}", hardware_source)
    if not match:
        raise RuntimeError("missing native layout table")
    return [int(v) for v in match.group(1).replace("\n", "").split(",") if v.strip()]


chip_ids, electrodes = lanes("V1_LANE_M"), lanes("V1_LANE_E")
if len(chip_ids) != 32 or len(electrodes) != 32:
    raise RuntimeError("wrong layout size")


def crc(data):
    value = 0xFFFF
    for byte in data[:126]:
        value ^= byte << 8
        for _ in range(8):
            value = ((value << 1) ^ (0x1021 if value & 0x8000 else 0)) & 0xFFFF
    return value


jobs = []
for file in DATA.glob("*.json"):
    job = json.loads(file.read_text(encoding="utf-8"))
    if job.get("completed") and job.get("user_confirmed") is True and "mode" in job:
        jobs.append(job)
if len(jobs) != 4:
    raise RuntimeError("expected four accepted same-config trials")
reference_tables = None
reference_controller = None
reports = {}
for job in jobs:
    after = DATA / (job["id"] + "_device/after_reboot")
    snapshot = json.loads((after / "snapshot.json").read_text(encoding="utf-8"))
    if "BID=round89g" not in snapshot["version"] or snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
        raise RuntimeError("restored snapshot mismatch")
    tables = {address: (after / f"chip_{address:02x}.bin").read_bytes() for address in (0x40, 0x41, 0x42)}
    controller = (after / "controller_config.bin").read_bytes()
    if controller[2] != 2:
        raise RuntimeError("recorded hardware layout differs")
    if reference_tables is None:
        reference_tables, reference_controller = tables, controller
    elif tables != reference_tables or controller != reference_controller:
        raise RuntimeError("trial restoration tables disagree")
    if not all(job["hardware"].get(k) for k in ("candidate_applied", "restore_verified", "restore_after_reboot")):
        raise RuntimeError("trial verification incomplete")

for index, address in enumerate((0x40, 0x41, 0x42)):
    table = reference_tables[address]
    if len(table) != 128 or crc(table) != int.from_bytes(table[126:], "little") or table[0x51] != address:
        raise RuntimeError("recorded native table integrity or address mismatch")
    enabled = [e for e in range(16) if int.from_bytes(table[:2], "little") & (1 << e)]
    sensitivity = [(table[8 + e // 4] >> (2 * (e % 4))) & 3 for e in enabled]
    ft = [table[0x0C + e] for e in enabled]
    if any(v != 3 for v in sensitivity) or any(v != 200 for v in ft):
        raise RuntimeError("recorded min-sensitivity/max-FT assumption changed")
    emc_conflicts = [e for e in enabled if e >= 10]
    disabled_lanes = [i + 1 for i, (m, e) in enumerate(zip(chip_ids, electrodes)) if m == index and e in emc_conflicts]
    reports[f"0x{address:02x}"] = {
        "sha256": hashlib.sha256(table).hexdigest(), "crc_valid": True,
        "sensor_en": f"0x{int.from_bytes(table[:2], 'little'):04X}", "enabled_electrodes": enabled,
        "button_sensitivity_settings": sensitivity, "button_sensitivity_ff": [100 * (s + 1) for s in sensitivity],
        "configured_finger_thresholds": ft, "ath_enabled": bool(table[0x4F] & 8),
        "shield_enabled": bool(table[0x4F] & 1), "emc_enabled": bool(table[0x4F] & 4),
        "hysteresis_override": bool(table[0x1D] & 128), "stored_hysteresis_field": table[0x1D] & 31,
        "emc_incompatible_enabled_electrodes": emc_conflicts,
        "game_lanes_lost_if_all_emc_incompatible_electrodes_disabled": disabled_lanes,
    }

tool = Path(r"C:\Program Files (x86)\Cypress\EZ-Click\2.0\EZ-Click.exe")
manual = tool.parent / "Documentation/EZ-ClickUserGuide.pdf"
result = {
    "date": "2026-10-02", "scope": "Offline decoding of recorded restored tables; no live serial connection, generated config, or NVM writes",
    "source_trial_ids": [job["id"] for job in jobs], "restored_table_sets_verified": len(jobs),
    "controller_sha256": hashlib.sha256(reference_controller).hexdigest(), "chips": reports,
    "ez_click": {"installed_registry_version": "2.0.0.2305", "executable": str(tool), "executable_exists": tool.exists(),
                 "user_guide": str(manual), "user_guide_sha256": hashlib.sha256(manual.read_bytes()).hexdigest(),
                 "export_formats": [".h (128-byte array for MBR3)", ".hex (Intel HEX; not 128-byte flat binary)", ".iic (BCP I2C instructions)"]},
    "hardware_evidence": {"shield_connection": "User confirmed SH is not connected to shield copper on 2026-10-02", "schematic_not_available": True},
    "decision": "NVM programming path exists and retains configuration on normal boot. No documented full SmartSense-off mode; current button settings already minimum sensitivity and maximum legal FT. Shield unavailable under firmware-only constraint. No new production candidate exported or applied.",
    "native_limits": {"sensitivity_ff": [100, 200, 300, 400], "finger_threshold": [31, 200], "hysteresis_count": [0, 31], "maximum_legal_ft_plus_hysteresis": 231},
}
output = DOCS / "MBR3116_round89t_NVRAM路线核对.json"
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("VERIFIED", len(jobs), "restored table sets; native CRC/address and 400fF/FT200; no device access")
for address, report in reports.items():
    print(address, "SENSOR_EN", report["sensor_en"], "ATH", report["ath_enabled"], "HYS override", report["hysteresis_override"],
          "EMC conflicting lanes", report["game_lanes_lost_if_all_emc_incompatible_electrodes_disabled"])
print("EZCLICK", tool.exists(), "manual SHA256", result["ez_click"]["user_guide_sha256"])

files = [output, DOCS / "MBR3116_round89t_EZClick与NVRAM配置路线.md", Path(__file__),
         FW / "src/hw_devices.cpp", FW / "src/app_link.cpp", FW / "src/production_mode.cpp",
         ROOT / "_dev_tools/round89c_ath_ab.py"]
for job in jobs:
    files.append(DATA / (job["id"] + ".json"))
    files.extend(p for p in (DATA / (job["id"] + "_device/after_reboot")).rglob("*") if p.is_file())
manifest = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
archive = DOCS / "MBR3116_round89t_NVRAM核对复现包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for path in files:
        bundle.write(path, path.relative_to(ROOT).as_posix())
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != expected for name, expected in manifest.items()):
        raise RuntimeError("archive contents differ from source")
print("ARCHIVE VERIFIED", len(manifest), archive.stat().st_size, hashlib.sha256(archive.read_bytes()).hexdigest())
