"""Validate and summarize frozen all-chip MPR captures; no hardware access."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90i_same32_20261004'
CAPTURES = OUT / 'page_v2'
WINDOWS = {'baseline': (.5, 3.5), 'hold': (6, 11.5), 'late': (9, 11.5), 'release': (14, 21.5)}


def stats(values):
    return {'min': min(values), 'median': statistics.median(values), 'max': max(values)} if values else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--captures', type=Path, default=CAPTURES)
    parser.add_argument('--config', type=Path, default=OUT / 'mpr_controller_config.bin')
    parser.add_argument('--mapping', type=Path, default=OUT / 'source_mapping.json')
    parser.add_argument('--out', type=Path, default=OUT / 'actions_analysis.json')
    args = parser.parse_args()
    config = args.config.read_bytes()
    checksum = 0
    for byte in config:
        checksum ^= byte
    assert len(config) == 128 and config[:4] == bytes([0x88, 2, 2, 0]) and not checksum
    mapping_doc = json.loads(args.mapping.read_text(encoding='utf-8'))
    assert mapping_doc['origin'] == 'source-intent' and mapping_doc['hardware_layout'] == 'HW1/2 three-chip V1'
    mapping = {(row['address'], row['electrode']): row['logical_lane'] for row in mapping_doc['lanes']}
    assert len(mapping) == 32 and set(mapping.values()) == set(range(32))
    output = {'scope': 'native configuration-mode signals, not simultaneous game HID or exact physical-contact truth',
              'windows_s': WINDOWS, 'jobs': [], 'confirmed': [], 'discarded': [], 'validation_errors': []}
    hashes = {}
    for path in sorted(args.captures.glob('*.json')):
        if path.name == 'session_closed.json':
            continue
        job = json.loads(path.read_text(encoding='utf-8'))
        assert job['completed'] and job['controller_equal_after']
        assert job['mock'] is False and job['origin'] == 'hardware-readback'
        assert job['controller_config'] == config.hex()
        csv_path = path.with_suffix('.csv')
        hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        hashes[csv_path.name] = hashlib.sha256(csv_path.read_bytes()).hexdigest()
        rows = []
        with csv_path.open(encoding='utf-8') as stream:
            for raw in csv.DictReader(stream):
                channels = json.loads(raw['channels_json'])
                times = json.loads(raw['chip_times_json'])
                assert len(channels) == 36 and [t['address'] for t in times] == [0x5A, 0x5B, 0x5C]
                reconstructed = []
                fault_expected = False
                for address in (0x5A, 0x5B, 0x5C):
                    data = bytes.fromhex(raw[f'registers_{address:02x}'])
                    assert len(data) == 128
                    status, oor = int.from_bytes(data[:2], 'little'), int.from_bytes(data[2:4], 'little')
                    fault_expected |= bool(oor or status & 0x8000)
                    for electrode in range(12):
                        c = next(c for c in channels if c['address'] == address and c['electrode'] == electrode)
                        filtered = int.from_bytes(data[4+2*electrode:6+2*electrode], 'little')
                        baseline = data[0x1E+electrode] << 2
                        assert filtered < 1024
                        assert c['filtered'] == filtered and c['baseline_floor'] == baseline
                        assert c['delta_floor'] == baseline-filtered and c['delta_ceiling'] == baseline+3-filtered
                        assert c['native_on'] == bool(status & (1 << electrode))
                        assert c['logical_lane'] == mapping.get((address, electrode))
                        assert c['touch_threshold'] == data[0x41+2*electrode] == 13
                        assert c['release_threshold'] == data[0x42+2*electrode] == 12
                        assert c['oor'] == bool(oor & (1 << electrode))
                        if c['native_on'] and c['logical_lane'] is not None:
                            reconstructed.append(c['logical_lane'])
                assert sorted(reconstructed) == json.loads(raw['native_lanes_json'])
                assert bool(raw['error']) == fault_expected
                assert all(t['bytes'] == 128 and t['end_s'] >= t['start_s'] for t in times)
                assert all(times[i+1]['start_s'] >= times[i]['end_s'] for i in (0, 1))
                rows.append({'time': float(raw['elapsed_s']), 'valid': int(raw['phase_valid']) == 1 and not raw['error'],
                             'error': raw['error'], 'channels': channels, 'native_lanes': reconstructed,
                             'cycle_ms': (float(raw['cycle_end_s'])-float(raw['cycle_start_s']))*1000})
        summary = {'id': job['id'], 'mode': job['mode'], 'user_confirmed': job['user_confirmed'],
                   'rows': len(rows), 'errors': sum(bool(r['error']) for r in rows),
                   'host_cycle_ms': stats([r['cycle_ms'] for r in rows]), 'windows': {}}
        for name, (begin, end) in WINDOWS.items():
            chosen = [r for r in rows if r['valid'] and begin <= r['time'] <= end]
            lanes = {}
            for lane in range(32):
                values = [next(c for c in r['channels'] if c['logical_lane'] == lane) for r in chosen]
                lanes[str(lane)] = {'native_on': sum(c['native_on'] for c in values),
                                    'delta_floor': stats([c['delta_floor'] for c in values]),
                                    'baseline_floor': stats([c['baseline_floor'] for c in values]),
                                    'filtered': stats([c['filtered'] for c in values])}
            summary['windows'][name] = {'valid_cycles': len(chosen),
                                       'any_native_on': sum(bool(r['native_lanes']) for r in chosen),
                                       'lanes': lanes}
        output['jobs'].append(summary)
        output['confirmed' if job['user_confirmed'] else 'discarded'].append(job['id'])
        if job['user_confirmed']:
            late = summary['windows']['late']
            active = {lane: value['native_on'] for lane, value in late['lanes'].items() if value['native_on']}
            top = sorted(late['lanes'].items(), key=lambda item: item[1]['delta_floor']['max'], reverse=True)[:4]
            print(job['mode'], 'rows', len(rows), 'late ON', late['any_native_on'], '/', late['valid_cycles'],
                  'active lanes', active, 'top delta', [(lane, v['delta_floor']) for lane, v in top])
    output['file_sha256'] = hashes
    output['session_closed'] = json.loads((args.captures / 'session_closed.json').read_text(encoding='utf-8'))
    assert output['session_closed']['exit_reboot_sent'] and output['session_closed']['hands_away_confirmed_by_finish_button']
    assert len(output['confirmed']) == 6 and len(output['discarded']) == 3
    args.out.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('validated rows', sum(j['rows'] for j in output['jobs']), 'confirmed rows',
          sum(j['rows'] for j in output['jobs'] if j['user_confirmed']), 'discarded retained', len(output['discarded']))


if __name__ == '__main__':
    main()
