"""Freeze confirmed and discarded physical captures with portable replay inputs."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90i_same32_20261004'
DOCS = ROOT / 'Nyanithm_firmware_hw_v1/docs'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    packet = DOCS / 'MBR3116_round90i_同32寸六组证据.zip'
    if packet.exists():
        raise RuntimeError('physical evidence already frozen; do not overwrite')
    import round90i_same32_page as page  # Safe import: no worker/server or serial opened.
    source = ROOT / 'Nyanithm_firmware_hw_v1/src/hw_devices.cpp'
    save(OUT / 'source_mapping.json', {'origin': 'source-intent', 'hardware_layout': 'HW1/2 three-chip V1',
         'source': 'src/hw_devices.cpp V1_LANE_M/E', 'source_sha256': sha(source.read_bytes()),
         'lanes': [{'address': address, 'electrode': electrode, 'logical_lane': lane}
                   for (address, electrode), lane in sorted(page.LANES.items(), key=lambda row: row[1])]})
    subprocess.run([sys.executable, str(ROOT / '_dev_tools/round90i_analyze_actions.py')], check=True)
    save(OUT / 'game_feedback.json', {'source': 'user answer to separate game acceptance question',
         'feedback_verbatim': '目前很稳定', 'mode': 'normal firmware, CDC observers released',
         'firmware': '1.6.6-beta11 / round90g', 'mpr_global_touch_release': [13, 12],
         'quantified_hid_reports': False, 'scope': 'subjective gameplay acceptance; not precise per-action error/latency counts',
         'monitor_interference': 'user reported device busy during concurrent CDC watch; watch ended and COM6 open-close verified, then game feedback received',
         'further_serial_access': False})
    analysis = json.loads((OUT / 'actions_analysis.json').read_text(encoding='utf-8'))
    files = {'actions/' + path.name: path for path in sorted((OUT / 'page_v2').glob('*')) if path.is_file()}
    for name in ('source_mapping.json', 'actions_analysis.json', 'game_feedback.json', 'mpr_controller_config.bin'):
        files[name] = OUT / name
    for name in ('round90i_analyze_actions.py', 'round90i_package_actions.py'):
        files['host_tools/' + name] = ROOT / '_dev_tools' / name
    metadata = {'scope': 'native three-chip diagnostic captures and separate subjective normal game feedback',
                'all_jobs': 9, 'confirmed_jobs': 6, 'discarded_jobs': 3,
                'all_cycles': sum(j['rows'] for j in analysis['jobs']),
                'confirmed_cycles': sum(j['rows'] for j in analysis['jobs'] if j['user_confirmed']),
                'baseline_packet_sha256': '38386c05b4cb10759acfe32b7f3d5ed54c17df9b3a949455ebb3d6d013356f72',
                'manifest': {name: sha(path.read_bytes()) for name, path in files.items()}}
    with zipfile.ZipFile(packet, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr('manifest.json', json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(packet) as archive:
        assert archive.testzip() is None
        for name, digest in metadata['manifest'].items():
            assert sha(archive.read(name)) == digest
        replay = OUT / 'actions_replay'
        replay.mkdir(exist_ok=False)
        archive.extractall(replay)  # Locally generated exact-member archive, validated above.
    result = replay / 'replay.json'
    subprocess.run([sys.executable, str(replay / 'host_tools/round90i_analyze_actions.py'),
                    '--captures', str(replay / 'actions'), '--config', str(replay / 'mpr_controller_config.bin'),
                    '--mapping', str(replay / 'source_mapping.json'), '--out', str(result)], check=True)
    assert result.read_bytes() == (OUT / 'actions_analysis.json').read_bytes()
    check = {'packet': packet.name, 'sha256': sha(packet.read_bytes()), 'bytes': packet.stat().st_size,
             'members_verified': len(files), 'all_cycles': metadata['all_cycles'],
             'confirmed_cycles': metadata['confirmed_cycles'], 'discarded_jobs_retained': 3,
             'portable_replay_byte_equal': True, 'game_feedback': '目前很稳定',
             'direct_hid_report_capture': False, 'mbr_hover_cured': False}
    save(DOCS / 'MBR3116_round90i_六组核查.json', check)
    print(json.dumps(check, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
