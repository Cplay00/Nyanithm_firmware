import csv
import hashlib
import json
import math
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import round89i_analyze_pair as paired
import round89q_no_autoreset_capture as experiment

experiment.configure()
ROOT = Path(__file__).resolve().parents[1]
DATA = experiment.OUT
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
MODES = ("finger_contact", "finger_hover3", "palm_hover5", "palm_contact")
LABELS = ("Finger contact", "Finger hover ~3 mm", "Palm hover ~5 mm", "Palm contact")
COLORS = ("#2463a8", "#e2a224", "#cf5365", "#268166")
paired.ROOT = DATA
analysis = paired.analyze()
accepted = [j for j in analysis["jobs"] if j["completed"] and j["user_confirmed"] is True]
if len(accepted) != 4 or {j["mode"] for j in accepted} != set(MODES):
    raise RuntimeError("unexpected accepted trial set")

files, checks, traces, points, far_points = {}, {}, {}, {}, {}
for mode in MODES:
    job = next(j for j in accepted if j["mode"] == mode)
    source = DATA / (job["id"] + ".json")
    native = json.loads(source.read_text(encoding="utf-8"))
    hardware = native["hardware"]
    if native["reference_mode"] != experiment.capture.REFERENCE_MODE or not all(hardware.get(k) for k in ("candidate_applied", "restore_verified", "restore_after_reboot")):
        raise RuntimeError("mode or restore flags disagree")
    device = DATA / (job["id"] + "_device")
    for folder in (device, device / "after_reboot"):
        if (folder / "controller_config.bin").read_bytes() != experiment.capture.CFG:
            raise RuntimeError("controller config mismatch")
        if any((folder / f"chip_{a:02x}.bin").read_bytes() != table for a, table in experiment.capture.ORIGINALS.items()):
            raise RuntimeError("chip config mismatch")
    snapshot = json.loads((device / "after_reboot/snapshot.json").read_text(encoding="utf-8"))
    if snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
        raise RuntimeError("nonzero restored state")
    with source.with_suffix(".csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    good = [r for r in rows if not r["error"]]
    if any(int(r["ref_delta"]) != int(r["ref_raw"]) - int(r["ref_baseline"]) or int(r["delta"]) != int(r["raw"]) - int(r["baseline"]) for r in good):
        raise RuntimeError("delta arithmetic disagreement")
    windows = {}
    for phase, (start, end) in {"baseline": (.5, 3.5), "hold": (6, 11.5), "release": (14, 21.5)}.items():
        selected = [r for r in rows if r["phase"] == phase and start <= float(r["elapsed_s"]) <= end]
        fixed = [r for r in selected if not r["error"] and r["phase_valid"] == "1"]
        summary = job["windows"][phase]
        if len(fixed) != summary["valid"] or sum(bool(r["error"]) for r in selected) != summary["errors"]:
            raise RuntimeError("window count disagreement")
        for field in ("delta", "ref_delta", "diff", "ref_diff", "raw", "ref_raw", "baseline", "ref_baseline"):
            if min(int(r[field]) for r in fixed) != summary[field]["min"] or max(int(r[field]) for r in fixed) != summary[field]["max"]:
                raise RuntimeError("independent extrema disagreement")
        windows[phase] = fixed
    far_center = float(np.median([int(r["raw"]) for r in windows["baseline"]]))
    far_reference = float(np.median([int(r["ref_raw"]) for r in windows["baseline"]]))
    for scheme in ("native", "fixed_far"):
        def values(r):
            if scheme == "native":
                return int(r["delta"]), int(r["ref_delta"])
            return int(r["raw"]) - far_center, int(r["ref_raw"]) - far_reference
        points.setdefault(scheme, {})[mode] = np.array([values(r) for r in windows["hold"]], dtype=float)
        far_points.setdefault(scheme, {})[mode] = np.array([values(r) for r in windows["baseline"]], dtype=float)
    all_hold = [r for r in good if r["phase"] == "hold" and r["phase_valid"] == "1"]
    traces[mode] = {
        "csv_rows": len(rows), "whole_valid_hold_rows": len(all_hold),
        "whole_hold_ref_baseline_range": [min(int(r["ref_baseline"]) for r in all_hold), max(int(r["ref_baseline"]) for r in all_hold)],
        "fixed_hold_ref_baseline_range": [min(int(r["ref_baseline"]) for r in windows["hold"]), max(int(r["ref_baseline"]) for r in windows["hold"])],
        "whole_record_baseline_steps_at_least_500": [float(b["elapsed_s"]) for a, b in zip(good, good[1:]) if abs(int(b["ref_baseline"]) - int(a["ref_baseline"])) >= 500],
        "fixed_hold_reference_diff_zero_rows": sum(int(r["ref_diff"]) == 0 for r in windows["hold"]),
        "far_raw_medians": [far_center, far_reference],
    }
    checks[mode] = {"candidate_applied": True, "backup_and_reboot_four_blocks_equal": True, "raw": snapshot["raw_status"], "slider_all_zero": True, "csv_arithmetic_and_windows_verified": True, "version": snapshot["version"]}
    for suffix in (".json", ".csv"):
        files["samples/" + source.with_suffix(suffix).name] = source.with_suffix(suffix)
    for path in device.rglob("*"):
        if path.is_file():
            files["samples/" + path.relative_to(DATA).as_posix()] = path


def fit(dataset, modes):
    contacts = np.concatenate([dataset[m] for m in modes if "contact" in m])
    hovers = np.concatenate([dataset[m] for m in modes if "hover" in m])
    alpha = np.arange(10001, dtype=float) / 10000
    contact_min = np.min(contacts[:, 0, None] - contacts[:, 1, None] * alpha, axis=0)
    hover_max = np.max(hovers[:, 0, None] - hovers[:, 1, None] * alpha, axis=0)
    gap = contact_min - hover_max
    index = int(np.argmax(gap))
    return {"alpha": float(alpha[index]), "gap": float(gap[index]),
            "min_contact": float(contact_min[index]), "max_hover": float(hover_max[index]),
            "threshold": float((contact_min[index] + hover_max[index]) / 2),
            "search_alpha": [0, 1, .0001]}


fits = {}
for scheme, dataset in points.items():
    fitted = fit(dataset, MODES)
    summaries = {}
    held_out = {}
    for mode in MODES:
        p = dataset[mode]
        score = p[:, 0] - fitted["alpha"] * p[:, 1]
        noise = far_points[scheme][mode]
        noise_score = noise[:, 0] - fitted["alpha"] * noise[:, 1]
        summaries[mode] = {"hold_score_range": [float(score.min()), float(score.max())],
                           "hold_pairs": len(score), "far_pairs": len(noise_score),
                           "far_score_peak_to_peak": float(np.ptp(noise_score)),
                           "far_score_std_population": float(np.std(noise_score))}
        train = fit(dataset, [m for m in MODES if m != mode])
        test_score = p[:, 0] - train["alpha"] * p[:, 1]
        wrong = test_score < train["threshold"] if "contact" in mode else test_score >= train["threshold"]
        held_out[mode] = {"training_fit": train, "held_out_score_range": [float(test_score.min()), float(test_score.max())],
                          "wrong_sample_pairs": int(np.count_nonzero(wrong)), "total_sample_pairs": len(test_score)}
    fits[scheme] = {"all_four_in_sample_fit": fitted, "pose_scores": summaries,
                    "leave_one_pose_out_stress_check": held_out,
                    "status": "Exploratory only; each pose is one trial, correlated sequential pairs, no independent validation or usable mm model."}

half_angle = math.radians(12.5)
geometry = {"source": "User ruler estimate on 2026-10-02; upward front-edge VL53L0X",
            "optical_window_below_acrylic_mm": 4, "nearest_window_horizontal_offset_mm": [45, 50],
            "nominal_full_fov_deg": 25,
            "nominal_beam_radius_at_surface_and_hover_mm": {str(h): (4 + h) * math.tan(half_angle) for h in (0, 3, 5, 10)},
            "height_above_acrylic_for_point_to_reach_nominal_cone_mm": [b / math.tan(half_angle) - 4 for b in (45, 50)],
            "decision": "Nominal cone does not cover fixed central fingertip near the surface. Palm elsewhere in beam is not contact evidence for each lane; no global Air veto.",
            "limitations": "Geometric inference, not an optical field test. Target shape, reflectance, optics and crosstalk can affect returns; no return does not imply touch."}

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
for mode, label, color in zip(MODES, LABELS, COLORS):
    p = points["native"][mode]
    axes[0, 0].scatter(p[:, 0], p[:, 1], s=17, alpha=.7, color=color, label=label)
    if mode.startswith("finger"):
        axes[0, 1].scatter(p[:, 0], p[:, 1], s=22, alpha=.7, color=color, label=label)
    y = MODES.index(mode)
    s = fits["native"]["pose_scores"][mode]["hold_score_range"]
    axes[1, 0].plot(s, [y, y], color=color, lw=5, solid_capstyle="round")
    axes[1, 0].scatter(s, [y, y], color=color, s=24)
for ax in axes[0]:
    ax.set_xlabel("Center RAW - native BASE (count)")
    ax.set_ylabel("Reference RAW - native BASE (count)")
    ax.grid(alpha=.2)
axes[0, 0].set_title("Four confirmed trials | same configuration")
axes[0, 0].legend(fontsize=8)
axes[0, 1].set_title("Finger detail | reference intervals overlap")
axes[0, 1].legend(fontsize=8)
fitted = fits["native"]["all_four_in_sample_fit"]
axes[1, 0].axvline(fitted["threshold"], color="#555555", ls="--", label="Fitted threshold")
axes[1, 0].set_yticks(range(4), LABELS, fontsize=9)
axes[1, 0].invert_yaxis()
axes[1, 0].set_xlabel(f"Fitted score C - {fitted['alpha']:.4f} R (count)")
axes[1, 0].set_title(f"In-sample gap {fitted['gap']:.2f}; not a validated gate")
axes[1, 0].grid(axis="x", alpha=.2)
for mode, label, color in zip(MODES[:2], LABELS[:2], COLORS[:2]):
    source = DATA / (next(j["id"] for j in accepted if j["mode"] == mode) + ".csv")
    with source.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    axes[1, 1].plot([float(r["elapsed_s"]) for r in rows], [int(r["ref_baseline"]) if not r["error"] else np.nan for r in rows], color=color, label=label, lw=1.6)
axes[1, 1].axvspan(6, 11.5, color="#d9eada", alpha=.6)
axes[1, 1].axvline(4, color="#777777", ls=":")
axes[1, 1].axvline(12, color="#777777", ls=":")
axes[1, 1].set_xlim(0, 22)
axes[1, 1].set_xlabel("Elapsed seconds")
axes[1, 1].set_ylabel("Reference native BASE (count)")
axes[1, 1].set_title("Auto-reset OFF does not freeze baseline tracking")
axes[1, 1].legend(fontsize=8)
axes[1, 1].grid(alpha=.2)
fig.suptitle("Native 16-bit proximity reference: limits after four same-config poses", fontsize=14)
fig.tight_layout(rect=(0, .06, 1, .95))
fig.text(.5, .018, "Hold analysis 6-11.5 s; sequential C7; bad pairs omitted, not zero-filled. Manual heights from acrylic top.", ha="center", fontsize=9)
figure = DOCS / "MBR3116_round89s_联合信号与基线.png"
fig.savefig(figure, dpi=160)
plt.close(fig)
files[figure.name] = figure

analysis["semantics"] = "Sequential C7, not simultaneous; fixed windows; error pairs excluded without zero filling. Native documented temporary 0x42 NVM mode patch; all four config blocks restored and verified after reboot per trial."
evidence = {"date": "2026-10-02", "mode": experiment.capture.REFERENCE_MODE, "candidate_applied": True,
            "candidate_sha256": hashlib.sha256(experiment.make_patch(experiment.capture.ORIGINALS[0x42])).hexdigest(),
            "analysis": analysis, "trace_checks": traces, "restoration": checks,
            "exploratory_linear_fits": fits, "tof_geometry": geometry,
            "decision": "No deployment of RAW-reference classifier or global Air veto. Native scalar threshold route and current global mm calibration lack separation; debug-ID wait and only CS0/CS1 proximity constrain full-board timing and coverage. Goal unresolved; preserve user-accepted round89g.",
            "limitations": ["One manual trial per pose, no fixed spacer or independent repeat", "No proof that all nonlinear temporal classifiers are impossible", "In-sample fitting and leave-one-pose-out stress checks are not calibrated error probabilities", "Baseline tracking and cross-reset gain affect raw counts", "Four C7 stable windows are not initial-touch or gameplay latency measurements"]}
for name in ("round89s_package_evidence.py", "round89q_no_autoreset_capture.py", "round89n_prox16_capture.py", "round89m_alp_off_capture.py", "round89k_prox_capture.py", "round89j_prox_idle.py", "round89h_timed_capture.py", "round89h_timed_capture.html", "round89h_raw_capture.py", "round89g_latency_probe.py", "round89_live.py", "round89_live_debug.py", "round89i_analyze_pair.py", "round89h_analyze_timed.py"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
for name in ("controller_config.bin", "chip_40.bin", "chip_41.bin", "chip_42.bin"):
    files["original/" + name] = experiment.capture.probe.ARCHIVE / name
files["firmware/Nyanithm_round89g.uf2"] = ROOT / "Nyanithm_firmware_hw_v1/build_round89g/Nyanithm.uf2"
uf2_digest = hashlib.sha256(files["firmware/Nyanithm_round89g.uf2"].read_bytes()).hexdigest()
if uf2_digest != "aa4a65dbbf98ccb809142bb765d8ace786a489baa742edc8aa32dc25daefc941":
    raise RuntimeError("production firmware backup mismatch")
evidence["production_uf2_sha256"] = uf2_digest
payload = {name: path.read_bytes() for name, path in files.items()}
payload["analysis.json"] = (json.dumps(evidence, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
manifest = {name: hashlib.sha256(content).hexdigest() for name, content in payload.items()}
archive = DOCS / "MBR3116_round89s_同配置四组证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, content in payload.items():
        bundle.writestr(name, content)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != digest for name, digest in manifest.items()):
        raise RuntimeError("archive hash disagreement")
evidence["archive"] = {"name": archive.name, "files": len(manifest), "size": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
(DOCS / "MBR3116_round89s_联合信号与可行性分析.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "four trials restored; production UF2 verified")
for scheme, result in fits.items():
    print(scheme, json.dumps(result))
print("GEOMETRY", json.dumps(geometry))
