import csv
import hashlib
import json
import zipfile
from pathlib import Path

import round89i_analyze_pair as paired
import round89q_no_autoreset_capture as experiment

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "_dev_tools/round89n_prox16_20261002"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
paired.ROOT = DATA
analysis = paired.analyze()
analysis["semantics"] = "Sequential native C7; 16-bit ALP OFF temporary NVM experiment restored per job; paired errors excluded without zero filling; fixed hold 6-11.5 seconds"
accepted = [j for j in analysis["jobs"] if j["completed"] and j["user_confirmed"] is True]
if len(accepted) != 4 or {j["mode"] for j in accepted} != {"finger_contact", "finger_hover3", "palm_hover5", "palm_contact"}:
    raise RuntimeError("unexpected accepted poses")

files, checks, jumps, confirmations = {}, {}, {}, {}
for job in accepted:
    source = DATA / (job["id"] + ".json")
    native = json.loads(source.read_text(encoding="utf-8"))
    hardware = native["hardware"]
    if "16-bit ALP OFF" not in native["reference_mode"] or not all(hardware.get(k) for k in ("candidate_applied", "restore_verified", "restore_after_reboot")):
        raise RuntimeError("invalid mode or restoration")
    device = DATA / (job["id"] + "_device")
    after = device / "after_reboot"
    for a, table in experiment.capture.ORIGINALS.items():
        if (device / f"chip_{a:02x}.bin").read_bytes() != table or (after / f"chip_{a:02x}.bin").read_bytes() != table:
            raise RuntimeError("chip backup or restore mismatch")
    if (after / "controller_config.bin").read_bytes() != experiment.capture.CFG:
        raise RuntimeError("controller restore mismatch")
    snapshot = json.loads((after / "snapshot.json").read_text(encoding="utf-8"))
    if snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
        raise RuntimeError("nonzero final status")
    rows = list(csv.DictReader(source.with_suffix(".csv").open(encoding="utf-8", newline="")))
    good = [r for r in rows if not r["error"]]
    if any(int(r["ref_raw"]) - int(r["ref_baseline"]) != int(r["ref_delta"]) for r in good):
        raise RuntimeError("reference delta disagreement")
    fixed = [r for r in good if r["phase"] == "hold" and r["phase_valid"] == "1" and 6 <= float(r["elapsed_s"]) <= 11.5]
    if len(fixed) != job["windows"]["hold"]["valid"]:
        raise RuntimeError("fixed count disagreement")
    for field in ("delta", "ref_delta", "diff", "ref_diff"):
        for key, fn in (("min", min), ("max", max)):
            if fn(int(r[field]) for r in fixed) != job["windows"]["hold"][field][key]:
                raise RuntimeError("independent CSV extrema disagreement")
    changes = []
    for previous, current in zip(good, good[1:]):
        step = int(current["ref_baseline"]) - int(previous["ref_baseline"])
        if abs(step) >= 500:
            changes.append({"elapsed_s": float(current["elapsed_s"]), "phase": current["phase"],
                            "previous_baseline": int(previous["ref_baseline"]), "baseline": int(current["ref_baseline"]),
                            "raw": int(current["ref_raw"]), "delta": int(current["ref_delta"]),
                            "diff": int(current["ref_diff"]), "sync": int(current["ref_sync"]), "step": step})
    threshold_rows = [r for r in good if r["phase"] == "hold" and int(r["ref_diff"]) >= 512]
    jumps[job["mode"]] = {"changes_at_least_500": changes,
                           "first_observed_diff_at_least_512_s": float(threshold_rows[0]["elapsed_s"]) if threshold_rows else None,
                           "timing_is_not_hardware_onset": True}
    confirmations[job["id"]] = native.get("confirmation_source", {"kind": "page_label"})
    checks[job["id"]] = {"backup_and_restoration_equal": True, "raw": snapshot["raw_status"], "slider_all_zero": True,
                          "fixed_csv_checked": True, "version": snapshot["version"]}
    for suffix in (".json", ".csv"):
        files["samples/" + source.with_suffix(suffix).name] = source.with_suffix(suffix)
    for path in device.rglob("*"):
        if path.is_file():
            files["samples/" + path.relative_to(DATA).as_posix()] = path

original = experiment.capture.ORIGINALS[0x42]
desired = experiment.make_patch(original)
full = experiment.full.make_patch(original)
spec = {
    "date": "2026-10-02", "address": "0x42", "sensor": "CS0", "firmware_bid": "round89g",
    "purpose": "Isolate five-second proximity auto-reset from sustained-palm baseline collapse; no production gate",
    "source_trm": "https://www.infineon.com/assets/row/public/documents/30/57/infineon-cy8cmbr3xxx-capsense-express-controllers-registers-trm-additionaltechnicalinformation-en.pdf",
    "source_section": "1.5.60 DEVICE_CFG2, page 91; bits7:6 PROXIMITY_ARST 1=five seconds, 0=disabled",
    "source_guide": "https://assets.infineon.com/is/content/infineon/infineon/row/public/documents/30/42/infineon-an90071-cy8cmbr3xxx-capsenser-design-guide-applicationnotes-en.pdf",
    "guide_sections": "5.1.1.8 page55; glossary Sensor Auto Reset page115",
    "only_change_from_previous_candidate": {"address": "0x4F", "before": "0x68", "after": "0x28", "mask": "0xC0"},
    "unchanged": ["16-bit output", "ALP OFF", "button auto-reset 20s", "ATH ON", "button FT200", "proximity touch512/base200", "0x40/0x41 and controller config"],
    "changes_from_device_original_excluding_crc": [f"0x{i:02X}" for i in range(126) if desired[i] != original[i]],
    "changes_from_previous_candidate_excluding_crc": [f"0x{i:02X}" for i in range(126) if desired[i] != full[i]],
    "original_sha256": hashlib.sha256(original).hexdigest(), "candidate_sha256": hashlib.sha256(desired).hexdigest(),
    "candidate_crc_bytes": desired[-2:].hex(" "), "candidate_crc_u16": f"0x{int.from_bytes(desired[-2:], 'little'):04X}",
    "recovery": "Read all four original blocks, save per-job backups, apply and verify candidate, capture, unconditionally restore attempted writes, reboot and compare all four blocks before confirmation; failed restoration blocks new jobs",
    "not_yet_applied": True, "height_reference": "acrylic top; manually estimated with ruler",
    "runtime_limit": "Sequential C7 is diagnostic only; not inserted into game scanning; CS0/CS1 limitation remains",
}
spec_path = DOCS / "MBR3116_round89q_自动复位对照规格.json"
spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
files["specification.json"] = spec_path
for name in ("round89p_package_evidence.py", "round89q_no_autoreset_capture.py", "test_round89q_no_autoreset.py",
             "round89n_prox16_capture.py", "round89m_alp_off_capture.py", "round89k_prox_capture.py", "round89j_prox_idle.py",
             "round89h_timed_capture.py", "round89h_timed_capture.html", "round89h_raw_capture.py", "round89g_latency_probe.py",
             "round89_live.py", "round89_live_debug.py", "round89i_analyze_pair.py", "round89h_analyze_timed.py",
             "test_round89k_prox_capture.py", "test_round89m_alp_off.py", "test_round89h_timed_ui.js"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89p_手掌与基线证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != digest for name, digest in manifest.items()):
        raise RuntimeError("archive mismatch")
evidence = {"date": "2026-10-02", "analysis": analysis, "checks": checks, "confirmation_sources": confirmations,
            "baseline_jump_trace": jumps, "device_cfg2": {"byte": "0x68", "prox_autoreset_s": 5, "button_autoreset_s": 20, "ATH": True},
            "interpretation": "Palm hover exceeds finger contact in reference amplitude; increasing reference thresholds and reference/center ratio alone do not solve all poses. Palm baseline jumps are consistent with native auto-reset, awaiting single-variable control; no claim that all two-channel classifiers are impossible.",
            "limitations": ["Four manually placed poses at one location, no repeated-trial validation", "Fixed windows straddle reference baseline jumps; early stable segments must not be presented as full-duration acceptance", "Unknown hardware ON onset; sampled DIFF threshold crossing is approximate only", "C7 sequential pairs do not prove simultaneous independent scans or game throughput", "No mm calibration or full-board gating result"],
            "archive": {"name": archive.name, "files": len(manifest), "size": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DOCS / "MBR3116_round89p_四组采样与基线分析.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "four jobs restored")
for job in accepted:
    hold = job["windows"]["hold"]
    print(job["mode"], "pairs", hold["valid"], "center", hold["delta"]["min"], hold["delta"]["max"],
          "reference", hold["ref_delta"]["min"], hold["ref_delta"]["max"], "jumps", jumps[job["mode"]])
print("CANDIDATE", spec["candidate_sha256"], spec["candidate_crc_u16"])
