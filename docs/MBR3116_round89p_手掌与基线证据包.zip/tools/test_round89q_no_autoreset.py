import unittest
from unittest.mock import patch

import round89q_no_autoreset_capture as experiment
import test_round89k_prox_capture as capture_tests
from test_round89m_alp_off import bitwise_crc

capture = experiment.capture


class AutoResetTests(unittest.TestCase):
    def test_only_proximity_autoreset_changes_from_full_resolution(self):
        original = capture.ORIGINALS[0x42]
        full = experiment.full.make_patch(original)
        desired = experiment.make_patch(original)
        self.assertEqual([i for i in range(126) if full[i] != desired[i]], [0x4F])
        self.assertEqual(original[0x4F], 0x68)
        self.assertEqual(desired[0x4F], 0x28)
        self.assertEqual(desired[0x4F] & 0x3F, original[0x4F] & 0x3F)
        self.assertEqual([i for i in range(126) if desired[i] != original[i]], [0x26, 0x27, 0x4F])
        self.assertEqual(bitwise_crc(desired), int.from_bytes(desired[-2:], "little"))

    def test_unknown_autoreset_mode_rejected(self):
        for mode in (0, 2, 3):
            original = bytearray(capture.ORIGINALS[0x42])
            original[0x4F] = (original[0x4F] & 0x3F) | (mode << 6)
            original[-2:] = bitwise_crc(original).to_bytes(2, "little")
            with self.subTest(mode=mode), self.assertRaisesRegex(RuntimeError, "five-second"):
                experiment.make_patch(original)

    def test_button_threshold_and_auxiliary_settings_preserved(self):
        original = bytearray(capture.ORIGINALS[0x42])
        original[0x4F] = 0x55
        original[-2:] = bitwise_crc(original).to_bytes(2, "little")
        desired = experiment.make_patch(original)
        self.assertEqual(desired[0x4F], 0x15)
        self.assertEqual(desired[0x08:0x1F], original[0x08:0x1F])
        self.assertEqual(desired[0x2F:0x34], original[0x2F:0x34])

    def test_success_and_faults_reuse_verified_restore_transaction(self):
        desired = experiment.make_patch(capture.ORIGINALS[0x42])
        for failure in (None, "capture", "restore", "reboot", "precheck", "exit", "invalid_data"):
            with self.subTest(failure=failure), patch.object(capture, "DESIRED", desired):
                capture_tests.CaptureTests().exercise(failure)

    def test_service_identity(self):
        with patch.object(capture, "DESIRED"), patch.object(capture, "REFERENCE_MODE"), \
             patch.object(capture, "PAGE_TITLE"), patch.object(capture, "DEFAULT_MODE"), \
             patch.object(capture.ui, "OUT"), patch.object(capture.ui, "ORIGIN"):
            experiment.configure()
            self.assertEqual(capture.ui.OUT, experiment.OUT)
            self.assertEqual(capture.ui.ORIGIN, "http://127.0.0.1:8772")
            self.assertIn("16-bit ALP OFF ARST OFF", capture.REFERENCE_MODE)
            self.assertEqual(capture.DEFAULT_MODE, "palm_hover5")


if __name__ == "__main__":
    unittest.main()
