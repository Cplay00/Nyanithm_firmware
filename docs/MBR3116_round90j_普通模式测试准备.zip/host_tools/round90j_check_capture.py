"""Offline framing checks and integrity-only audit; no hypothesis fitting."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import struct

import round90j_normal_page as page


def offline_checks():
    passed = 0
    for lane in range(32):
        words = [0, 0, 0]
        for (address, e), mapped in page.previous.LANES.items():
            if mapped == lane:
                words[address-0x5A] = 1 << e
        data = b'\xaa\x55' + struct.pack('<6H', *(words+words)) + bytes(128 if i == lane else 0 for i in range(32))
        row = page.parse_chain(data)
        assert all(json.loads(row[k]) == [lane] for k in ('native_lanes_json', 'verified_lanes_json', 'final_lanes_json'))
        passed += 1
    blank = b'\xaa\x55' + bytes(44)
    bad = [blank[:-1], blank+b'\x00', b'\x00'+blank[1:],
           blank[:3]+b'\x10'+blank[4:], blank[:14]+b'\x01'+blank[15:]]
    for data in bad:
        try:
            page.parse_chain(data)
        except RuntimeError:
            passed += 1
        else:
            raise AssertionError('invalid frame accepted')
    return {'passed': passed, 'cases': '32 source-lane mappings plus 5 malformed C0 frames'}


def audit(folder):
    jobs = []
    for metadata in sorted(folder.glob('*.json')):
        job = json.loads(metadata.read_text(encoding='utf-8'))
        if 'mode' not in job:
            continue
        rows = list(csv.DictReader(metadata.with_suffix('.csv').open(encoding='utf-8', newline='')))
        if not job.get('completed') or job.get('error'):
            raise RuntimeError('incomplete job: '+metadata.name)
        for row in rows:
            parsed = page.parse_chain(bytes.fromhex(row['chain_hex']))
            assert not row['error']
            for key, value in parsed.items():
                assert row[key] == value, (metadata.name, key)
            game = bytes.fromhex(row['game_hex'])
            assert len(game) == 33 and all(v in (0, 128) for v in game[:32])
            assert json.loads(row['game_lanes_json']) == [i for i, v in enumerate(game[:32]) if v]
            assert float(row['chain_start_s']) <= float(row['chain_end_s']) <= float(row['game_start_s']) <= float(row['game_end_s'])
        jobs.append({'id': job['id'], 'mode': job['mode'], 'user_confirmed': job['user_confirmed'],
                     'rows': len(rows), 'valid_phase_rows': sum(int(r['phase_valid']) for r in rows),
                     'errors': 0, 'mock': job['mock']})
    return {'scope': 'integrity only; outcome/threshold/baseline analysis deferred', 'jobs': jobs,
            'total_rows': sum(j['rows'] for j in jobs),
            'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir()) if p.is_file()}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = {'offline': offline_checks()}
    if args.folder:
        result['capture'] = audit(args.folder)
    if args.out:
        if args.out.exists():
            raise RuntimeError('audit output already exists')
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))
