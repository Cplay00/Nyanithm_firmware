"""Verify the frozen beta12-rejection / beta11-recovery ZIP offline only."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        manifest = json.loads(z.read('manifest.json'))
        if len(names) != len(set(names)) or z.testzip() is not None:
            raise ValueError('ZIP member duplication or CRC error')
        if set(names) != set(manifest['files']) | {'manifest.json'}:
            raise ValueError('ZIP members do not match manifest')
        for name, digest in manifest['files'].items():
            if sha(z.read(name)) != digest:
                raise ValueError(f'member hash failed: {name}')
        report = json.loads(z.read('restore.json'))
        if not report['completed'] or report['beta13_deployed'] or report['hid_gameplay_regression_proven']:
            raise ValueError('incorrect recovery or observation-scope metadata')
        before = z.read('before/controller_config.bin')
        after = z.read('after/controller_config.bin')
        checksum = 0
        for b in before:
            checksum ^= b
        if before != after or len(before) != 128 or checksum or before[:2] != b'\x88\x02':
            raise ValueError('controller config validation/equality failed')
        if sha(before) != 'd2b2cbe5ecb3f6dc625ed1c17e0e1672ebf688a2e5d5be7db2d08209c1f05596':
            raise ValueError('config differs from accepted baseline')
        gain_changes = {}
        comparisons = 0
        for address in ('5a', '5b', '5c'):
            a, b = (z.read(f'{stage}/mpr_{address}.bin') for stage in ('before', 'after'))
            if len(a) != 128 or len(b) != 128 or any(a[:4]) or any(b[:4]):
                raise ValueError('incomplete or non-idle snapshot')
            for reg in list(range(0x2B, 0x5F)) + list(range(0x73, 0x80)):
                if a[reg] != b[reg]:
                    raise ValueError(f'static control drift: {address}/{reg:#x}')
                comparisons += 1
            changes = [{'register': f'0x{i:02X}', 'before': a[i], 'after': b[i]}
                       for i in range(0x5F, 0x73) if a[i] != b[i]]
            if changes != report['static_and_gain_comparison'][f'0x{address}']['startup_retunable_cdc_cdt_changes']:
                raise ValueError('gain-change report does not match bytes')
            gain_changes[address] = changes
        for filename, digest, signature, size in (
                ('firmware/beta11_recovery.uf2',
                 '4412c8af403cba32125cc7135628b6c193d278cbfeeac944022ccfcad35f34d1',
                 b'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g', 200704),
                ('firmware/beta12_rejected.uf2',
                 'd9e760c66dd45645a32df2133d7dffbcd8b067b0f2f9e2ac365c57ed3b369e9c',
                 b'NYANFW1;1.6.6-beta12;hw_v1;BID=round90m', 199680)):
            data = z.read(filename)
            if len(data) != size or sha(data) != digest:
                raise ValueError('UF2 size/hash mismatch')
            addresses, payloads = set(), []
            for offset in range(0, size, 512):
                m0, m1, flags, addr, length, block, count, family = struct.unpack_from('<8I', data, offset)
                if ((m0, m1, flags, family) != (0x0A324655, 0x9E5D5157, 0x2000, 0xE48BFF56)
                        or length != 256 or block != offset // 512 or count != size // 512
                        or addr in addresses or addr < 0x10000000 or addr + length > 0x101FF000
                        or struct.unpack_from('<I', data, offset + 508)[0] != 0x0AB16F30):
                    raise ValueError('UF2 header/address validation failed')
                addresses.add(addr)
                payloads.append(data[offset + 32:offset + 288])
            if signature not in b''.join(payloads):
                raise ValueError('UF2 firmware identity failed')
        normal = report['final_normal']
        if ('NYANFW1;1.6.6-beta11;hw_v1;BID=round90g' not in normal['version']
                or normal['raw_status'] != 'RAW=0' or not normal['serial_closed']
                or len(normal['idle_frames']) != 30
                or any(len(f) != 33 or any(f[:32]) for f in normal['idle_frames'])):
            raise ValueError('final identity/mode/idle/port closure failed')
        return {'zip_members': len(names), 'member_hashes_verified': len(manifest['files']),
                'controller_config_equal_bytes': 128, 'static_register_comparisons': comparisons,
                'native_idle_images': 6, 'normal_idle_zero_frames': 30, 'gain_changes': gain_changes,
                'restored_signature': 'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g',
                'beta12_user_rejected': True, 'beta13_deployed': False,
                'reported_observation_surface': report['reported_observation_surface'],
                'hid_gameplay_regression_proven': False, 'gameplay_retest': report['gameplay_retest']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = json.dumps(verify(args.package), ensure_ascii=False, indent=2) + '\n'
    if args.out:
        args.out.write_text(result, encoding='utf-8')
    print(result, end='')


if __name__ == '__main__':
    main()
