const {chromium}=require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path');
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{
const page=await browser.newPage({viewport:{width:1280,height:960}}),issues=[];
page.on('console',m=>{if(['warning','error'].includes(m.type()))issues.push(m.text())});page.on('pageerror',e=>issues.push(e.message));
await page.goto('http://127.0.0.1:8886/');await page.getByRole('heading',{name:'32寸 MPR 固定位置映射'}).waitFor();
await page.waitForFunction(closed=>closed?document.getElementById('cue').classList.contains('closed'):document.getElementById('message').textContent.includes('先关闭游戏'),process.argv.includes('--closed'));
const state=await page.request.get('http://127.0.0.1:8886/status').then(r=>r.json()),closed=process.argv.includes('--closed');
if(state.mock||state.running)throw Error('real page not idle');
if(closed){if(state.phase!=='closed'||state.jobs.length!==4||state.jobs.some(j=>j.user_confirmed!==true)||state.usb_side!=='left')throw Error('real mapping not completed/closed')}
else if(state.jobs.length||state.usb_side)throw Error('real page not untouched');
if(!(await page.locator('#start').isDisabled()))throw Error('setup gate missing');
await page.screenshot({path:path.join(__dirname,'round90l_mapping_20261004',closed?'real_closed.png':'real_ready.png')});
if(issues.length)throw Error(JSON.stringify(issues));
fs.writeFileSync(path.join(__dirname,'round90l_mapping_20261004',closed?'real_closed_page_audit.json':'real_page_audit.json'),JSON.stringify({url:page.url(),title:await page.title(),mock:false,idle:true,jobs:state.jobs.length,phase:state.phase,usb_side:state.usb_side,viewport:'1280x960',console_issues:issues,start_not_clicked:true},null,2)+'\n');
console.log('PASS real page identity, idle/setup gate, console;',closed?'closed four confirmed points':'untouched ready','; no Start or device session');
}finally{await browser.close()}})().catch(e=>{console.error(e.stack);process.exit(1)});
