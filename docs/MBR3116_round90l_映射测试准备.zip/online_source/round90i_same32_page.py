"""Reuse the timed research page with read-only, coherent MPR C6 samples."""
import argparse
import hashlib
import json
from pathlib import Path
import queue
import threading
import time

import round89h_timed_capture as ui
import round89_live as live
from round90i_same32_setup import MPR_CONFIG, DIAG, OUT, connect_checked
import re

MOCK = False
PAGE_OUT = OUT / 'page_v2'
FIELDS = ['elapsed_s', 'phase', 'phase_valid', 'address', 'electrode', 'filtered',
          'baseline', 'delta', 'delta_upper', 'threshold', 'native_on', 'native_status',
          'oor_status', 'cycle_start_s', 'cycle_end_s', 'registers_5a', 'registers_5b',
          'registers_5c', 'chip_times_json', 'channels_json', 'native_lanes_json', 'faults_json', 'error']
MODES = {
    'finger_contact': '食指轻触从左数第9竖条上半区的中央，避开上下分界',
    'lower_contact': '食指轻触第9竖条下半区的中央，避开上下分界',
    'slow_contact': '食指用约4秒缓慢靠近第9竖条上半区中央直到轻触，再保持贴面',
    'finger_hover5': '食指在第9竖条上半区中央上方约5毫米悬空，不接触',
    'palm_hover5': '手掌在第9竖条上半区附近上方约5毫米悬空，不接触',
    'four_contact': '四指轻贴第8、9竖条的上下四个区域，保持贴面',
}


def lane_mapping():
    source = (OUT.parents[1] / 'Nyanithm_firmware_hw_v1/src/hw_devices.cpp').read_text(encoding='utf-8')
    tables = []
    for name in ('V1_LANE_M', 'V1_LANE_E'):
        match = re.search(r'static const uint8_t ' + name + r'\[32\] = \{([^}]+)\}', source)
        if not match:
            raise RuntimeError('authoritative HW1/2 mapping table absent')
        table = [int(v) for v in re.findall(r'\d+', match.group(1))]
        if len(table) != 32:
            raise RuntimeError('invalid authoritative mapping length')
        tables.append(table)
    mapping = {(0x5A + m, e): lane for lane, (m, e) in enumerate(zip(*tables))}
    if len(mapping) != 32:
        raise RuntimeError('mapping has duplicate electrodes')
    return mapping


LANES = lane_mapping()


def compact(value):
    return json.dumps(value, separators=(',', ':'))


def read_mpr(port):
    start = time.perf_counter()
    images, times, channels, faults, native_lanes = {}, [], [], [], []
    for address in (0x5A, 0x5B, 0x5C):
        began = time.perf_counter()
        if MOCK:
            time.sleep(.02)
            registers = bytearray(128)
            # Source-lane 16 / 17 synthetic responses test upper/lower plumbing;
            # these are not assertions about the physical panel wiring.
            electrode = 0 if address == 0x5C and ui.STATE.get('mock_mode') == 'lower_contact' else 7
            active = ui.STATE['phase'] == 'hold' and (
                address == 0x5C and ui.STATE.get('mock_mode') == 'lower_contact' or
                address == 0x5A and ui.STATE.get('mock_mode') != 'lower_contact')
            for e in range(12):
                delta = 25 if active and e == electrode else 0
                registers[4 + 2*e:6 + 2*e] = (720-delta).to_bytes(2, 'little')
                registers[0x1E+e] = 180
                registers[0x41+2*e] = 13
                registers[0x42+2*e] = 12
            registers[0:2] = ((1 << electrode) if active else 0).to_bytes(2, 'little')
            registers[0x5B:0x5F] = bytes([0x11, 0x10, 0x28, 0xCC])
            data = bytes(registers)
        else:
            live.split(port, 0xC6, [address])
            data = live.exact(port, 128, 2)
        ended = time.perf_counter()
        if len(data) != 128 or any(data[5+2*e] & ~3 for e in range(12)):
            raise RuntimeError('invalid complete 10-bit MPR signal response')
        status = int.from_bytes(data[:2], 'little')
        oor = int.from_bytes(data[2:4], 'little')
        if oor or status & 0x8000:
            faults.append({'address': address, 'oor': oor, 'overcurrent': bool(status & 0x8000)})
        images[address] = data
        times.append({'address': address, 'start_s': began, 'end_s': ended, 'bytes': len(data)})
        for e in range(12):
            filtered = int.from_bytes(data[4+2*e:6+2*e], 'little')
            baseline = data[0x1E+e] << 2
            lane = LANES.get((address, e))
            on = bool(status & (1 << e))
            channel = {'address': address, 'electrode': e, 'logical_lane': lane,
                       'filtered': filtered, 'baseline_floor': baseline,
                       'delta_floor': baseline-filtered, 'delta_ceiling': baseline+3-filtered,
                       'touch_threshold': data[0x41+2*e], 'release_threshold': data[0x42+2*e],
                       'native_on': on, 'oor': bool(oor & (1 << e))}
            channels.append(channel)
            if on and lane is not None:
                native_lanes.append(lane)
    primary = max((c for c in channels if c['logical_lane'] is not None), key=lambda c: c['delta_floor'])
    return {'address': primary['address'], 'electrode': primary['electrode'], 'filtered': primary['filtered'],
            'baseline': primary['baseline_floor'], 'delta': primary['delta_floor'],
            'delta_upper': primary['delta_ceiling'], 'threshold': primary['touch_threshold'],
            'native_on': int(primary['native_on']),
            'native_status': compact({hex(a): int.from_bytes(d[:2], 'little') for a, d in images.items()}),
            'oor_status': compact({hex(a): d[2:4].hex() for a, d in images.items()}),
            'cycle_start_s': start, 'cycle_end_s': time.perf_counter(),
            **{f'registers_{a:02x}': d.hex() for a, d in images.items()},
            'chip_times_json': compact(times), 'channels_json': compact(channels),
            'native_lanes_json': compact(sorted(native_lanes)), 'faults_json': compact(faults),
            'error': 'native-fault-marked' if faults else ''}


def close_session(port, mock, diagnostic_entered):
    report = {'hands_away_confirmed_by_finish_button': True, 'exit_reboot_sent': False,
              'device_mode_verified': False, 'diagnostic_entered': diagnostic_entered,
              'mock': mock, 'closed_utc_epoch': time.time()}
    if port is not None:
        try:
            port.write(b'\xb9')
            port.flush()
            report['exit_reboot_sent'] = True
        except Exception as error:
            report['exit_error'] = repr(error)
        finally:
            try:
                port.close()
            except Exception as error:
                report['close_error'] = repr(error)
    report['device_exit_unconfirmed'] = not mock and diagnostic_entered and not report['exit_reboot_sent']
    return report


def worker():
    port = None
    diagnostic_entered = False
    firmware = 'synthetic mock, no hardware'
    heartbeat = 0
    expected = MPR_CONFIG.read_bytes()
    while True:
        try:
            task = ui.TASKS.get(timeout=0.2)
        except queue.Empty:
            if port is not None and time.perf_counter() - heartbeat > 10:
                try:
                    port.write(b'\xc3')
                    port.flush()
                    heartbeat = time.perf_counter()
                except Exception as error:
                    port.close()
                    port = None
                    ui.update(blocked=True, phase='error', message='请移开双手并结束诊断：' + str(error))
            continue
        try:
            if task == 'finish':
                # Finish explicitly confirms hands away. Record actual B9
                # submission, not an unverified claim of successful reboot.
                report = close_session(port, MOCK, diagnostic_entered)
                port = None
                (PAGE_OUT / 'session_closed.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
                message = ('模拟采样已结束，无设备操作' if MOCK else
                           '采样已结束，已发送设备退出与重启命令' if report['exit_reboot_sent'] else
                           '本页已结束，设备退出状态未确认' if report['device_exit_unconfirmed'] else
                           '本页已结束，尚未进入设备诊断模式')
                ui.update(running=False, blocked=True, phase='closed', message=message, end_ms=0)
                continue
            if port is None and not MOCK:
                ui.update(phase='preparing', message='设备准备中，请保持双手远离', end_ms=0)
                port, info, firmware = connect_checked(DIAG)
                port.write(b'\xb3')
                diagnostic_entered = True
                live.tail(port, 0.3)
                cfg, _ = live.config_read(port)
                if cfg != expected:
                    raise RuntimeError('controller configuration changed')
                task['usb_serial'] = info.serial_number
            ui.update(mock_mode=task['mode'])
            task.update(mock=MOCK, origin='synthetic-test' if MOCK else 'hardware-readback',
                        board='original 32-inch PCB/controller, transplanted three MPR121 modules', controller_config=expected.hex(),
                        native_signal_group='43 bytes 0x00..0x2A single repeated-START read per chip',
                        three_chips='sequential 0x5A/0x5B/0x5C, not same-instant samples',
                        physical_mapping='user labels required; source logical lanes are not physical contact truth',
                        hid_game_mode=False,
                        control_group='separate 85 bytes 0x2B..0x7F',
                        action_scope='whole user-confirmed action, phase cues are not physical contact timestamps',
                        host_configuration_write_commands=False,
                        original_firmware_idle_baseline_processing_preserved=True)
            ui.capture_job(port, task, firmware, reader=read_mpr, fields=FIELDS, publish=False)
            if port is not None:
                check, _ = live.config_read(port)
                task['controller_equal_after'] = check == expected
                if check != expected:
                    raise RuntimeError('controller configuration changed during capture')
            else:
                task['controller_equal_after'] = True
            ui.save_job(task)
            with ui.LOCK:
                ui.STATE['jobs'].append(task)
            ui.update(running=False, phase='done', message='采完了，请保持双手远离，并确认本组动作', end_ms=0)
            heartbeat = time.perf_counter()
        except Exception as error:
            if isinstance(task, dict):
                task.update(error=repr(error), completed=False)
                ui.save_job(task)
            # Keep the failed session alive until the user explicitly confirms
            # hands away with Finish. Do not reboot into calibration mid-pose.
            ui.update(running=False, blocked=True, phase='error',
                      message='采样失败；请移开双手，再点击结束诊断：' + str(error), end_ms=0)
            print('ERROR', repr(error), flush=True)


class Handler(ui.Handler):
    def do_GET(self):
        if self.path == '/':
            return self.send(200, Path(__file__).with_suffix('.html').read_bytes(), 'text/html; charset=utf-8')
        super().do_GET()

    def do_POST(self):
        if self.headers.get('Origin') != ui.ORIGIN:
            return self.send(403, {'error': 'origin rejected'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 2048:
                raise ValueError('invalid request size')
            payload = json.loads(self.rfile.read(size))
            if self.path == '/start':
                mode = payload.get('mode')
                if mode not in ui.MODES:
                    raise ValueError('invalid mode')
                with ui.LOCK:
                    pending = ui.STATE['jobs'] and ui.STATE['jobs'][-1]['user_confirmed'] is None
                    if ui.STATE['running'] or ui.STATE['blocked'] or pending:
                        return self.send(409, {'error': '请先完成或确认当前采样'})
                    ui.STATE.update(running=True, phase='queued', message='请保持双手远离')
                    identifier = f'{time.time_ns()}_{mode}'
                ui.TASKS.put({'id': identifier, 'mode': mode})
                return self.send(200, {'id': identifier})
            if self.path == '/label':
                with ui.LOCK:
                    job = next((j for j in ui.STATE['jobs'] if j['id'] == payload.get('id')), None)
                    if (job is None or not isinstance(payload.get('valid'), bool)
                            or payload.get('hands_away') is not True or ui.STATE['running']):
                        raise ValueError('invalid action/hands-clear label')
                    job.update(user_confirmed=payload['valid'], hands_away_confirmed=True)
                    ui.save_job(job)
                return self.send(200, {'saved': True})
            if self.path == '/finish':
                if payload.get('hands_away') is not True:
                    raise ValueError('hands-clear confirmation required')
                with ui.LOCK:
                    pending = ui.STATE['jobs'] and ui.STATE['jobs'][-1]['user_confirmed'] is None
                    if ui.STATE['blocked'] and ui.STATE['phase'] == 'closed':
                        return self.send(409, {'error': '诊断已关闭'})
                    if ui.STATE['running'] or pending:
                        return self.send(409, {'error': '请先等待采样结束并确认或作废本组'})
                    ui.STATE['running'] = True
                ui.TASKS.put('finish')
                return self.send(200, {'closing': True})
            self.send(404, {'error': 'not found'})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.send(400, {'error': str(error)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8882)
    parser.add_argument('--mock', action='store_true')
    args = parser.parse_args()
    MOCK = args.mock
    PAGE_OUT = OUT / ('page_mock_v2' if MOCK else 'page_v2')
    PAGE_OUT.mkdir(exist_ok=True)
    ui.OUT = PAGE_OUT
    ui.ORIGIN = f'http://127.0.0.1:{args.port}'
    ui.MODES.clear()
    ui.MODES.update(MODES)
    ui.STATE.update(jobs=[])
    ui.STATE.update(blocked=False, mock=MOCK, message='请将双手移离至少30厘米，再开始')
    threading.Thread(target=worker, daemon=True).start()
    print('READY', ui.ORIGIN, 'MOCK' if MOCK else 'same 32-inch three-MPR diagnostic', flush=True)
    ui.ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
