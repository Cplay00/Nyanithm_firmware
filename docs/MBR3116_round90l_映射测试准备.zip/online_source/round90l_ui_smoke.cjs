// Browser plugin is absent; CLI package is absent. Use bundled Playwright without installation.
const {chromium}=require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs');
const path=require('path');
const out=path.join(__dirname,'round90l_mapping_20261004');
async function main(){
  const browser=await chromium.launch({channel:'msedge',headless:true});
  const page=await browser.newPage({viewport:{width:1280,height:960}});
  const issues=[];page.on('console',m=>{if(['error','warning'].includes(m.type()))issues.push(m.text())});page.on('pageerror',e=>issues.push(e.message));
  const checks=[];function check(test,ok){if(!ok)throw Error(test);checks.push(test)}
  await page.goto('http://127.0.0.1:8885/');
  await page.getByRole('heading',{name:'32寸 MPR 固定位置映射'}).waitFor();
  check('page identity',await page.title()==='32寸 MPR 固定位置映射');
  check('meaningful body',await page.locator('body').innerText().then(t=>t.includes('从USB接口端')&&t.includes('无响应也照实确认')));
  check('mock banner',await page.locator('#message').innerText().then(t=>t.includes('模拟')));
  check('setup gates capture',await page.locator('#start').isDisabled());
  await page.locator('#usb-side').selectOption('right');await page.locator('#count-clear').check();
  await page.locator('#start').waitFor({state:'visible'});
  await page.waitForFunction(()=>!document.getElementById('start').disabled);
  check('right side mirrors two strips',await page.locator('[data-mode="usb8_upper"]').evaluate(e=>e.style.gridColumn)==='2');
  await page.screenshot({path:path.join(out,'mock_desktop_ready.png')});
  await page.setViewportSize({width:390,height:844});
  check('mobile no horizontal clipping',await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.screenshot({path:path.join(out,'mock_mobile_ready.png'),fullPage:true});
  await page.setViewportSize({width:1280,height:960});
  for(const [index,mode] of ['usb8_upper','usb8_lower','usb9_upper','usb9_lower'].entries()){
    check('correct selected mode '+mode,await page.locator('#mode').inputValue()===mode);
    await page.locator('#start').click();
    await page.waitForFunction(()=>document.getElementById('cue').classList.contains('hold'),{},{timeout:15000});
    check('direction locked '+mode,await page.locator('#usb-side').isDisabled());
    await page.waitForFunction(()=>document.getElementById('response').textContent.includes('格'),{},{timeout:3000});
    if(index===0)await page.screenshot({path:path.join(out,'mock_hold.png')});
    await page.waitForFunction(()=>!document.getElementById('valid').disabled,{},{timeout:25000});
    // Exercise a discarded retry once; it must stay on the same physical point.
    if(index===0){
      await page.locator('#note').fill('synthetic discard to exercise retry, no hardware');
      await page.locator('#invalid').click();
      await page.waitForFunction(()=>!document.getElementById('start').disabled);
      check('discard keeps same physical point',await page.locator('#mode').inputValue()===mode);
      await page.locator('#start').click();
      await page.waitForFunction(()=>!document.getElementById('valid').disabled,{},{timeout:30000});
    }
    await page.locator('#valid').click();
    await page.waitForFunction(expected=>document.getElementById('log').textContent.split('已确认').length-1===expected,index+1);
    if(index===0){await page.reload();await page.waitForFunction(()=>document.getElementById('usb-side').value==='right'&&document.getElementById('mode').value==='usb8_lower');check('reload restores fixed direction and next position',await page.locator('#count-clear').isChecked())}
    console.log('PASS confirmed',mode);
  }
  await page.waitForFunction(()=>document.getElementById('start').disabled&&!document.getElementById('finish').disabled);
  await page.locator('#finish').click();
  await page.waitForFunction(()=>document.getElementById('cue').classList.contains('closed'));
  check('no relevant console/page errors',issues.length===0);
  await page.screenshot({path:path.join(out,'mock_closed.png')});
  const state=await page.request.get('http://127.0.0.1:8885/status').then(r=>r.json());
  check('4 confirmed and 1 discarded',state.jobs.filter(j=>j.user_confirmed===true).length===4&&state.jobs.filter(j=>j.user_confirmed===false).length===1);
  fs.writeFileSync(path.join(out,'ui_audit.json'),JSON.stringify({browser_path:'Browser plugin absent; CLI package absent; Chrome and cached Chromium unavailable; bundled regular Playwright with installed Edge headless, no installation',url:page.url(),viewports:['1280x960','390x844'],checks,issues,closed:true},null,2)+'\n');
  await browser.close();console.log('PASS UI checks',checks.length);
}
main().catch(e=>{console.error(e.stack);process.exit(1)});
