"""Guarded setup for the original 32-inch controller with transplanted MPRs.

Only --configure writes controller configuration. --idle uses config C6.
The preserved MBR tables are never sent to the now-MPR hardware.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
import time

import serial.tools.list_ports
import round89_live as live
from round89c_flash_probe import rp2040_drives

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90i_same32_20261004'
BACKUP = ROOT / '_dev_archive/round90i_same32_before_20261004'
SERIAL = '5303284739002C9C'
OLD = 'NYANFW1;1.6.6-beta10;hw_v1;BID=round90e'
DIAG = 'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g'
MPR_CONFIG = OUT / 'mpr_controller_config.bin'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def connect_checked(signature=DIAG):
    port, info = live.connect()
    try:
        version = live.version(port)
        if info.serial_number != SERIAL or signature not in version:
            raise RuntimeError(f'target identity mismatch: {info.serial_number} {version}')
        return port, info, version
    except BaseException:
        port.close()
        raise


def wait_device():
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        matches = [p for p in serial.tools.list_ports.comports()
                   if p.vid == 0xCAFE and p.pid == 0x4009 and p.serial_number == SERIAL]
        if matches:
            time.sleep(1)
            return
        time.sleep(.25)
    raise RuntimeError('original 32-inch controller did not re-enumerate')


def probe_checked(port):
    port.write(b'\xbc')
    probe = live.exact(port, 6)
    if probe != bytes.fromhex('bc0700050502'):
        raise RuntimeError(f'expected three MPRs, zero MBRs and HW2: {probe.hex()}')
    return probe.hex()


def read_config_checked(signature, expected):
    port, info, version = connect_checked(signature)
    entered = False
    try:
        probe = probe_checked(port)
        port.write(b'\xb3')
        entered = True
        live.tail(port, .3)
        cfg, trailer = live.config_read(port)
        if cfg != expected:
            raise RuntimeError('controller configuration differs from expected snapshot')
        return {'version': version, 'port': info.device, 'probe': probe,
                'controller_config_equal': True, 'controller_sha256': sha(cfg), 'trailer': trailer}
    finally:
        if entered:
            port.write(b'\xb9')
            port.flush()
        port.close()


def validate_backups():
    manifest = json.loads((BACKUP / 'backup_complete.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        if sha((BACKUP / name).read_bytes()) != expected:
            raise RuntimeError(f'backup hash mismatch: {name}')
    cfg = (BACKUP / 'controller_config.bin').read_bytes()
    if len(cfg) != 128 or cfg[:4] != bytes([0x88, 2, 2, 2]) or live.xor(cfg):
        raise RuntimeError('invalid preserved original 32-inch MBR configuration')
    return cfg


def flash():
    expected = validate_backups()
    path = OUT / 'flash.json'
    if path.exists():
        raise RuntimeError('recorded flash attempt exists; inspect it before any retry')
    uf2 = ROOT / 'Nyanithm_firmware_hw_v1/build_round90g/Nyanithm.uf2'
    report = {'serial': SERIAL, 'completed': False,
              'software_bootsel_erases_first_flash_sector': True,
              'original_uf2_preserved': str(BACKUP / 'round90e_original.uf2')}
    try:
        data = uf2.read_bytes()
        if sha(data) != '4412c8af403cba32125cc7135628b6c193d278cbfeeac944022ccfcad35f34d1' or len(data) != 200704:
            raise RuntimeError('verified diagnostic firmware hash/size differs')
        addresses = set()
        payloads = []
        for pos in range(0, len(data), 512):
            m0, m1, flags, address, size, block, count, family = struct.unpack_from('<8I', data, pos)
            if ((m0, m1, flags, family) != (0x0A324655, 0x9E5D5157, 0x2000, 0xE48BFF56)
                    or size != 256 or block != pos // 512 or count != len(data) // 512
                    or address in addresses or not 0x10000000 <= address
                    or address + size > 0x101ff000
                    or struct.unpack_from('<I', data, pos + 508)[0] != 0x0AB16F30):
                raise RuntimeError('invalid firmware-only RP2040 UF2')
            addresses.add(address)
            payloads.append(data[pos + 32:pos + 288])
        if DIAG.encode() not in b''.join(payloads):
            raise RuntimeError('diagnostic firmware signature absent from UF2')
        report.update(uf2_sha256=sha(data), uf2_size=len(data),
                      flash_range=[min(addresses), max(addresses) + 256])
        report['before'] = read_config_checked(OLD, expected)
        time.sleep(1.5)
        if rp2040_drives():
            raise RuntimeError('pre-existing BOOTSEL drive; target ambiguous')
        port, _, _ = connect_checked(OLD)
        try:
            probe_checked(port)
            port.write(b'\xbb\xa5')
            port.flush()
            report['bootsel_sent'] = True
            save(path, report)
        finally:
            port.close()
        deadline = time.monotonic() + 20
        drives = []
        while time.monotonic() < deadline:
            drives = rp2040_drives()
            if drives:
                break
            time.sleep(.25)
        if len(drives) != 1:
            raise RuntimeError(f'expected one new RP2040 drive: {drives}')
        report['drive'] = str(drives[0])
        shutil.copyfile(uf2, drives[0] / 'Nyanithm.uf2')
        report['uf2_copied'] = True
        save(path, report)
        wait_device()
        report['after'] = read_config_checked(DIAG, expected)
        report['completed'] = True
        print(json.dumps(report, indent=2), flush=True)
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        save(path, report)


def configure(retry=False):
    original = validate_backups()
    path = OUT / ('configure_retry.json' if retry else 'configure.json')
    if path.exists() or (not retry and MPR_CONFIG.exists()):
        raise RuntimeError('configuration attempt exists; inspect before retry')
    if retry:
        previous = json.loads((OUT / 'configure.json').read_text(encoding='utf-8'))
        if previous.get('completed') or 'save_response' in previous or not previous.get('exit_reboot_sent'):
            raise RuntimeError('retry only supports the documented unsaved B4-read-semantics failure')
    candidate = bytearray(original)
    candidate[3] &= ~2  # Native cfg0 MBR selector; HW2/32 LEDs are retained.
    candidate[7:9] = bytes([13, 12])  # Explicit 27-inch global MPR threshold reference.
    candidate[127] = live.xor(candidate[:127])
    candidate = bytes(candidate)
    # Existing valid MBR profile is already OFF. Non-MBR sanitizer leaves it OFF.
    if original[93] != 0 or any(original[26:90]) or live.xor(candidate):
        raise RuntimeError('unexpected profile/per-lane state; candidate needs fresh review')
    changes = [{'offset': i, 'before': a, 'after': b}
               for i, (a, b) in enumerate(zip(original, candidate)) if a != b]
    if [c['offset'] for c in changes] != [3, 7, 8, 127]:
        raise RuntimeError('unexpected candidate byte changes')
    if retry:
        if MPR_CONFIG.read_bytes() != candidate:
            raise RuntimeError('preserved candidate changed')
    else:
        MPR_CONFIG.write_bytes(candidate)
        save(OUT / 'candidate.json', {'changes': changes, 'before_sha256': sha(original),
                                'candidate_sha256': sha(candidate), 'per_lane_thresholds': 'all zero: inherit global',
                                'copied_27inch_config': False, 'new_touch_algorithm': False})
    report = {'completed': False, 'candidate_sha256': sha(candidate), 'changes': changes}
    if retry:
        report['previous_attempt_cause'] = 'B4 reloads Flash into RAM; it is not a RAM-only read. Previous B7 was never saved.'
    port, info, version = connect_checked()
    entered = False
    try:
        report.update(version=version, usb_serial=info.serial_number, probe=probe_checked(port))
        port.write(b'\xb3')
        entered = True
        report['entry'] = live.tail(port, .3)
        cfg, _ = live.config_read(port)
        if cfg != original:
            raise RuntimeError('live configuration changed since original backup')
        live.split(port, 0xB7, candidate)
        # No command nudges while the 128-byte configuration is being received.
        report['set_response'] = live.tail(port, .4)
        if 'check ok. config changed.' not in report['set_response']:
            raise RuntimeError('CFG_SET did not acknowledge a valid configuration')
        # B4 calls readConfig(), replacing RAM from Flash. Never issue it
        # between B7 and B5; verification must follow the save command.
        port.write(b'\xb5')
        report['save_response'] = live.tail(port, .5)
        if 'saveConfig result: 0' not in report['save_response']:
            raise RuntimeError('CFG_SAVE failed')
        check, _ = live.config_read(port)
        report['saved_readback_equal'] = check == candidate
        if check != candidate:
            raise RuntimeError('saved configuration differs from candidate')
        port.write(b'\xce')
        report['command_log'] = live.exact(port, live.exact(port, 1)[0]).hex()
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        if entered:
            port.write(b'\xb9')
            port.flush()
            report['exit_reboot_sent'] = True
        port.close()
        save(path, report)
    time.sleep(1.5)
    wait_device()
    report['after_reboot'] = read_config_checked(DIAG, candidate)
    report['completed'] = True
    save(path, report)
    print(json.dumps(report, indent=2), flush=True)


def idle():
    sys.path.insert(0, str(ROOT / 'Nyanithm_firmware_hw_v1/tools'))
    from decode_mpr121_snapshot import decode
    expected = MPR_CONFIG.read_bytes()
    destination = OUT / 'idle'
    destination.mkdir(exist_ok=False)
    report = {'complete': False, 'board': 'original 32-inch PCB/controller, transplanted 3 MPR121 modules',
              'action_label': 'user confirmed hands and other objects >=20cm away',
              'usb_serial': SERIAL, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'mode': 'configuration diagnostic; game HID disabled',
              'host_configuration_write_commands': False, 'firmware_idle_processing_preserved': True,
              'native_signal_window': '43B 0x00..0x2A single repeated-START transaction',
              'control_window': '85B separate read; three chips are sequential, not simultaneous', 'samples': []}
    port, _, version = connect_checked()
    entered = False
    try:
        report['version'] = version
        port.write(b'\xb3')
        entered = True
        live.tail(port, .3)
        cfg, _ = live.config_read(port)
        if cfg != expected:
            raise RuntimeError('MPR controller configuration mismatch')
        report['controller_sha256'] = sha(cfg)
        for sequence in range(12):
            for address in (0x5A, 0x5B, 0x5C):
                start = time.perf_counter()
                live.split(port, 0xC6, [address])
                data = live.exact(port, 128, 2)
                document = {'schema': 'mpr121-register-snapshot-v1', 'origin': 'hardware-readback',
                            'registers': {f'0x{i:02X}': b for i, b in enumerate(data)}}
                report['samples'].append({'sequence': sequence, 'address': address, 'hex': data.hex(),
                                          'host_start_s': start, 'host_end_s': time.perf_counter(),
                                          'response_bytes': len(data), 'sha256': sha(data), 'decoded': decode(document)})
            time.sleep(.05)
        check, _ = live.config_read(port)
        if check != expected:
            raise RuntimeError('controller configuration changed during native idle reads')
        report['controller_equal_after'] = True
        report['complete'] = True
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        if entered:
            port.write(b'\xb9')
            port.flush()
        port.close()
        report['session_closed'] = True
        save(destination / 'capture.json', report)
    summary = []
    for address in (0x5A, 0x5B, 0x5C):
        rows = [r for r in report['samples'] if r['address'] == address]
        decoded = rows[0]['decoded']
        summary.append({'address': hex(address), 'observations': len(rows), 'global': decoded['global'],
                        'ecr': decoded['ecr'], 'debounce': decoded['debounce'], 'autoconfig': decoded['autoconfig'],
                        'active_cdc_uA': [e['effective_cdc_uA'] for e in decoded['electrodes'][:12]],
                        'active_cdt_us': [e['effective_cdt_us'] for e in decoded['electrodes'][:12]],
                        'touch_threshold': [e['touch_threshold'] for e in decoded['electrodes'][:12]],
                        'native_status': [int.from_bytes(bytes.fromhex(r['hex'])[:2], 'little') for r in rows],
                        'oor_status': [bytes.fromhex(r['hex'])[2:4].hex() for r in rows]})
    save(destination / 'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)


def normal_idle():
    path = OUT / 'normal_idle.json'
    if path.exists():
        raise RuntimeError('normal idle capture already recorded')
    port, info, version = connect_checked()
    try:
        report = {'usb_serial': info.serial_number, 'version': version,
                  'probe': probe_checked(port),
                  'mode': 'normal CDC GET_INPUT; not directly read HID reports', 'frames': []}
        port.write(b'\xc4')
        report['raw_status'] = live.tail(port)
        started = time.perf_counter()
        for _ in range(100):
            port.write(b'\xb1')
            data = live.exact(port, 33)
            report['frames'].append({'elapsed_s': time.perf_counter() - started, 'hex': data.hex()})
            time.sleep(.01)
        report['touch_active_frames'] = sum(any(bytes.fromhex(x['hex'])[:32]) for x in report['frames'])
        save(path, report)
        print(json.dumps({k: v for k, v in report.items() if k != 'frames'}, indent=2), flush=True)
    finally:
        port.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('flash', 'configure', 'configure-retry', 'idle', 'normal-idle'))
    args = parser.parse_args()
    {'flash': flash, 'configure': configure, 'configure-retry': lambda: configure(retry=True),
     'idle': idle, 'normal-idle': normal_idle}[args.action]()
