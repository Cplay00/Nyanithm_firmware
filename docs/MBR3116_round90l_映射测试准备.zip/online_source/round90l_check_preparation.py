"""Read-only preparation checks; negative mock requests cannot queue a capture."""
import json
from pathlib import Path
import urllib.error
import urllib.request

import round90j_check_capture as frozen
import round90l_mapping_page as page

out = page.OUT
mapping_path = page.capture.previous.OUT / 'source_mapping.json'
mapping = frozen.load_mapping(mapping_path)
assert mapping == page.capture.previous.LANES
checks = frozen.offline_checks(mapping)
preflight = json.loads((out / 'preflight.json').read_text(encoding='utf-8'))
assert preflight['serial_released'] and preflight['hands_state_unknown']
assert preflight['identity']['usb_serial'] == '5303284739002C9C'
assert preflight['identity']['probe'] == 'bc0700050502'
assert preflight['identity']['raw_status'] == 'RAW=0'
assert not preflight['identity']['configuration_live_read']
assert not preflight['identity']['configuration_commands_sent']
for row in preflight['frames']:
    parsed = frozen.parse_chain(bytes.fromhex(row['chain_hex']), mapping)
    for key, value in parsed.items():
        assert row[key] == value
    game = bytes.fromhex(row['game_hex'])
    assert len(game) == 33 and all(value in (0,128) for value in game[:32])


def denied(endpoint, payload, expected, origin='http://127.0.0.1:8885'):
    request = urllib.request.Request('http://127.0.0.1:8885' + endpoint,
        data=json.dumps(payload).encode(), headers={'Content-Type':'application/json','Origin':origin})
    try:
        urllib.request.urlopen(request, timeout=3)
    except urllib.error.HTTPError as error:
        assert error.code == expected, (endpoint,error.code,error.read())
        return {'path':endpoint,'expected_status':expected,'passed':True}
    raise AssertionError('negative request was accepted')


negative = [denied('/start', {}, 403, 'http://example.invalid'),
            denied('/start', {'mode':'usb8_upper','usb_side':'','count_from_usb':True}, 400),
            denied('/start', {'mode':'usb8_upper','usb_side':'right','count_from_usb':False}, 400),
            denied('/start', {'mode':'usb9_lower','usb_side':'right','count_from_usb':True}, 409),
            denied('/label', {'id':'missing','valid':True,'hands_away':True}, 400),
            denied('/finish', {'hands_away':False}, 400)]
result = {'offline_frame_checks': checks, 'mock_negative_requests': negative,
          'preflight_pairs': len(preflight['frames']), 'preflight_serial_released': True,
          'preflight_identity': preflight['identity'],
          'no_physical_mapping_or_idle_claim': True}
(out / 'preparation_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PASS',checks['passed'],'frame checks,',len(negative),'mock request guards,',len(preflight['frames']),'real normal pairs; no pose conclusion')
