import csv
import hashlib
import json
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import round89i_analyze_pair as paired
import round89q_no_autoreset_capture as experiment

experiment.configure()
ROOT = Path(__file__).resolve().parents[1]
DATA = experiment.OUT
OLD = ROOT / "_dev_tools/round89n_prox16_20261002"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
paired.ROOT = DATA
accepted = [j for j in paired.analyze()["jobs"] if j["mode"] in ("palm_hover5", "palm_contact") and j["completed"] and j["user_confirmed"] is True]
if len(accepted) != 2 or {j["mode"] for j in accepted} != {"palm_hover5", "palm_contact"}:
    raise RuntimeError("unexpected accepted palms")

files, checks, traces = {}, {}, {}
fig, axes = plt.subplots(2, 2, figsize=(12, 7), sharex=True, sharey="row")
for row_index, mode in enumerate(("palm_hover5", "palm_contact")):
    job = next(j for j in accepted if j["mode"] == mode)
    source = DATA / (job["id"] + ".json")
    native = json.loads(source.read_text(encoding="utf-8"))
    hardware = native["hardware"]
    if native["reference_mode"] != experiment.capture.REFERENCE_MODE or not all(hardware.get(k) for k in ("candidate_applied", "restore_verified", "restore_after_reboot")):
        raise RuntimeError("mode or restore flags disagree")
    device = DATA / (job["id"] + "_device")
    for folder in (device, device / "after_reboot"):
        if (folder / "controller_config.bin").read_bytes() != experiment.capture.CFG:
            raise RuntimeError("controller config mismatch")
        if any((folder / f"chip_{a:02x}.bin").read_bytes() != table for a, table in experiment.capture.ORIGINALS.items()):
            raise RuntimeError("chip config mismatch")
    snapshot = json.loads((device / "after_reboot/snapshot.json").read_text(encoding="utf-8"))
    if snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
        raise RuntimeError("nonzero restored state")
    rows = list(csv.DictReader(source.with_suffix(".csv").open(encoding="utf-8", newline="")))
    good = [r for r in rows if not r["error"]]
    if any(int(r["ref_delta"]) != int(r["ref_raw"]) - int(r["ref_baseline"]) for r in good):
        raise RuntimeError("delta arithmetic disagreement")
    fixed = [r for r in good if r["phase"] == "hold" and r["phase_valid"] == "1" and 6 <= float(r["elapsed_s"]) <= 11.5]
    if len(fixed) != job["windows"]["hold"]["valid"]:
        raise RuntimeError("fixed-window count disagreement")
    for field in ("delta", "ref_delta", "diff", "ref_diff", "ref_baseline"):
        if min(int(r[field]) for r in fixed) != job["windows"]["hold"][field]["min"] or max(int(r[field]) for r in fixed) != job["windows"]["hold"][field]["max"]:
            raise RuntimeError("independent extrema disagreement")
    all_hold = [r for r in good if r["phase"] == "hold" and r["phase_valid"] == "1"]
    traces[mode] = {"rows": len(rows), "valid_hold": len(all_hold),
                    "whole_hold_baseline_range": [min(int(r["ref_baseline"]) for r in all_hold), max(int(r["ref_baseline"]) for r in all_hold)],
                    "whole_record_baseline_steps_at_least_500": [float(b["elapsed_s"]) for a, b in zip(good, good[1:]) if abs(int(b["ref_baseline"]) - int(a["ref_baseline"])) >= 500],
                    "fixed_hold_diff_zero_rows": sum(int(r["ref_diff"]) == 0 for r in fixed),
                    "whole_hold_diff_zero_rows": sum(int(r["ref_diff"]) == 0 for r in all_hold),
                    "whole_hold_delta_range": [min(int(r["ref_delta"]) for r in all_hold), max(int(r["ref_delta"]) for r in all_hold)]}
    checks[mode] = {"backup_and_reboot_four_blocks_equal": True, "raw": snapshot["raw_status"], "slider_all_zero": True,
                    "csv_arithmetic_and_window_verified": True, "version": snapshot["version"]}
    for suffix in (".json", ".csv"):
        files["samples/" + source.with_suffix(suffix).name] = source.with_suffix(suffix)
    for path in device.rglob("*"):
        if path.is_file():
            files["samples/" + path.relative_to(DATA).as_posix()] = path
    old_candidates = []
    for path in OLD.glob("*.json"):
        earlier = json.loads(path.read_text(encoding="utf-8"))
        if earlier.get("mode") == mode and earlier.get("completed") and earlier.get("user_confirmed") is True:
            old_candidates.append(path)
    if len(old_candidates) != 1:
        raise RuntimeError("ambiguous comparison trial")
    old_source = old_candidates[0]
    for suffix in (".json", ".csv"):
        files["previous/" + old_source.with_suffix(suffix).name] = old_source.with_suffix(suffix)
    for column, (path, label) in enumerate(((old_source, "5-second auto-reset"), (source, "Auto-reset disabled"))):
        plot_rows = list(csv.DictReader(path.with_suffix(".csv").open(encoding="utf-8", newline="")))
        x = [float(r["elapsed_s"]) for r in plot_rows]
        ax = axes[row_index, column]
        for field, color, name in (("ref_raw", "#2873a8", "Raw count"), ("ref_baseline", "#d86f29", "Baseline")):
            y = [int(r[field]) if not r["error"] else np.nan for r in plot_rows]
            ax.plot(x, y, lw=1.6, color=color, label=name)
        ax.axvspan(6, 11.5, color="#d9eada", alpha=.65, label="Analysis window")
        ax.axvline(4, color="#777777", ls=":", lw=.9)
        ax.axvline(12, color="#777777", ls=":", lw=.9)
        ax.set_title(("Palm hover ~5 mm" if mode == "palm_hover5" else "Palm light contact") + " | " + label)
        ax.grid(alpha=.2)
        ax.set_xlim(0, 22)
        if column == 0:
            ax.set_ylabel("Reference native count")
        if row_index == 1:
            ax.set_xlabel("Elapsed seconds")
axes[0, 0].legend(loc="upper left", framealpha=.85, fontsize=9)
fig.suptitle("Sustained palm: native reference baseline before and after auto-reset control", fontsize=14)
fig.tight_layout(rect=(0, .06, 1, .95))
fig.text(.5, .02, "Sequential C7; separate manual trials. Dotted lines: nominal hold cue 4-12 s. Config restored after each trial.", ha="center", fontsize=9)
figure = DOCS / "MBR3116_round89r_基线复位对照.png"
fig.savefig(figure, dpi=160)
plt.close(fig)
files[figure.name] = figure
for name in ("round89r_package_evidence.py", "round89q_no_autoreset_capture.py", "round89n_prox16_capture.py", "round89m_alp_off_capture.py",
             "round89k_prox_capture.py", "round89j_prox_idle.py", "round89h_timed_capture.py", "round89h_timed_capture.html",
             "round89h_raw_capture.py", "round89g_latency_probe.py", "round89_live.py", "round89_live_debug.py",
             "round89i_analyze_pair.py", "round89h_analyze_timed.py"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89r_自动复位实测证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != digest for name, digest in manifest.items()):
        raise RuntimeError("archive hash disagreement")
evidence = {"date": "2026-10-02", "mode": experiment.capture.REFERENCE_MODE, "candidate_applied": True,
            "candidate_sha256": hashlib.sha256(experiment.make_patch(experiment.capture.ORIGINALS[0x42])).hexdigest(),
            "accepted_jobs": accepted, "trace_checks": traces, "restoration": checks,
            "interpretation": "Five-second collapse is absent in both accepted control trials, consistent with native proximity auto-reset cause. Hover remains strong; amplitude and ratio are still area-dependent. Not a contact-only or mm-distance fix.",
            "limitations": ["Only two manual palm trials in this configuration", "Whole hold includes approach; early zero counts do not prove rejection", "Different trials have different amplitudes; do not attribute amplitude reduction to ARST or call it reduced sensitivity", "Fixed windows are not initial-touch latency measurements; 89 pairs are not 89 independent touches", "Per-chip proximity availability and game readout timing remain unresolved"],
            "archive": {"name": archive.name, "files": len(manifest), "size": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DOCS / "MBR3116_round89r_自动复位实测分析.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "two palms restored")
for job in accepted:
    h = job["windows"]["hold"]
    print(job["mode"], "pairs", h["valid"], "base", h["ref_baseline"]["min"], h["ref_baseline"]["max"],
          "reference", h["ref_delta"]["min"], h["ref_delta"]["max"], "ratio", h["delta_ratio"]["min"], h["delta_ratio"]["max"])
print(json.dumps(traces))
