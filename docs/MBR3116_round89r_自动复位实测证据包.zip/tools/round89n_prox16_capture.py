import argparse

import round89m_alp_off_capture as alp

capture = alp.capture
PORT = 8771
ORIGIN = f"http://127.0.0.1:{PORT}"
OUT = capture.ROOT / "_dev_tools/round89n_prox16_20261002"


def make_patch(original):
    patched = bytearray(alp.make_patch(original))
    patched[0x2E] &= 0xF8
    patched[126:128] = capture.probe.crc(patched).to_bytes(2, "little")
    if any(original[i] != patched[i] for i in range(128) if i not in (0x26, 0x27, 0x7E, 0x7F)):
        raise RuntimeError("unexpected full-resolution experiment fields")
    return bytes(patched)


def configure():
    capture.DESIRED = make_patch(capture.ORIGINALS[capture.probe.ADDRESS])
    capture.REFERENCE_MODE = "0x42 CS0 Proximity 16-bit ALP OFF; center 0x40 CS7 button; sequential native C7"
    capture.PAGE_TITLE = "参考精度对照采样"
    capture.DEFAULT_MODE = "finger_contact"
    capture.ui.OUT = OUT
    capture.ui.ORIGIN = ORIGIN


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    if not args.serve:
        parser.error("use --serve")
    configure()
    capture.serve(PORT)
