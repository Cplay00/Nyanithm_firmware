import csv
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "round89h_timed_20261001"
WINDOWS = {"baseline": (.5, 3.5), "hold": (6.0, 11.5), "release": (14.0, 21.5)}


def describe(values):
    ordered = sorted(values)
    if not ordered:
        return None
    return {"n": len(ordered), "min": ordered[0],
            "p05": ordered[int((len(ordered) - 1) * .05)],
            "median": statistics.median(ordered),
            "p95": ordered[int((len(ordered) - 1) * .95)], "max": ordered[-1]}


def analyze():
    jobs = []
    for path in sorted(ROOT.glob("*.json")):
        job = json.loads(path.read_text(encoding="utf-8"))
        if "mode" not in job or not path.with_suffix(".csv").exists():
            continue
        rows = list(csv.DictReader(path.with_suffix(".csv").open(encoding="utf-8", newline="")))
        result = {"id": job["id"], "mode": job["mode"],
                  "user_confirmed": job.get("user_confirmed"),
                  "completed": job.get("completed", False), "firmware": job.get("firmware"),
                  "windows": {}}
        for phase, (start, end) in WINDOWS.items():
            selected = [r for r in rows if r["phase"] == phase and start <= float(r["elapsed_s"]) <= end]
            valid = [r for r in selected if not r["error"] and r["phase_valid"] == "1"]
            summary = {"start_s": start, "end_s": end, "rows": len(selected),
                       "valid": len(valid), "errors": sum(bool(r["error"]) for r in selected),
                       "boundary_excluded": sum(not r["error"] and r["phase_valid"] != "1" for r in selected)}
            for field in ("diff", "raw", "baseline", "delta"):
                summary[field] = describe([int(r[field]) for r in valid])
            summary["relative_delta"] = describe([int(r["delta"]) / int(r["baseline"])
                                                    for r in valid if int(r["baseline"]) > 0])
            summary["diff_saturated_fraction"] = sum(int(r["diff"]) == 255 for r in valid) / len(valid) if valid else None
            summary["error_messages"] = sorted(set(r["error"] for r in selected if r["error"]))
            result["windows"][phase] = summary
        jobs.append(result)
    confirmed = [j for j in jobs if j["user_confirmed"] is True and j["completed"]]
    contact = [j for j in confirmed if j["mode"].endswith("contact")]
    hover = [j for j in confirmed if "hover" in j["mode"]]
    separation = {}
    for field in ("diff", "delta", "relative_delta"):
        c = [j["windows"]["hold"][field] for j in contact if j["windows"]["hold"][field]]
        h = [j["windows"]["hold"][field] for j in hover if j["windows"]["hold"][field]]
        if c and h:
            contact_min, hover_max = min(s["min"] for s in c), max(s["max"] for s in h)
            separation[field] = {"contact_min": contact_min, "hover_max": hover_max,
                                 "observed_gap": contact_min - hover_max,
                                 "separable_in_confirmed_windows": contact_min > hover_max}
    return {"target": {"address": "0x40", "sensor": 7, "lane": 17},
            "window_policy": "Fixed time windows for all poses; no amplitude-based selection. Manual reaction and height uncertainty remain.",
            "jobs": jobs, "confirmed_window_separation": separation}


if __name__ == "__main__":
    result = analyze()
    (ROOT / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for job in result["jobs"]:
        hold = job["windows"]["hold"]
        print(job["mode"], job["user_confirmed"], "n=", hold["valid"],
              "diff=", hold["diff"], "delta=", hold["delta"], "errors=", hold["errors"])
    print(json.dumps(result["confirmed_window_separation"], indent=2))
