import csv
import json
from pathlib import Path

from round89h_analyze_timed import describe

ROOT = Path(__file__).resolve().parent / "round89i_pair_20261001"
FIELDS = ("delta", "ref_delta", "diff", "ref_diff", "raw", "ref_raw", "baseline", "ref_baseline", "delta_ratio")


def analyze():
    jobs, examples, clipped_examples, confirmed_points = [], {}, {}, {}
    for path in sorted(ROOT.glob("*.json")):
        job = json.loads(path.read_text(encoding="utf-8"))
        if "mode" not in job or not path.with_suffix(".csv").exists():
            continue
        rows = list(csv.DictReader(path.with_suffix(".csv").open(encoding="utf-8", newline="")))
        result = {"id": job["id"], "mode": job["mode"], "user_confirmed": job.get("user_confirmed"),
                  "completed": job.get("completed", False), "windows": {}}
        far = [r for r in rows if r["phase"] == "baseline" and r["phase_valid"] == "1" and not r["error"]
               and .5 <= float(r["elapsed_s"]) <= 3.5]
        far_center = describe([int(r["raw"]) for r in far])
        far_reference = describe([int(r["ref_raw"]) for r in far])
        for phase, (start, end) in {"baseline": (.5, 3.5), "hold": (6, 11.5), "release": (14, 21.5)}.items():
            selected = [r for r in rows if r["phase"] == phase and start <= float(r["elapsed_s"]) <= end]
            valid = [r for r in selected if r["phase_valid"] == "1" and not r["error"]]
            summary = {"valid": len(valid), "errors": sum(bool(r["error"]) for r in selected)}
            for field in FIELDS:
                summary[field] = describe([float(r[field]) for r in valid if r.get(field, "") != ""])
            summary["relative_center"] = describe([int(r["delta"]) / int(r["baseline"]) for r in valid if int(r["baseline"]) > 0])
            summary["relative_reference"] = describe([int(r["ref_delta"]) / int(r["ref_baseline"]) for r in valid if int(r["ref_baseline"]) > 0])
            if far_center and far_reference:
                fixed = [(int(r["raw"]) - far_center["median"], int(r["ref_raw"]) - far_reference["median"]) for r in valid]
                summary["fixed_far_center_delta"] = describe([c for c, _ in fixed])
                summary["fixed_far_reference_delta"] = describe([r for _, r in fixed])
                summary["fixed_far_ratio"] = describe([r / c for c, r in fixed if c > 0])
            result["windows"][phase] = summary
            if phase == "hold" and job.get("user_confirmed") is True:
                for row in valid:
                    key = (int(row["delta"]), int(row["ref_delta"]))
                    examples.setdefault(key, {}).setdefault(job["mode"], {"id": job["id"], "elapsed_s": float(row["elapsed_s"])})
                    clipped_key = (int(row["diff"]), int(row["ref_delta"]))
                    clipped_examples.setdefault(clipped_key, {}).setdefault(job["mode"], {"id": job["id"], "elapsed_s": float(row["elapsed_s"])})
                    confirmed_points.setdefault(job["mode"], []).append(key)
        jobs.append(result)
    collisions = [{"center_delta": key[0], "reference_delta": key[1], "examples": value}
                  for key, value in examples.items() if any("hover" in mode for mode in value) and any("contact" in mode for mode in value)]
    clipped_collisions = [{"center_diff": key[0], "reference_delta": key[1], "examples": value}
                          for key, value in clipped_examples.items() if any("hover" in mode for mode in value) and any("contact" in mode for mode in value)]
    closest = None
    c, h = confirmed_points.get("finger_contact", []), confirmed_points.get("finger_hover3", [])
    if c and h:
        distance, a, b = min((((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** .5, a, b) for a in c for b in h)
        closest = {"euclidean_distance": distance, "contact": list(a), "hover": list(b)}
    return {"target": {"center": "0x40:CS7/lane17", "reference": "0x42:CS0/lane18"},
            "semantics": "Sequential C7 windows, not simultaneous; same fixed time windows, errors excluded without zero filling; no NVM writes",
            "jobs": jobs, "joint_delta_collisions": collisions,
            "capped_center_plus_reference_collisions": clipped_collisions,
            "closest_finger_pair": closest}


if __name__ == "__main__":
    result = analyze()
    (ROOT / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for job in result["jobs"]:
        print(job["mode"], job["user_confirmed"], job["windows"]["hold"])
    print("JOINT COLLISIONS", len(result["joint_delta_collisions"]))
