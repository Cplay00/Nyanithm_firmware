import argparse

import round89n_prox16_capture as full

capture = full.capture
PORT = 8772
ORIGIN = f"http://127.0.0.1:{PORT}"
OUT = capture.ROOT / "_dev_tools/round89q_no_autoreset_20261002"


def make_patch(original):
    patched = bytearray(full.make_patch(original))
    if (original[0x4F] >> 6) != 1:
        raise RuntimeError("expected documented five-second proximity auto-reset")
    patched[0x4F] &= 0x3F
    patched[126:128] = capture.probe.crc(patched).to_bytes(2, "little")
    if any(original[i] != patched[i] for i in range(128) if i not in (0x26, 0x27, 0x4F, 0x7E, 0x7F)):
        raise RuntimeError("unexpected auto-reset experiment fields")
    return bytes(patched)


def configure():
    capture.DESIRED = make_patch(capture.ORIGINALS[capture.probe.ADDRESS])
    capture.REFERENCE_MODE = "0x42 CS0 Proximity 16-bit ALP OFF ARST OFF; center 0x40 CS7 button; sequential native C7"
    capture.PAGE_TITLE = "基线自动复位对照采样"
    capture.DEFAULT_MODE = "palm_hover5"
    capture.ui.OUT = OUT
    capture.ui.ORIGIN = ORIGIN


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    if not args.serve:
        parser.error("use --serve")
    configure()
    capture.serve(PORT)
