"""Offline fixed-location capture audit. Raw frames, never physical-touch rates."""
import argparse
from collections import Counter
import csv
import importlib.util
import json
from pathlib import Path
import struct

spec=importlib.util.spec_from_file_location('normal_framing',Path(__file__).with_name('round90j_check_capture.py'))
framing=importlib.util.module_from_spec(spec)
spec.loader.exec_module(framing)

MODES = ('usb8_upper', 'usb8_lower', 'usb9_upper', 'usb9_lower')
WINDOWS = {'baseline': (.5, 3.5), 'hold': (6, 11.5), 'late': (9, 11.5), 'release': (14, 21.5)}


def analyze(folder, mapping):
    audit = framing.audit(folder, mapping)
    jobs = []
    inverse = {lane: (address, electrode) for (address, electrode), lane in mapping.items()}
    for item in audit['jobs']:
        meta = json.loads((folder / (item['id']+'.json')).read_text(encoding='utf-8'))
        assert meta['mode'] in MODES and meta['count_origin'] == 'USB connector end is physical strip 1'
        assert meta['usb_side_from_front'] in ('left', 'right')
        assert isinstance(meta['user_confirmed'], bool), 'unconfirmed action cannot enter completed analysis'
        assert meta['serial_released_after_capture'] and meta['no_configuration_write_or_reboot']
        rows = list(csv.DictReader((folder / (item['id']+'.csv')).open(encoding='utf-8', newline='')))
        assert all(float(rows[i]['elapsed_s']) < float(rows[i+1]['elapsed_s']) for i in range(len(rows)-1))
        for row in rows:
            assert set(json.loads(row['verified_lanes_json'])).issubset(json.loads(row['native_lanes_json']))
        result = {**item, 'physical_target': meta['physical_target'], 'usb_side_from_front': meta['usb_side_from_front'],
                  'user_note': meta.get('user_note', ''), 'windows': {}}
        result['all_rows_differences'] = {'native_verified':sum(r['native_lanes_json']!=r['verified_lanes_json'] for r in rows),
                                        'final_game':sum(r['final_lanes_json']!=r['game_lanes_json'] for r in rows)}
        result['sampled_on_runs'] = {}
        for stage in ('native','final','game'):
            runs, start = [], None
            for index,row in enumerate(rows):
                on = bool(json.loads(row[stage+'_lanes_json']))
                if on and start is None:
                    start = index
                if start is not None and (not on or index==len(rows)-1):
                    end=index-1 if not on else index
                    runs.append({'first_on_s':float(rows[start]['elapsed_s']), 'last_on_s':float(rows[end]['elapsed_s']),
                                 'previous_off_s':float(rows[start-1]['elapsed_s']) if start else None,
                                 'next_off_s':float(row['elapsed_s']) if not on else None,'on_observations':end-start+1})
                    start=None
            result['sampled_on_runs'][stage]=runs
        if not item['mock']:
            identity=meta['identity']
            assert identity['usb_serial']=='5303284739002C9C' and identity['probe']=='bc0700050502'
            assert 'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g' in identity['firmware'] and identity['raw_status']=='RAW=0'
            assert not identity['configuration_live_read'] and not identity['configuration_commands_sent']
            b,a=[bytes.fromhex(meta[key]['raw_hex']) for key in ('telemetry_before','telemetry_after')]
            assert len(b)==len(a)==528
            head_before,head_after=struct.unpack_from('<10I',b),struct.unpack_from('<10I',a)
            served_delta=(head_after[1]-head_before[1])&0xFFFFFFFF
            assert served_delta==len(rows)
            rise0,rise1=struct.unpack_from('<32H',b,40),struct.unpack_from('<32H',a,40)
            fall0,fall1=struct.unpack_from('<32H',b,104),struct.unpack_from('<32H',a,104)
            result['C1']={'served_delta':served_delta,'edge_delta_including_air':(head_after[2]-head_before[2])&0xFFFFFFFF,
                          'rise_delta':{str(i):(x-y)&0xFFFF for i,(x,y) in enumerate(zip(rise1,rise0)) if x!=y},
                          'fall_delta':{str(i):(x-y)&0xFFFF for i,(x,y) in enumerate(zip(fall1,fall0)) if x!=y},
                          'scope':'this host B1 responses, not independent contact or direct HID events'}
        for name, (begin, end) in WINDOWS.items():
            selected = [r for r in rows if r['phase_valid']=='1' and begin <= float(r['elapsed_s']) <= end]
            stages = {}
            for stage in ('native', 'verified', 'final', 'game'):
                values = [json.loads(row[stage+'_lanes_json']) for row in selected]
                counts = Counter(lane for value in values for lane in value)
                stages[stage] = {'any_on': sum(bool(value) for value in values),
                    'lane_on': {str(lane): n for lane, n in sorted(counts.items())},
                    'patterns': [{'lanes':list(pattern),'observations':n} for pattern,n in Counter(tuple(v) for v in values).most_common()]}
            result['windows'][name] = {'observations':len(selected), 'stages':stages}
        candidates = sorted(int(lane) for lane in result['windows']['late']['stages']['game']['lane_on'])
        result['late_observed_candidates'] = [{'lane':lane,'address':inverse[lane][0],'electrode':inverse[lane][1]} for lane in candidates]
        result['mapping_status'] = 'no_late_response' if not candidates else 'one_observed_lane' if len(candidates)==1 else 'multiple_observed_lanes'
        jobs.append(result)
    confirmed = [job for job in jobs if job['user_confirmed']]
    assert len({job['mode'] for job in confirmed}) == len(confirmed), 'duplicate confirmed physical point'
    assert len({job['usb_side_from_front'] for job in jobs}) <= 1, 'orientation changed during session'
    requested = json.loads((folder / 'mapping_completion_requested.json').read_text(encoding='utf-8'))
    closed = json.loads((folder / 'session_closed.json').read_text(encoding='utf-8'))
    complete = {job['mode'] for job in confirmed} == set(MODES)
    assert requested['all_four_actions_confirmed'] == complete
    assert closed['serial_released'] and not closed['reset_sent'] and not closed['config_mode_entered']
    assert all(job['mock'] == closed['mock'] for job in jobs)
    return {'scope':'fixed physical action labels and sampled normal-mode responses; not exact physical contact truth, sensor freshness or direct HID',
            'hardware_mask_read_quality':'C0 has no validity flag; failed touched() reads can look OFF',
            'confirmed_physical_points':len(confirmed), 'discarded_jobs':len(jobs)-len(confirmed),
            'all_four_actions_confirmed':complete, 'serial_released':True, 'mock':closed['mock'],
            'normal_pair_integrity':audit, 'windows_s':WINDOWS, 'jobs':jobs}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--mapping', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args=parser.parse_args()
    if args.out.exists():
        raise RuntimeError('output exists; preserve earlier audit')
    result=analyze(args.folder, framing.load_mapping(args.mapping))
    args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PASS',result['normal_pair_integrity']['total_rows'],'normal pairs;',result['confirmed_physical_points'],'confirmed points;',
          result['discarded_jobs'],'discarded;', 'MOCK' if result['mock'] else 'REAL')


if __name__=='__main__':
    main()
