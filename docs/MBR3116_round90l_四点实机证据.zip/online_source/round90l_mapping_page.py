"""Fixed physical-to-logical mapping, reusing the accepted normal C0/B1 reader.

No configuration mode, register writes, reset, calibration or background device
session while idle. Each timed capture closes its own serial connection.
"""
import argparse
import json
from pathlib import Path
import struct
import threading
import time

import round90j_normal_page as capture

ui = capture.ui
OUT = Path(__file__).resolve().parent / 'round90l_mapping_20261004'
MODES = {
    'usb8_upper': '食指轻贴从USB接口端数第8竖条上半区中心（靠灯条边）',
    'usb8_lower': '食指轻贴从USB接口端数第8竖条下半区中心（靠ToF开口边）',
    'usb9_upper': '食指轻贴从USB接口端数第9竖条上半区中心（靠灯条边）',
    'usb9_lower': '食指轻贴从USB接口端数第9竖条下半区中心（靠ToF开口边）',
}
MOCK_LANES = dict(zip(MODES, (14, 15, 16, 17)))  # Synthetic only, never a real mapping assumption.
INVERSE = {lane: (address, electrode) for (address, electrode), lane in capture.previous.LANES.items()}
ORIGINAL_READER = capture.read_chain


def next_mode():
    confirmed = {j['mode'] for j in ui.STATE['jobs'] if j['user_confirmed'] is True}
    return next((mode for mode in MODES if mode not in confirmed), None)


def read_mapping(port):
    if not capture.MOCK:
        result = ORIGINAL_READER(port)
    else:
        began = time.perf_counter()
        lane = MOCK_LANES[ui.STATE['mock_mode']]
        active = [lane] if ui.STATE['phase'] == 'hold' else []
        words = [0, 0, 0]
        for lane in active:
            address, electrode = INVERSE[lane]
            words[address-0x5A] |= 1 << electrode
        frame = b'\xaa\x55' + struct.pack('<6H', *(words+words)) + bytes(128 if i in active else 0 for i in range(32))
        result = capture.parse_chain(frame)
        chain_end = time.perf_counter()
        game_start = time.perf_counter()
        game = frame[14:] + b'\x00'
        result.update(game_hex=game.hex(), game_lanes_json=capture.compact(active),
                      chain_start_s=began, chain_end_s=chain_end,
                      game_start_s=game_start, game_end_s=time.perf_counter())
        time.sleep(.01)
    lanes = json.loads(result['game_lanes_json'])
    ui.update(latest_game_lanes=lanes,
              latest_electrodes=[f'格{lane} = 0x{INVERSE[lane][0]:02X}/ELE{INVERSE[lane][1]}' for lane in lanes])
    return result


class Handler(ui.Handler):
    def do_GET(self):
        if self.path == '/':
            return self.send(200, Path(__file__).with_suffix('.html').read_bytes(), 'text/html; charset=utf-8')
        super().do_GET()

    def do_POST(self):
        if self.headers.get('Origin') != ui.ORIGIN:
            return self.send(403, {'error': 'origin rejected'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 2048:
                raise ValueError('invalid request size')
            payload = json.loads(self.rfile.read(size))
            if self.path == '/start':
                mode, orientation = payload.get('mode'), payload.get('usb_side')
                if mode not in MODES or orientation not in ('left', 'right') or payload.get('count_from_usb') is not True:
                    raise ValueError('请先选择正面USB所在侧，并确认从USB接口端数格')
                with ui.LOCK:
                    pending = ui.STATE['jobs'] and ui.STATE['jobs'][-1]['user_confirmed'] is None
                    if ui.STATE['running'] or ui.STATE['blocked'] or pending:
                        return self.send(409, {'error': '请先完成并确认或作废当前组'})
                    if mode != next_mode():
                        return self.send(409, {'error': '请按顺序测试；作废时重做同一点'})
                    if ui.STATE.get('usb_side') not in (None, orientation):
                        raise ValueError('本轮方向已固定，请勿中途改变设备方向或计数起点')
                    ui.STATE.update(running=True, phase='queued', message='请保持双手远离',
                                    usb_side=orientation, latest_game_lanes=[], latest_electrodes=[])
                    identifier = f'{time.time_ns()}_{mode}'
                ui.TASKS.put({'id': identifier, 'mode': mode, 'usb_side_from_front': orientation,
                              'count_origin': 'USB connector end is physical strip 1',
                              'physical_target': MODES[mode], 'upper_edge': 'LED strip',
                              'lower_edge': 'ToF openings', 'center_contact': True,
                              'physical_mapping_inferred_from_response': False})
                return self.send(200, {'id': identifier})
            if self.path == '/label':
                note = payload.get('note', '')
                if not isinstance(note, str) or len(note) > 300:
                    raise ValueError('invalid note')
                with ui.LOCK:
                    job = ui.STATE['jobs'][-1] if ui.STATE['jobs'] else None
                    if (job is None or job['id'] != payload.get('id') or job['user_confirmed'] is not None
                            or not isinstance(payload.get('valid'), bool) or payload.get('hands_away') is not True
                            or ui.STATE['running']):
                        raise ValueError('invalid current action/hands-clear label')
                    job.update(user_confirmed=payload['valid'], hands_away_confirmed=True, user_note=note.strip())
                    ui.save_job(job)
                    following = next_mode()
                return self.send(200, {'saved': True, 'next_mode': following})
            if self.path == '/finish':
                if payload.get('hands_away') is not True:
                    raise ValueError('hands-clear confirmation required')
                with ui.LOCK:
                    pending = ui.STATE['jobs'] and ui.STATE['jobs'][-1]['user_confirmed'] is None
                    if ui.STATE['running'] or pending or ui.STATE['phase'] == 'closed':
                        return self.send(409, {'error': '请等待结束并确认或作废本组'})
                    ui.STATE['running'] = True
                    completion = {'all_four_actions_confirmed': next_mode() is None,
                                  'usb_side_from_front': ui.STATE.get('usb_side'), 'mock': capture.MOCK,
                                  'closed_serial_claim_requires_session_closed_record': True}
                (ui.OUT / 'mapping_completion_requested.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
                ui.TASKS.put('finish')
                return self.send(200, {'closing': True})
            self.send(404, {'error': 'not found'})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.send(400, {'error': str(error)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8886)
    parser.add_argument('--mock', action='store_true')
    parser.add_argument('--mock-recheck', action='store_true')
    parser.add_argument('--probe', action='store_true')
    args = parser.parse_args()
    if args.mock_recheck and not args.mock:
        parser.error('--mock-recheck requires --mock')
    capture.MOCK = args.mock
    capture.read_chain = read_mapping
    ui.OUT = OUT / ('mock_recheck' if args.mock_recheck else 'mock' if args.mock else 'actions')
    ui.OUT.mkdir(parents=True, exist_ok=True)
    if args.probe:
        if args.mock:
            parser.error('--probe is only a real identity/normal-frame check')
        target = OUT / 'preflight.json'
        if target.exists():
            raise RuntimeError('preflight already exists; inspect before retrying')
        port, identity = capture.prepare()
        try:
            frames = [read_mapping(port) for _ in range(20)]
        finally:
            port.close()
        target.write_text(json.dumps({'identity': identity, 'frames': frames, 'serial_released': True,
                                     'hands_state_unknown': True, 'no_idle_or_mapping_conclusion': True}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        print('PASS identity, 20 normal C0/B1 pairs, serial released', flush=True)
        return
    if list(ui.OUT.glob('*.json')):
        raise RuntimeError('session records exist; do not overwrite or resume silently')
    ui.ORIGIN = f'http://127.0.0.1:{args.port}'
    ui.MODES.clear()
    ui.MODES.update(MODES)
    ui.STATE.update(jobs=[], blocked=False, mock=args.mock, usb_side=None,
                    latest_game_lanes=[], latest_electrodes=[],
                    message='先关闭游戏，固定方向并确认计数起点；双手远离后开始')
    threading.Thread(target=capture.worker, daemon=True).start()
    print('READY', ui.ORIGIN, 'MOCK' if args.mock else 'NORMAL FIXED MAPPING', flush=True)
    ui.ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()


if __name__ == '__main__':
    main()
