"""Normal-mode C0 + B1 action capture. No configuration/write/reset commands."""
import argparse
import hashlib
import json
from pathlib import Path
import queue
import struct
import threading
import time

import round89h_timed_capture as ui
import round89_live as live
import round90i_same32_page as previous
from round90i_same32_setup import DIAG, MPR_CONFIG, connect_checked, probe_checked

OUT = Path(__file__).resolve().parent / 'round90j_normal_20261004'
MOCK = False
MODES = {k: previous.MODES[k] for k in ('finger_contact', 'slow_contact', 'four_contact')}
FIELDS = ['elapsed_s', 'phase', 'phase_valid', 'chain_hex', 'hardware_json',
          'verified_json', 'native_lanes_json', 'verified_lanes_json', 'final_lanes_json',
          'game_hex', 'game_lanes_json', 'chain_start_s', 'chain_end_s',
          'game_start_s', 'game_end_s', 'error']


def compact(value):
    return json.dumps(value, separators=(',', ':'))


def parse_chain(data):
    if len(data) != 46 or data[:2] != b'\xaa\x55':
        raise RuntimeError('C0 frame length/sync mismatch')
    masks = struct.unpack_from('<6H', data, 2)
    if any(m & ~0xFFF for m in masks) or any(v not in (0, 128) for v in data[14:]):
        raise RuntimeError('unexpected MPR mask or nonbinary slider snapshot')
    def lanes(words):
        return sorted(lane for (address, e), lane in previous.LANES.items()
                      if words[address-0x5A] & (1 << e))
    return {'chain_hex': data.hex(), 'hardware_json': compact(masks[:3]),
            'verified_json': compact(masks[3:]), 'native_lanes_json': compact(lanes(masks[:3])),
            'verified_lanes_json': compact(lanes(masks[3:])),
            'final_lanes_json': compact([i for i, v in enumerate(data[14:]) if v]), 'error': ''}


def read_chain(port):
    began = time.perf_counter()
    if MOCK:
        lanes = [14, 15, 16, 17] if ui.STATE.get('mock_mode') == 'four_contact' else [16]
        active = lanes if ui.STATE['phase'] == 'hold' else []
        words = [0, 0, 0]
        for (address, e), lane in previous.LANES.items():
            if lane in active:
                words[address-0x5A] |= 1 << e
        data = b'\xaa\x55' + struct.pack('<6H', *(words+words)) + bytes(128 if i in active else 0 for i in range(32))
    else:
        port.write(b'\xc0')
        data = live.exact(port, 46, 2)
    chain_end = time.perf_counter()
    result = parse_chain(data)
    game_start = time.perf_counter()
    if MOCK:
        game = data[14:] + b'\x00'
    else:
        port.write(b'\xb1')
        game = live.exact(port, 33, 2)
    if len(game) != 33 or any(v not in (0, 128) for v in game[:32]):
        raise RuntimeError('unexpected B1 binary response')
    result.update(game_hex=game.hex(), game_lanes_json=compact([i for i, v in enumerate(game[:32]) if v]),
                  chain_start_s=began, chain_end_s=chain_end,
                  game_start_s=game_start, game_end_s=time.perf_counter())
    time.sleep(.01)
    return result


def telemetry(port):
    if MOCK:
        return {'mock': True}
    port.write(b'\xc1')
    data = live.exact(port, 528, 2)
    words = struct.unpack_from('<10I', data)
    return {'raw_hex': data.hex(), 'uptime_ms': words[0], 'served_count': words[1],
            'edge_count': words[2], 'loop_count': words[8],
            'scope': 'B1 responses include this host; not a game-only or atomic counter snapshot'}


def prepare():
    port, info, version = connect_checked(DIAG)
    try:
        probe = probe_checked(port)
        port.write(b'\xc4')
        raw = live.exact(port, 6, 2)
        if raw != b'RAW=0\n':
            raise RuntimeError('expected unchanged binary RAW=0 mode')
        return port, {'usb_serial': info.serial_number, 'port': info.device,
                      'firmware': version, 'probe': probe, 'raw_status': raw.decode().strip(),
                      'configuration_reference_sha256': hashlib.sha256(MPR_CONFIG.read_bytes()).hexdigest(),
                      'configuration_live_read': False, 'configuration_commands_sent': False}
    except BaseException:
        port.close()
        raise


def worker():
    while True:
        task = ui.TASKS.get()
        port = None
        try:
            if task == 'finish':
                report = {'serial_released': True, 'reset_sent': False, 'config_mode_entered': False,
                          'mock': MOCK, 'finished_epoch': time.time()}
                (ui.OUT / 'session_closed.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
                ui.update(running=False, blocked=True, phase='closed', message='采集已结束，串口已释放；固件和参数保持原样', end_ms=0)
                continue
            identity = {'firmware': 'synthetic mock, no hardware'} if MOCK else None
            if not MOCK:
                port, identity = prepare()
            task.update(mock=MOCK, identity=identity, mode_context='normal, game application closed',
                        no_live_sensor_reads=True, no_configuration_write_or_reboot=True,
                        snapshot_limit='C0 can return a cached coherent frame; no freshness flag or scan ID',
                        paired_read_limit='C0 and B1 are sequential responses, not one atomic frame',
                        baseline_writer_observed=False, direct_hid_capture=False,
                        physical_truth='user action labels; cues are not exact physical contact timestamps')
            task['telemetry_before'] = telemetry(port)
            ui.update(mock_mode=task['mode'])
            ui.capture_job(port, task, identity['firmware'], reader=read_chain, fields=FIELDS, publish=False)
            task['telemetry_after'] = telemetry(port)
            if port is not None:
                port.close()
                port = None
            task['serial_released_after_capture'] = True
            ui.save_job(task)
            with ui.LOCK:
                ui.STATE['jobs'].append(task)
            ui.update(running=False, phase='done', message='采集完成，串口已释放；请移开双手并确认本组', end_ms=0)
        except Exception as error:
            if port is not None:
                port.close()
                port = None
            if isinstance(task, dict):
                task.update(error=repr(error), completed=False)
                ui.save_job(task)
            ui.update(running=False, blocked=True, phase='error', message='采集失败，已释放串口：' + str(error), end_ms=0)
        finally:
            if port is not None:
                port.close()


def page_html():
    html = Path(previous.__file__).with_suffix('.html').read_text(encoding='utf-8')
    html = html.replace('32寸同板 MPR121 对照', '32寸 MPR 普通模式三组测试')
    start = html.index('<p>按顺序')
    end = html.index('<label for="mode">', start)
    html = html[:start] + ('<p>三组：第9竖条上半区轻触 → 约4秒慢轻触 → 第8、9竖条上下四指轻贴。'
           '开始前双手远离至少30 cm，跟随倒计时；动作有偏差可作废重做。</p>'
           '<p>请先关闭游戏。本页保持普通模式，读取既有输入快照；每组采完自动释放串口，'
           '不更改参数或重启。全部完成后点击“结束测试”。</p>') + html[end:]
    start = html.index('<select id="mode">')
    end = html.index('</select>', start) + len('</select>')
    options = ''.join(f'<option value="{mode}">{i}. {text}</option>' for i, (mode, text) in enumerate(MODES.items(), 1))
    return (html[:start] + '<select id="mode">' + options + '</select>' + html[end:]).replace('结束诊断', '结束测试').encode('utf-8')


class Handler(previous.Handler):
    def do_GET(self):
        if self.path == '/':
            return self.send(200, page_html(), 'text/html; charset=utf-8')
        ui.Handler.do_GET(self)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8884)
    parser.add_argument('--mock', action='store_true')
    parser.add_argument('--probe', action='store_true')
    args = parser.parse_args()
    MOCK = args.mock
    ui.OUT = OUT / ('mock' if MOCK else 'actions')
    ui.OUT.mkdir(parents=True, exist_ok=True)
    if args.probe:
        path = OUT / 'preflight.json'
        if path.exists():
            raise RuntimeError('preflight exists; inspect before retrying')
        port, identity = prepare()
        try:
            report = {'identity': identity, 'frames': [read_chain(port) for _ in range(20)]}
        finally:
            port.close()
        report['serial_released'] = True
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print('PASS 20 C0/B1 paired frames, port closed', flush=True)
    else:
        if list(ui.OUT.glob('*.json')):
            raise RuntimeError('session records already exist; do not overwrite or restart silently')
        ui.ORIGIN = f'http://127.0.0.1:{args.port}'
        ui.MODES.clear()
        ui.MODES.update(MODES)
        ui.STATE.update(jobs=[], blocked=False, mock=MOCK, message='关闭游戏，双手远离至少30厘米，再开始')
        threading.Thread(target=worker, daemon=True).start()
        print('READY', ui.ORIGIN, 'MOCK' if MOCK else 'NORMAL READ-ONLY', flush=True)
        ui.ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
