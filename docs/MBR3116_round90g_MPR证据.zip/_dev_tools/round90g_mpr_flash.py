"""Apply/restore the isolated round88d read-only diagnostic on the 27-inch unit."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import time

import serial.tools.list_ports
import round89_live as live
from round89c_flash_probe import rp2040_drives

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90g_mpr_20261003'
BACKUP = ROOT / '_dev_archive/round90g_mpr27_before_20261003'
SERIAL = '50443405C0B5A81C'
OLD = 'NYANFW1;1.6.5;hw_v1;BID=round88d'
DIAG = 'NYANFW1;1.6.5-diag;hw_v1;BID=round90g-88d'


def connect_checked(signature):
    port, info = live.connect()
    try:
        version = live.version(port)
        if info.serial_number != SERIAL or signature not in version:
            raise RuntimeError(f'target identity mismatch: {info.serial_number} {version}')
        return port, info, version
    except BaseException:
        port.close()
        raise


def read_config_checked(signature):
    expected = (BACKUP / 'controller_config.bin').read_bytes()
    port, info, version = connect_checked(signature)
    entered = False
    try:
        port.write(b'\xb3')
        entered = True
        live.tail(port, 0.3)
        cfg, _ = live.config_read(port)
        if cfg != expected:
            raise RuntimeError('controller configuration differs from preserved original')
        port.write(b'\xb8')
        live.tail(port, 0.15)
        return {'version': version, 'port': info.device, 'controller_config_equal': True,
                'controller_sha256': hashlib.sha256(cfg).hexdigest()}
    finally:
        if entered:
            port.write(b'\xb9')
            port.flush()
        port.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--restore', action='store_true')
    args = parser.parse_args()
    before, after = (DIAG, OLD) if args.restore else (OLD, DIAG)
    uf2 = (BACKUP / 'round88d_original.uf2' if args.restore else
           ROOT / '_dev_tools/round90g_88d_diag_source/build/Nyanithm.uf2')
    expected_hash = ('807aa08a49ac86e2a013fac6d6a194430fbaaf0437071ce2cd9d1556fe609c11' if args.restore else
                     '55f5a3abd27bdbd5334e2710da746a552741e07e8e7de177fee1b6b5a5e45e10')
    path = OUT / ('restore.json' if args.restore else 'flash.json')
    if path.exists():
        raise RuntimeError('this recorded flash attempt already exists; inspect it before retrying')
    report = {'serial': SERIAL, 'before_signature': before, 'after_signature': after,
              'software_bootsel_erases_first_flash_sector': True,
              'restorable_local_original_uf2_preserved': True, 'completed': False}
    def save():
        path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    try:
        data = uf2.read_bytes()
        if hashlib.sha256(data).hexdigest() != expected_hash or not data or len(data) % 512:
            raise RuntimeError('immutable firmware hash/size mismatch')
        addresses = set()
        for pos in range(0, len(data), 512):
            m0, m1, flags, address, size, block, count, family = struct.unpack_from('<8I', data, pos)
            if ((m0, m1, flags, family) != (0x0A324655, 0x9E5D5157, 0x2000, 0xE48BFF56)
                    or size != 256 or block != pos // 512 or count != len(data) // 512
                    or address in addresses or not 0x10000000 <= address < 0x101ff000
                    or struct.unpack_from('<I', data, pos + 508)[0] != 0x0AB16F30):
                raise RuntimeError('bad firmware-only RP2040 UF2')
            addresses.add(address)
        report['uf2_sha256'] = expected_hash
        report['before'] = read_config_checked(before)
        time.sleep(1.5)
        if rp2040_drives():
            raise RuntimeError('unexpected existing BOOTSEL drive')
        port, info, version = connect_checked(before)
        try:
            port.write(b'\xbb\xa5')
            port.flush()
            report['bootsel_sent'] = True
            save()
        finally:
            port.close()
        deadline = time.monotonic() + 20
        drives = []
        while time.monotonic() < deadline:
            drives = rp2040_drives()
            if drives:
                break
            time.sleep(0.25)
        if len(drives) != 1:
            raise RuntimeError(f'expected one newly appearing RP2040 drive: {drives}')
        report['drive'] = str(drives[0])
        shutil.copyfile(uf2, drives[0] / 'Nyanithm.uf2')
        report['uf2_copied'] = True
        save()
        deadline = time.monotonic() + 25
        while time.monotonic() < deadline:
            found = [p for p in serial.tools.list_ports.comports()
                     if p.vid == 0xCAFE and p.pid == 0x4009 and p.serial_number == SERIAL]
            if found:
                break
            time.sleep(0.25)
        else:
            raise RuntimeError('target did not re-enumerate')
        time.sleep(1)
        report['after'] = read_config_checked(after)
        report['completed'] = True
        print(json.dumps(report, indent=2))
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        save()


if __name__ == '__main__':
    main()
