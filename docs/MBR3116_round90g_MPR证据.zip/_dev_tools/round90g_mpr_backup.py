"""Preserve the separately identified 27-inch MPR unit before diagnostics."""
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import time

import round89_live as live

ROOT = Path(__file__).resolve().parents[1]
VARIANT = ROOT / 'Nyanithm_firmware_hw_v1'
OUT = ROOT / '_dev_archive/round90g_mpr27_before_20261003'
SERIAL = '50443405C0B5A81C'
SIGNATURE = 'NYANFW1;1.6.5;hw_v1;BID=round88d'


def identity(port, info):
    if info.serial_number != SERIAL:
        raise RuntimeError('not the separately connected 27-inch unit')
    version = live.version(port)
    if SIGNATURE not in version:
        raise RuntimeError(f'unexpected firmware: {version}')
    port.write(b'\xbc')
    probe = live.exact(port, 6)
    if probe != bytes.fromhex('bc0700040501'):
        raise RuntimeError(f'unexpected native hardware: {probe.hex()}')
    return version, probe.hex()


def main():
    OUT.mkdir(exist_ok=False)
    uf2 = VARIANT / 'build_round88d4/Nyanithm.uf2'
    data = uf2.read_bytes()
    payloads = {}
    for pos in range(0, len(data), 512):
        header = struct.unpack_from('<8I', data, pos)
        m0, m1, flags, address, size, block, count, family = header
        if ((m0, m1, flags, family) != (0x0A324655, 0x9E5D5157, 0x2000, 0xE48BFF56)
                or size != 256 or count != len(data) // 512 or block != pos // 512
                or address in payloads or not 0x10000000 <= address < 0x101ff000
                or struct.unpack_from('<I', data, pos + 508)[0] != 0x0AB16F30):
            raise RuntimeError('invalid RP2040 firmware-only restore UF2')
        payloads[address] = data[pos + 32:pos + 288]
    binary = b''.join(payloads[address] for address in sorted(payloads))
    for expected in (b'Sep  8 2026', b'00:32:53', b'round88d', b'1.6.5', b'hw_v1'):
        if expected not in binary:
            raise RuntimeError(f'local restore artifact does not match firmware identity: {expected!r}')
    shutil.copy2(uf2, OUT / 'round88d_original.uf2')
    subprocess.run(['git', '-C', str(VARIANT), 'archive', '--format=zip',
                    '-o', str(OUT / 'round88d_source.zip'), '123de2a'], check=True)
    subprocess.run(['git', '-C', str(VARIANT), 'archive', '--format=zip',
                    '-o', str(OUT / 'current_source.zip'), 'HEAD'], check=True)
    report = {'usb_serial': SERIAL, 'board': 'separate 27-inch complete unit',
              'restore_uf2_sha256': hashlib.sha256(data).hexdigest(),
              'restore_basis': 'local UF2 matches version/BID/build date and time; not a physical flash dump',
              'persistent_writes': False, 'chip_register_writes': False,
              'exit_reboots_and_reruns_native_startup': True}
    port, info = live.connect()
    entered = False
    try:
        report['version'], report['probe'] = identity(port, info)
        report['port'] = info.device
        port.write(b'\xc4')
        report['raw_before'] = live.tail(port)
        port.write(b'\xbf')
        report['legacy_bf_before'] = live.exact(port, 129).hex()
        port.write(b'\xb3')
        entered = True
        report['config_entry'] = live.tail(port, 0.35)
        cfg, report['config_trailer'] = live.config_read(port)
        (OUT / 'controller_config.bin').write_bytes(cfg)
        check, report['second_trailer'] = live.config_read(port)
        if cfg != check or cfg[2] != 1 or cfg[3] & 2:
            raise RuntimeError('config identity or repeat-read mismatch')
        report['controller_config'] = cfg.hex()
        report['controller_sha256'] = hashlib.sha256(cfg).hexdigest()
        report['repeat_read_equal'] = True
    finally:
        if entered:
            port.write(b'\xb9')
            port.flush()
        port.close()
        (OUT / 'backup.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    time.sleep(1.5)
    port, info = live.connect()
    try:
        report['reboot_version'], report['reboot_probe'] = identity(port, info)
        port.write(b'\xbf')
        report['legacy_bf_after_reboot'] = live.exact(port, 129).hex()
        port.write(b'\xc4')
        report['raw_after'] = live.tail(port)
    finally:
        port.close()
        (OUT / 'backup.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'backup': str(OUT), 'version': report['version'], 'serial': SERIAL,
                      'config_head': list(cfg[:13]), 'config_repeat_equal': True,
                      'restore_sha256': report['restore_uf2_sha256'],
                      'bf_e0_after': [list(bytes.fromhex(report['legacy_bf_after_reboot'])[6 + 41*m + 36:6 + 41*m + 41]) for m in range(3)]}, indent=2))


if __name__ == '__main__':
    main()
