"""Prepare a hash-checked round88d diagnostic source, changing only C6 and BID."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VARIANT = ROOT / 'Nyanithm_firmware_hw_v1'
sys.path.insert(0, str(VARIANT / 'tools'))
from test_touch_snapshot_readers import extract_body


def main():
    target = ROOT / '_dev_tools/round90g_88d_diag_source'
    target.mkdir(exist_ok=False)
    archive = ROOT / '_dev_archive/round90g_mpr27_before_20261003/round88d_source.zip'
    baseline = {}
    with zipfile.ZipFile(archive) as files:
        for name in files.namelist():
            path = (target / name).resolve()
            if not path.is_relative_to(target.resolve()):
                raise RuntimeError('source archive escaped destination')
            if not name.endswith('/'):
                data = files.read(name)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
                baseline[name] = hashlib.sha256(data).hexdigest()
    original = (target / 'src/app_link.cpp').read_text(encoding='utf-8')
    current = (VARIANT / 'src/app_link.cpp').read_text(encoding='utf-8')
    marker = 'else if (cmd == CMD_READ3116CONFIG)'
    old_body, new_body = extract_body(original, marker), extract_body(current, marker)
    if original.count(old_body) != 1:
        raise RuntimeError('ambiguous C6 replacement')
    with (target / 'src/app_link.cpp').open('w', encoding='utf-8', newline='\n') as output:
        output.write(original.replace(old_body, new_body, 1))
    header_path = target / 'include/share/nyanithm_shared.h'
    header = header_path.read_text(encoding='utf-8')
    for old, new in [('NYANITHM_FW_VERSION "1.6.5"', 'NYANITHM_FW_VERSION "1.6.5-diag"'),
                     ('NYANITHM_BUILD_ID "round88d"', 'NYANITHM_BUILD_ID "round90g-88d"')]:
        if header.count(old) != 1:
            raise RuntimeError('unexpected original header')
        header = header.replace(old, new, 1)
    with header_path.open('w', encoding='utf-8', newline='\n') as output:
        output.write(header)
    actual = {name: hashlib.sha256((target / name).read_bytes()).hexdigest() for name in baseline}
    changed = [name for name in baseline if baseline[name] != actual[name]]
    if set(changed) != {'src/app_link.cpp', 'include/share/nyanithm_shared.h'}:
        raise RuntimeError(f'unexpected backport changes: {changed}')
    report = {'git_baseline': '123de2a', 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'changed_files': changed, 'unchanged_files': len(baseline) - len(changed),
              'c6_body_sha256': hashlib.sha256(new_body.encode()).hexdigest(),
              'original_sha256': baseline, 'diagnostic_sha256': actual,
              'temporary_diagnostic_only': True,
              'version': 'NYANFW1;1.6.5-diag;hw_v1;BID=round90g-88d'}
    (ROOT / '_dev_tools/round90g_mpr_20261003/backport_manifest.json').write_text(
        json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: report[key] for key in ('git_baseline', 'changed_files', 'unchanged_files', 'c6_body_sha256')}, indent=2))


if __name__ == '__main__':
    main()
