"""Archive round90g evidence and verify offline replay in a fresh directory.

No serial access or firmware writes. Live scripts are archived for provenance,
not executed by this packaging entry point.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile


ROOT = Path(__file__).resolve().parents[1]
VARIANT = ROOT / 'Nyanithm_firmware_hw_v1'
OUT = ROOT / '_dev_tools/round90g_mpr_20261003'
PACKAGE = VARIANT / 'docs/MBR3116_round90g_MPR证据.zip'
VERIFY = ROOT / '_dev_tools/round90g_package_verify'

CHANGELOG = '''### 20261003 round90g: Add native MPR diagnostics and prepare same-board comparison

- **原生接口**：配置模式C6额外受理MPR 0x5A–0x5C，以SDK既有I2C入口读取43B一致信号窗及独立85B控制窗，精确字节数校验、250ms提交/断连界限及USB/看门狗泵。旧MBR分支不变，不Stop/校准/写寄存器值；原配置模式扫描和软件基线处理仍运行。主维护beta11仅编译，未刷32寸。
- **实机证据**：27寸独立MPR整机使用基于Git123de2a/round88d、仅C6与版本宏变化的最小诊断版。三片36组空闲/72组悬空及测试页四组2995条完整0x5A记录确认逐电极CDC/CDT实际增益；快触实际响应ELE8，原选ELE7不代表该接触。固定窗快触148/187 ON，晚窗85/85；慢触晚窗基线下移且0/85 ON，需查基线吸收，不能直接判整机漏触（另外两片/HID未采、无逐样本接触真值）。未提出新抗悬空门限或烧MBR表。
- **恢复/验证**：27寸已恢复原round88d及相等控制器配置、串口关闭；原版UF2为本地版本/构建时间匹配产物，非物理Flash镜像。32寸仍beta10。生产C6测试28/28、迁移153/153、读者28/28、离线24/24和两版SDK2.2.0构建通过；独立只读复核无阻断问题。临时页Mock与实机数据隔离，证据包逐文件哈希并解压复跑；下一步同32寸PCB三片MPR对照，先定位电极、覆盖三片并检查HID。MBR隔空尚未解决，见docs/MBR3116_round90g_MPR实机参数与同板对照准备.md。本地提交，不push。

'''

README = '''# round90g MPR native evidence

本包是本地诊断证据，未证明MBR隔空根治或严格接触输入。

27寸独立MPR整机：50443405C0B5A81C；临时最小诊断round90g-88d完成四组后已恢复round88d，配置相等。32寸5303284739002C9C仍为beta10/round90e，未迁移模块。原版UF2由本地版本/BID/构建时间匹配选定，不是物理Flash镜像。

保留目录结构解压到一个新目录，先核对manifest.json内各文件SHA256，再运行以下两个入口；它们只读取本包文件，无串口、网络、设备访问：

```powershell
& 'C:\\Users\\HP\\AppData\\Local\\Python\\pythoncore-3.14-64\\python.exe' .\\_dev_tools\\round90g_analyze_mpr.py
& 'C:\\Users\\HP\\AppData\\Local\\Python\\pythoncore-3.14-64\\python.exe' .\\_dev_tools\\round90g_analyze_page.py
```

其他机器使用可用Python 3启动器；分析仅需标准库。重算的analysis.json/page_analysis.json应逐字节等于随包产物。tools/test_native_register_dump.py额外需要可用C++17编译器，提取随包真实生产C6路径；仅编译/运行主机桩，不访问设备。

idle和finger_hover5包含三片顺序读取；page四组只包含0x5A整片。0x00–0x2A为同片43B一致信号窗，后85B及各片不同步；主机样本不是独立原生扫描。基线低2位未知，差值为区间。用户确认针对整次动作，5mm为估计高度，未记录精确接触时刻或HID游戏输入。基线软件处理仍运行，未写标志仅指主机命令/新增读取分支。

四组2995条数据：实际轻触主响应ELE8，原代表ELE7无本轮接触代表性；分析ELE8属探索。6–11.5秒窗沿用旧分析，9–11.5秒另行披露。慢触基线下移/该片无ON需进一步核查，不能直接判整机漏触。Mock数据未收入本包。

artifacts内UF2仅为归档。archived现场脚本及依赖供追溯，其地址/串号/绝对构建路径绑定当时设备，**不属于自动复跑步骤，不应直接用于下一次32寸试验**。后台页已结束诊断。约21.8MB的两个当前源码备份ZIP保留在原工作区，manifest记录哈希和HEAD；原round88d源码ZIP随包保留。SDK/工具链不随包分发。

两份构建日志及已有测试日志随包保留；153迁移与28生产C6的初次命令结果来自本轮执行，validation_summary.json明确记录该来源。打包后的实际解压、离线逐字节复跑及C6重新编译结果见独立package_check.json（证据包旁）。
'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def local_import_dependencies(start):
    pending = list(start)
    found = set()
    while pending:
        path = pending.pop()
        if path in found:
            continue
        found.add(path)
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        names = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names.extend(item.name.split('.')[0] for item in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                names.append(node.module.split('.')[0])
        for name in names:
            dependency = ROOT / '_dev_tools' / (name + '.py')
            if dependency.is_file():
                pending.append(dependency)
    return found


def main():
    if PACKAGE.exists() or VERIFY.exists():
        raise FileExistsError('Fresh package and verification directory required')
    changelog = VARIANT / '更新日志_固件.md'
    raw = changelog.read_bytes()
    bom = raw.startswith(b'\xef\xbb\xbf')
    old = raw.decode('utf-8-sig').replace('\r\n', '\n')
    if not old.startswith(CHANGELOG.split('\n', 1)[0]):
        changelog.write_bytes((b'\xef\xbb\xbf' if bom else b'') + (CHANGELOG + old).encode('utf-8'))

    validation = {
        'origin': 'summary of completed tool executions in this round; not new device measurements',
        'native_c6_production_scenarios': 28,
        'touch_migration_scenarios': 153,
        'production_snapshot_reader_scenarios': 28,
        'offline_tool_tests': 24,
        'firmware_pipeline_changed': False,
        'independent_review': {
            'agent': '/root/review_round90g',
            'scope': 'read-only diff, native interface, tests and 61-file original-source backport comparison',
            'blocking_findings': 0,
            'hardware_access': False,
            'summary_captured_by_primary_agent': True,
            'caveats': ['250ms bounds CDC submission rather than host receipt',
                        'original config-mode scanning/software baseline processing still runs',
                        'host must discard partial responses and reset the session with hands away']},
        'deployment': {'main_beta11': 'compiled only; not installed on 32-inch',
                       'mpr27_diagnostic': 'used then restored to round88d',
                       'game_hid': 'not validated in this round'},
    }
    (OUT / 'validation_summary.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8')

    files = {}

    def add(path, role, archive_name=None):
        if not path.is_file():
            raise FileNotFoundError(path)
        name = archive_name or path.relative_to(ROOT).as_posix()
        if name in files:
            return
        files[name] = {'data': path.read_bytes(), 'role': role}

    for path in OUT.rglob('*'):
        if not path.is_file() or 'page_mock' in path.parts:
            continue
        if path.name in {'server_pids.json', 'mock_server.log', 'mock_server_errors.log'} or not path.stat().st_size:
            continue
        add(path, 'physical evidence / analysis / build and validation provenance')
    backup_dirs = ['round90g_before_20261003', 'round90g_mpr27_before_20261003']
    excluded = []
    for dirname in backup_dirs:
        for path in (ROOT / '_dev_archive' / dirname).iterdir():
            if path.name in {'source.zip', 'current_source.zip'}:
                excluded.append({'path': path.relative_to(ROOT).as_posix(), 'size': path.stat().st_size,
                                 'sha256': digest(path.read_bytes()), 'git_baseline': '41d2291',
                                 'reason': 'large current source archive retained at original workspace'})
            elif path.is_file():
                add(path, 'identity, configuration and restoration backup')
    for name in ('round90g_analyze_mpr.py', 'round90g_analyze_page.py'):
        add(ROOT / '_dev_tools' / name, 'pure offline replay entry point')
    scripts = local_import_dependencies([
        ROOT / '_dev_tools' / name for name in
        ('round90g_mpr_page.py', 'round90g_mpr_capture.py', 'round90g_mpr_flash.py',
         'round90g_mpr_identify.py', 'round90g_mpr_backup.py', 'round90g_prepare_backport.py')])
    for path in scripts:
        add(path, 'archived live helper/dependency; do not automatically execute')
    for name in ('round90g_mpr_page.html', 'round90g_finalize_page.py', 'round90g_build_backport.ps1',
                 'round90g_finalize_evidence.py'):
        add(ROOT / '_dev_tools' / name, 'archived live/build/packaging provenance')
    for name in ('decode_mpr121_snapshot.py', 'test_native_register_dump.py',
                 'test_touch_snapshot_readers.py', 'elf2uf2.py'):
        add(VARIANT / 'tools' / name, 'native decoder / actual-production host test / build converter')
    for name in ('src/app_link.cpp', 'include/share/nyanithm_shared.h',
                 'docs/MBR3116_round90g_MPR实机参数与同板对照准备.md',
                 'docs/MBR3116_算法与驱动重构计划_20261003.md'):
        add(VARIANT / name, 'current production source or experiment plan')
    add(VARIANT / 'build_round90g/Nyanithm.uf2', 'compiled main beta11; not installed on 32-inch',
        'artifacts/main_beta11_round90g.uf2')
    add(ROOT / '_dev_tools/round90g_88d_diag_source/build/Nyanithm.uf2',
        'temporary 27-inch original-algorithm diagnostic; subsequently restored',
        'artifacts/mpr27_round90g_88d_diag.uf2')

    manifest = {'round': 'round90g', 'excluded_large_local_backups': excluded,
                'files': {name: {'sha256': digest(item['data']), 'size': len(item['data']), 'role': item['role']}
                          for name, item in sorted(files.items())}}
    # Textual instructions are also hashed; manifest cannot hash itself.
    files['README.md'] = {'data': README.encode('utf-8'), 'role': 'scope and offline replay instructions'}
    manifest['files']['README.md'] = {'sha256': digest(files['README.md']['data']),
                                      'size': len(files['README.md']['data']), 'role': files['README.md']['role']}
    with zipfile.ZipFile(PACKAGE, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, item in sorted(files.items()):
            archive.writestr(name, item['data'])
        archive.writestr('manifest.json', json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')

    verify_root = VERIFY.resolve()
    if not verify_root.is_relative_to((ROOT / '_dev_tools').resolve()):
        raise ValueError('Verification directory outside intended workspace')
    VERIFY.mkdir()
    with zipfile.ZipFile(PACKAGE) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC check failed')
        if set(archive.namelist()) != set(manifest['files']) | {'manifest.json'}:
            raise ValueError('Unexpected ZIP membership')
        for name, item in manifest['files'].items():
            data = archive.read(name)
            if digest(data) != item['sha256'] or len(data) != item['size']:
                raise ValueError('ZIP payload hash mismatch: ' + name)
        for name in archive.namelist():
            if not (VERIFY / name).resolve().is_relative_to(verify_root):
                raise ValueError('ZIP traversal: ' + name)
        archive.extractall(VERIFY)

    replay = []
    for script, output in [('round90g_analyze_mpr.py', 'analysis.json'),
                           ('round90g_analyze_page.py', 'page_analysis.json')]:
        original = (OUT / output).read_bytes()
        result = subprocess.run([sys.executable, str(VERIFY / '_dev_tools' / script)],
                                cwd=VERIFY, capture_output=True, text=True, encoding='utf-8')
        if result.returncode or (VERIFY / '_dev_tools/round90g_mpr_20261003' / output).read_bytes() != original:
            raise RuntimeError('Offline replay mismatch: ' + script + '\n' + result.stderr)
        replay.append({'script': script, 'returncode': result.returncode,
                       'output_byte_equal': True, 'output_sha256': digest(original)})
    native_test = subprocess.run([sys.executable, str(VERIFY / 'Nyanithm_firmware_hw_v1/tools/test_native_register_dump.py')],
                                 cwd=VERIFY, capture_output=True, text=True, encoding='utf-8', errors='replace')
    if native_test.returncode or '28/28 native-register scenarios passed' not in native_test.stdout:
        raise RuntimeError('Extracted production C6 test failed\n' + native_test.stdout + native_test.stderr)
    check = {'zip': PACKAGE.name, 'size': PACKAGE.stat().st_size, 'sha256': digest(PACKAGE.read_bytes()),
             'payload_hashes_verified': len(manifest['files']), 'zip_crc_ok': True,
             'offline_replay': replay, 'fresh_extracted_production_c6_test': {
                 'returncode': native_test.returncode, 'stdout': native_test.stdout, 'stderr': native_test.stderr}}
    check_path = PACKAGE.with_suffix('.package_check.json')
    check_path.write_text(json.dumps(check, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in check.items() if key != 'fresh_extracted_production_c6_test'},
                     indent=2, ensure_ascii=False))
    print('Fresh extracted production C6: 28/28 passed')


if __name__ == '__main__':
    main()
