"""Read coherent MPR signal groups and actual charge configuration via config C6."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

import round89_live as live
from round90g_mpr_flash import BACKUP, DIAG, OUT, connect_checked

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Nyanithm_firmware_hw_v1/tools'))
from decode_mpr121_snapshot import decode


def capture(destination, rounds, addresses, label, wait_for_clear):
    expected = (BACKUP / 'controller_config.bin').read_bytes()
    destination.mkdir(exist_ok=False)
    port, info, version = connect_checked(DIAG)
    report = {'version': version, 'usb_serial': info.serial_number, 'port': info.device,
              'board': 'separate 27-inch complete unit', 'action_label': label,
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'timing_scope': 'host roundtrip, includes split command gap and USB; not MCU I2C start/end or scan number',
              'firmware_idle_processing_preserved': True,
              'host_configuration_write_commands': False,
              'native_signal_window': '0x00..0x2A single 43-byte repeated-START transaction per chip',
              'control_window': '0x2B..0x7F separate 85-byte read; chips and windows not simultaneous',
              'samples': [], 'complete': False}
    entered = False
    clean = False
    try:
        port.write(b'\xb3')
        entered = True
        report['entry'] = live.tail(port, 0.3)
        cfg, _ = live.config_read(port)
        if cfg != expected:
            raise RuntimeError('original controller configuration changed')
        report['controller_config_equal'] = True
        report['controller_sha256'] = hashlib.sha256(cfg).hexdigest()
        for sequence in range(rounds):
            for address in addresses:
                started = time.perf_counter()
                live.split(port, 0xC6, [address])
                payload_sent = time.perf_counter()
                # Any text failure, short read or timeout aborts the ENTIRE
                # session. Never drain-and-retry to assemble a bogus next image.
                data = live.exact(port, 128, 2)
                ended = time.perf_counter()
                document = {'schema': 'mpr121-register-snapshot-v1', 'origin': 'hardware-readback',
                            'registers': {f'0x{i:02X}': b for i, b in enumerate(data)}}
                decoded = decode(document)
                row = {'sequence': sequence, 'address': address, 'host_start_s': started,
                       'host_payload_sent_s': payload_sent, 'host_end_s': ended,
                       'response_bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                       'hex': data.hex(), 'snapshot': document, 'decoded': decoded}
                report['samples'].append(row)
                (destination / 'capture.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
            time.sleep(0.05)
        check, _ = live.config_read(port)
        report['controller_equal_after'] = check == expected
        if check != expected:
            raise RuntimeError('controller configuration changed during capture')
        report['complete'] = True
        clean = True
        if wait_for_clear:
            # EXIT reboots and reruns AutoConfig / startup calibration. Never
            # do that while the user is still holding the measured posture.
            print('CAPTURE_DONE_MOVE_HAND_AWAY; waiting for confirmed CLEAR', flush=True)
            cleared = threading.Event()
            def receive_clear():
                for line in sys.stdin:
                    if line.strip() == 'CLEAR':
                        cleared.set()
                        return
            threading.Thread(target=receive_clear, daemon=True).start()
            last_keepalive = time.monotonic()
            while not cleared.wait(0.05):
                if time.monotonic() - last_keepalive > 10:
                    port.write(b'\xc3')
                    port.flush()
                    last_keepalive = time.monotonic()
            report['hands_clear_confirmed_before_exit_reboot'] = True
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        if entered:
            try:
                port.write(b'\xb9')
                port.flush()
                report['exit_reboot_sent'] = True
            except Exception as error:
                report['exit_error'] = repr(error)
        port.close()
        report['session_closed'] = True
        report['ended_utc'] = datetime.now(timezone.utc).isoformat()
        (destination / 'capture.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    if clean:
        summaries = []
        for address in addresses:
            rows = [r for r in report['samples'] if r['address'] == address]
            first = rows[0]['decoded']
            summaries.append({'address': hex(address), 'observations': len(rows), 'global': first['global'],
                              'ecr': first['ecr'], 'debounce': first['debounce'], 'autoconfig': first['autoconfig'],
                              'active_cdc_uA': [e['effective_cdc_uA'] for e in first['electrodes'][:12]],
                              'active_cdt_us': [e['effective_cdt_us'] for e in first['electrodes'][:12]],
                              'touch_threshold': [e['touch_threshold'] for e in first['electrodes'][:12]],
                              'native_status': [int.from_bytes(bytes.fromhex(r['hex'])[:2], 'little') for r in rows],
                              'oor_status': [bytes.fromhex(r['hex'])[2:4].hex() for r in rows]})
        (destination / 'summary.json').write_text(json.dumps(summaries, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(summaries, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', default='idle')
    parser.add_argument('--rounds', type=int, default=12)
    parser.add_argument('--addresses', default='5a,5b,5c')
    parser.add_argument('--label', default='user confirmed hands and objects >=20cm away from 27-inch board')
    parser.add_argument('--wait-for-clear', action='store_true',
                        help='keep config session alive after sampling; stdin CLEAR requires user hands-clear confirmation')
    args = parser.parse_args()
    addresses = tuple(int(a, 16) for a in args.addresses.split(','))
    if not 1 <= args.rounds <= 2000 or any(a not in (0x5A, 0x5B, 0x5C) for a in addresses):
        raise ValueError('invalid bounded MPR capture request')
    if not args.name or Path(args.name).name != args.name or args.name in ('.', '..'):
        raise ValueError('capture name must be one local directory component')
    capture(OUT / args.name, args.rounds, addresses, args.label, args.wait_for_clear)


if __name__ == '__main__':
    main()
