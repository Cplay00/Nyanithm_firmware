from pathlib import Path

root = Path(__file__).resolve().parent
page = (root / 'round89h_timed_capture.html').read_text(encoding='utf-8')
replacements = {
    '触摸对照采样': 'MPR121 原生触摸对照',
    '滑条中央第17格附近': '从左数第9个竖条的上半区（第17格附近）',
    '<option value="finger_hover3">食指悬空3 mm</option>': '<option value="slow_contact">食指约4秒慢轻触</option>',
    '<button id="finish">结束诊断</button>': '<button id="finish">双手已移开，结束诊断</button>',
    '本组按提示完成': '动作正确，双手已移开',
    '动作有偏差，作废': '有偏差，双手已移开并作废',
    "$('start').disabled=state.running||unconfirmed;": "$('start').disabled=state.running||state.blocked||unconfirmed;",
    "$('finish').disabled=state.running;": "$('finish').disabled=state.running||state.phase==='closed';",
    "await post('/finish',{})": "await post('/finish',{hands_away:true})",
    'id:state.jobs.at(-1).id,valid}': 'id:state.jobs.at(-1).id,valid,hands_away:true}',
    "$('message').textContent=state.message;": "$('message').textContent=(state.mock?'【模拟，无设备】':'')+state.message;",
}
for before, after in replacements.items():
    if before not in page:
        raise ValueError('missing timed-page anchor: ' + before)
    page = page.replace(before, after)
with (root / 'round90g_mpr_page.html').open('w', encoding='utf-8', newline='\n') as output:
    output.write(page)
print('Updated', len(replacements), 'timed-page anchors')
