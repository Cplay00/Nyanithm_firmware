"""Reuse the timed research page with read-only, coherent MPR C6 samples."""
import argparse
import hashlib
import json
from pathlib import Path
import queue
import threading
import time

import round89h_timed_capture as ui
import round89_live as live
from round90g_mpr_flash import BACKUP, DIAG, OUT, connect_checked

MOCK = False
PAGE_OUT = OUT / 'page'
FIELDS = ['elapsed_s', 'phase', 'phase_valid', 'address', 'electrode', 'filtered',
          'baseline', 'delta', 'delta_upper', 'threshold', 'native_on', 'native_status',
          'oor_status', 'register_hex', 'error']
CURRENT_PHASE = ''


def read_mpr(port):
    if MOCK:
        time.sleep(0.03)
        registers = bytearray(128)
        delta = 25 if ui.STATE['phase'] == 'hold' else 0
        registers[0] = 0x80 if delta else 0
        registers[0x12:0x14] = (720 - delta).to_bytes(2, 'little')
        registers[0x25] = 180
        registers[0x4F] = 15
        registers[0x5C:0x5F] = bytes([0x10, 0x28, 0xCC])
        data = bytes(registers)
    else:
        live.split(port, 0xC6, [0x5A])
        data = live.exact(port, 128, 2)
    # Failed / short responses abort the whole job; no same-session retry.
    if data[0x13] & ~3 or data[2:4] != b'\0\0' or data[1] & 0x80:
        raise RuntimeError('invalid filtered/OOR/overcurrent evidence')
    filtered = int.from_bytes(data[0x12:0x14], 'little')
    baseline = data[0x25] << 2
    status = int.from_bytes(data[:2], 'little')
    return {'address': 0x5A, 'electrode': 7, 'filtered': filtered, 'baseline': baseline,
            'delta': baseline - filtered, 'delta_upper': baseline + 3 - filtered,
            'threshold': data[0x4F], 'native_on': int(bool(status & 0x80)),
            'native_status': status, 'oor_status': data[2:4].hex(),
            'register_hex': data.hex(), 'error': ''}


def worker():
    port = None
    firmware = 'synthetic mock, no hardware'
    heartbeat = 0
    expected = (BACKUP / 'controller_config.bin').read_bytes()
    while True:
        try:
            task = ui.TASKS.get(timeout=0.2)
        except queue.Empty:
            if port is not None and time.perf_counter() - heartbeat > 10:
                try:
                    port.write(b'\xc3')
                    port.flush()
                    heartbeat = time.perf_counter()
                except Exception as error:
                    port.close()
                    port = None
                    ui.update(blocked=True, phase='error', message='请移开双手并结束诊断：' + str(error))
            continue
        try:
            if task == 'finish':
                if port is not None:
                    # The finish button explicitly confirms hands are away.
                    port.write(b'\xb9')
                    port.flush()
                    port.close()
                    port = None
                (PAGE_OUT / 'session_closed.json').write_text(json.dumps(
                    {'hands_away_confirmed_by_finish_button': True, 'exit_reboot_sent': not MOCK,
                     'mock': MOCK, 'closed_utc_epoch': time.time()}, indent=2), encoding='utf-8')
                ui.update(running=False, blocked=True, phase='closed', message='采样已结束，设备已退出诊断模式', end_ms=0)
                continue
            if port is None and not MOCK:
                ui.update(phase='preparing', message='设备准备中，请保持双手远离', end_ms=0)
                port, info, firmware = connect_checked(DIAG)
                port.write(b'\xb3')
                live.tail(port, 0.3)
                cfg, _ = live.config_read(port)
                if cfg != expected:
                    raise RuntimeError('controller configuration changed')
                task['usb_serial'] = info.serial_number
            task.update(mock=MOCK, origin='synthetic-test' if MOCK else 'hardware-readback',
                        board='separate 27-inch complete unit', controller_config=expected.hex(),
                        native_signal_group='43 bytes 0x00..0x2A single repeated-START read',
                        control_group='separate 85 bytes 0x2B..0x7F',
                        action_scope='whole user-confirmed action, phase cues are not physical contact timestamps',
                        host_configuration_write_commands=False,
                        original_firmware_idle_baseline_processing_preserved=True)
            ui.capture_job(port, task, firmware, reader=read_mpr, fields=FIELDS, publish=False)
            if port is not None:
                check, _ = live.config_read(port)
                task['controller_equal_after'] = check == expected
                if check != expected:
                    raise RuntimeError('controller configuration changed during capture')
            else:
                task['controller_equal_after'] = True
            ui.save_job(task)
            with ui.LOCK:
                ui.STATE['jobs'].append(task)
            ui.update(running=False, phase='done', message='采完了，请保持双手远离，并确认本组动作', end_ms=0)
            heartbeat = time.perf_counter()
        except Exception as error:
            if isinstance(task, dict):
                task.update(error=repr(error), completed=False)
                ui.save_job(task)
            # Keep the failed session alive until the user explicitly confirms
            # hands away with Finish. Do not reboot into calibration mid-pose.
            ui.update(running=False, blocked=True, phase='error',
                      message='采样失败；请移开双手，再点击结束诊断：' + str(error), end_ms=0)
            print('ERROR', repr(error), flush=True)


class Handler(ui.Handler):
    def do_GET(self):
        if self.path == '/':
            return self.send(200, Path(__file__).with_suffix('.html').read_bytes(), 'text/html; charset=utf-8')
        super().do_GET()

    def do_POST(self):
        if self.headers.get('Origin') != ui.ORIGIN:
            return self.send(403, {'error': 'origin rejected'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 2048:
                raise ValueError('invalid request size')
            payload = json.loads(self.rfile.read(size))
            if self.path == '/start':
                mode = payload.get('mode')
                if mode not in ui.MODES:
                    raise ValueError('invalid mode')
                with ui.LOCK:
                    pending = ui.STATE['jobs'] and ui.STATE['jobs'][-1]['user_confirmed'] is None
                    if ui.STATE['running'] or ui.STATE['blocked'] or pending:
                        return self.send(409, {'error': '请先完成或确认当前采样'})
                    ui.STATE.update(running=True, phase='queued', message='请保持双手远离')
                    identifier = f'{time.time_ns()}_{mode}'
                ui.TASKS.put({'id': identifier, 'mode': mode})
                return self.send(200, {'id': identifier})
            if self.path == '/label':
                with ui.LOCK:
                    job = next((j for j in ui.STATE['jobs'] if j['id'] == payload.get('id')), None)
                    if (job is None or not isinstance(payload.get('valid'), bool)
                            or payload.get('hands_away') is not True or ui.STATE['running']):
                        raise ValueError('invalid action/hands-clear label')
                    job.update(user_confirmed=payload['valid'], hands_away_confirmed=True)
                    ui.save_job(job)
                return self.send(200, {'saved': True})
            if self.path == '/finish':
                if payload.get('hands_away') is not True:
                    raise ValueError('hands-clear confirmation required')
                with ui.LOCK:
                    if ui.STATE['running']:
                        return self.send(409, {'error': '请等当前采样结束'})
                    ui.STATE['running'] = True
                ui.TASKS.put('finish')
                return self.send(200, {'closing': True})
            self.send(404, {'error': 'not found'})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.send(400, {'error': str(error)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8878)
    parser.add_argument('--mock', action='store_true')
    args = parser.parse_args()
    MOCK = args.mock
    PAGE_OUT = OUT / ('page_mock' if MOCK else 'page')
    PAGE_OUT.mkdir(exist_ok=True)
    ui.OUT = PAGE_OUT
    ui.ORIGIN = f'http://127.0.0.1:{args.port}'
    ui.MODES['slow_contact'] = '食指用约4秒缓慢靠近直到轻触，再保持贴面'
    ui.STATE.update(blocked=False, mock=MOCK, message='请将双手移离至少30厘米，再开始')
    threading.Thread(target=worker, daemon=True).start()
    print('READY', ui.ORIGIN, 'MOCK' if MOCK else '27-inch MPR diagnostic', flush=True)
    ui.ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
