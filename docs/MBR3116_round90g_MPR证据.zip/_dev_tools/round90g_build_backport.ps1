$ErrorActionPreference = 'Stop'
$taskSource = 'D:\Opencode,OCCM\Items\Nyanithm_Firmware\_dev_tools\round90g_88d_diag_source'
$taskJunction = 'D:\Nyanithm_build\round90g_88d_diag'
if (-not (Test-Path -LiteralPath $taskJunction)) {
    New-Item -ItemType Junction -Path $taskJunction -Target $taskSource | Out-Null
}
$resolvedTarget = (Get-Item -LiteralPath $taskJunction).Target
if ($resolvedTarget -ne $taskSource) { throw 'Unexpected diagnostic junction target' }
$env:PICO_SDK_PATH = 'D:\pico-sdk'
$env:PATH = 'C:\Program Files\Git\mingw64\bin;C:\Program Files\LLVM\bin;C:\Users\HP\.pico-sdk\toolchain\14_2_Rel1\bin;C:\Users\HP\AppData\Local\Programs\Python\Python312\Scripts;' + $env:PATH
$env:CC = 'C:\Program Files\LLVM\bin\clang.exe'
$env:CXX = 'C:\Program Files\LLVM\bin\clang++.exe'
& cmake -S $taskJunction -B "$taskJunction\build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DPICO_NO_PICOTOOL=1
if ($LASTEXITCODE -ne 0) { throw 'Diagnostic CMake failed' }
& ninja -C "$taskJunction\build" -j4 Nyanithm.elf
if ($LASTEXITCODE -ne 0) { throw 'Diagnostic Ninja failed' }
& arm-none-eabi-objcopy -Obinary "$taskJunction\build\Nyanithm.elf" "$taskJunction\build\Nyanithm.bin"
if ($LASTEXITCODE -ne 0) { throw 'Diagnostic objcopy failed' }
$taskConverter = 'D:\Opencode,OCCM\Items\Nyanithm_Firmware\Nyanithm_firmware_hw_v1\tools\elf2uf2.py'
$taskPython = 'C:\Users\HP\AppData\Local\Programs\Python\Python312\python.exe'
$taskProcess = Start-Process -FilePath $taskPython -ArgumentList "`"$taskConverter`"" -WorkingDirectory "$taskJunction\build" -RedirectStandardOutput "$taskJunction\build\Nyanithm.uf2" -RedirectStandardError "$taskJunction\build\uf2_conversion.log" -WindowStyle Hidden -Wait -PassThru
if ($taskProcess.ExitCode -ne 0) { throw 'Diagnostic UF2 conversion failed' }
Get-Content -LiteralPath "$taskJunction\build\uf2_conversion.log"
Get-Item -LiteralPath "$taskJunction\build\Nyanithm.uf2" | Select-Object FullName,Length
Get-FileHash -LiteralPath "$taskJunction\build\Nyanithm.uf2" -Algorithm SHA256
