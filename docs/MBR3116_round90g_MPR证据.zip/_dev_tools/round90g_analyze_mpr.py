"""Summarize native MPR evidence, retaining baseline precision and action scope."""
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90g_mpr_20261003'


def main():
    result = {}
    for name in ('idle', 'finger_hover5', 'finger_contact'):
        path = OUT / name / 'capture.json'
        if not path.exists():
            continue
        capture = json.loads(path.read_text(encoding='utf-8'))
        if not capture.get('complete') or not capture.get('controller_equal_after'):
            raise ValueError(f'incomplete or changed configuration: {name}')
        summary = {'action_label': capture['action_label'], 'samples': len(capture['samples']),
                   'all_same_firmware': len({r['version'] for r in [capture]}) == 1,
                   'chips': []}
        for address in sorted({r['address'] for r in capture['samples']}):
            rows = [r for r in capture['samples'] if r['address'] == address]
            raw = [bytes.fromhex(r['hex']) for r in rows]
            first = rows[0]['decoded']
            if any(data[2:4] != bytes(2) or data[1] & 0x80 for data in raw):
                raise ValueError('out-of-range/autoconfig/overcurrent errors invalidate signal comparison')
            channels = []
            for e in range(12):
                records = [r['decoded']['electrodes'][e] for r in rows]
                if any(record['internal_delta_range_if_same_instant'] is None for record in records):
                    raise ValueError('bad signal byte cannot enter summary')
                floors = [record['internal_delta_range_if_same_instant'][0] for record in records]
                ceilings = [record['internal_delta_range_if_same_instant'][1] for record in records]
                filtered = [record['filtered_counts'] for record in records]
                baseline = [record['visible_baseline_floor_counts'] for record in records]
                touched = [bool(int.from_bytes(data[:2], 'little') & (1 << e)) for data in raw]
                channels.append({'electrode': e, 'delta_low_min': min(floors), 'delta_high_max': max(ceilings),
                                 'delta_floor_median': statistics.median(floors),
                                 'filtered_min': min(filtered), 'filtered_max': max(filtered),
                                 'baseline_floor_min': min(baseline), 'baseline_floor_max': max(baseline),
                                 'native_on_observations': sum(touched), 'observations': len(rows),
                                 'threshold': records[0]['touch_threshold'],
                                 'release': records[0]['release_threshold'],
                                 'effective_cdc_uA': records[0]['effective_cdc_uA'],
                                 'effective_cdt_us': records[0]['effective_cdt_us']})
            chip = {'address': hex(address), 'observations': len(rows), 'global': first['global'],
                    'ecr': first['ecr'], 'debounce': first['debounce'], 'autoconfig': first['autoconfig'],
                    'controls_byte_equal_across_observations': len({data[43:] for data in raw}) == 1,
                    'baseline_filters': first['baseline_filters'],
                    'native_on_samples': sum(any(data[:2]) for data in raw),
                    'channels': channels,
                    'host_roundtrip_ms': {'min': min((r['host_end_s'] - r['host_start_s']) * 1000 for r in rows),
                                         'max': max((r['host_end_s'] - r['host_start_s']) * 1000 for r in rows)}}
            summary['chips'].append(chip)
        result[name] = summary
    (OUT / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    for name, summary in result.items():
        print(name, 'observations', summary['samples'])
        for chip in summary['chips']:
            e7 = chip['channels'][7]
            print(chip['address'], 'controls_stable', chip['controls_byte_equal_across_observations'],
                  'CDC_range', [min(e['effective_cdc_uA'] for e in chip['channels']), max(e['effective_cdc_uA'] for e in chip['channels'])],
                  'CDT', sorted({e['effective_cdt_us'] for e in chip['channels']}),
                  'native_ON', chip['native_on_samples'], 'ELE7', e7)


if __name__ == '__main__':
    main()
