"""Analyze confirmed MPR timed-page actions with a fixed, declared hold window."""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
BACKUP = ROOT / '_dev_archive/round90g_mpr27_before_20261003'
OUT = ROOT / '_dev_tools/round90g_mpr_20261003'
DIAG = 'NYANFW1;1.6.5-diag;hw_v1;BID=round90g-88d'


def main():
    expected = (BACKUP / 'controller_config.bin').read_bytes().hex()
    result = {'hold_window_s': [6, 11.5], 'window_basis': 'same declared window as round90f; no fitted new cutoffs',
              'action_labels_are_whole_job_not_exact_contact_times': True, 'jobs': []}
    for path in sorted((OUT / 'page').glob('*_*.json')):
        if path.name == 'session_closed.json':
            continue
        job = json.loads(path.read_text(encoding='utf-8'))
        if (not job.get('completed') or job.get('user_confirmed') is not True or job.get('mock')
                or job.get('origin') != 'hardware-readback' or not job.get('controller_equal_after')
                or job.get('controller_config') != expected or DIAG not in job.get('firmware', '')):
            raise ValueError('unqualified timed action: ' + path.name)
        csv_path = path.with_suffix('.csv')
        rows = []
        with csv_path.open(encoding='utf-8', newline='') as stream:
            for row in csv.DictReader(stream):
                elapsed = float(row['elapsed_s'])
                if not math.isfinite(elapsed) or row['error']:
                    raise ValueError('invalid time or native read error')
                data = bytes.fromhex(row['register_hex'])
                if len(data) != 128 or int(row['address']) != 0x5A or int(row['electrode']) != 7:
                    raise ValueError('incorrect native response identity/length')
                if data[2:4] != bytes(2) or data[1] & 0x80:
                    raise ValueError('native OOR/overcurrent invalidates group')
                filtered = int.from_bytes(data[0x12:0x14], 'little')
                baseline = data[0x25] << 2
                status = int.from_bytes(data[:2], 'little')
                expected_scalars = {'filtered': filtered, 'baseline': baseline, 'delta': baseline - filtered,
                                    'delta_upper': baseline + 3 - filtered, 'threshold': data[0x4F],
                                    'native_status': status, 'native_on': int(bool(status & 0x80))}
                if any(int(row[field]) != value for field, value in expected_scalars.items()):
                    raise ValueError('raw/scalar mismatch')
                rows.append({'t': elapsed, 'phase': row['phase'], 'valid': row['phase_valid'] == '1',
                             'bytes': data, **expected_scalars})
        windows = {}
        for phase in ('baseline', 'hold', 'hold_late', 'release'):
            native_phase = 'hold' if phase == 'hold_late' else phase
            # Slow approach is instructed to take ~4s after cue t=4s. The
            # late window t=9..11.5 is a separately disclosed cue-based view,
            # not an inferred physical contact timestamp or fitted cutoff.
            selected = [r for r in rows if r['phase'] == native_phase and r['valid']
                        and (native_phase != 'hold' or (9 if phase == 'hold_late' else 6) <= r['t'] <= 11.5)]
            if not selected:
                raise ValueError('empty phase window')
            channels = []
            for electrode in range(12):
                values = [int.from_bytes(r['bytes'][4+2*electrode:6+2*electrode], 'little') for r in selected]
                if any(value > 1023 for value in values):
                    raise ValueError('reserved filtered bits or impossible 10-bit code')
                bases = [r['bytes'][0x1E+electrode] << 2 for r in selected]
                deltas = [base - value for base, value in zip(bases, values)]
                on = [bool(r['native_status'] & (1 << electrode)) for r in selected]
                channels.append({'electrode': electrode, 'filtered_min': min(values), 'filtered_max': max(values),
                                 'baseline_min': min(bases), 'baseline_max': max(bases),
                                 'delta_low_min': min(deltas), 'delta_high_max': max(deltas) + 3,
                                 'delta_floor_median': statistics.median(deltas),
                                 'native_on': sum(on), 'threshold': selected[0]['bytes'][0x41+2*electrode]})
            windows[phase] = {'n': len(selected), 'any_native_on': sum(bool(r['native_status']) for r in selected),
                              'representative_ele7': channels[7], 'channels': channels}
        result['jobs'].append({'id': job['id'], 'mode': job['mode'], 'samples': len(rows),
                               'controls_stable': len({r['bytes'][43:] for r in rows}) == 1,
                               'csv_sha256': hashlib.sha256(csv_path.read_bytes()).hexdigest(),
                               'job_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'windows': windows})
    if {j['mode'] for j in result['jobs']} != {'finger_contact', 'finger_hover5', 'slow_contact', 'palm_hover5'}:
        raise ValueError('missing or extra action type')
    (OUT / 'page_analysis.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    for job in result['jobs']:
        print(job['mode'], 'n', job['samples'], 'controls_stable', job['controls_stable'])
        for phase, window in job['windows'].items():
            ele7 = window['representative_ele7']
            print(phase, 'n', window['n'], 'any_native_on', window['any_native_on'], 'ELE7', ele7)


if __name__ == '__main__':
    main()
