"""Identify the newly connected MPR unit without configuration mode or writes."""
import json
from pathlib import Path
import round89_live as live

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90g_mpr_20261003'

if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    port, info = live.connect()
    report = {'port': info.device, 'usb_serial': info.serial_number, 'board': '27-inch separate unit, user confirmed',
              'config_mode_entered': False, 'persistent_writes': False}
    try:
        report['version'] = live.version(port)
        if 'NYANFW1;' not in report['version']:
            raise RuntimeError('unrecognized protocol signature')
        port.write(b'\xbc')
        probe = live.exact(port, 6)
        report['probe'] = probe.hex()
        if probe[0] != 0xbc or probe[1] != 7 or probe[2] != 0:
            raise RuntimeError('requires three MPRs and no MBR on separate unit')
        report['legacy_bf'] = []
        for _ in range(3):
            port.write(b'\xbf')
            data = live.exact(port, 129)
            report['legacy_bf'].append(data.hex())
        report['bf_semantics'] = 'Legacy scalar reads, no per-read success flags, not a coherent signal/config snapshot; limited preliminary evidence only.'
        print(json.dumps({'version': report['version'], 'probe': report['probe'], 'serial': report['usb_serial'],
                          'bf_tail_fields': [list(bytes.fromhex(report['legacy_bf'][0])[6+41*m+36:6+41*m+41]) for m in range(3)]}, indent=2))
    finally:
        port.close()
        (OUT / 'initial_identity.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
