# round90g MPR native evidence

本包是本地诊断证据，未证明MBR隔空根治或严格接触输入。

27寸独立MPR整机：50443405C0B5A81C；临时最小诊断round90g-88d完成四组后已恢复round88d，配置相等。32寸5303284739002C9C仍为beta10/round90e，未迁移模块。原版UF2由本地版本/BID/构建时间匹配选定，不是物理Flash镜像。

保留目录结构解压到一个新目录，先核对manifest.json内各文件SHA256，再运行以下两个入口；它们只读取本包文件，无串口、网络、设备访问：

```powershell
& 'C:\Users\HP\AppData\Local\Python\pythoncore-3.14-64\python.exe' .\_dev_tools\round90g_analyze_mpr.py
& 'C:\Users\HP\AppData\Local\Python\pythoncore-3.14-64\python.exe' .\_dev_tools\round90g_analyze_page.py
```

其他机器使用可用Python 3启动器；分析仅需标准库。重算的analysis.json/page_analysis.json应逐字节等于随包产物。tools/test_native_register_dump.py额外需要可用C++17编译器，提取随包真实生产C6路径；仅编译/运行主机桩，不访问设备。

idle和finger_hover5包含三片顺序读取；page四组只包含0x5A整片。0x00–0x2A为同片43B一致信号窗，后85B及各片不同步；主机样本不是独立原生扫描。基线低2位未知，差值为区间。用户确认针对整次动作，5mm为估计高度，未记录精确接触时刻或HID游戏输入。基线软件处理仍运行，未写标志仅指主机命令/新增读取分支。

四组2995条数据：实际轻触主响应ELE8，原代表ELE7无本轮接触代表性；分析ELE8属探索。6–11.5秒窗沿用旧分析，9–11.5秒另行披露。慢触基线下移/该片无ON需进一步核查，不能直接判整机漏触。Mock数据未收入本包。

artifacts内UF2仅为归档。archived现场脚本及依赖供追溯，其地址/串号/绝对构建路径绑定当时设备，**不属于自动复跑步骤，不应直接用于下一次32寸试验**。后台页已结束诊断。约21.8MB的两个当前源码备份ZIP保留在原工作区，manifest记录哈希和HEAD；原round88d源码ZIP随包保留。SDK/工具链不随包分发。

两份构建日志及已有测试日志随包保留；153迁移与28生产C6的初次命令结果来自本轮执行，validation_summary.json明确记录该来源。打包后的实际解压、离线逐字节复跑及C6重新编译结果见独立package_check.json（证据包旁）。
