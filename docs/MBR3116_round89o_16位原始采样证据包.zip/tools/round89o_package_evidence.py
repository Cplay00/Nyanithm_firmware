import csv
import hashlib
import json
import zipfile
from pathlib import Path

import round89i_analyze_pair as paired
import round89n_prox16_capture as experiment

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "_dev_tools/round89n_prox16_20261002"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
paired.ROOT = DATA
analysis = paired.analyze()
accepted = [j for j in analysis["jobs"] if j["completed"] and j["user_confirmed"] is True]
if len(accepted) != 2 or {j["mode"] for j in accepted} != {"finger_contact", "finger_hover3"}:
    raise RuntimeError("unexpected accepted pose set")
files, restoration, broader_windows = {}, {}, {}
for job in accepted:
    source = DATA / (job["id"] + ".json")
    native = json.loads(source.read_text(encoding="utf-8"))
    if "16-bit ALP OFF" not in native["reference_mode"] or not all(native["hardware"].get(k) for k in ("candidate_applied", "restore_verified", "restore_after_reboot")):
        raise RuntimeError("invalid experiment mode or restoration")
    device = DATA / (job["id"] + "_device")
    after = device / "after_reboot"
    equal = all((after / f"chip_{a:02x}.bin").read_bytes() == table for a, table in experiment.capture.ORIGINALS.items())
    equal = equal and (after / "controller_config.bin").read_bytes() == experiment.capture.CFG
    snapshot = json.loads((after / "snapshot.json").read_text(encoding="utf-8"))
    if not equal or snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
        raise RuntimeError("restoration snapshot mismatch")
    restoration[job["id"]] = {"all_four_blocks_equal": True, "raw": snapshot["raw_status"], "slider_all_zero": True, "version": snapshot["version"]}
    rows = list(csv.DictReader(source.with_suffix(".csv").open(encoding="utf-8", newline="")))
    hold = [r for r in rows if r["phase"] == "hold" and r["phase_valid"] == "1" and not r["error"]]
    fixed = [r for r in hold if 6 <= float(r["elapsed_s"]) <= 11.5]
    summary = job["windows"]["hold"]
    if len(fixed) != summary["valid"]:
        raise RuntimeError("fixed-window count disagreement")
    for field in ("delta", "ref_delta", "diff", "ref_diff"):
        span = {"min": min(int(r[field]) for r in fixed), "max": max(int(r[field]) for r in fixed)}
        if any(summary[field][k] != v for k, v in span.items()):
            raise RuntimeError("independent CSV range disagreement")
    broader_windows[job["id"]] = {"valid": len(hold), "ranges": {field: {"min": min(int(r[field]) for r in hold), "max": max(int(r[field]) for r in hold)} for field in ("delta", "ref_delta", "diff", "ref_diff")}, "semantics": "Entire phase_valid hold includes approach/movement and is not a measured firmware latency window"}
    for suffix in (".json", ".csv"):
        path = source.with_suffix(suffix)
        files["samples/" + path.name] = path
    for path in device.rglob("*"):
        if path.is_file():
            files["samples/" + path.relative_to(DATA).as_posix()] = path

touch = next(j for j in accepted if j["mode"] == "finger_contact")["windows"]
hover = next(j for j in accepted if j["mode"] == "finger_hover3")["windows"]
gap = touch["hold"]["ref_delta"]["min"] - hover["hold"]["ref_delta"]["max"]
fixed_gap = touch["hold"]["fixed_far_reference_delta"]["min"] - hover["hold"]["fixed_far_reference_delta"]["max"]
far_span = {j["mode"]: j["windows"]["baseline"]["ref_raw"]["max"] - j["windows"]["baseline"]["ref_raw"]["min"] for j in accepted}
evidence = {
    "date": "2026-10-02", "accepted_samples": accepted, "restoration": restoration, "broader_hold_windows": broader_windows,
    "semantics": "Sequential native C7; completed human-confirmed single-finger poses; fixed hold 6-11.5 seconds, invalid pairs excluded without zero filling",
    "reference_native_delta_gap": gap, "reference_fixed_far_gap": fixed_gap, "short_far_raw_peak_to_peak": far_span,
    "reference_delta_in_12_bit_units": {j["mode"]: {k: j["windows"]["hold"]["ref_delta"][k] / 16 for k in ("min", "median", "max")} for j in accepted},
    "conclusion": "These two fixed single-finger windows separate in native reference delta, but ratios overlap, short far variation is material, and stronger contact in this run prevents attributing separation to resolution alone. Keep route provisional pending palm-hover counterexample.",
    "next": ["Same 16-bit ALP OFF setup: palm hover about 5 mm", "Same setup: palm light contact; no new register variables"],
    "limitations": ["One manually positioned finger, one estimated height and location; no fixture or repeated-trial validation", "Rows are sequential windows, not simultaneous independent physical touch trials", "Broader hold includes approach and shows lower contact reference values; no low-latency gating claim", "No palm, full-board, native game throughput, or distance-in-mm result yet", "No runtime firmware changes; probe modes automatically restored after each job"],
    "checks": {"accepted_jobs_and_mode": "2/2", "all_four_restored_blocks": "2/2", "independent_fixed_window_csv_ranges": "PASS", "cpp_or_production_panel_changes": False},
}
for name in ("round89o_package_evidence.py", "round89n_prox16_capture.py", "round89m_alp_off_capture.py",
             "round89k_prox_capture.py", "round89j_prox_idle.py", "round89h_timed_capture.py", "round89h_timed_capture.html",
             "round89h_raw_capture.py", "round89g_latency_probe.py", "round89_live.py", "round89_live_debug.py",
             "round89i_analyze_pair.py", "round89h_analyze_timed.py", "test_round89n_prox16.py",
             "test_round89m_alp_off.py", "test_round89k_prox_capture.py"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
files["specification.json"] = DOCS / "MBR3116_round89n_16位对照规格.json"
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89o_16位原始采样证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != digest for name, digest in manifest.items()):
        raise RuntimeError("archive mismatch")
evidence["archive"] = {"name": archive.name, "files": len(manifest), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "size": archive.stat().st_size}
(DOCS / "MBR3116_round89o_16位实测分析.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "accepted pairs", [j["windows"]["hold"]["valid"] for j in accepted])
print("REFERENCE GAPS", gap, fixed_gap, "FAR RAW SPANS", far_span)
