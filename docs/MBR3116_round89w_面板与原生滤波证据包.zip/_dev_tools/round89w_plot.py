import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / '_dev_tools/round89u_native_filter_20261002'
OUTPUT = ROOT / 'Nyanithm_firmware_hw_v1/docs/MBR3116_round89w_原生滤波对照.png'
plt.rcParams.update({'font.family': 'Microsoft YaHei', 'axes.unicode_minus': False,
                     'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
analysis = json.loads((DATA / 'analysis.json').read_text(encoding='utf-8'))
jobs = {j['mode']: j for j in analysis['jobs'] if j['accepted']}
fig = plt.figure(figsize=(12.4, 10.4), facecolor='white')
grid = GridSpec(4, 2, figure=fig, height_ratios=[2, 1.5, 2, 1.5], hspace=.72, wspace=.26)
for pair, setting in enumerate(('a', 'b')):
    for col, gesture in enumerate(('finger_contact', 'palm_hover5')):
        mode = f'{setting}_{gesture}'
        job = jobs[mode]
        with (DATA / (job['id'] + '.csv')).open(encoding='utf-8', newline='') as stream:
            rows = [r for r in csv.DictReader(stream) if not r['error']]
        time = [float(r['elapsed_s']) for r in rows]
        ax = fig.add_subplot(grid[pair * 2, col])
        ax.plot(time, [int(r['diff']) for r in rows], color='#176B9D', lw=1.2)
        for field, y, color in [('hardware', 300, '#2A7D5A'), ('final', 340, '#303B4A')]:
            xs = [t for t, r in zip(time, rows) if int(r[field])]
            ax.scatter(xs, [y] * len(xs), marker='|', s=15, color=color, linewidths=.65)
        label = 'A 无滤波' if setting == 'a' else 'B 三点中值'
        action = '食指轻触' if gesture == 'finger_contact' else '手掌悬空约 5 mm'
        ax.set_title(f'{label} · {action}', loc='left', fontsize=12, fontweight='bold')
        ax.set_ylim(-10, 365)
        ax.set_yticks([0, 128, 255, 300, 340], ['0', '128', '255', '芯片ON', '第17格ON'])
        ax.set_ylabel('中心 DIFF / 状态')
        ax.grid(axis='y', alpha=.18)
        raster = fig.add_subplot(grid[pair * 2 + 1, col], sharex=ax)
        active_time, active_lane = [], []
        for t, r in zip(time, rows):
            for i, value in enumerate(bytes.fromhex(r['slider'])):
                if value:
                    active_time.append(t)
                    active_lane.append(i + 1)
        raster.scatter(active_time, active_lane, marker='|', s=16, color='#303B4A', linewidths=.7)
        raster.set_ylim(33, 0)
        raster.set_yticks([1, 8, 16, 24, 32])
        channels = '、'.join(job['fixed_windows']['hold']['final_channels']) or '无'
        raster.set_title(f'保持窗口输出格：{channels}', loc='left', fontsize=9, color='#445260')
        raster.set_ylabel('32格最终输出')
        raster.set_xlabel('主机记录时间（秒）')
        raster.grid(axis='y', alpha=.18)
        for panel in (ax, raster):
            panel.axvspan(4, 12, color='#E5F1F8', zorder=-2)
            panel.axvline(6, color='#A8B6C1', lw=.8, ls='--')
            panel.axvline(11.5, color='#A8B6C1', lw=.8, ls='--')
            panel.set_xlim(0, 22)
            panel.set_xticks([0, 4, 8, 12, 16, 20, 22])
        plt.setp(ax.get_xticklabels(), visible=False)
fig.suptitle('中值滤波仍存在悬空触发', fontsize=18, fontweight='bold', x=.07, ha='left', y=.98)
fig.text(.07, .945, '4组均确认动作并恢复原表；只有0x40修改参数。中心信号不能代表全板。', fontsize=11, color='#445260')
fig.text(.07, .035, '蓝底：动作提示窗口；虚线：固定分析窗口6–11.5秒。原生与最终状态来自顺序CDC读取。\n'
                    '这些记录不是独立扫描或触摸次数，也不测量物理输入延迟；未经HID游戏验收。', fontsize=9, color='#445260')
fig.subplots_adjust(left=.1, right=.98, top=.9, bottom=.11)
fig.savefig(OUTPUT, dpi=170)
plt.close(fig)
print(OUTPUT)
