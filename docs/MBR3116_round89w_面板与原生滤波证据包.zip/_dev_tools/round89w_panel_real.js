const { app, BrowserWindow, session } = require('electron');
const fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.resolve(__dirname, '..');
const out = path.join(__dirname, 'round89w_panel_real');
const before = JSON.parse(fs.readFileSync(path.join(out, 'before/snapshot.json'), 'utf8'));
const candidate = JSON.parse(fs.readFileSync(path.join(__dirname, 'round89u_native_filter_20261002/candidates.json'), 'utf8')).b.hex;
const report = { checks: [], errors: [], before, candidate, downloads: [] };
let win, downloadNo = 0;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const js = code => win.webContents.executeJavaScript(code, true);
async function until(code, timeout = 15000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) { if (await js(code)) return; await sleep(100); }
    throw new Error('timeout: ' + code);
}
function check(label, value) { assert(value, label); report.checks.push(label); console.log('PASS ' + label); }
async function click(id) { await js(`document.getElementById(${JSON.stringify(id)}).click()`); }
async function select(id, value) { await js(`(()=>{const e=document.getElementById(${JSON.stringify(id)});e.value=${JSON.stringify(String(value))};e.dispatchEvent(new Event('change',{bubbles:true}));})()`); }
async function tableHex() { return js("document.getElementById('mbrHexTable').value.match(/\\b[0-9a-f]{2}\\b/gi).join('').toLowerCase()"); }
async function exportConfig() {
    const n = report.downloads.length;
    await click('btnExportCfg');
    const end = Date.now() + 5000;
    while (report.downloads.length === n && Date.now() < end) await sleep(50);
    assert(report.downloads.length > n, 'configuration download completes');
    return fs.readFileSync(report.downloads.at(-1)).toString('hex');
}
async function burn() {
    await js("document.getElementById('mbrWriteStatus').textContent='';");
    await click('btnMbrRegWrite');
    await until("/完成|失败/.test(document.getElementById('mbrWriteStatus').textContent)", 20000);
    const status = await js("document.getElementById('mbrWriteStatus').textContent");
    check('NVRAM UI reports successful full readback: ' + status, status.includes('完成'));
}
async function run() {
    const ses = session.defaultSession;
    ses.setPermissionRequestHandler((wc, permission, cb) => cb(permission === 'serial'));
    ses.setPermissionCheckHandler((wc, permission) => permission === 'serial');
    ses.setDevicePermissionHandler(d => d.deviceType === 'serial');
    ses.on('select-serial-port', (event, ports, wc, callback) => {
        event.preventDefault();
        const matched = ports.find(p => p.portName === before.port);
        console.log('PORTS ' + JSON.stringify(ports));
        callback(matched ? matched.portId : '');
    });
    ses.on('will-download', (event, item) => {
        const target = path.join(out, `download_${++downloadNo}_${item.getFilename()}`);
        item.setSavePath(target);
        item.once('done', (e, state) => { if (state === 'completed') report.downloads.push(target); });
    });
    win = new BrowserWindow({ width: 1440, height: 1080, show: false, webPreferences: { nodeIntegration: false, contextIsolation: true } });
    win.webContents.on('console-message', (event, level, message) => { if (level >= 2) report.errors.push(message); });
    await win.loadFile(path.join(root, 'Nyanithm_firmware_hw_v1/ControlPanel_v1.html'));
    await js(`(()=>{
        window.__writes=[];window.__writeGuardErrors=[];window.__expectedCfg=${JSON.stringify(before.controller_config)};
        window.__allowedMbr=${JSON.stringify([before.chips['0x40'].hex, candidate])};
        const old=WritableStreamDefaultWriter.prototype.write;
        WritableStreamDefaultWriter.prototype.write=function(chunk){
            const bytes=Array.from(chunk),last=window.__writes.at(-1);window.__writes.push(bytes);
            if(last&&last.length===1&&last[0]===0xb7&&bytes.length===128){
                const hex=bytes.map(b=>b.toString(16).padStart(2,'0')).join('');
                if(hex!==window.__expectedCfg){window.__writeGuardErrors.push('CFG_SET differed from backup');chunk=Uint8Array.from(window.__expectedCfg.match(/../g),b=>parseInt(b,16));}
            }
            if(last&&last.length===1&&last[0]===0xba){
                const hex=bytes.slice(1).map(b=>b.toString(16).padStart(2,'0')).join('');
                if(bytes.length!==129||bytes[0]!==0x40||!window.__allowedMbr.includes(hex))throw new Error('unexpected NVRAM payload');
            }
            return old.call(this,chunk);
        };
    })()`);
    await click('connectBtn');
    await until("!document.getElementById('btnEnterConfig').disabled && document.getElementById('mainLog').textContent.includes('round89g')");
    check('real Web Serial handshake identifies round89g', true);
    await click('btnEnterConfig');
    await until("document.getElementById('btnEnterConfig').textContent.includes('退出') && !document.getElementById('ckMbr3116').disabled");
    check('real configuration read equals 128B backup', await exportConfig() === before.controller_config);
    await click('btnMbrRegWin');
    await click('btnMbrRegRead');
    await until("!document.getElementById('mbrReg_4D').disabled");
    check('real 0x40 read equals native backup', await tableHex() === before.chips['0x40'].hex);
    check('single chip editing before read-all', !await js("document.getElementById('mbrRegGlobal').checked"));
    await select('mbrReg_4D', 1); await select('mbrReg_4F', 0);
    check('draft equals documented median candidate exactly', await tableHex() === candidate);
    await burn();
    check('candidate is retained in readback cache', await tableHex() === candidate);
    await select('mbrReg_4D', 0); await select('mbrReg_4F', 8);
    check('restore draft equals original table exactly', await tableHex() === before.chips['0x40'].hex);
    await burn();
    check('original is retained in readback cache', await tableHex() === before.chips['0x40'].hex);
    await click('mbrRegClose');
    await click('btnSaveAndReboot'); await click('btnSaveAndReboot');
    await until("document.getElementById('mainLog').textContent.includes('已自动重连') && !document.getElementById('btnEnterConfig').disabled", 20000);
    check('real save/reboot automatically reconnects', true);
    await click('btnEnterConfig');
    await until("document.getElementById('btnEnterConfig').textContent.includes('退出') && !document.getElementById('ckMbr3116').disabled");
    check('post-reboot controller readback is exact', await exportConfig() === before.controller_config);
    await js('window.dumpCfgCmdLog()');
    check('firmware 0xCE command log reads successfully', await js("document.getElementById('mainLog').textContent.includes('设备命令日志(') && !document.getElementById('mainLog').textContent.includes('命令日志读取失败')"));
    report.writes = await js('window.__writes');
    report.writeGuardErrors = await js('window.__writeGuardErrors');
    check('all actual CFG_SET data matches unchanged backup', report.writeGuardErrors.length === 0);
    const at=report.writes.findIndex(w=>w.length===1&&w[0]===0xb7);
    check('CFG_SET command and payload are separate writes', at>=0 && report.writes[at+1].length===128);
    check('exactly candidate and restoration NVRAM writes', report.writes.filter(w=>w.length===1&&w[0]===0xba).length===2);
    await win.webContents.capturePage().then(im=>fs.writeFileSync(path.join(out,'real_panel.png'),im.toPNG()));
    report.mainLog = await js("document.getElementById('mainLog').textContent");
    await click('btnEnterConfig'); await click('btnEnterConfig');
    await until("document.getElementById('mainLog').textContent.includes('已发送重启命令')",5000).catch(()=>{});
    report.completed=true;
}
app.whenReady().then(run).catch(async e => {
    report.failure=e.stack; console.error(e.stack); process.exitCode=1;
    if(win) { report.mainLog=await js("document.getElementById('mainLog').textContent").catch(()=>null);report.writes=await js('window.__writes').catch(()=>null); }
}).finally(()=>{
    fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));
    console.log(`TOTAL ${report.checks.length} real checks; completed=${!!report.completed}`);
    app.quit();
});
