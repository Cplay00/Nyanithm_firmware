const assert = require('assert');
const path = require('path');
const {chromium} = require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async () => {
    const browser = await chromium.launch({channel:'msedge', headless:true});
    const page = await browser.newPage({viewport:{width:1100,height:900}});
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    let state = {running:false, blocked:false, phase:'idle', message:'准备', jobs:[], end_ms:0};
    const actions = [];
    await page.route('**/*', async route => {
        const request = route.request(), endpoint = new URL(request.url()).pathname;
        if (endpoint === '/') return route.continue();
        if (endpoint === '/favicon.ico') return route.fulfill({status:204});
        if (endpoint === '/status') return route.fulfill({contentType:'application/json', body:JSON.stringify({...state, now_ms:Date.now()})});
        if (request.method() === 'POST') {
            actions.push({endpoint, value:request.postDataJSON()});
            if (endpoint === '/start') state = {...state, running:true, phase:'hold', message:'食指轻触', end_ms:Date.now()+8000};
            if (endpoint === '/label') state.jobs.at(-1).user_confirmed = request.postDataJSON().valid;
            if (endpoint === '/finish') state = {...state, phase:'closed', message:'设备已恢复普通模式'};
            return route.fulfill({contentType:'application/json', body:'{}'});
        }
        throw Error('Unexpected endpoint '+endpoint);
    });
    try {
        await page.goto('http://127.0.0.1:8773/');
        assert.equal(await page.title(), '3116 原生参数对照');
        await page.locator('#start:enabled').waitFor();
        await page.locator('#setting').selectOption('b');
        await page.locator('#gesture').selectOption('finger_contact');
        await page.locator('#start').click();
        await page.locator('.cue.hold').waitFor();
        assert.equal(actions[0].value.mode, 'b_finger_contact');
        assert(await page.locator('#start').isDisabled());
        assert(await page.locator('#finish').isDisabled());
        state = {...state, phase:'restoring', message:'恢复并核对', end_ms:0};
        await page.locator('.cue.restoring').waitFor();
        assert(await page.locator('#valid').isDisabled());
        state = {...state, running:false, phase:'done', jobs:[{id:'fake', mode:'b_finger_contact', user_confirmed:null}]};
        await page.locator('#valid:enabled').waitFor();
        assert(await page.locator('#start').isDisabled());
        await page.locator('#valid').click();
        await page.locator('#start:enabled').waitFor();
        state = {...state, blocked:true};
        await page.waitForFunction(()=>document.getElementById('start').disabled);
        assert(await page.locator('#finish').isDisabled());
        await page.screenshot({path:path.join(__dirname,'round89u_capture_desktop.png')});
        await page.setViewportSize({width:390,height:844});
        await page.screenshot({path:path.join(__dirname,'round89u_capture_mobile.png')});
        assert(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth));
        assert.deepEqual(errors, []);
        console.log('Capture UI: identity, actions, running/restoring/confirmation/blocked guards, mobile layout PASS; mocked POST only, no device writes');
    } finally {
        await browser.close();
    }
})().catch(error=>{console.error(error);process.exitCode=1;});
