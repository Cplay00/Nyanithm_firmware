import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'round89u_native_filter_20261002'


def metrics(rows):
    differences = [int(row['diff']) for row in rows]
    sliders = [bytes.fromhex(row['slider']) for row in rows]
    masks = [bytes.fromhex(row['hardware_masks']) for row in rows]
    if any(len(s) != 32 or set(s) - {0, 128} for s in sliders) or any(len(m) != 6 for m in masks):
        raise RuntimeError('invalid final/native frame')
    channels = {str(i + 1): sum(s[i] != 0 for s in sliders) for i in range(32)}
    native = {}
    for chip in range(3):
        counts = {f'CS{i}': sum(bool(int.from_bytes(m[chip * 2:chip * 2 + 2], 'little') & (1 << i)) for m in masks) for i in range(16)}
        native[hex(0x40 + chip)] = {k: v for k, v in counts.items() if v}
    return {'rows': len(rows), 'center_diff_range': [min(differences), max(differences)],
            'center_saturated_rows': sum(d == 255 for d in differences),
            'center_native_on_rows': sum(int(r['hardware']) != 0 for r in rows),
            'center_final_on_rows': sum(int(r['final']) != 0 for r in rows),
            'any_final_on_rows': sum(any(s) for s in sliders),
            'final_channels': {k: v for k, v in channels.items() if v}, 'native_channels': native,
            'center_saturated_native_on_final_off_rows': sum(int(r['diff']) == 255 and int(r['hardware']) != 0 and int(r['final']) == 0 for r in rows)}


def analyze():
    results = []
    for path in sorted(ROOT.glob('*.json')):
        job = json.loads(path.read_text(encoding='utf-8'))
        if 'mode' not in job or job.get('preflight'):
            continue
        accepted = job.get('completed') and job.get('user_confirmed') is True and job.get('hardware', {}).get('restore_after_reboot')
        result = {'id': job['id'], 'mode': job['mode'], 'accepted': bool(accepted)}
        if not accepted:
            results.append(result)
            continue
        with path.with_suffix('.csv').open(encoding='utf-8', newline='') as stream:
            rows = list(csv.DictReader(stream))
        good = [r for r in rows if not r['error']]
        result['fixed_windows'] = {name: metrics([r for r in good if start <= float(r['elapsed_s']) <= end])
                                   for name, start, end in [('baseline', .25, 3.5), ('hold', 6, 11.5), ('release', 14, 21.5)]}
        result['phases'] = {}
        for phase in ('baseline', 'hold', 'release'):
            valid = [row for row in rows if row['phase'] == phase and row['phase_valid'] == '1' and not row['error']]
            if not valid:
                raise RuntimeError('missing valid phase')
            differences = [int(row['diff']) for row in valid]
            hardware = [int(row['hardware']) != 0 for row in valid]
            final = [int(row['final']) != 0 for row in valid]
            first_active = next((float(row['elapsed_s']) for row in valid if int(row['final']) != 0), None)
            last_active = next((float(row['elapsed_s']) for row in reversed(valid) if int(row['final']) != 0), None)
            result['phases'][phase] = {'rows': len(valid), 'diff_range': [min(differences), max(differences)],
                                       'saturated_rows': sum(value == 255 for value in differences),
                                       'native_on_rows': sum(hardware), 'final_on_rows': sum(final),
                                       'first_final_host_s': first_active, 'last_final_host_s': last_active}
        results.append(result)
    report = {'note': 'Sequential CDC observations; rows are not independent sensor scans or touches. Host times do not measure physical input latency.',
              'accepted_jobs': sum(result['accepted'] for result in results), 'jobs': results}
    (ROOT / 'analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    analyze()
