import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'Nyanithm_firmware_hw_v1/docs'
OUT = ROOT / '_dev_tools/round89u_native_filter_20261002'
QA = Path('C:/Users/HP/AppData/Local/Temp/nyan_nvram_qa_20261002')
files = {}


def add(path, name=None):
    assert path.is_file(), path
    files[name or path.relative_to(ROOT).as_posix()] = path.read_bytes()


analysis = json.loads((OUT / 'analysis.json').read_text(encoding='utf-8'))
assert analysis['accepted_jobs'] == 4
restored = {}
for job in analysis['jobs']:
    assert job['accepted']
    folder = OUT / (job['id'] + '_device')
    comparisons = {name: (folder / name).read_bytes() == (folder / 'after_reboot' / name).read_bytes()
                   for name in ('chip_40.bin', 'chip_41.bin', 'chip_42.bin', 'controller_config.bin')}
    assert all(comparisons.values())
    restored[job['mode']] = comparisons
    assert all(job['fixed_windows'][phase]['any_final_on_rows'] == 0 for phase in ('baseline', 'release'))
before = ROOT / '_dev_tools/round89w_panel_real/before'
after = ROOT / '_dev_tools/round89w_panel_real/after'
panel_restored = {name: (before / name).read_bytes() == (after / name).read_bytes()
                  for name in ('chip_40.bin', 'chip_41.bin', 'chip_42.bin', 'controller_config.bin')}
assert all(panel_restored.values())
release = ROOT / 'Nyanithm_firmware_hw_v1/ControlPanel_v1.html'
html = release.read_text(encoding='utf-8')
assert 'const PANEL_VERSION = "1.1.1-beta9";' in html and 'devDiag' not in html
assert html.count('<main') == 1 and html.count('\n<body>\n') == 1
for p in OUT.rglob('*'):
    if p.is_file() and p.suffix in ('.json', '.csv', '.bin'):
        add(p)
for p in (ROOT / '_dev_tools/round89w_panel_real').rglob('*'):
    if p.is_file():
        add(p)
for source in ('round89u_native_filter_capture.py', 'round89u_analyze.py', 'round89w_plot.py', 'round89w_pack.py',
               'round89w_panel_real.js', 'round89_live.py', 'round89k_prox_capture.py', 'round89j_prox_idle.py',
               'round89h_timed_capture.py', 'round89h_timed_capture.html', 'round89h_raw_capture.py',
               'round89_panel_mock_test.js', 'test_round89u_capture_ui.js'):
    add(ROOT / '_dev_tools' / source)
for folder in ('round89u_device_before_20261002', 'round89v_device_readonly_20261002', 'round89j_device_before_20261001'):
    for p in (ROOT / '_dev_archive' / folder).glob('*'):
        if p.is_file() and p.suffix in ('.bin', '.json'):
            add(p)
for p in (ROOT / '_dev_tools/round89u_restoration_20261002').rglob('*'):
    if p.is_file() and p.suffix in ('.bin', '.json'):
        add(p)
add(ROOT / '_dev_archive/round89v_review_before_20261002/fa64229.patch')
panel = ROOT / 'ControlPanel_v1_refit_dev'
for p in (panel / 'src').glob('*'):
    if p.is_file():
        add(p)
for name in ('build.py', 'ControlPanel_v1_refit.base.html', 'devlog.md'):
    add(panel / name)
add(release)
for name in ('qa.js', 'strict_bid_qa.js', 'nvram_desktop.png', 'nvram_mobile.png', '3116_write_backups.json', 'ControlPanel_v1_refit.html'):
    add(QA / name, 'qa/' + name)
for name in ('MBR3116_round89w_提交复核与原生滤波对照.md', 'MBR3116_round89w_原生滤波对照.png'):
    add(DOCS / name)
readme = '''round89w 本地证据包，2026-10-02。
四组确认动作/恢复已核对；preflight不计效果组。用户暂停后续配合测试，采样服务已关闭。
源码/数据按工作区相对路径保存；解压到新的目录进行离线复核，不覆盖当前工作区。
离线分析：py -3 _dev_tools/round89u_analyze.py
绘图：py -3.12 _dev_tools/round89w_plot.py（matplotlib）
面板重建：py -3 ControlPanel_v1_refit_dev/build.py --release
qa/包含实际测试脚本及测试时HTML；46项测试后仅改版本标记/注释，写/保存实现不变。
QA脚本原有本机路径需改为解压目录；Playwright依赖用本机安装路径。Mock不得连接真实设备。
真机回归在最终畸形BID门禁3行收尾前进行，report中保留真实断开/开发CSP日志。
真机脚本及候选仅作证据，继续前需要重新核对设备身份、当前配置/备份及用户测试状态。
未获得稳定抗悬空配置；设备保持原始三片NVRAM、现有controller_config与round89g。
ZIP中的manifest.json逐项保存SHA-256与大小；证据核对JSON保存ZIP SHA及恢复/发布检查。
'''
files['README.txt'] = readme.encode('utf-8')
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(files.items())}
package = DOCS / 'MBR3116_round89w_面板与原生滤波证据包.zip'
with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8'))
with zipfile.ZipFile(package) as archive:
    assert len(archive.namelist()) == len(manifest) + 1
    for name, info in manifest.items():
        data = archive.read(name)
        assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256'], name
report = {'accepted_jobs': analysis['accepted_jobs'], 'gesture_restoration': restored,
          'panel_restoration': panel_restored,
          'panel_release': {'bytes': release.stat().st_size, 'sha256': hashlib.sha256(release.read_bytes()).hexdigest(),
                            'version': '1.1.1-beta9', 'devDiag': 0},
          'package': {'name': package.name, 'files': len(manifest), 'bytes': package.stat().st_size,
                      'sha256': hashlib.sha256(package.read_bytes()).hexdigest(), 'all_file_hashes_verified': True},
          'user_tests_paused': True, 'firmware_unchanged': 'round89g'}
(DOCS / 'MBR3116_round89w_证据核对.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
