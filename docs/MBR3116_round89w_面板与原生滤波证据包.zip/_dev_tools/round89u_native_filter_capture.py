import argparse
import json
from pathlib import Path

import round89k_prox_capture as capture

ROOT = Path(__file__).resolve().parents[1]
BACKUP = ROOT / '_dev_archive/round89u_device_before_20261002'
OUT = ROOT / '_dev_tools/round89u_native_filter_20261002'
PORT = 8773
SETTINGS = {
    'a': ('A 手动阈值・无滤波', 0, None),
    'b': ('B 手动阈值・中值滤波', 1, None),
    'c': ('C 手动阈值・IIR 滤波', 2, None),
    'd': ('D 手动阈值・迟滞31', 0, 31),
}
GESTURES = {
    'finger_contact': '食指轻触',
    'palm_hover5': '手掌悬空约5 mm（始终不接触）',
    'finger_hover3': '食指悬空约3 mm（始终不接触）',
    'finger_taps': '食指轻点10次（每次明确抬起）',
    'slide_chord': '慢划一遍，再相邻双指轻按',
}
ORIGINALS = {a: (BACKUP / f'chip_{a:02x}.bin').read_bytes() for a in (0x40, 0x41, 0x42)}


def patch(original, setting):
    if len(original) != 128 or capture.probe.crc(original) != int.from_bytes(original[126:], 'little'):
        raise RuntimeError('invalid source CRC')
    if original[0x51] != 0x40 or original[0x4D] != 0 or original[0x26] != 0:
        raise RuntimeError('unexpected source mode/address')
    if any(original[0x0C + i] != 200 for i in range(12)) or original[0x1C] != 1:
        raise RuntimeError('unexpected threshold/debounce baseline')
    candidate = bytearray(original)
    _, filters, hys = SETTINGS[setting]
    candidate[0x4F] &= ~8
    candidate[0x4D] = (candidate[0x4D] & ~3) | filters
    if hys is not None:
        candidate[0x1D] = 0x80 | hys
    candidate[126:] = capture.probe.crc(candidate).to_bytes(2, 'little')
    if any(candidate[i] != original[i] for i in range(128) if i not in (0x1D, 0x4D, 0x4F, 0x7E, 0x7F)):
        raise RuntimeError('unexpected patch fields')
    return bytes(candidate)


ui = capture.ui
native = capture.NATIVE
run_original = capture.run_job
capture.ORIGINALS = ORIGINALS
capture.CFG = (ROOT / '_dev_archive/round89v_device_readonly_20261002/controller_config.bin').read_bytes()
capture.probe.ADDRESS = 0x40
ui.OUT = OUT
ui.ORIGIN = f'http://127.0.0.1:{PORT}'
ui.MODES = {f'{setting}_{gesture}': label for setting in SETTINGS for gesture, label in GESTURES.items()}
ui.FIELDS = ['elapsed_s', 'phase', 'phase_valid', 'diff', 'hardware', 'final', 'slider', 'hardware_masks', 'request_ms', 'error']


def read_center(port):
    if capture.STOP.is_set():
        raise RuntimeError('capture cancelled')
    started = ui.time.perf_counter()
    port.write(b'\xb1')
    raw = ui.live.exact(port, 33, 1)
    port.write(b'\xc0')
    chain = ui.live.exact(port, 46, 1)
    if chain[:2] != b'\xaa\x55':
        raise RuntimeError('invalid chain header')
    duration = ui.time.perf_counter() - started
    ui.time.sleep(max(0, .02 - duration))
    return {'diff': raw[16], 'hardware': int(bool(int.from_bytes(chain[2:4], 'little') & (1 << 7))),
            'final': chain[30], 'slider': chain[14:46].hex(), 'hardware_masks': chain[2:8].hex(),
            'request_ms': duration * 1000, 'error': ''}


capture.read_pair = read_center
capture.probe.samples = lambda port, count=20: [native(port, 0x40, 7) for _ in range(count)]
base_update = ui.update


def update_cue(**values):
    message = values.get('message', '')
    if values.get('phase') == 'hold' and ('轻点10次' in message or '慢划一遍' in message):
        values['message'] = message.removesuffix('，保持不动')
    base_update(**values)


ui.update = update_cue


def run_job(job):
    setting = job['mode'].split('_', 1)[0]
    desired = patch(ORIGINALS[0x40], setting)
    job['setting'] = setting
    job['candidate_hex'] = desired.hex()
    job['changed_offsets'] = [i for i in range(128) if desired[i] != ORIGINALS[0x40][i]]
    job['reference_mode'] = SETTINGS[setting][0] + '; ordinary RAW=2 B1(33B) + C0(46B), sequential; no ToF'
    folder = OUT / (job['id'] + '_device')
    folder.mkdir()
    report = {'programming_attempted': False, 'candidate_applied': False, 'restore_verified': False, 'restore_after_reboot': False}
    job['hardware'] = report
    port = None
    in_config = False
    try:
        ui.update(phase='preparing', message='设备准备中，请继续保持手远离', end_ms=0)
        port, info = capture.probe.connect_reboot_ready()
        firmware = ui.live.version(port)
        report['usb_serial'] = info.serial_number
        port.write(b'\xb3')
        in_config = True
        ui.live.tail(port, .25)
        before = {a: capture.probe.read_chip(port, a) for a in ORIGINALS}
        config, _ = ui.live.config_read(port)
        if before != ORIGINALS or config != capture.CFG:
            ui.update(blocked=True)
            raise RuntimeError('device changed since backup; no write performed')
        for a, table in before.items():
            (folder / f'chip_{a:02x}.bin').write_bytes(table)
        (folder / 'controller_config.bin').write_bytes(config)
        report['programming_attempted'] = True
        report['apply_reply'] = capture.probe.program(port, desired)
        candidate = {a: capture.probe.read_chip(port, a) for a in ORIGINALS}
        if candidate[0x40] != desired or any(candidate[a] != ORIGINALS[a] for a in (0x41, 0x42)):
            raise RuntimeError('candidate readback mismatch')
        report['candidate_applied'] = True
        capture.wait_ready(port)
        port.write(b'\xb9')
        port.flush()
        port.close()
        port = None
        in_config = False
        port, _ = capture.probe.connect_reboot_ready()
        ui.live.split(port, 0xC5, [2])
        if ui.live.tail(port, .2) != 'RAW=2':
            raise RuntimeError('raw session enable failed')
        read_center(port)
        ui.capture_job(port, job, firmware, reader=read_center, fields=ui.FIELDS, publish=False)
    except Exception as error:
        report['error'] = repr(error)
    finally:
        if port:
            try:
                if in_config:
                    port.write(b'\xb9')
                    port.flush()
            except Exception as error:
                report['close_error'] = repr(error)
            finally:
                try:
                    port.close()
                except Exception as error:
                    report['close_error'] = repr(error)
            port = None
        if report['programming_attempted']:
            ui.update(phase='restoring', message='请保持手远离，正在恢复并核对', end_ms=0)
            try:
                port, _ = capture.probe.connect_reboot_ready()
                port.write(b'\xb3')
                ui.live.tail(port, .25)
                now = {a: capture.probe.read_chip(port, a) for a in ORIGINALS}
                check_cfg, _ = ui.live.config_read(port)
                if check_cfg != capture.CFG or now[0x40] not in (desired, ORIGINALS[0x40]) or any(now[a] != ORIGINALS[a] for a in (0x41, 0x42)):
                    raise RuntimeError('unexpected concurrent configuration change; restoration stopped')
                capture.probe.restore(port, ORIGINALS, capture.CFG, report)
            except Exception as error:
                report['restore_error'] = repr(error)
                ui.update(blocked=True)
            finally:
                if port:
                    try:
                        if report['restore_verified']:
                            port.write(b'\xb9')
                            port.flush()
                    except Exception as error:
                        report['exit_error'] = repr(error)
                        ui.update(blocked=True)
                    finally:
                        try:
                            port.close()
                        except Exception as error:
                            report['exit_error'] = repr(error)
                            ui.update(blocked=True)
                    port = None
            if report['restore_verified']:
                try:
                    after = folder / 'after_reboot'
                    after.mkdir()
                    ui.live.connect = capture.probe.connect_reboot_ready
                    ui.live.snapshot(after)
                    report['restore_after_reboot'] = all((after / f'chip_{a:02x}.bin').read_bytes() == ORIGINALS[a] for a in ORIGINALS) and (after / 'controller_config.bin').read_bytes() == capture.CFG
                    if not report['restore_after_reboot']:
                        raise RuntimeError('reboot restoration mismatch')
                except Exception as error:
                    report['reboot_error'] = repr(error)
                    ui.update(blocked=True)
        job['completed'] = bool(job.get('completed') and report['restore_after_reboot'] and not any(k in report for k in ('error', 'restore_error', 'reboot_error', 'close_error', 'exit_error')))
        ui.save_job(job)
    if not job['completed']:
        raise RuntimeError(json.dumps(report, ensure_ascii=False))
    with ui.LOCK:
        ui.STATE['jobs'].append(job)
    ui.update(running=False, phase='done', message='原设置已恢复，请确认本组动作', end_ms=0)


capture.run_job = run_job

PAGE = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>3116 原生参数对照</title>
<style>*{box-sizing:border-box}body{background:#111c21;color:#e6f5f4;font:18px system-ui;margin:0}main{max-width:850px;margin:30px auto;padding:24px}h1{font-size:28px}p{color:#b8cbce;line-height:1.6}select,button{font:inherit;background:#203940;color:inherit;border:1px solid #557179;border-radius:10px;padding:12px}button{cursor:pointer}button:disabled{opacity:.35}label{display:block;margin:18px 0 8px}.controls{display:flex;gap:12px;flex-wrap:wrap}.cue{padding:30px;border:2px solid #58747b;border-radius:18px;text-align:center;margin:24px 0}.hold{border-color:#ffd48f}.release{border-color:#67dcc9}#message{font-size:27px}#timer{font-size:66px}#error{color:#ffadad}#log{line-height:1.8;color:#b8cbce}@media(max-width:600px){main{margin:0}select{width:100%}}</style>
<main><h1>3116 原生参数对照</h1><p>同一位置：滑条第17格。每组临时调整0x40，结束自动恢复并核对。按页面提示行动。</p><label>对照配置</label><select id="setting">__SETTINGS__</select><label>本组动作</label><select id="gesture">__GESTURES__</select><div class="controls" style="margin-top:22px"><button id="start">手已远离，开始</button><button id="finish">结束诊断</button></div><div id="cue" class="cue"><div id="message">先将整只手远离至少30 cm</div><div id="timer">—</div><div id="phase">远离4秒 → 动作8秒 → 移开10秒</div></div><div id="error"></div><div class="controls"><button id="valid" disabled>按提示完成</button><button id="invalid" disabled>动作有偏差，作废</button></div><p id="log"></p></main><script>
const $=id=>document.getElementById(id);let state={},offset=0,lastPhase='',audio;
async function post(path,value){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});const d=await r.json();if(!r.ok)throw Error(d.error);return d}
function tone(){if(!audio)return;const o=audio.createOscillator(),g=audio.createGain();o.connect(g);g.connect(audio.destination);g.gain.value=.12;o.frequency.value=700;o.start();o.stop(audio.currentTime+.15)}
async function poll(){try{const r=await fetch('/status');state=await r.json();offset=state.now_ms-Date.now();$('message').textContent=state.message;$('cue').className='cue '+state.phase;$('phase').textContent=({preparing:'请保持手远离',baseline:'准备阶段',hold:'执行指定动作',release:'整只手移开',restoring:'恢复并核对中',done:'请确认本组',closed:'设备已恢复普通模式'})[state.phase]||'';if(state.phase!==lastPhase&&['hold','release','done'].includes(state.phase))tone();lastPhase=state.phase;const j=state.jobs.at(-1),pending=j&&j.user_confirmed===null;for(const id of ['start','setting','gesture'])$(id).disabled=state.running||state.blocked||pending;$('finish').disabled=state.running||state.blocked;for(const id of ['valid','invalid'])$(id).disabled=state.running||!pending;$('log').replaceChildren(...state.jobs.map(j=>{const line=document.createElement('div');line.textContent=j.mode+'：'+(j.user_confirmed===true?'已确认':j.user_confirmed===false?'作废':'待确认');return line}));}catch(e){$('error').textContent=e.message}setTimeout(poll,180)}
$('start').onclick=async()=>{try{$('start').disabled=true;$('error').textContent='';try{audio??=new AudioContext();await audio.resume()}catch{}await post('/start',{mode:$('setting').value+'_'+$('gesture').value})}catch(e){$('error').textContent=e.message}};
$('finish').onclick=()=>post('/finish',{}).catch(e=>$('error').textContent=e.message);for(const[id,valid]of[['valid',true],['invalid',false]])$(id).onclick=()=>post('/label',{id:state.jobs.at(-1).id,valid}).catch(e=>$('error').textContent=e.message);
setInterval(()=>{$('timer').textContent=state.end_ms?Math.max(0,Math.ceil((state.end_ms-Date.now()-offset)/1000)):'—'},70);poll();</script></html>'''
PAGE = PAGE.replace('__SETTINGS__', ''.join(f'<option value="{key}">{item[0]}</option>' for key, item in SETTINGS.items()))
PAGE = PAGE.replace('__GESTURES__', ''.join(f'<option value="{key}">{label}</option>' for key, label in GESTURES.items()))


class Handler(capture.Handler):
    def do_GET(self):
        if self.path == '/':
            self.send(200, PAGE.encode('utf-8'), 'text/html; charset=utf-8')
        else:
            super().do_GET()


capture.Handler = Handler


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--serve', action='store_true')
    parser.add_argument('--selfcheck', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    manifest = {key: {'label': value[0], 'changed_offsets': [i for i in range(128) if patch(ORIGINALS[0x40], key)[i] != ORIGINALS[0x40][i]], 'hex': patch(ORIGINALS[0x40], key).hex()} for key, value in SETTINGS.items()}
    (OUT / 'candidates.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    if args.selfcheck:
        ui.MODES['a_idle_preflight'] = '保持手远离；流程预检，不是效果验收'
        job = {'id': 'preflight_' + str(ui.time.time_ns()), 'mode': 'a_idle_preflight', 'preflight': True}
        run_job(job)
        job['user_confirmed'] = False
        ui.save_job(job)
        print(json.dumps({'completed': job['completed'], 'restored': job['hardware']['restore_after_reboot']}, indent=2))
    elif args.serve:
        capture.serve(PORT)
    else:
        print(json.dumps({key: {'label': value['label'], 'changed_offsets': value['changed_offsets']} for key, value in manifest.items()}, ensure_ascii=False, indent=2))
