const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root='D:/Opencode,OCCM/Items/Nyanithm_Firmware/ControlPanel_v1_refit_dev/src/';
const core=fs.readFileSync(root+'app_core.js','utf8');
const ui=fs.readFileSync(root+'app_ui.js','utf8');
const gate=ui.match(/    function mbrCanProgram\(\) \{[\s\S]*?\n    \}/)[0];
const ctx=vm.createContext({TextDecoder});
vm.runInContext(core+'\nlet configMode=true,mbrGateFwSupport=true,devInfo=null;\n'+gate+'\nglobalThis.can=(buildId,mode=true,support=true)=>{devInfo={buildId};configMode=mode;mbrGateFwSupport=support;return mbrCanProgram();};',ctx);
const cases=[['round88c',false],['round88d',true],['round88e',true],['round89',true],['round89a',true],['round88dd',true],['round88',false],['round87z',false],['round88d-unknown',false],['round89BAD',false],['round89a-extra',false],['round89a\n',false],[' round89a',false],['round89a ',false],['round89a!',false],['round-89a',false],['round9e20a',false],['round9007199254740992a',false],['round999999999999999999999999999a',false],['round9007199254740991a',true],['',false],[null,false],[undefined,false],[89,false],[{},false]];
let count=0;for(const [id,want] of cases){assert.strictEqual(ctx.can(id),want,JSON.stringify(id));count++;}
assert.strictEqual(ctx.can('round89a',false),false);count++;
assert.strictEqual(ctx.can('round89a',true,false),false);count++;
console.log('PASS '+count+'/'+count+' strict NVRAM build-ID gate cases');
