/* ================================================================
   ControlPanel v2 — UI 接线(三代组件 + 一代引擎)
   依赖: app_core.js(先加载);与原三代脚本同位替换
   ================================================================ */
(function () {
    'use strict';

    const INTRO_SUBTITLE = 'CONTROL PANEL FOR GEN 1';

    // ================================================================
    // 入场动画(三代原版逻辑)
    // ================================================================
    (function calcLogoCenter() {
        const logo = document.querySelector('.intro-brand-logo');
        const text = document.querySelector('.intro-brand-text');
        if (!logo || !text) return;
        function calc() {
            if (!logo.naturalWidth || !text.naturalWidth) return;
            const logoW = logo.naturalWidth * (48 / logo.naturalHeight);
            const textW = text.naturalWidth * (48 / text.naturalHeight);
            const groupW = logoW + 30 + textW;
            const offset = (groupW / 2) - (logoW / 2);
            logo.style.setProperty('--logo-center-x', offset + 'px');
        }
        if (logo.complete && text.complete) calc();
        else { logo.addEventListener('load', calc); text.addEventListener('load', calc); }
    })();

    (function typewriter() {
        const el = document.querySelector('.intro-sub');
        if (!el) return;
        el.textContent = '';
        let i = 0;
        const speed = 42;
        (function type() {
            if (i < INTRO_SUBTITLE.length) { el.textContent += INTRO_SUBTITLE[i]; i++; setTimeout(type, speed); }
        })();
    })();

    (function introAnim() {
        const percentEl = document.querySelector('.intro-percent');
        if (percentEl) {
            let startT = null;
            const dur = 1300, delay = 400;
            function tick(ts) {
                if (!startT) startT = ts + delay;
                if (ts < startT) { requestAnimationFrame(tick); return; }
                const t = Math.min((ts - startT) / dur, 1);
                const eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
                percentEl.textContent = String(Math.round(eased * 100)).padStart(3, '0');
                if (t < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
        }
        setTimeout(() => {
            const ov = document.getElementById('introOverlay');
            if (ov) { window.__introOverlayHTML = ov.outerHTML; ov.remove(); }
        }, 2650);
    })();

    window.replayIntroAnimation = function () {
        if (!window.__introOverlayHTML) return;
        var existing = document.getElementById('introOverlay');
        if (existing) existing.remove();
        document.body.insertAdjacentHTML('afterbegin', window.__introOverlayHTML);
        void document.getElementById('introOverlay').offsetWidth;
        (function calcLogoCenter() {
            var logo = document.querySelector('.intro-brand-logo');
            var text = document.querySelector('.intro-brand-text');
            if (!logo || !text) return;
            function calc() {
                if (!logo.naturalWidth || !text.naturalWidth) return;
                var logoW = logo.naturalWidth * (48 / logo.naturalHeight);
                var textW = text.naturalWidth * (48 / text.naturalHeight);
                var groupW = logoW + 30 + textW;
                logo.style.setProperty('--logo-center-x', ((groupW / 2) - (logoW / 2)) + 'px');
            }
            if (logo.complete && text.complete) calc();
            else { logo.addEventListener('load', calc); text.addEventListener('load', calc); }
        })();
        (function typewriter() {
            var el = document.querySelector('.intro-sub');
            if (!el) return;
            el.textContent = '';
            var i = 0;
            (function type() {
                if (i < INTRO_SUBTITLE.length) { el.textContent += INTRO_SUBTITLE[i]; i++; setTimeout(type, 42); }
            })();
        })();
        (function introAnim() {
            var percentEl = document.querySelector('.intro-percent');
            if (percentEl) {
                var startT = null;
                var dur = 1300, delay = 400;
                function tick(ts) {
                    if (!startT) startT = ts + delay;
                    if (ts < startT) { requestAnimationFrame(tick); return; }
                    var t = Math.min((ts - startT) / dur, 1);
                    var eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
                    percentEl.textContent = String(Math.round(eased * 100)).padStart(3, '0');
                    if (t < 1) requestAnimationFrame(tick);
                }
                requestAnimationFrame(tick);
            }
            setTimeout(function () {
                var ov = document.getElementById('introOverlay');
                if (ov) ov.remove();
            }, 2650);
        })();
    };

    // ================================================================
    // 基础工具
    // ================================================================
    const $ = (id) => document.getElementById(id);
    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    // 0-delay macrotask yield via MessageChannel: escapes setTimeout's 4ms nesting
    // clamp so waitForBytes/waitForLine poll readBuffer every ~0.1ms(一代引擎原版)
    const _mc = new MessageChannel();
    const _tickQ = [];
    _mc.port2.onmessage = () => { const fn = _tickQ.shift(); if (fn) fn(); };
    function nextTick() { return new Promise(r => { _tickQ.push(r); _mc.port1.postMessage(0); }); }

    // ================================================================
    // 全局状态(一代面板状态机)
    // ================================================================
    let port = null, reader = null, writer = null;
    let readBuffer = new Uint8Array(0);
    let readLoopRunning = false, inputLoopRunning = false;
    let connected = false, configMode = false;
    let inputPolling = true;
    let ledAnimId = null;
    let tofPollId = null, tofPollGen = 0;
    let lastReadConfig = null;
    // lightLimit 原字节保真(见 packConfig 内注释)
    let rawLightLimit = { byte: null, pct: null };

    // 设备身份(门禁用)。devInfo 来自 0xBD(正常模式);probeInfo 来自 0xBC
    let devInfo = null;      // {fw, api, hwVer, var, sig, raw}
    let probeInfo = null;    // {mprMask, mbrMask, tofCount, flags, cfgHwVer}
    let hwVerProbe = null;
    let cfgVerMismatch = false;

    // MBR3116 表编辑状态
    let mbrTable = null;

    // 固件刷写状态(round54 全自动流程)
    let uf2Buf = null, uf2FileName = "", uf2Parsed = null;
    let uf2Errors = [], uf2Warnings = [];
    let bootselReady = false;
    let flashPhase = "idle";
    let reconnectWatch = null, reconnectDeadline = 0;

    // 输入指标
    let inputFrames = 0, lastFpsTime = performance.now();
    let totalPackets = 0, lastPollTime = 0;
    let latestInputData = null, inputRafScheduled = false;

    // ================================================================
    // 日志
    // ================================================================
    function log(msg, type = "info") {
        const box = $("mainLog");
        const t = new Date().toLocaleTimeString("zh-CN", { hour12: false });
        if (box.textContent === "等待连接...") box.textContent = "";
        box.textContent += (box.textContent ? "\n" : "") + `[${t}] ${msg}`;
        box.scrollTop = box.scrollHeight;
        if (type === "error") console.error(msg);
        else if (type === "warn") console.warn(msg);
    }
    function statusLog(msg) {
        const box = $("statusLog");
        box.textContent = msg;
        box.scrollTop = box.scrollHeight;
    }

    // ================================================================
    // 三代组件:odometer / 滑条 / 状态栏同步
    // ================================================================
    // round72 重写状态机。条带几何 = [9副本][0..9][0副本] 共 12 格(头部 9 副本
    // 占 idx0),因此数字 k 的静止位固定是 translateY(-(k+1)em)。round71d/e 当初
    // 插入头部副本后仍沿用上游 translateY(-digit em) 公式,整体错位一格:静止的
    // 0 位显示的是头部 9(再叠加 leading-zero 变淡,即用户看到的"幽灵 9"),进位
    // 落点也全部偏移。
    // 进位语义(round71b/71e 保留):9→0 经尾部 0 副本长滚后归位;0→9 经头部 9
    // 副本反向长滚后归位。d.cur 恒等于"当前逻辑显示的数字"(0-9);每次写入先
    // odoFinalize 收尾上一笔未完动画(清定时器/监听器、瞬态副本位无动画归位,
    // 副本与本位字形相同故跳变不可见),再从静止位起滚。
    function odRest(k) { return 'translateY(-' + (k + 1) + 'em)'; }

    function createOdometer(el, numDigits) {
        el.classList.add('odometer');
        el.innerHTML = '';
        el._odometer = { digits: [], numDigits };
        for (let i = 0; i < numDigits; i++) {
            const digitEl = document.createElement('span');
            digitEl.className = 'odometer-digit';
            const strip = document.createElement('span');
            strip.className = 'odometer-strip';
            const head = document.createElement('span');
            head.textContent = '9';
            strip.appendChild(head);
            for (let n = 0; n <= 9; n++) {
                const numEl = document.createElement('span');
                numEl.textContent = n;
                strip.appendChild(numEl);
            }
            const clone = document.createElement('span');
            clone.textContent = '0';
            strip.appendChild(clone);
            strip.style.transform = odRest(0);   // 初始静止显示 0
            digitEl.appendChild(strip);
            el.appendChild(digitEl);
            el._odometer.digits.push({ el: digitEl, strip, cur: 0, snapTimer: null, onEnd: null });
        }
    }

    // 结束某列未完成的进位动画:清定时器与监听器,若条带停在瞬态副本位则无动画
    // 归到 d.cur 的静止位(字形一致,视觉连续),随后恢复过渡以便下一次滚动生效。
    function odoFinalize(d) {
        if (d.snapTimer) { clearTimeout(d.snapTimer); d.snapTimer = null; }
        if (d.onEnd) { d.strip.removeEventListener('transitionend', d.onEnd); d.onEnd = null; }
        d.strip.style.transition = 'none';
        d.strip.style.transform = odRest(d.cur);
        void d.strip.offsetWidth;
        d.strip.style.transition = '';
    }

    // 把仍在副本位的条带无动画收回本位
    function odoSnapHome(d) {
        d.strip.style.transition = 'none';
        d.strip.style.transform = odRest(d.cur);
        void d.strip.offsetWidth;
        d.strip.style.transition = '';
    }

    // 发起 cur→digit 的滚动。普通位移直接过渡到目标静止位;跨 9/0 边界时经副
    // 本格长滚(transitionend 正常路径 + 450ms 兜底,页签隐藏时 end 不触发)。
    function odoMove(d, digit) {
        const from = d.cur;
        d.cur = digit;
        if (from === digit) return;
        if (!((from === 9 && digit === 0) || (from === 0 && digit === 9))) {
            d.strip.style.transform = odRest(digit);
            return;
        }
        // round72b: 尾部 0 副本是条带第 12 格(idx11),完整可见位是 -11em。
        // 此前误写 -12em——窗口滑出条带底缘,动画尾段整格空白,过渡结束才 snap
        // 回本位"闪现"出 0(用户反馈的飞出空白)。头部 9 副本 idx0 对应 0em 不变。
        d.strip.style.transform = (from === 9) ? 'translateY(-11em)' : 'translateY(0em)';
        if (d.onEnd) d.strip.removeEventListener('transitionend', d.onEnd);
        const onEnd = (e) => {
            if (e.target !== d.strip || e.propertyName !== 'transform') return;
            if (d.onEnd !== onEnd) return;   // 已被新一轮收尾覆盖
            d.onEnd = null;
            d.strip.removeEventListener('transitionend', onEnd);
            if (d.snapTimer) { clearTimeout(d.snapTimer); d.snapTimer = null; }
            odoSnapHome(d);
        };
        d.onEnd = onEnd;
        d.strip.addEventListener('transitionend', onEnd);
        d.snapTimer = setTimeout(() => {
            if (d.onEnd !== onEnd) return;
            d.onEnd = null;
            d.strip.removeEventListener('transitionend', onEnd);
            odoSnapHome(d);
        }, 450);
    }

    function setOdometerValue(el, value) {
        if (!el || !el._odometer || !Number.isFinite(value)) return;
        const { digits, numDigits } = el._odometer;
        const str = String(Math.max(0, Math.round(value))).padStart(numDigits, '0');
        let foundNonZero = false;
        for (let i = 0; i < numDigits; i++) {
            const digit = parseInt(str[i], 10);
            const d = digits[i];
            // 上一笔进位若仍挂在瞬态副本位:先无跳变收尾,再从静止位判断方向。
            // round72c: 落点与进行中进位相同(d.cur===digit)时不得收尾——逐键气泡
            // 滑条同时挂通用 input 监听与气泡自身 oninput,一次拖动连写两笔同值,
            // 第二笔若立即 finalize 会把刚发起的 wrap 当帧无过渡归位(9↔0 滚动
            // 消失的根因);同值续写让动画自然走完,onEnd/兜底负责归位。
            if ((d.snapTimer || d.onEnd) && d.cur !== digit) odoFinalize(d);
            odoMove(d, digit);
            // 前导零(非末位且未遇到非零数字)做浅色处理
            if (!foundNonZero && digit === 0 && i < numDigits - 1) digits[i].el.classList.add('leading-zero');
            else { digits[i].el.classList.remove('leading-zero'); if (digit !== 0) foundNonZero = true; }
        }
    }

    function updateSliderFill(slider) {
        const min = parseFloat(slider.min), max = parseFloat(slider.max), val = parseFloat(slider.value);
        const pct = max > min ? ((val - min) / (max - min)) * 100 : 0;
        slider.parentElement.style.setProperty('--fill', pct);
    }

    function updateSliderOut(slider, value) {
        const out = $(slider.id + 'v');
        if (out) {
            if (out._odometer) setOdometerValue(out, value);
            else out.textContent = value;
        }
    }

    // 状态栏同步:主滑条 → odometer。round86 #11: sb3(触摸阈值大数显)按设备
    // 触摸主控切换数据源 -- MPR121 设备显示 rgThTouch(TH TOUCH),3116 设备显示
    // mbrThreshold(THRESHOLD)。互斥守卫: 非当前主控的滑条动画(unpack 的
    // smoothSliderTo 等)不再回写 sb3,防止两滑条并发动画串台。
    const sbMap = { rgAirMin: 'sb1', rgAirMax: 'sb2', rgThTouch: 'sb3', rgBright: 'sb4' };
    function sb3SourceIsMbr() {
        return perKeyIsMbr();
    }
    function updateStatusBar(sliderId, value) {
        // round86 #11: mbrThreshold 联动 sb3(3116 时)
        if (sliderId === 'mbrThreshold') {
            if (sb3SourceIsMbr()) {
                const el = $("sb3");
                if (el && el._odometer) setOdometerValue(el, value);
                else if (el) el.textContent = String(value).padStart(3, '0');
            }
            return;
        }
        // rgThTouch 仅在 MPR 主控时回写 sb3(3116 下的 unpack 动画不得串台)
        if (sliderId === 'rgThTouch' && sb3SourceIsMbr()) return;
        const el = $(sbMap[sliderId]);
        if (!el) return;
        if (el._odometer) setOdometerValue(el, value);
        else el.textContent = String(value).padStart(3, '0');
    }    // round86 #11: 按当前主控刷新 sb3 标签与数值(TH TOUCH / THRESHOLD)
    function updateSb3ForChip() {
        const mbr = sb3SourceIsMbr();
        const labelEn = $("sb3en2"), labelCn = $("sb3en");
        // round86 审查修复(P3): 中文区分两主控语义 -- MPR 为阈值差值判据,
        // 3116 为芯片绝对阈值寄存器, 英文侧已是 TH TOUCH/THRESHOLD。
        if (labelEn) labelEn.textContent = mbr ? "THRESHOLD" : "TH TOUCH";
        if (labelCn) labelCn.textContent = mbr ? "触摸阈值 (芯片)" : "触摸阈值";
        const el = $("sb3");
        if (!el) return;
        const v = mbr ? parseInt($("mbrThreshold").value, 10) : parseInt($("rgThTouch").value, 10);
        if (!isNaN(v)) {
            if (el._odometer) setOdometerValue(el, v);
            else el.textContent = String(v).padStart(3, '0');
        }
    }

    function setSlider(slider, value, opts = {}) {
        if (!slider) return;
        if (value < parseFloat(slider.min)) slider.min = value;
        if (value > parseFloat(slider.max)) slider.max = value;
        slider.value = value;
        updateSliderFill(slider);
        updateSliderOut(slider, value);
        if (!opts.quiet) updateStatusBar(slider.id, parseInt(value, 10));
    }

    // 在途滑条动画登记:保存前必须收敛到目标值,防止打包动画中间值
    const activeSliderAnims = new Map();
    function finishSliderAnims() {
        for (const [id, anim] of activeSliderAnims) {
            cancelAnimationFrame(anim.raf);
            setSlider(anim.slider, anim.target);
            anim.slider.parentElement.style.transition = '';
        }
        activeSliderAnims.clear();
    }

    function smoothSliderTo(slider, targetValue, duration = 600) {
        const startValue = parseFloat(slider.value);
        const diff = targetValue - startValue;
        const track = slider.parentElement;
        track.style.transition = 'none';
        if (Math.abs(diff) < 0.5) {
            setSlider(slider, targetValue);
            track.style.transition = '';
            return;
        }
        const startTime = performance.now();
        // round72: 同一滑条 600ms 内被再次 smoothSliderTo 时,取消旧动画环并按
        // 身份删除登记——此前直接覆盖 Map 条目,旧环继续争写 value 且其收尾的
        // delete 会误删新环登记(finishSliderAnims 在该窗口内收敛不到新环)
        const prev = activeSliderAnims.get(slider.id);
        if (prev) { cancelAnimationFrame(prev.raf); }
        const anim = { slider, target: targetValue, raf: 0 };
        activeSliderAnims.set(slider.id, anim);
        (function tick(now) {
            const progress = Math.min((now - startTime) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            const current = startValue + diff * eased;
            slider.value = current;
            updateSliderFill(slider);
            updateSliderOut(slider, Math.round(current));
            updateStatusBar(slider.id, Math.round(current));
            if (progress < 1) anim.raf = requestAnimationFrame(tick);
            else {
                if (activeSliderAnims.get(slider.id) === anim) activeSliderAnims.delete(slider.id);
                setSlider(slider, targetValue);
                requestAnimationFrame(() => { track.style.transition = ''; });
                // round72d: 程序化动画不触发 input 事件,unpack 后挂在动画尾部的
                // 格子阈值展示/警告/变色只会读到动画起点的旧值,且动画结束后再无
                // 刷新时机(实机首次进配置 6/4 vs 13/12 的根因)。落地时按滑条
                // 身份广播一次,与用户拖动的 input 监听器同源。
                notifySliderSettled(slider.id);
            }
        })(performance.now());
    }

    // round72d: 滑条程序化落地后的联动刷新。阈值类滑条落到设备值后,INPUT TEST
    // 格子的生效阈值、警告文案与滑条/数显变色都以 slider.value 为数据源,必须
    // 在此显式触发(用户拖动路径由 initSliderAnimations 的 input 监听器覆盖)。
    function notifySliderSettled(sliderId) {
        if (sliderId === 'rgThTouch' || sliderId === 'rgThRelease') {
            checkThresholdHints();
            updateTcThresholdDisplay();
        } else if (sliderId === 'rgDt' || sliderId === 'rgDr') {
            checkThresholdHints();
        } else if (sliderId === 'rgBright') {
            updateLightLimitHint();
        }
    }

    const sliderDigits = { rgAirMin: 3, rgAirMax: 3, rgThTouch: 2, rgThRelease: 2, rgBright: 3, rgDt: 1, rgDr: 1, rgHeight: 2, rgLatency: 2, rgMbrGate: 3, mbrThreshold: 3, mbrDebounce: 2, mbrSensitivity: 2, pkThTouch: 2, pkThRelease: 2 };
    // round72: ledLimit/ledSpeed 是灯光面板的迷你直显滑条。此前先被通用循环
    // odometer 化、又被下方文本直写摧毁,_odometer 残留指向孤立节点(僵尸表),
    // 未来任何 setSlider 打到它们都会静默失更新——现在从建表环节直接排除。
    const MINI_TEXT_SLIDERS = { ledLimit: 1, ledSpeed: 1 };

    function initSliderAnimations() {
        Object.entries(sbMap).forEach(([sid, sbid]) => {
            const sbEl = $(sbid);
            if (!sbEl) return;
            createOdometer(sbEl, 3);
            // round72: 启动即按滑条当前值同步状态栏。此前只建表不赋值,sb 停在
            // 全 0 直到用户第一次拖动滑条触发 input,造成页面加载期显示不一致。
            const src = $(sid);
            const v0 = parseInt(src && src.value, 10);
            if (!isNaN(v0)) setOdometerValue(sbEl, v0);
        });
        document.querySelectorAll('input[type="range"]').forEach(slider => {
            const out = $(slider.id + 'v');
            if (out && !MINI_TEXT_SLIDERS[slider.id]) {
                createOdometer(out, sliderDigits[slider.id] || 3);
                setOdometerValue(out, parseInt(slider.value, 10));
            } else if (out) {
                // 迷你直显滑条: 初始即纯文本,通用 input 监听器的 textContent
                // 分支已覆盖其更新路径,无需(也不得)再挂第二套监听器
                out.textContent = slider.value;
            }
            updateSliderFill(slider);
            slider.addEventListener('input', () => {
                updateSliderFill(slider);
                if (out && out._odometer) setOdometerValue(out, parseInt(slider.value, 10));
                else if (out) out.textContent = slider.value;
                updateStatusBar(slider.id, parseInt(slider.value, 10));
                if (slider.id === 'rgBright') updateLightLimitHint();
                if (['rgThTouch', 'rgThRelease', 'rgDt', 'rgDr'].includes(slider.id)) {
                    checkThresholdHints();
                    // round71: 配置模式下全局阈值变化实时反映到 INPUT TEST 格子
                    if (slider.id === 'rgThTouch' || slider.id === 'rgThRelease') updateTcThresholdDisplay();
                }
            });
        });
    }

    // ================================================================
    // Mock 设备(?mock=1 常规一代模拟;?mock=gen2 模拟非一代设备,测门禁拒绝)
    // ================================================================
    const MOCK_PARAM = new URLSearchParams(location.search).get("mock");
    const MOCK = MOCK_PARAM !== null;
    const MOCK_GEN2 = MOCK_PARAM === "gen2";

    function buildMockConfig() {
        const buf = new Uint8Array(CFG_SIZE);
        buf[0] = CFG_MAGIC; buf[1] = CFG_VERSION; buf[2] = 1;
        buf[5] = 0; buf[6] = 0;  // round55: 动态照明开 / 延迟 0ms
        buf[7] = 6; buf[8] = 4; buf[9] = 0x11;
        buf[10] = 500 & 0xFF; buf[11] = (500 >> 8) & 0xFF;
        buf[12] = 200 & 0xFF; buf[13] = (200 >> 8) & 0xFF;
        buf[24] = 255; buf[25] = 10;
        // round64: 逐键阈值全 0(继承); Mock 按 1.6.0 报版本以启用面板逐键 UI
        for (let i = 0; i < CFG_NUM_KEYS; i++) {
            buf[CFG_OFF_TH_TOUCH_KEY + i] = 0;
            buf[CFG_OFF_TH_RELEASE_KEY + i] = 0;
        }
        buf[127] = calcXorSum(buf);
        return buf;
    }

    // round89a: 模拟已保存 Flash 与当前 RAM 配置的区别。新建端口恢复最近
    // CFG_SAVE 快照, CFG_SET 单独执行不会跨重连持久化。
    let mockSavedConfig = null;
    class MockPort {
        constructor() {
            this.cfg = mockSavedConfig ? mockSavedConfig.slice() : buildMockConfig();
            this.configMode = false;
            this.cfgSetPending = null;  // round63f: CFG_SET 载入流跨 write 累积
            this.mbrPending = null;  // round75: 0xBA 载荷跨 write 累积(面板改双写)
            this.mbrPendingTimer = null;  // round75 审查: 载入流断流超时, 仿固件 readCdcPayload
            this.mbrCfg = {};  // round82: 各芯片最近烧录的 128B 表(0xC6 回读数据源)
            this.read3116Pending = null;  // round82: 0xC6 载荷 [addr] 跨 write 累积
            this.read3116Timer = null;  // round82: 载荷断流超时
            this.mbrDbgPending = null;  // round88: 0xC7 载荷 [addr][sensor] 跨 write 累积
            this.mbrDbgTimer = null;  // round88: 载荷断流超时
            this.flashingPending = false;  // round76b: 0xBB 确认字节跨 write(面板改双写)
            this.flashingTimer = null;  // round76b: 仿固件 5s 确认窗,超时 denied
            this.tofCount = MOCK_GEN2 ? 3 : 5;  // mock=1 模拟 v1·32寸三片 MBR 恢复链
            this.mockMbrMask = MOCK_GEN2 ? 0 : 0b001110;
            this.rawReport = 0;  // round66/85: 压力上报会话 level (0/1/2)
            this.cmdLog = [];  // round63h: 与真实固件 0xCE 命令日志同构(仅顶层命令字节)
            // 无定时器收发:后台标签页的 setTimeout 节流会把 Mock 卡死,
            // 因此数据入队即唤醒等待的 reader,不依赖轮询。
            this.dev = { rx: [], closed: false, waiters: [] };
            const self = this;
            this.readerObj = {
                read: async () => {
                    while (self.dev.rx.length === 0 && !self.dev.closed) {
                        await new Promise(r => self.dev.waiters.push(r));
                    }
                    if (self.dev.rx.length === 0) return { value: undefined, done: true };
                    return { value: self.dev.rx.shift(), done: false };
                },
                cancel: async () => {
                    self.dev.closed = true;
                    self.dev.waiters.forEach(w => w());
                    self.dev.waiters = [];
                },
                releaseLock: () => {},
            };
            this.writerObj = {
                write: async (bytes) => { self.onHostWrite(new Uint8Array(bytes)); },
                close: async () => {},
            };
            this.opened = false;
        }
        getInfo() { return { usbVendorId: 0xCAFE, usbProductId: 0x4009 }; }
        async open() { this.opened = true; return; }
        async setSignals() {}  // round76: 真实 Web Serial 有此 API,Mock 补 no-op
        async close() { this.opened = false; }
        get readable() { return { getReader: () => this.readerObj }; }
        get writable() { return { getWriter: () => this.writerObj }; }

        send(bytes, delay = 0) {
            const chunk = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
            const deliver = () => {
                this.dev.rx.push(chunk);
                const w = this.dev.waiters.shift();
                if (w) w();
            };
            if (delay > 0) setTimeout(deliver, delay);
            else deliver();
        }
        sendText(text, delay = 0) {
            this.send(new TextEncoder().encode(text + "\n"), delay);
        }

        // round75 审查: 仿固件 readCdcPayload 的 1s 总时限——载入流断流时丢弃
        // 半截载荷, 避免杂散 0xBA 之后 Mock 永久吞掉后续命令(固件侧是真复位风险,
        // Mock 侧是命令通道卡死)。
        mbrArm() {
            if (this.mbrPendingTimer) clearTimeout(this.mbrPendingTimer);
            this.mbrPendingTimer = setTimeout(() => { this.mbrPending = null; this.mbrPendingTimer = null; }, 1000);
        }
        mbrComplete() {
            if (this.mbrPendingTimer) { clearTimeout(this.mbrPendingTimer); this.mbrPendingTimer = null; }
            const payload = new Uint8Array(this.mbrPending);
            this.mbrPending = null;
            const addr = payload[0];
            this.mbrCfg[addr] = payload.slice(1);
            this.sendText("programing 3116 chip", 10);
            this.sendText("done", 600);
        }
        flashingClear() {
            if (this.flashingTimer) { clearTimeout(this.flashingTimer); this.flashingTimer = null; }
            this.flashingPending = false;
        }
        // round78: 0xBB 确认流辅助。固件语义:0xBB 后读 1 字节确认(跨 write 或
        // 同 write 续段),readCdcPayload 只取 1 字节,非 0xA5 即 deny,deny 后
        // 剩余字节回到命令循环。返回 true 表示设备已离开(BOOTSEL 模拟断开)。
        flashingArm() {
            this.flashingPending = true;
            if (this.flashingTimer) clearTimeout(this.flashingTimer);
            this.flashingTimer = setTimeout(() => {
                this.flashingPending = false;
                this.flashingTimer = null;
                this.sendText("flashing denied", 10);
            }, 5000);
        }
        flashingConsume(b) {
            this.flashingClear();
            if (b === 0xA5) {
                // 仿固件进入 BOOTSEL:设备离开(端口消失)。面板刷写流程的
                // "重启验证"(轮询 connected)据此放行;mock 无真实盘符,
                // 后续盘符选择以浏览器不支持/用户取消自然收尾。
                this.dev.closed = true;
                this.dev.waiters.forEach(w => w());
                this.dev.waiters = [];
                return true;
            }
            this.sendText("flashing denied", 10);
            return false;
        }

        onHostWrite(bytes) {
            let i = 0;
            // round75: 若正处于 0xBA 载入流中, 本次 write 的全部字节都是
            // addr+128B 表负载续段(面板双写发送), 不可能是新的命令字节。
            if (this.mbrPending !== null) {
                while (i < bytes.length && this.mbrPending.length < 129) {
                    this.mbrPending.push(bytes[i++]);
                }
                if (this.mbrPending.length === 129) {
                    // round82: 记录各芯片最近烧录的表, 供 0xC6 回读(仿固件 NVM)
                    const a = this.mbrPending[0];
                    this.mbrCfg[a] = new Uint8Array(this.mbrPending.slice(1));
                    this.mbrComplete();
                }
                return;  // 载入流未凑满 129 也直接返回, 剩余字节留到下一次 write
            }
            // round82: 0xC6 读回载荷 [addr] 跨 write 累积(面板双写), 与
            // cfgSetPending/mbrPending 同模式
            if (this.read3116Pending !== null) {
                while (i < bytes.length && this.read3116Pending.length < 1) {
                    this.read3116Pending.push(bytes[i++]);
                }
                if (this.read3116Pending.length === 1) {
                    const a = this.read3116Pending[0];
                    this.read3116Pending = null;
                    if (this.read3116Timer) { clearTimeout(this.read3116Timer); this.read3116Timer = null; }
                    const allowed = (a === 0x37) || (a >= 0x40 && a <= 0x44);
                    const key = "0x" + a.toString(16);
                    if (!allowed) {
                        this.sendText("read3116: address not allowed.", 10);
                    } else {
                        const t = this.mbrCfg[a] || MBR_TABLES[key];
                        if (t) this.send(Array.from(t), 20);
                        else this.sendText("3116 read fail", 10);
                    }
                }
                return;
            }
            // round88: 0xC7 载荷 [addr][sensor] 跨 write 累积(面板双写), 与
            // read3116Pending 同模式。满 2B 后仿固件回 11B 小端帧或文本行。
            if (this.mbrDbgPending !== null) {
                while (i < bytes.length && this.mbrDbgPending.length < 2) {
                    this.mbrDbgPending.push(bytes[i++]);
                }
                if (this.mbrDbgPending.length === 2) {
                    const a = this.mbrDbgPending[0];
                    const s = this.mbrDbgPending[1];
                    this.mbrDbgPending = null;
                    if (this.mbrDbgTimer) { clearTimeout(this.mbrDbgTimer); this.mbrDbgTimer = null; }
                    if (!(a >= 0x40 && a <= 0x44) || s > 15) {
                        this.sendText("mbrdebug: address / sensor not allowed.", 10);
                    } else {
                        // 模拟读数: DIFF 以传感器编号相位摆动(0-255), 不代表毫米;
                        // sync 恒定; cp 随编号 8-30pF;
                        // baseline=1024+40*s; raw=baseline+diff。
                        const t = Date.now() / 1000;
                        const diff = Math.round(127.5 + 127.5 * Math.sin(t * 1.2 + s * 0.9));
                        const cp = 8 + (s * 3) % 24;
                        const base = 1024 + 40 * s;
                        const raw = Math.min(4095, base + diff);
                        const out = [CMD.MBR3116_DEBUG, a, s, 0x42, cp,
                            diff & 0xFF, (diff >> 8) & 0xFF,
                            base & 0xFF, (base >> 8) & 0xFF,
                            raw & 0xFF, (raw >> 8) & 0xFF];
                        this.send(out, 30);
                    }
                }
                return;
            }
            // round63f: 若正处于 CFG_SET 载入流中, 本次 write 的全部字节都是
            // 配置负载续段(面板分块发送), 不可能是新的命令字节, 直接累积。
            if (this.cfgSetPending !== null) {
                while (i < bytes.length && this.cfgSetPending.length < 128) {
                    this.cfgSetPending.push(bytes[i++]);
                }
                if (this.cfgSetPending.length === 128) {
                    const cfg = new Uint8Array(this.cfgSetPending);
                    this.cfgSetPending = null;
                    if (cfg[0] === CFG_MAGIC && calcXorSum(cfg) === cfg[127]) {
                        sanitizeMbrSignalProfile(cfg);
                        cfg[127] = calcXorSum(cfg);
                        this.cfg = cfg;
                        this.sendText("read 128 byte. check ok. config changed.", 15);
                    } else {
                        this.sendText("illegal config", 15);
                    }
                }
                return;  // 载入流未凑满 128 也直接返回, 剩余字节留到下一次 write
            }
            // round78: 0xBB 确认窗开启中——本笔 write 的首字节即确认字节
            // (固件 readCdcPayload 语义), 与 cfgSetPending/mbrPending 同模式。
            if (this.flashingPending) {
                const b = bytes[i++];
                if (this.flashingConsume(b)) return;  // 设备已离开(BOOTSEL)
                // denied: 剩余字节作为新命令流继续走下方分发
            }
            while (i < bytes.length) {
                const cmd = bytes[i++];
                if (this.cmdLog.length > 255) this.cmdLog.shift();
                this.cmdLog.push(cmd);
                if (cmd === CMD.DEV_DETECT) { this.send([CMD.DEV_DETECT]); }
                else if (cmd === CMD.GET_API_LEVEL) { this.send([0x10]); }  // 一代设备 API 恒为 0x10
                else if (cmd === CMD.GET_INPUT) { this.send(this.inputFrame()); }
                else if (cmd === CMD.SET_LED) { i += 96; /* 无应答 */ }
                else if (cmd === CMD.CONFIG_MODE) { this.configMode = true; }
                else if (cmd === CMD.CFG_KEEPALIVE) { /* round57: 心跳,静默无响应 */ }
                else if (cmd === CMD.GET_RAW_STATUS) {
                    // round66: 压力上报开关查询
                    // round68: 报 active 状态(会话 level OR cfg2 bit1 游戏基线)
                    // round85: 会话为 level 0/1/2, 与真机固件 RAW=0|1|2 同构
                    const lvl = this.rawReport ? this.rawReport : (((this.cfg[5] & BIT_GAME_RAW_SLIDER) !== 0) ? 1 : 0);
                    this.sendText("RAW=" + lvl, 8);
                }
                else if (cmd === CMD.SET_RAW_REPORT) {
                    // round66: 压力上报开关设置(1B)
                    // round68: 0x00 仅关会话开关;0xC4 报 active(含游戏基线)
                    // round85: 载荷为 level(0/1/2), 未知值保持现态(真机同语义)
                    const v = bytes[i++];
                    if (v === 0) this.rawReport = 0;
                    else if (v === 1 || v === 2) this.rawReport = v;
                    const lvl = this.rawReport ? this.rawReport : (((this.cfg[5] & BIT_GAME_RAW_SLIDER) !== 0) ? 1 : 0);
                    this.sendText("RAW=" + lvl, 8);
                }
                else if (cmd === 0xCE) {
                    // round63h: 命令日志转储, 与真机 handleCommand 0xCE 同构
                    const n = Math.min(this.cmdLog.length, 255);
                    this.send([n]);
                    this.send(Array.from(this.cmdLog.slice(-n)));
                }
                else if (cmd === CMD.DETECT) {
                    this.send([CMD.DETECT, MOCK_GEN2 ? 0b111 : 0, this.mockMbrMask, this.tofCount, 0b00000001, MOCK_GEN2 ? 1 : 2]);
                }
                else if (cmd === CMD.CFG_READ) {
                    this.send(Array.from(this.cfg), 15);
                    this.sendText("read 128 byte ok", 25);
                    this.sendText("using config in page 3", 35);
                }
                else if (cmd === CMD.CFG_SAVE) {
                    mockSavedConfig = this.cfg.slice();
                    this.sendText("saveConfig result: 0, currentPage = 3", 15);
                }
        else if (cmd === CMD.CFG_ERASE) { mockSavedConfig = null; this.sendText("erase ok", 15); }
        else if (cmd === CMD.CFG_SET) {
            // round63f: 真实固件 setConfig() 一次性读 128 字节, 面板可能分块发送。
            // Mock 必须跨 write 累积载入流(此前按单次 write 解析, 分块会被拆坏)。
            if (this.cfgSetPending === null) this.cfgSetPending = [];
            while (i < bytes.length && this.cfgSetPending.length < 128) {
                this.cfgSetPending.push(bytes[i++]);
            }
            if (this.cfgSetPending.length === 128) {
                const cfg = new Uint8Array(this.cfgSetPending);
                this.cfgSetPending = null;
                if (cfg[0] === CFG_MAGIC && calcXorSum(cfg) === cfg[127]) {
                    sanitizeMbrSignalProfile(cfg);
                    cfg[127] = calcXorSum(cfg);
                    this.cfg = cfg;
                    this.sendText("read 128 byte. check ok. config changed.", 15);
                } else {
                    this.sendText("illegal config", 15);
                }
            }
            // 未凑满 128 字节则等待下一次 write(与真机 setConfig 行为一致)
        }
                else if (cmd === CMD.GET_STATUS) {
                    this.sendText("get status...", 8);
                    this.sendText("Nyanithm build MOCK-1.5.3", 16);
                    this.sendText("hwVer: " + this.cfg[2], 24);
                    this.sendText("tof0 = 812 tof1 = 905 tof2 = 770 tof3 = 640", 32);
                    this.sendText("using config in page 3", 40);
                }
                else if (cmd === CMD.EXIT) { this.configMode = false; }
                else if (cmd === CMD.LOAD3116CONFIG) {
                    // round75: 面板改双写后 0xBA 与 129B 载荷分两次 write 到达,
                    // Mock 与 CFG_SET 同理跨 write 状态化累积(addr+128B)再应答。
                    if (this.mbrPending === null) { this.mbrPending = []; this.mbrArm(); }
                    while (i < bytes.length && this.mbrPending.length < 129) {
                        this.mbrPending.push(bytes[i++]);
                    }
                    if (this.mbrPending.length === 129) {
                        this.mbrComplete();
                    }
                }
                else if (cmd === CMD.FLASHING) {
                    // round78 重写: 0xBB 武装 5s 确认窗(仿固件),确认字节由
                    // onHostWrite 顶部 flashingPending pre-check 消费(跨 write)。
                    // 旧实现(round76b)把同 write 的 0xA5 也当"武装"字节、第二笔
                    // [0xA5] 落到 unknown command——确认链路从未走通。
                    // 旧式合并写([0xBB,0xA5] 单笔)由下方立即消费兼容。
                    this.flashingArm();
                    if (i < bytes.length && this.flashingPending) {
                        const b = bytes[i++];
                        if (this.flashingConsume(b)) return;  // 设备已离开
                    }
                }
                else if (cmd === CMD.GET_VERSION) {
                    // round89a: Mock 覆盖实验性持续 DIFF 门的版本门禁。
                    const s = "FW:1.6.6-beta1 API:0x10 HW:v1 Built:Jan 01 2026 12:00:00 SDK:2.2.0 VAR:hw_v1 NYANFW1;1.6.6-beta1;hw_v1;BID=round89a";
                    this.send([s.length], 8);
                    this.send(Array.from(new TextEncoder().encode(s)), 14);
                }
                else if (cmd === CMD.READ3116CONFIG) {
                    // round82: 0xC6 命令字节首发; 载荷 [addr] 由顶部
                    // read3116Pending 跨 write 消费。1s 断流超时仿固件语义。
                    this.read3116Pending = [];
                    if (this.read3116Timer) clearTimeout(this.read3116Timer);
                    this.read3116Timer = setTimeout(() => { this.read3116Pending = null; }, 1000);
                }
                else if (cmd === CMD.MBR3116_DEBUG) {
                    // round88: 0xC7 命令字节首发; 载荷 [addr][sensor] 由顶部
                    // mbrDbgPending 跨 write 消费(固件侧 readCdcPayload 500ms)。
                    this.mbrDbgPending = [];
                    if (this.mbrDbgTimer) clearTimeout(this.mbrDbgTimer);
                    this.mbrDbgTimer = setTimeout(() => { this.mbrDbgPending = null; }, 1000);
                }
                else { this.sendText("unknown command", 10); }
            }
        }

        inputFrame() {
            const f = new Uint8Array(33);
            const t = Date.now() / 1000;
            for (let i = 0; i < 32; i++) {
                // round66: 模拟真实 diff 尺度(Idle 底噪 ~4-13、触碰 40-60、坏键偏置 +14)。
                // rawReport=false(普通轮询演示): 高斯扫模拟划键;
                // rawReport=true(校准会话): 静止 idle + 坏键偏置 + 轮转"按下"每 1.5s 一键,
                // 使校准 Phase1(静置) 采到真实 idleMax、Phase2(划键) 采到每键 touchMin。
                // round69: cfg2 bit1(游戏压力映射)开启且无会话开关时,模拟固件 game 分支
                // (按下报映射值 / 释放 0)。
                // round80: 固件报送层对 MPR ×2 (clamp 255)——Mock 作为设备模拟器
                // 同步该语义: game 映射 ×4→×2; rawReport 会话对 MPR 输出 ×2。
                const gameRawOn = this.rawReport === 0 && ((this.cfg[5] & BIT_GAME_RAW_SLIDER) !== 0);
                const simMbr = ((this.cfg[3] & BIT_MBR3116) !== 0) || this.cfg[2] >= 3;
                let idleBias = 0;
                if (i === 4) idleBias = 14;   // 坏键 A(高空闲)
                else if (i === 16) idleBias = 6;  // 坏键 B(中等)
                const base = 6 + 2 * (0.5 + 0.5 * Math.sin(t * 2.1 + i * 1.7));
                let v = base + idleBias + 3 * (0.5 + 0.5 * Math.sin(t * 3 + i));
                // round86: level 2=原始物理层直报(含 idle 噪底);
                // level 1(模拟结果) 或 level 0(常规游戏): 呈现设备在游戏中的实际输入结果!
                // 未触发判定恒为 0; 触发时若开启真实压力(gameRawOn)输出动态压力, 否则输出 128 标准判定。
                if (this.rawReport === 2) {
                    f[i] = Math.round(Math.min(255, v));
                } else {
                    const bump = Math.exp(-Math.pow(((t * 6) % 32) - i, 2) / 6);
                    const pressed = (bump > 0.35);
                    if (!pressed) {
                        f[i] = 0;
                    } else if (gameRawOn) {
                        f[i] = Math.min(255, Math.round(v * 2));
                    } else {
                        f[i] = 128;
                    }
                }
            }
            f[32] = (Math.sin(t * 1.7) > 0 ? 0b001100 : 0) | (Math.sin(t * 0.9) > 0.6 ? 0b110000 : 0);
            return f;
        }
    }

    let mockPort = null;
    function acquireMockPort() {
        // Enumerating an open device returns that same port. Creating another
        // instance here would make __mockPort point at an unused transport.
        if (!mockPort || mockPort.dev.closed) mockPort = new MockPort();
        window.__mockPort = mockPort;
        return mockPort;
    }
    // round72d: 桥接实例到 window 供控制台调试/自动化注入设备侧配置
    // (与 window.dumpCfgCmdLog 同惯例;仅 MOCK 分支存在)。
    const mockSerial = {
        getPorts: async () => [acquireMockPort()],
        requestPort: async () => acquireMockPort(),
        addEventListener: () => {},
        removeEventListener: () => {},
    };
    if (MOCK) {
        // navigator.serial 在原型上只有 getter,严格模式直接赋值会抛
        // TypeError;必须用 defineProperty 在实例上遮蔽
        try {
            Object.defineProperty(navigator, "serial", { value: mockSerial, configurable: true });
        } catch (e) {
            console.warn("mock serial 注入失败:", e);
        }
        log("Mock 模式已启用:使用内置一代设备模拟器(无真机协议流程)", "warn");
    }

    // ================================================================
    // 串口读写(一代引擎)
    // ================================================================
    async function openPort(portArg, quiet, opts) {
        // round75 审查: 幂等守卫——自动重连轮询与手动点击并发时, 已连接状态
        // 直接成功返回, 防止同端口二次 open 抛 InvalidStateError 打出与实际
        // 状态矛盾的「串口连接失败」文案(存量+新增窗口一并关闭)。
        if (connected) return true;
        if (!navigator.serial) {
            alert("当前浏览器不支持 Web Serial API,请使用 Chrome / Edge 并通过 https 或 localhost 访问。");
            return false;
        }
        const manual = !!(opts && opts.manualPicker);  // round86 #10: 强制弹系统选口列表
        try {
            const NYAN_VID = 0xCAFE, NYAN_PID = 0x4009;
            // round86 #10: 上次设备记忆。单设备时直接回连;多设备时优先
            // 上次连接的那台(localStorage 记录连接时的枚举序索引,跨刷新尽力
            // 恢复;同 VID/PID 设备 Web Serial 无稳定唯一 ID,枚举序是唯一近似)。
            // 索引基于本次 getPorts() 快照计算,连接后不再二次调用 getPorts()
            // 同一枚举快照用于选口,避免无谓重查。
            const authorized = await navigator.serial.getPorts();
            const nyList = authorized.filter(p => {
                const info = p.getInfo();
                return info.usbVendorId === NYAN_VID && info.usbProductId === NYAN_PID;
            });
            if (portArg) {
                port = portArg;
            } else if (manual) {
                // round86 #10: 强制手动选择设备(长按触发)。
                // 绝不受 lastPort 干扰, 无条件调用 requestPort 弹出系统设备选择列表!
                try {
                    port = await navigator.serial.requestPort({ filters: [{ usbVendorId: NYAN_VID, usbProductId: NYAN_PID }] });
                } catch (e1) {
                    if (e1.name === "NotFoundError" || e1.name === "AbortError" || (e1.message && e1.message.includes("No port selected"))) {
                        log("已取消串口选择", "info");
                        return false;
                    }
                    try {
                        port = await navigator.serial.requestPort({});
                    } catch (e2) {
                        log("已取消串口选择", "info");
                        return false;
                    }
                }
            } else {
                let lastPort = null;
                if (nyList.length > 0) {
                    const lastIdx = parseInt(localStorage.getItem("nyanithm.lastPortIdx") || "-1", 10);
                    lastPort = (lastIdx >= 0 && lastIdx < nyList.length) ? nyList[lastIdx] : null;
                    if (nyList.length === 1) lastPort = nyList[0];
                }
                let alreadyOpen = false;
                if (lastPort) {
                    try {
                        await lastPort.open({ baudRate: 115200, bufferSize: 8192 });
                        port = lastPort;
                        alreadyOpen = true;
                    } catch (eOpen) {
                        localStorage.removeItem("nyanithm.lastPortIdx");
                        log("上次连接的设备未能直接打开(可能已更换/重枚举), 正在打开选择列表...", "warn");
                        lastPort = null;
                    }
                }
                if (!port) {
                    try {
                        port = await navigator.serial.requestPort({ filters: [{ usbVendorId: NYAN_VID, usbProductId: NYAN_PID }] });
                    } catch (e1) {
                        if (e1.name === "NotFoundError" || e1.name === "AbortError" || (e1.message && e1.message.includes("No port selected"))) {
                            log("已取消串口选择", "info");
                            return false;
                        }
                        try {
                            port = await navigator.serial.requestPort({});
                        } catch (e2) {
                            log("已取消串口选择", "info");
                            return false;
                        }
                    }
                }
                if (alreadyOpen) {
                    await finishOpen();
                    return true;
                }
            }
            // round86 #10: 记录本次连接的设备索引(下次单击直接回连)
            try {
                const idx = nyList.indexOf(port);
                if (idx >= 0) localStorage.setItem("nyanithm.lastPortIdx", String(idx));
                else localStorage.removeItem("nyanithm.lastPortIdx");  // 手动新选的设备不在快照内,清记忆
            } catch (e) { /* 记忆失败不影响连接 */ }
            await port.open({ baudRate: 115200, bufferSize: 8192 });
            await finishOpen();
            return true;
        } catch (e) {
            if (!quiet) { log("打开串口失败: " + e.message, "error"); setStatus("串口连接失败", "error"); }
            return false;
        }
    }

    // round86 审查修复(P3): openPort 的共享后段(DTR/读写器/状态翻转)。
    // 抽出供 early-open(记忆端口直连)与常规路径复用, 防二次 open。
    async function finishOpen() {
        // round76: 显式拉高 DTR。固件 standby 超时据此识别"主机仍握着端口",
        // 在面板事务间隙继续抑制 Windows 动态照明抢写,否则最后一次 0xB2
        // 五秒后灯带就被系统强调色(默认蓝)刷掉。
        try { await port.setSignals({ dataTerminalReady: true }); } catch (e) { log("DTR 置位失败(动态照明抑制可能不生效): " + e.message, "warn"); }
        writer = port.writable.getWriter();
        reader = port.readable.getReader();
        readBuffer = new Uint8Array(0);
        readLoopRunning = true;
        readLoop();
        connected = true;
        updateUI();
        setStatus("串口已连接", "");
        log("串口已打开,波特率 115200");
    }

    // round57: 配置模式心跳。固件在配置模式下 60s 无 CDC 操作自动重启退出
    // (handleCommand 的保底);面板在进入配置模式后每 30s 发 0xC3 重置该计时器,
    // 让长时间配置会话不被打断。退出配置/断开时停止。
    let cfgKeepaliveTimer = null;
    function startCfgKeepalive() {
        stopCfgKeepalive();
        cfgKeepaliveTimer = setInterval(async () => {
            if (!connected || !configMode) { stopCfgKeepalive(); return; }
            // round63: 心跳必须和命令事务串行。此前直接 writeBytes(0xC3) 不认
            // serialBusy,若在 doSaveConfig 发送 CFG_SET 的 128 字节载入流的窗口内
            // 命中,0xC3 会在 UART 层被固件 setConfig() 读进配置块,使整块错位,
            // 最终一个配置字节残留在缓冲并可能被解码成 0xB9/0xBB,触发设备重启
            // (表现为"等待行响应超时" + "device has been lost")。走 withSerialLock
            // 让心跳排在当前事务之后,绝不穿插进载入流。
            await withSerialLock(async () => {
                if (!connected || !configMode) return;
                try {
                    await writeBytes(new Uint8Array([CMD.CFG_KEEPALIVE]));
                } catch (e) { /* 串口异常由 readLoop/断开清理兜底 */ }
            });
        }, 30000);
    }
    function stopCfgKeepalive() {
        if (cfgKeepaliveTimer) { clearInterval(cfgKeepaliveTimer); cfgKeepaliveTimer = null; }
    }

    async function closePort() {
        resetMbrSession();
        mbrSignalFwSupport = false;
        stopCfgKeepalive();
        stopLedAnim();
        stopTofPoll();
        stopUnplugReconnect();  // round75: 主动关闭时停掉意外断开重连轮询
        // round76 审查: 显式释放 DTR 兜底,不依赖 OS 在 port.close() 时反断言
        try { if (port) await port.setSignals({ dataTerminalReady: false }); } catch (e) {}
        inputPolling = false;
        readLoopRunning = false;
        configMode = false;
        rawReportOn = false; rawReportLevelCur = 0;  // round85: 会话态复位
        updateTcThresholdDisplay();  // round71: 断开时格子恢复压力基线
        try { if (reader) await reader.cancel(); } catch (e) {}
        try { if (writer) await writer.close(); } catch (e) {}
        try { if (port) await port.close(); } catch (e) {}
        reader = null; writer = null; port = null;
        connected = false;
        resetInputBtn();
        updateUI();
        setStatus("未连接", "");
        log("串口已关闭");
    }

    // 意外断开(拔线 / 设备重启进 BOOTSEL / 刷写后重枚举)的幂等清理
    function handleUnexpectedDisconnect(reason) {
        resetMbrSession();
        mbrSignalFwSupport = false;
        if (!connected && !port && !reader) return;
        stopSaveRebootReconnect();  // round63j: 意外断开时停止保存后自动重连计时器
        stopCfgKeepalive();
        stopLedAnim();
        stopTofPoll();
        inputPolling = false;
        readLoopRunning = false;
        configMode = false;
        rawReportOn = false; rawReportLevelCur = 0;  // round85: 会话态复位
        try { if (reader) reader.cancel().catch(() => {}); } catch (e) {}
        try { if (writer) writer.close().catch(() => {}); } catch (e) {}
        try { if (port) port.close().catch(() => {}); } catch (e) {}
        reader = null; writer = null; port = null;
        readBuffer = new Uint8Array(0);
        connected = false;
        resetInputBtn();
        updateTcThresholdDisplay();  // round71 复查 A1: 清格子阈值标记,重进配置才能正确重绘
        // round71 终审 P3: 校准测量中断线,中止向导避免跑完弹出伪统计报告
        if (calRunning) calAbort = true;
        updateUI();
        setStatus("连接已断开", "error");
        log(reason, "warn");
        // round75: 设备复位/重枚举后自动尝试重连, 不再要求用户手动点连接。
        startUnplugReconnect();
    }

    async function readLoop() {
        while (readLoopRunning && reader) {
            try {
                const { value, done } = await reader.read();
                if (done || !value) break;
                const nb = new Uint8Array(readBuffer.length + value.length);
                nb.set(readBuffer);
                nb.set(value, readBuffer.length);
                readBuffer = nb;
            } catch (e) {
                if (readLoopRunning) log("读取错误: " + e.message, "error");
                break;
            }
        }
        if (readLoopRunning) handleUnexpectedDisconnect("串口连接已断开(设备重启或拔出)");
    }

    async function writeBytes(bytes) {
        if (!writer) throw new Error("未连接");
        await writer.write(bytes);
    }

    async function waitForBytes(n, timeout = 1000) {
        const start = performance.now();
        while (readBuffer.length < n) {
            if (performance.now() - start > timeout) throw new Error(`等待 ${n} 字节超时`);
            await nextTick();
        }
        const out = readBuffer.slice(0, n);
        readBuffer = readBuffer.slice(n);
        return out;
    }

    async function waitForLine(timeout = 1000) {
        const start = performance.now();
        while (true) {
            const idx = readBuffer.indexOf(10);
            if (idx >= 0) {
                const line = readBuffer.slice(0, idx + 1);
                readBuffer = readBuffer.slice(idx + 1);
                return new TextDecoder().decode(line).replace(/\r?\n$/, "");
            }
            if (performance.now() - start > timeout) throw new Error("等待行响应超时");
            await nextTick();
        }
    }

    async function readAllText(timeout = 400) {
        await sleep(timeout);
        const out = readBuffer;
        readBuffer = new Uint8Array(0);
        return new TextDecoder().decode(out);
    }

    function flushReadBuffer() { readBuffer = new Uint8Array(0); }

    // 串口事务锁:inputLoop 每轮 flushReadBuffer() 会吞掉命令应答,
    // 所有命令-应答交互必须持锁串行,inputLoop 见锁即让路。
    let serialBusy = false;
    let serialQueue = Promise.resolve();
    function withSerialLock(task) {
        const run = serialQueue.then(async () => {
            serialBusy = true;
            await sleep(30);  // 让在途的 GET_INPUT 应答落盘并随后被丢弃
            try { return await task(); } finally { serialBusy = false; }
        });
        serialQueue = run.catch(() => {});
        return run;
    }

    // ================================================================
    // 握手与设备信息
    // ================================================================
    async function autoHandshake() {
        await withSerialLock(async () => {
            try {
                flushReadBuffer();
                await writeBytes(new Uint8Array([CMD.DEV_DETECT]));
                const b = await waitForBytes(1, 800);
                if (b[0] === CMD.DEV_DETECT) { log("设备握手成功 (0xB0)"); setStatus("手台已连接", "connected"); }
                else { log(`设备握手异常,返回 0x${b[0].toString(16).padStart(2, "0")}`, "warn"); }
            } catch (e) { log("设备握手失败: " + e.message, "warn"); return; }
            try {
                await sleep(20);
                flushReadBuffer();
                await writeBytes(new Uint8Array([CMD.GET_API_LEVEL]));
                const b = await waitForBytes(1, 800);
                const lvl = b[0];
                $("apiLevelVal").textContent = "0x" + lvl.toString(16).padStart(2, "0");
                // round69: API 0x10(1.5.x)/0x11(v1.6) 均属一代固件; <0x10 才提示不匹配
                if (lvl >= 0x10) { log("API Level 匹配 v1 固件: 0x" + lvl.toString(16)); $("apiLevelVal").className = "metric-cell-value ok"; }
                else {
                    log(`警告: 检测到 API Level 0x${lvl.toString(16).padStart(2, "0")},低于一代固件最低要求 (0x10)`, "warn");
                    $("apiLevelVal").className = "metric-cell-value err";
                    setStatus("设备版本不匹配", "error");
                }
            } catch (e) { log("读取 API Level 失败: " + e.message, "warn"); }
            try {
                await sleep(20);
                await queryDevInfo();
            } catch (e) { log("读取设备信息失败: " + e.message, "warn"); }
        });
    }

    // 0xBD: [1B len][ASCII] "FW:%s API:..." -> devInfo
    async function queryDevInfo() {
        // Capabilities belong to this successful handshake, never a previous
        // device whose version request timed out or returned malformed text.
        mbrSignalFwSupport = false;
        updateMbrSignalUi();
        flushReadBuffer();
        await writeBytes(new Uint8Array([CMD.GET_VERSION]));
        const lenB = await waitForBytes(1, 800);
        const len = lenB[0];
        if (len === 0) { log("设备信息为空", "warn"); return null; }
        const payload = await waitForBytes(len, 1000);
        const info = new TextDecoder("utf-8").decode(payload);
        const m = info.match(/FW:(\S+)\s+API:0x([0-9A-Fa-f]+)\s+HW:v(\d+)/);
        if (m) {
            const vm = info.match(/VAR:([A-Za-z_0-9]+)/);
            const sm = info.match(/NYANFW1;([^;\s]+);([^;\s]+)(?:;BID=([^;\s]+))?/);
            devInfo = { fw: m[1], api: parseInt(m[2], 16), hwVer: parseInt(m[3], 10), var: vm ? vm[1] : null, sig: sm ? { version: sm[1], variant: sm[2], buildId: sm[3] || null } : null, buildId: sm ? (sm[3] || null) : null, raw: info };
            log(`设备信息: 固件 ${devInfo.fw}${devInfo.var ? " (" + devInfo.var + ")" : ""}${devInfo.buildId ? " / 构建 " + devInfo.buildId : " / 旧构建(无精确标识)"} / API 0x${devInfo.api.toString(16)} / 硬件 v${devInfo.hwVer} (${hwVerLabel(devInfo.hwVer)})`);
            $("infoFw").textContent = devInfo.fw + (devInfo.var ? " · " + devInfo.var : "");
            // round81: 裸 "v2"(hwVer 数值)曾被视为"二代机"误导——32寸一代机=hw2,
            // 显示为「v1·32寸」全称; 原始数值保留在日志与详情弹窗。
            $("infoApi").textContent = "0x" + devInfo.api.toString(16) + " / " + hwVerLabel(devInfo.hwVer);
            $("infoVar").textContent = devInfo.var || "(旧固件)";
            // round66/70: 压力上报会话门禁以固件版本为准(1.6.0+ 才有 0xC4/0xC5
            // pressureSnap 管线)。API 是硬件/协议标识(一代=0x10),不能当新命令
            // 门禁:旧面板曾用 api>=0x11 导致真机(API 0x10)永远不发 0xC5。
            rawReportSupported = !!(devInfo.fw && cmpVersion(devInfo.fw, "1.6.0") >= 0);
            // round80/81: 悬空抑制滑块(mbrTouchGate)门禁, 需固件 1.6.2-beta1+
            // (旧固件该字节是 reserved, 写入不生效)。
            mbrGateFwSupport = !!(devInfo.fw && cmpVersion(devInfo.fw, "1.6.2-beta1") >= 0);
            // round85: 0xC5 level 2(原始结果)门禁, 需固件 1.6.3-beta1+
            // (旧固件对载荷 2 落空忽略; 门禁未过时面板自动回退发 level 1)。
            rawLevelFwSupport = !!(devInfo.fw && cmpVersion(devInfo.fw, "1.6.3-beta1") >= 0);
            // round88: 0xC7 调试读数门禁, 需固件 1.6.5+(正式版号, cmpVersion 纯数值)。
            mbrDebugFwSupport = !!(devInfo.fw && cmpVersion(devInfo.fw, "1.6.5") >= 0);
            mbrSignalFwSupport = !!(devInfo.sig && devInfo.sig.version === devInfo.fw &&
                devInfo.sig.variant === "hw_v1" && devInfo.var === "hw_v1" &&
                supportsMbrSignalFirmware(devInfo.fw, devInfo.buildId));
            // round64: v1.6 逐键阈值门禁。0xBD 版本 >=1.6.0 才允许编辑逐键;
            // 旧固件保留 reserved 全 0, UI 显示全部"继承"并禁用。
            // round68: ckGameRaw 同门禁(实验开关需 1.6.0 固件)。旧固件清勾选
            // 防止用户勾选后保存被 sanitize 静默丢弃; disabled 由 updateUI 统一门禁。
            if (devInfo.fw && cmpVersion(devInfo.fw, "1.6.0") >= 0) {
                if (!perKeyFwSupport) {
                    perKeyFwSupport = true;
                    log("固件 1.6.0+: 逐键阈值已启用", "");
                    updatePerKeyUi();
                    updateTcThresholdDisplay();
                }
            } else {
                if (perKeyFwSupport) perKeyFwSupport = false;
                $("ckGameRaw").checked = false;
                log("固件低于 1.6.0: 逐键阈值编辑禁用(全部继承全局)", "warn");
            }
            // round56: 连接时即从 0xBD 直读 hwVer 并同步到硬件版本选择器
            // (普通模式唯一可读的配置字段;其余字段需进配置模式 0xB4 读取)。
            // 仅在尚未进入配置模式时同步,避免覆盖表单未保存的编辑。
            if (devInfo.hwVer >= 1 && devInfo.hwVer <= 4 && !configMode && getHwVer() !== devInfo.hwVer) {
                setHwVer(devInfo.hwVer, true);
                log(`连接直读: 设备 hwVer=v${devInfo.hwVer},已同步硬件版本选择`, "warn");
            }
        } else {
            devInfo = { fw: null, api: null, hwVer: null, var: null, sig: null, raw: info };
            log("设备信息: " + info);
        }
        updateUI();
        return devInfo;
    }

    // round86 #6: 普通模式硬件探测(固件 1.6.4-beta1 起 0xBC 下放普通模式)。
    // 握手后自动调用;探测帧结构与配置模式一致(6B),但 flags bit2=1 标记
    // tofCount 为 hwVer 推导值(固件普通模式不扫 ToF 通道,避免破坏 mux 状态)。
    // 旧固件在普通模式对 0xBC 回 "unknown command" 文本或静默 -- waitForBytes
    // 收不到帧即放弃,不阻塞连接流程(门禁仍由配置模式探测兜底)。
    // round86 审查修复(P1): 必须持 withSerialLock 串行 + 先停输入轮询 --
    // inputLoop 的 0xB1(33B 应答)与探测 6B 帧竞态会让 waitForBytes(6) 切到
    // 输入帧前 6 字节而误判失败(Mock 的即时送达掩盖了该竞态,真机必现)。
    let normalProbeDone = false;
    async function normalModeProbe() {
        if (!connected || configMode) return false;
        if (normalProbeDone && probeInfo) return true;
        const wasPolling = inputPolling;
        if (wasPolling) {
            inputPolling = false;  // inputLoop 每帧循环让位检查,≤1 帧内停发
            await sleep(30);
        }
        try {
            return await withSerialLock(async () => {
                flushReadBuffer();
                await writeBytes(new Uint8Array([CMD.DETECT]));
                const f = await waitForBytes(6, 3000);
                if (f && f[0] === CMD.DETECT) {
                    probeInfo = parseProbeFrame(f);
                    normalProbeDone = true;
                    log("硬件探测(普通模式): " + describeProbe(probeInfo));
                    const probeEl = $("infoProbe");
                    if (probeEl) probeEl.textContent = describeProbe(probeInfo);
                    // 探测判定 hwVer 与 0xBD 直读不一致时以探测为准(只提示,不强改,
                    // 配置模式进入后有 crossCheckProbe 权威核对)
                    const trueHw = hwVerFromProbe(probeInfo);
                    if (devInfo && devInfo.hwVer && trueHw && trueHw !== devInfo.hwVer) {
                        log(`探测判定 hwVer=${trueHw} 与固件上报 v${devInfo.hwVer} 不一致,以探测为准`, "warn");
                        if (!configMode) setHwVer(trueHw, true);
                    }
                    refreshMbrChips();
                    return true;
                }
                return false;
            });
        } catch (e) { /* 旧固件或探测超时: 静默,由配置模式探测兜底 */ return false; }
        finally {
            if (wasPolling && connected && !configMode) {
                inputPolling = true;  // 恢复轮询(startInputPolling 语义的循环部分)
                inputLoop();
            }
        }
    }

    // ================================================================
    // 配置模式流式会话(round54e)与门禁
    // ================================================================
    function describeProbe(p) {
        const chips = [];
        MBR_ADDRS.forEach((a, i) => { if (p.mbrMask & (1 << i)) chips.push(a); });
        const touch = chips.length ? `CY8CMBR3116 (${chips.join(", ")})`
            : (p.mprMask ? `MPR121 ×${[0, 1, 2, 3].filter(i => p.mprMask & (1 << i)).length}` : "未识别");
        // round86: flags bit2 = tofCount 为 hwVer 推导值(普通模式探测不扫 ToF
        // 通道), 标注「按机型」防误读为实测;配置模式探测无 bit2, 显示「实测」。
        const tofTag = (p.flags & 0b100) ? "按机型" : "实测";
        return `${p.tofCount}×ToF(${tofTag}) / 触摸 ${touch} / mux ${p.flags & 1 ? "在位" : "缺失"}`;
    }

    // round54e: 探测 + 读配置合并为一次流式会话。连发 [0xBC, 0xB4] 后解析
    // 设备输出流(详见一代面板注释:应对输出滞留/任意拆包,500ms 轻推)。
    // round76c: 真机实测 0xBC I2C 探测耗时随总线状态在 1-6s 波动(缺席设备
    // 重试 + mux 通道扫描),总超时 5s→8s 避免慢探测轮误报连接失败。
    async function readConfigStream(totalTimeout = 8000) {
        flushReadBuffer();
        await writeBytes(new Uint8Array([CMD.DETECT, CMD.CFG_READ]));
        const deadline = performance.now() + totalTimeout;
        let lastFrame = null, frames = 0, cfg = null;
        const lines = [];
        let rxBytes = 0, headPreview = "";
        let nudgeAt = performance.now() + 500;
        while (!cfg && performance.now() < deadline) {
            const step = streamConsumeHead(readBuffer);
            if (step.type === "empty" || step.type === "partial") {
                if (performance.now() >= nudgeAt) {
                    await writeBytes(new Uint8Array([CMD.DETECT]));
                    nudgeAt = performance.now() + 500;
                }
                await nextTick();
                continue;
            }
            if (!headPreview) {
                const pv = [];
                for (let i = 0; i < Math.min(16, readBuffer.length); i++) pv.push(readBuffer[i].toString(16).padStart(2, "0"));
                headPreview = pv.join(" ");
            }
            if (step.type === "frame") {
                lastFrame = parseProbeFrame(step.data);
                frames++;
                readBuffer = readBuffer.slice(6);
                rxBytes += 6;
            } else if (step.type === "echo") {
                readBuffer = readBuffer.slice(1);
                rxBytes += 1;
            } else if (step.type === "line") {
                log("设备输出: " + new TextDecoder().decode(step.data).replace(/\r?\n$/, ""));
                readBuffer = readBuffer.slice(step.used);
                rxBytes += step.used;
            } else if (step.type === "magic") {
                cfg = await waitForBytes(CFG_SIZE, Math.max(300, deadline - performance.now()));
                rxBytes += CFG_SIZE;
            }
        }
        if (!cfg) {
            throw new Error(`流式读取超时: 共收 ${rxBytes}B, 探测帧 ×${frames}, 配置块未到 (首字节: ${headPreview || "无"})`);
        }
        const drainUntil = performance.now() + 1200;
        while (performance.now() < drainUntil && lines.length < 2) {
            const step = streamConsumeHead(readBuffer);
            if (step.type === "empty" || step.type === "partial") { await nextTick(); continue; }
            if (step.type === "frame") { lastFrame = parseProbeFrame(step.data); frames++; }
            else if (step.type === "line") lines.push(new TextDecoder().decode(step.data).replace(/\r?\n$/, ""));
            else if (step.type === "magic") break;
            readBuffer = readBuffer.slice(step.used || 0);
        }
        flushReadBuffer();
        return { cfg, line1: lines[0] || "", line2: lines[1] || "", probe: lastFrame, frames };
    }

    // 探测/配置交叉核对
    function crossCheckProbe() {
        if (!probeInfo) return;
        const trueHw = hwVerFromProbe(probeInfo);
        if (trueHw) hwVerProbe = trueHw;
        $("infoProbe").textContent = describeProbe(probeInfo);
        const cfgHw = getHwVer();
        const true32 = probeInfo.tofCount === 5;
        const cfg32 = (cfgHw === 2 || cfgHw === 4);
        if (trueHw && cfgHw !== trueHw) {
            log(`配置与硬件不一致: 配置 hwVer=${cfgHw},探测判定 hwVer=${trueHw} (${true32 ? "32寸" : "27寸"})`, "warn");
            if (confirm(`设备配置与硬件不一致:\n配置 hwVer=${cfgHw},硬件探测判定 hwVer=${trueHw}(${true32 ? "32寸" : "27寸"})。\n\n是否将表单修正为硬件真值?(仍需手动点"保存设置"才会写入设备)`)) {
                setHwVer(trueHw);
            }
        } else if (true32 !== cfg32) {
            log(`配置与硬件不一致: ToF 数量探测为 ${probeInfo.tofCount},配置按 ${cfg32 ? "5" : "4"} 颗运行`, "warn");
        }
        const use3116Cfg = $("ckMbr3116").checked;
        const has3116 = probeInfo.mbrMask !== 0;
        const hasMpr = probeInfo.mprMask !== 0;
        if (use3116Cfg && !has3116) {
            log("配置勾选了使用 3116,但探测未发现 CY8CMBR3116 芯片", "warn");
        } else if (!use3116Cfg && !hasMpr && has3116) {
            log("配置未勾选使用 3116,但探测只发现 CY8CMBR3116(无 MPR121)", "warn");
            if (confirm('探测发现触摸主控为 CY8CMBR3116,但配置未启用。是否勾选"使用 3116"?')) {
                $("ckMbr3116").checked = true;
                updateTouchUi();
            }
        }
        refreshMbrChips();
    }

    async function gateRejectDevice(reason) {
        log("设备门禁未通过: " + reason, "error");
        setStatus("设备被拦截", "error");
        alert("已阻止进入配置模式:\n\n" + reason + "\n\n设备将重启回普通模式。本面板仅适用于一代 (hw_v1) 27/32 寸设备。");
        try { await writeBytes(new Uint8Array([CMD.EXIT])); } catch (e) {}
        configMode = false;
        await sleep(400);
        await closePort();
    }

    // ================================================================
    // 输入测试(一代轮询引擎 + 三代渲染)
    // ================================================================
    const tcs = []; for (let i = 1; i <= 32; i++) tcs[i] = $("tc" + i);
    const airs = []; for (let i = 1; i <= 6; i++) airs[i] = $("air" + i);

    // round69: INPUT TEST 格子点击 → 配置模式下弹出逐键编辑气泡(复用 openPerKeyBubble)
    for (let i = 1; i <= 32; i++) {
        const tc = tcs[i];
        if (!tc) continue;
        tc.addEventListener("click", () => { openPerKeyBubble(i - 1); });
    }

    async function inputLoop() {
        if (inputLoopRunning) return;
        inputLoopRunning = true;
        while (connected && inputPolling) {
            try {
                // 事务锁让路: 其他操作 (如配置读取/保存/心跳) 正在执行时立即让步
                if (serialBusy || configMode) {
                    await nextTick();
                    continue;
                }
                flushReadBuffer();
                const t0 = performance.now();
                await writeBytes(new Uint8Array([CMD.GET_INPUT]));
                const data = await waitForBytes(33, 300);
                const dt = performance.now() - t0;
                lastPollTime = Math.round(dt);
                totalPackets++;
                inputFrames++;
                latestInputData = data;
                if (!inputRafScheduled) {
                    inputRafScheduled = true;
                    requestAnimationFrame(renderInputFrame);
                }
                updateMetrics();
                await nextTick();
            } catch (e) {
                if (serialBusy || configMode) {
                    await nextTick();
                } else {
                    await sleep(20);
                }
            }
        }
        inputLoopRunning = false;
    }

    function renderInputFrame() {
        inputRafScheduled = false;
        if (latestInputData) {
            renderInput(latestInputData);
            latestInputData = null;
        }
    }

    // ================================================================
    // 输入测试高对比度字体显示优化
    // 规则:
    // - 以高对比度为准,追求高对比辨识
    // - 亮度为 0 时仍然为纯白色,并降低一定的灰度和透明度 (序号与文字实体纯白)
    // - 亮度 ≥ 45% 时默认为纯黑色 (#000000, 100% 不透明)
    // - 其他亮度区间动态高对比辨识 (结合人眼与 WCAG 对比度指标最优化)
    // - 背景高亮与容器透明度解耦 (改用 backgroundColor 插值),防止子文本被 parent opacity 降权发灰
    // ================================================================
    let themeLuminanceCache = {
        bgR: 26, bgG: 26, bgB: 26,
        accentR: 255, accentG: 224, accentB: 64,
        yBg: 0.102, yAccent: 0.843
    };

    function parseCssColor(str) {
        if (!str) return null;
        str = str.trim();
        if (str.startsWith("#")) {
            let hex = str.slice(1);
            if (hex.length === 3) {
                hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
            }
            if (hex.length >= 6) {
                return {
                    r: parseInt(hex.slice(0, 2), 16),
                    g: parseInt(hex.slice(2, 4), 16),
                    b: parseInt(hex.slice(4, 6), 16)
                };
            }
        }
        const m = str.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
        if (m) {
            return {
                r: parseInt(m[1], 10),
                g: parseInt(m[2], 10),
                b: parseInt(m[3], 10)
            };
        }
        return null;
    }

    function calcPerceivedLuminance(r, g, b) {
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;
    }

    // 高对比度文本颜色判定 (WCAG 对比度最优化算法):
    // 1. 亮度为 0 (未按下 baseline / 纯黑底): 恒为纯白字 (#ffffff, 降低灰暗与透明度, false = not dark)
    // 2. 亮度 ≥ 45%: 默认为实体纯黑色 (#000000, 100% 不透明, true = dark text)
    // 3. 中间区间 (0% < Y < 45%): 动态高对比辨识
    //    基于 WCAG 相对亮度与人眼对比敏感度:
    //    纯白文本的对比度随着背景亮度提升而递减, 在 Y ~ 0.35 处与纯黑文本对比度相等 (交叉点 ~3.5:1)。
    //    当 Y >= 0.35 时黑字辨识度显著压倒白字, 切换为黑字; 当 Y < 0.35 时白字维持极高对比度。
    function isDarkTextForLuminance(y) {
        if (y <= 0.0001) return false;
        if (y >= 0.45) return true;
        return y >= 0.35;
    }

    function updateThemeLuminanceCache() {
        try {
            const rootStyle = window.getComputedStyle(document.documentElement);
            const isLight = document.documentElement.getAttribute("data-theme") === "light";
            
            // 尝试从 CSS 变量或元素采样背景色与高亮色
            let bgParsed = null;
            const tcSample = tcs[1] || document.querySelector(".div_touch_channel");
            if (tcSample) {
                const computedBg = window.getComputedStyle(tcSample).backgroundColor;
                bgParsed = parseCssColor(computedBg);
            }
            if (!bgParsed) {
                const surfaceVar = rootStyle.getPropertyValue("--c-surface-2") || rootStyle.getPropertyValue("--c-surface-1");
                bgParsed = parseCssColor(surfaceVar);
            }
            
            const accentVar = rootStyle.getPropertyValue("--c-accent");
            let accentParsed = parseCssColor(accentVar);

            // 兜底值保障
            if (!bgParsed) {
                bgParsed = isLight ? { r: 245, g: 245, b: 246 } : { r: 26, g: 26, b: 26 };
            }
            if (!accentParsed) {
                accentParsed = isLight ? { r: 13, g: 68, b: 212 } : { r: 255, g: 224, b: 64 };
            }

            themeLuminanceCache.bgR = bgParsed.r;
            themeLuminanceCache.bgG = bgParsed.g;
            themeLuminanceCache.bgB = bgParsed.b;
            themeLuminanceCache.accentR = accentParsed.r;
            themeLuminanceCache.accentG = accentParsed.g;
            themeLuminanceCache.accentB = accentParsed.b;

            themeLuminanceCache.yBg = calcPerceivedLuminance(bgParsed.r, bgParsed.g, bgParsed.b);
            themeLuminanceCache.yAccent = calcPerceivedLuminance(accentParsed.r, accentParsed.g, accentParsed.b);
        } catch (e) {
            const isLight = document.documentElement.getAttribute("data-theme") === "light";
            themeLuminanceCache.bgR = isLight ? 245 : 26;
            themeLuminanceCache.bgG = isLight ? 245 : 26;
            themeLuminanceCache.bgB = isLight ? 246 : 26;
            themeLuminanceCache.accentR = isLight ? 13 : 255;
            themeLuminanceCache.accentG = isLight ? 68 : 224;
            themeLuminanceCache.accentB = isLight ? 212 : 64;
            themeLuminanceCache.yBg = isLight ? 0.961 : 0.102;
            themeLuminanceCache.yAccent = isLight ? 0.267 : 0.843;
        }
    }

    function syncAllTouchTextColors() {
        const isDarkText = isDarkTextForLuminance(themeLuminanceCache.yBg);
        for (let i = 1; i <= 32; i++) {
            const tc = tcs[i];
            if (tc && !tc.classList.contains("active")) {
                tc.classList.toggle("tc-text-dark", isDarkText);
                tc.classList.toggle("tc-text-light", !isDarkText);
            }
        }
        for (let i = 1; i <= 6; i++) {
            const a = airs[i];
            if (a && !a.classList.contains("active")) {
                a.classList.toggle("tc-text-dark", isDarkText);
                a.classList.toggle("tc-text-light", !isDarkText);
            }
        }
    }

    function renderInput(data) {
        // round71: MPR121 原生压力 0-63, 按 (0,63] 线性映射才不会满按只有一半亮度;
        // MBR3116 原生 0-255。未开真实压力会话时固件输出恒定 128 判定帧,直接给最高亮度。
        // round85: 「原始结果」会话(level 2)下两芯片报送均为 0-255 原始物理值,
        // sensorMax 恒 255;「模拟结果」(level 1)沿用 round80 报送语义(MPR ×2 后 0-255)。
        const rawSession = rawReportOn && rawReportLevelCur === 2;
        const sensorMax = (perKeyIsMbr() || rawSession) ? 255 : 63;
        const { bgR, bgG, bgB, accentR, accentG, accentB, yBg, yAccent } = themeLuminanceCache;

        for (let i = 1; i <= 32; i++) {
            const tc = tcs[i];
            if (!tc) continue;
            const v = data[i - 1];
            let on = false;
            let alpha = 0.0;
            if (rawSession) {
                // round85: 「原始结果」模式 —— 真实呈现芯片物理层物理量,
                // 无论是否达到判定线, 只要有读数就忠实显示数值与按压渐变!
                on = v > 0;
                if (perKeyIsMbr()) {
                    // MBR3116: 原生 0-255
                    if (on) {
                        alpha = Math.min(1.0, Math.max(0.0, v / 255.0));
                    }
                } else {
                    // MPR121: 触摸值达到 100 时背景亮度达到最大, 0-100 线性提升亮度
                    on = v > 4;
                    if (on) {
                        alpha = Math.min(1.0, Math.max(0.20, v / 100.0));
                    }
                }
                tc.innerText = "" + v;
            } else {
                // round86: 「模拟结果」模式 —— 以设备在游戏中的真实结果的模拟!
                // 未触发判定 (v === 0) 恒为未激活, 文字清空;
                // 触发判定 (v > 0) 激活高亮, 呈现游戏中的实际输入结果 (128 标准判定或真实压力映射)
                on = v > 0;
                if (on) {
                    if (perKeyIsMbr()) {
                        // MBR3116: 标准 128 二值判定满亮 1.00; 真实压力映射依照 0-255 线性变化
                        if (v === 128) alpha = 1.0;
                        else alpha = Math.min(1.0, Math.max(0.0, v / 255.0));
                    } else {
                        // MPR121: 触摸值达到 100 时背景亮度达到最大, 0-100 线性提升亮度 (标准128直接满亮)
                        if (v === 128) alpha = 1.0;
                        else alpha = Math.min(1.0, Math.max(0.20, v / 100.0));
                    }
                    tc.innerText = "" + v;
                } else {
                    tc.innerText = "";
                }
            }
            tc.classList.toggle("active", on);

            // 背景亮度压感解耦机制:
            // 严禁用 tc.style.opacity 降低容器透明度 (会导致子文字与序号被 parent opacity 降权沦为灰色死区)
            // 容器透明度保持 1 (不透明), 通过 backgroundColor 线性插值呈现真实的按压渐变色彩
            if (on) {
                const curR = Math.round((1.0 - alpha) * bgR + alpha * accentR);
                const curG = Math.round((1.0 - alpha) * bgG + alpha * accentG);
                const curB = Math.round((1.0 - alpha) * bgB + alpha * accentB);
                tc.style.backgroundColor = `rgb(${curR}, ${curG}, ${curB})`;
                tc.style.opacity = "";

                // 计算当前混合后真实背景的感知亮度
                const curY = calcPerceivedLuminance(curR, curG, curB);
                const isDarkText = isDarkTextForLuminance(curY);
                tc.classList.toggle("tc-text-dark", isDarkText);
                tc.classList.toggle("tc-text-light", !isDarkText);
            } else {
                tc.style.backgroundColor = "";
                tc.style.opacity = "";
                // 未触碰状态: 严格遵循 L=0 纯白色, 低灰度低透明
                tc.classList.remove("tc-text-dark");
                tc.classList.add("tc-text-light");
            }

            // round67/69: 压力模式(会话开关或游戏映射)下叠加当前生效阈值提示
            if (rawReportOn || perKeyGameRaw) {
                const th = perKeyTouch[i - 1] || parseInt($("rgThTouch").value) || 6;
                const tag = rawSession ? "原始" : "模拟";
                tc.title = `tc${i}: ${tag} ${v} / 阈值 ${th}`;
            }
        }
        for (let i = 0; i < 6; i++) {
            const a = airs[i + 1];
            if (a) {
                const aOn = (data[32] & (1 << i)) !== 0;
                a.classList.toggle("active", aOn);
                const curY = aOn ? yAccent : yBg;
                const isDarkText = aOn ? isDarkTextForLuminance(curY) : false; // 未激活严格遵循 L=0 白字
                a.classList.toggle("tc-text-dark", isDarkText);
                a.classList.toggle("tc-text-light", !isDarkText);
            }
        }
    }

    function clearInputDisplay() {
        for (let i = 1; i <= 32; i++) {
            const tc = tcs[i];
            if (tc) {
                tc.innerText = "";
                tc.classList.remove("active");
                tc.style.backgroundColor = "";
                tc.style.opacity = "";
                // 未触碰状态: 纯白色低灰度低透明
                tc.classList.remove("tc-text-dark");
                tc.classList.add("tc-text-light");
            }
        }
        for (let i = 1; i <= 6; i++) {
            const a = airs[i];
            if (a) {
                a.classList.remove("active");
                a.classList.remove("tc-text-dark");
                a.classList.add("tc-text-light");
            }
        }
    }

    function updateMetrics() {
        const now = performance.now();
        if (now - lastFpsTime >= 1000) {
            $("fpsVal").textContent = inputFrames;
            inputFrames = 0;
            lastFpsTime = now;
        }
        $("pollVal").textContent = lastPollTime + "ms";
        $("pktVal").textContent = totalPackets;
    }

    // 开始/停止按钮(v3 单按钮切换)
    const playIcon = '<path d="M4 2L14 8L4 14V2Z" fill="currentColor"/>';
    const stopIcon = '<rect x="3" y="3" width="10" height="10" rx="1" fill="currentColor"/>';
    function setBtnState(btn, iconPath, text, cls) {
        btn.className = 'btn ' + cls;
        btn.querySelector('svg').innerHTML = iconPath;
        btn.lastChild.textContent = text;
    }
    function resetInputBtn() {
        const btn = $("toggleInputBtn");
        if (btn) setBtnState(btn, playIcon, ' 开始测试', 'btn-success');
    }

    // round66: 压力上报会话开关(仅普通模式, 固件 1.6.0+)。面板用 0xC5 显式
    // 开/关; 固件在 CDC 断连/进配置/重启时自动回 0, 无需面板兜底。
    // round84/85: 0xC5 载荷升级为 level -- 0=关, 1=模拟(固件报送层 MPR ×2,
    // 即「模拟结果」), 2=原始(pressureSnap 原值直报, 即「原始结果」);
    // 固件回显 RAW=0|1|2。rawReportOn 语义随之改为"会话激活"(level!=0)。
    // 需固件 >= 1.6.3-beta1 才发 level 2 (rawLevelFwSupport); 旧固件发 2 会被
    // 落空忽略(载荷保持现态), 因此低版本自动回退 level 1 行为。
    let rawReportOn = false;       // 会话激活(level != 0)
    let rawReportLevelCur = 0;     // 当前会话 level (1=模拟 / 2=原始)
    let rawReportSupported = false;  // 固件 1.6.0+ 或 Mock 时置真
    let mbrGateFwSupport = false;  // round81: 悬空抑制滑块门禁, 固件 1.6.2-beta1+
    let mbrDebugFwSupport = false;  // round88: 0xC7 调试读数门禁, 固件 1.6.5+
    let mbrSignalFwSupport = false; // round89a: 实验性持续信号门, 固件 1.6.6-beta1+
    let mbrSignalEdited = false;
    let rawLevelFwSupport = false; // round85: 0xC5 level 2 门禁, 固件 1.6.3-beta1+
    function setRawReportMode(level) {
        if (!rawReportSupported) return Promise.resolve(false);
        if (!connected) return Promise.resolve(false);
        if (level === 2 && !rawLevelFwSupport) level = 1;  // 旧固件回退模拟档
        const want = level;
        return withSerialLock(async () => {
            flushReadBuffer();
            await writeBytes(new Uint8Array([CMD.SET_RAW_REPORT, want]));
            const line = await waitForLine(1000);
            const m = (line || "").trim().match(/^RAW=([0-9])$/);
            const echoed = m ? parseInt(m[1], 10) : 0;
            rawReportLevelCur = echoed;
            rawReportOn = echoed !== 0;
            return rawReportOn && echoed === want;
        }).catch(e => {
            log("压力上报切换失败: " + e.message, "warn");
            return false;
        });
    }
    // round66 兼容入口(布尔语义): 校准向导等既有调用点继续使用 level 1。
    async function setRawReport(on) {
        return setRawReportMode(on ? 1 : 0);
    }
    async function queryRawReport() {
        if (!rawReportSupported || !connected) return null;
        try {
            return await withSerialLock(async () => {
                flushReadBuffer();
                await writeBytes(new Uint8Array([CMD.GET_RAW_STATUS]));
                const line = await waitForLine(1000);
                const m = (line || "").trim().match(/^RAW=([0-9])$/);
                const echoed = m ? parseInt(m[1], 10) : 0;
                rawReportLevelCur = echoed;
                rawReportOn = echoed !== 0;
                return echoed;
            });
        } catch (e) { return null; }
    }

    // round70: INPUT TEST 统一启动入口。连接/保存重启重连/刷写重连三条自动
    // 路径都用它,保证 INPUT TEST 始终显示真实压力:
    //   - 固件 1.6.0+: 自动开压力会话(0xC5 1),帧中每键报 0-255 模拟量,
    //     否则真机 GET_INPUT 只能回 1.5.x 二进制帧(按下 128/松开 0),用户
    //     看到的永远是固定 128——连接后不手动点"开始测试"就完全看不到压力。
    //   - round70b: "实时真实压力&压力映射"开关(perKeyGameRaw)选中时同样
    //     发 0xC5 会话开关——cfg2 bit1 是持久基线(游戏 DLL 用),0xC5 是
    //     面板会话(INPUT TEST 用),两者独立。选中开关 = INPUT TEST 显示
    //     实时真实压力;不选中 = 默认 0/128 判定帧。
    // 返回 true 表示轮询已启动。
    async function startInputPolling() {
        if (!connected || configMode) return false;
        inputPolling = true;
        setBtnState($("toggleInputBtn"), stopIcon, ' 停止测试', 'btn-warning');
        // round85: 轮询启动默认开「原始结果」会话(0xC5 level 2, 固件 1.6.3-beta1+
        // 才支持; 旧固件 setRawReportMode 内部自动回退 level 1=模拟)。切换按钮
        // 只改会话 level, 不动轮询循环。
        if (rawReportSupported) await setRawReportMode(inputRawMode);
        inputLoop();
        return true;
    }

    $("toggleInputBtn").addEventListener("click", async () => {
        const btn = $("toggleInputBtn");
        if (inputPolling && connected) {
            inputPolling = false;
            setBtnState(btn, playIcon, ' 开始测试', 'btn-success');
            log("已暂停输入轮询");
            // round70b: 停止测试即关会话开关(0xC5 0);cfg2 bit1 持久基线不受影响
            if (rawReportOn) setRawReport(false);
            clearInputDisplay();
        } else {
            if (!connected) { alert("需要先连接手台"); return; }
            if (configMode) { alert("配置模式下 HID 输入已暂停,请先退出配置模式"); return; }
            log("已开始输入轮询");
            // round70: 统一入口(自动开压力会话,INPUT TEST 显示真实压力)
            await startInputPolling();
        }
    });

    // round85: 「原始结果/模拟结果」报送切换(0xC5 level 2/1)。默认「原始结果」
    // = 固件 pressureSnap 原值直报(传感器物理读数); 点击切「模拟结果」= 固件
    // 报送层输出(MPR ×2、阈值管线后的最终报送值)。MBR 设备两档数值相同
    // (原生 0-255 无 ×2), 差异仅 MPR 设备可见。会话态不落 localStorage,
    // 重连后由 startInputPolling 按当前按钮态重开(level 1 回退见 setRawReportMode)。
    let inputRawMode = 2;  // 2=原始结果(默认) / 1=模拟结果
    function updateRawModeBtn() {
        const btn = $("btnRawMode");
        if (!btn) return;
        const raw = inputRawMode === 2;
        btn.textContent = raw ? "原始结果" : "模拟结果";
        btn.title = raw
            ? "当前显示传感器物理层读数(含未触碰时的底噪)。点击切换为模拟结果。"
            : "当前显示以设备在游戏中的真实结果的模拟(未触发判定为 0, 触发呈现游戏实际输入)。点击切换为原始结果。";
        btn.classList.toggle("btn-primary", !raw);   // 模拟档高亮提示当前非默认
        btn.classList.toggle("btn-ghost", raw);      // 原始档(默认)低调展示
    }
    $("btnRawMode").addEventListener("click", async () => {
        if (!connected) { alert("需要先连接手台"); return; }
        if (configMode) { alert("配置模式下输入已暂停,请先退出配置模式"); return; }
        const next = (inputRawMode === 2) ? 1 : 2;
        if (!rawReportSupported) { log("固件低于 1.6.0, 无压力报送", "warn"); return; }
        const ok = await setRawReportMode(next);
        if (ok) {
            inputRawMode = next;
            updateRawModeBtn();
            log(next === 2 ? "INPUT TEST 切换为「原始结果」(设备原始报送值)"
                           : "INPUT TEST 切换为「模拟结果」(固件最终报送值)");
            if (!inputPolling) log("会话已切换, 点「开始测试」后生效显示", "warn");
        }
    });
    updateRawModeBtn();

    // ================================================================
    // 配置打包 / 解析(v1 128B 布局 ↔ 新表单)
    // ================================================================
    function getHwVer() { return hwVerValue; }
    let hwVerValue = 1;

    // round64: 逐键阈值状态(仅 fw >= 1.6.0 时启用编辑, 0 = 继承全局)。
    // perKeyTouch[i]/perKeyRelease[i] 为原始字节 0-255, 0 表示继承。
    const perKeyTouch = new Array(CFG_NUM_KEYS).fill(0);
    const perKeyRelease = new Array(CFG_NUM_KEYS).fill(0);
    // round69: cfg2 bit1 游戏压力映射开关的运行时镜像(pack/unpack 同步)。
    // 开启时 INPUT TEST 不自动发 0xC5 会话开关,直接显示帧中映射值(与游戏 DLL 一致)。
    let perKeyGameRaw = false;
    let perKeyFwSupport = false;  // 0xBD 版本 >= 1.6.0 或 Mock 时置真
    // round67: 校准已回填但尚未确认保存时置真; unpackConfig(进配置模式读回)保留回填值,
    // 直到退出/重启(设备重枚举)后清除——保证"校准→进配置→保存并重启"链路不丢结果。
    let calPendingBackfill = false;

    function perKeyIsMbr() {
        return !!$("ckMbr3116").checked;
    }
    function perKeyRange() {
        return perKeyIsMbr() ? { min: 129, max: 255 } : { min: 1, max: 63 };
    }

    function packConfig() {
        const base = lastReadConfig && lastReadConfig.length === CFG_SIZE ? lastReadConfig.slice() : new Uint8Array(CFG_SIZE);
        const buf = base;
        buf[0] = CFG_MAGIC;
        buf[1] = CFG_VERSION;
        buf[2] = hwVerValue;

        let cfg0 = 0;
        if ($("ckForce16").checked) cfg0 |= BIT_FORCE16;
        if ($("ckMbr3116").checked) cfg0 |= BIT_MBR3116;
        if ($("ckDarkerGap").checked) cfg0 |= BIT_DARKER_GAP;
        buf[3] = cfg0;

        let cfg1 = 0;
        if ($("ckKbSlider").checked) cfg1 |= BIT_KB_SLIDER;
        if ($("ckKbAir").checked) cfg1 |= BIT_KB_AIR;
        buf[4] = cfg1;

        // round55: cfg2 bit0 = 关闭 LampArray(disable 语义);cfg3 = 附加输入延迟 0-15ms
        // round68/69: cfg2 bit1 = 压力报送&压力映射(单开关,默认关)——开启后面板
        // INPUT TEST 与游戏内 DLL 都收到线性归一化 0-255 映射值
        buf[5] = ($("ckLampArray").checked ? 0 : BIT_DISABLE_LAMP_ARRAY) |
                 ($("ckGameRaw").checked ? BIT_GAME_RAW_SLIDER : 0);
        perKeyGameRaw = $("ckGameRaw").checked;
        buf[6] = Math.max(0, Math.min(15, parseInt($("rgLatency").value) || 0));

        buf[7] = Math.max(1, Math.min(63, parseInt($("rgThTouch").value) || 1));
        buf[8] = Math.max(1, Math.min(63, parseInt($("rgThRelease").value) || 1));
        const dt = parseInt($("rgDt").value) || 0;
        const dr = parseInt($("rgDr").value) || 0;
        buf[9] = (dt & 0x0F) | ((dr & 0x0F) << 4);

        const airMax = parseInt($("rgAirMax").value) || 0;
        const airMin = parseInt($("rgAirMin").value) || 0;
        buf[10] = airMax & 0xFF;
        buf[11] = (airMax >> 8) & 0xFF;
        buf[12] = airMin & 0xFF;
        buf[13] = (airMin >> 8) & 0xFF;

        for (let i = 0; i < 5; i++) {
            const el = $("off" + i);
            const v = el ? (parseInt(el.value) || 0) : 0;
            const u16 = v < 0 ? v + 65536 : v;
            buf[14 + i * 2] = u16 & 0xFF;
            buf[15 + i * 2] = (u16 >> 8) & 0xFF;
        }
        // lightLimit 原字节保真:滑条以百分比呈现,但"读→不改→存"必须回写原字节,
        // 避免百分比往返量化漂移(如 200 → 78% → 199)。仅当用户真的动了滑条才重算。
        const brightPct = parseInt($("rgBright").value) || 0;
        buf[24] = (rawLightLimit.byte !== null && brightPct === rawLightLimit.pct)
            ? rawLightLimit.byte
            : Math.round(brightPct * 255 / 100) || 0;
        rawLightLimit = { byte: buf[24], pct: brightPct };
        buf[25] = parseInt($("rgHeight").value) || 0;

        // round80/81: MBR3116 悬空抑制门(0=旧行为)。固件 sanitize 对 uint8
        // 全域放行, 面板只做 0-255 钳位; 需固件 >= 1.6.2-beta1。
        buf[CFG_OFF_MBR_TOUCH_GATE] = Math.max(0, Math.min(255, parseInt($("rgMbrGate").value) || 0));
        // 不支持的旧固件保留 reserved 原字节，禁止绕过 UI 启用新门。
        if (!mbrSignalFwSupport && $("ckMbrSignalGate").checked) throw new Error("当前固件不支持实验性持续信号门");
        if (mbrSignalFwSupport && mbrSignalEdited) encodeMbrSignalProfile(buf, readMbrSignalProfileUi());
        if (mbrSignalFwSupport) sanitizeMbrSignalProfile(buf);

        // round64: 逐键阈值(0 = 继承,仅在 fw>=1.6.0 允许编辑)。底包保真:
        // 未编辑的键保持 lastReadConfig 原字节,编辑过的按 perKey 状态写回。
        if (perKeyFwSupport) {
            for (let i = 0; i < CFG_NUM_KEYS; i++) {
                const tv = perKeyTouch[i];
                const rv = perKeyRelease[i];
                if (tv !== null && tv !== undefined) buf[CFG_OFF_TH_TOUCH_KEY + i] = tv & 0xFF;
                if (rv !== null && rv !== undefined && !perKeyIsMbr()) buf[CFG_OFF_TH_RELEASE_KEY + i] = rv & 0xFF;
            }
        }

        buf[127] = calcXorSum(buf);
        return buf;
    }

    function unpackConfig(buf) {
        if (buf.length !== CFG_SIZE) throw new Error("配置长度错误: " + buf.length);
        if (buf[0] !== CFG_MAGIC) throw new Error("Magic 不匹配: 0x" + buf[0].toString(16));
        if (buf[2] < 1 || buf[2] > 4) throw new Error("配置 hwVer 越界: " + buf[2] + "(一代设备应为 1..4)");

        const cfgVerEl = $("cfgVerVal");
        cfgVerEl.value = "0x" + buf[1].toString(16).padStart(2, "0");
        if (buf[1] !== CFG_VERSION) {
            cfgVerMismatch = true;
            cfgVerEl.style.color = "var(--c-danger)";
            log(`设备配置版本 cfgVer=0x${buf[1].toString(16).padStart(2, "0")} 与面板支持的 0x${CFG_VERSION.toString(16).padStart(2, "0")} 不匹配,已禁用保存(固件也会拒绝该写入)`, "error");
        } else {
            cfgVerMismatch = false;
            cfgVerEl.style.color = "";
        }

        lastReadConfig = buf.slice();
        rawLightLimit = { byte: buf[24], pct: Math.round(buf[24] * 100 / 255) };
        setHwVer(buf[2], true);
        $("ckForce16").checked = !!(buf[3] & BIT_FORCE16);
        $("ckMbr3116").checked = !!(buf[3] & BIT_MBR3116);
        $("ckDarkerGap").checked = !!(buf[3] & BIT_DARKER_GAP);
        $("ckKbSlider").checked = !!(buf[4] & BIT_KB_SLIDER);
        $("ckKbAir").checked = !!(buf[4] & BIT_KB_AIR);
        // round55: cfg2 bit0 为 disable 语义(置1=关),复选框勾选=开启动态照明
        $("ckLampArray").checked = !(buf[5] & BIT_DISABLE_LAMP_ARRAY);
        $("ckGameRaw").checked = !!(buf[5] & BIT_GAME_RAW_SLIDER);
        perKeyGameRaw = $("ckGameRaw").checked;  // round69: 面板感知游戏映射开关,INPUT TEST 不覆盖
        setSlider($("rgLatency"), Math.min(15, buf[6] || 0), { quiet: true });
        // round70b: 校准回填后(calPendingBackfill)进配置模式时,全局 th_touch/
        // th_release 同样保留回填建议值,不被设备旧值覆盖(与下方逐键回填同保护)。
        if (!calPendingBackfill) {
            smoothSliderTo($("rgThTouch"), buf[7]);
            smoothSliderTo($("rgThRelease"), buf[8]);
        }
        setSlider($("rgDt"), buf[9] & 0x0F, { quiet: true });
        setSlider($("rgDr"), (buf[9] >> 4) & 0x0F, { quiet: true });
        smoothSliderTo($("rgAirMax"), buf[10] | (buf[11] << 8));
        smoothSliderTo($("rgAirMin"), buf[12] | (buf[13] << 8));
        for (let i = 0; i < 5; i++) {
            const lo = buf[14 + i * 2], hi = buf[15 + i * 2];
            let v = lo | (hi << 8);
            if (v >= 32768) v -= 65536;
            const el = $("off" + i);
            if (el) el.value = v;
        }
        smoothSliderTo($("rgBright"), Math.round(buf[24] * 100 / 255));
        setSlider($("rgHeight"), buf[25] || 10, { quiet: true });
        // round80/81: 悬空抑制读回(0=关闭)。
        setSlider($("rgMbrGate"), buf[CFG_OFF_MBR_TOUCH_GATE] || 0, { quiet: true });
        const signalProfile = decodeMbrSignalProfile(buf);
        $("ckMbrSignalGate").checked = signalProfile.enabled && mbrSignalFwSupport;
        $("mbrSignalZero").value = signalProfile.zero;
        $("mbrSignalFull").value = signalProfile.full;
        $("mbrSignalOn").value = signalProfile.onPercent;
        $("mbrSignalOff").value = signalProfile.offPercent;
        mbrSignalEdited = false;
        // round64: 逐键阈值读回(0 = 继承)。仅 fw>=1.6.0 时这些偏移才可能非 0;
        // 旧固件读到的 reserved 全 0, 逐键 UI 显示"全部继承"。
        // round67: 校准回填后(calPendingBackfill)进入配置模式的这次 unpack 不能
        // 用设备旧值覆盖回填结果——用户按弹窗提示"进配置模式→保存并重启"时,
        // 校准建议必须原样出现在网格里; 保存成功(EXIT/重启)后标志清除, 恢复正常读回。
        if (!calPendingBackfill) {
            for (let i = 0; i < CFG_NUM_KEYS; i++) {
                perKeyTouch[i] = buf[CFG_OFF_TH_TOUCH_KEY + i];
                perKeyRelease[i] = buf[CFG_OFF_TH_RELEASE_KEY + i];
            }
        }
        updatePerKeyUi();
        updateTcThresholdDisplay();
        $("xorVal").value = "0x" + buf[127].toString(16).padStart(2, "0");
        updateLightLimitHint();
        checkThresholdHints();
        updateTouchUi();
        updateUI();
    }

    function readMbrSignalProfileUi() {
        return { enabled: $("ckMbrSignalGate").checked,
            zero: Number($("mbrSignalZero").value || NaN), full: Number($("mbrSignalFull").value || NaN),
            onPercent: Number($("mbrSignalOn").value || NaN), offPercent: Number($("mbrSignalOff").value || NaN) };
    }
    function mbrSignalUsesMbr() {
        return perKeyIsMbr() || getHwVer() === 3 || getHwVer() === 4;
    }
    function updateMbrSignalUi() {
        if (!mbrSignalUsesMbr() && $("ckMbrSignalGate").checked) {
            $("ckMbrSignalGate").checked = false;
            mbrSignalEdited = true;
        }
        const profile = readMbrSignalProfileUi();
        const result = validateMbrSignalProfile(profile);
        const canEdit = connected && configMode && mbrSignalFwSupport && mbrSignalUsesMbr();
        ["ckMbrSignalGate", "mbrSignalZero", "mbrSignalFull", "mbrSignalOn", "mbrSignalOff"].forEach(id => $(id).disabled = !canEdit);
        const status = $("mbrSignalStatus");
        status.classList.toggle("warn", !result.valid);
        status.textContent = !mbrSignalFwSupport
            ? "当前固件未确认支持，禁止启用；需固件 ≥ " + MBR_SIGNAL_MIN_FW
            : !result.valid ? "参数无效：" + result.errors.join("；")
            : `${profile.enabled ? "已勾选（须保存生效）" : "关闭"} · DIFF ${profile.zero}→${profile.full} · ON ≥ ${profile.zero + Math.ceil((profile.full - profile.zero) * profile.onPercent / 100)} / OFF ≤ ${profile.zero + Math.floor((profile.full - profile.zero) * profile.offPercent / 100)} · 同时须通过原生与逐键门限`;
        if (mbrSignalFwSupport && mbrSignalEdited && !result.valid) $("btnSaveAndReboot").disabled = true;
    }
    ["ckMbrSignalGate", "mbrSignalZero", "mbrSignalFull", "mbrSignalOn", "mbrSignalOff"].forEach(id => {
        $(id).addEventListener("input", () => { mbrSignalEdited = true; updateUI(); });
    });

    // ================================================================
    // 配置模式按钮
    // ================================================================
    // round56: 进入/退出合并到同一按钮。普通模式 = 进入配置模式(含读取+门禁);
    // 配置模式 = 退出并重启。SVG 在进入后替换为重启矢量图标,退出后还原为读取图标。
    const ENTER_CONFIG_SVG = '<svg viewBox="0 0 16 16" fill="none"><path d="M2 4V12L8 8L14 12V4" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M2 4L8 8L14 4" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>';
    const EXIT_CONFIG_SVG = '<svg viewBox="0 0 16 16" fill="none"><path d="M10 3L14 8L10 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 8H5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M7 2H3V14H7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    function setEnterExitBtnLabel(cfg, overrideText) {
        const btn = $("btnEnterConfig");
        const text = overrideText || (cfg ? "退出并重启" : "进入配置模式");
        btn.innerHTML = (cfg ? EXIT_CONFIG_SVG : ENTER_CONFIG_SVG) +
            "<span>" + text + "</span>";
        btn.classList.toggle("btn-danger", !!cfg);
        btn.classList.toggle("btn-warning", !cfg);
    }

    // round58: 抽出的进入配置模式流程(含门禁/读取),返回 true 表示进入成功。
    // 供"进入配置模式"按钮与"开始刷写"复用。
    async function enterConfigMode() {
        if (configMode) return true;
        try {
            // 如果普通模式尚未获取 devInfo，在进入配置模式前主动补齐一次
            if (!devInfo) {
                try { await queryDevInfo(); } catch (e) { /* 忽略补全失败，继续常规流程 */ }
            }
            flushReadBuffer();
            inputPolling = false;
            resetInputBtn();
            stopLedAnim();  // 配置模式不处理 0xB2,动画会污染文本响应流
            await writeBytes(new Uint8Array([CMD.CONFIG_MODE]));
            await sleep(200);
            flushReadBuffer();

            probeInfo = null;
            const r = await readConfigStream();
            if (r.probe) {
                probeInfo = r.probe;
                log("硬件探测: " + describeProbe(r.probe));
                if (r.probe.tofCount !== 4 && r.probe.tofCount !== 5) {
                    await gateRejectDevice(`硬件探测到 ${r.probe.tofCount} 颗 ToF(应为 4 或 5),ToF 总线异常或非一代设备。`);
                    return false;
                }
                if (!r.probe.mprMask && !r.probe.mbrMask) {
                    await gateRejectDevice("硬件探测未发现任何触摸主控(MPR121/CY8CMBR3116 均无应答),触摸总线异常或非一代设备。");
                    return false;
                }
            } else {
                log("本轮会话未捕获 0xBC 探测帧(旧固件或输出滞留),回退到固件版本白名单门禁", "warn");
                if (devInfo && devInfo.fw) {
                    const isKnownV1 = KNOWN_V1_FW.includes(devInfo.fw) || cmpVersion(devInfo.fw, "1.5.0") >= 0;
                    if (!isKnownV1) {
                        await gateRejectDevice(`固件版本 ${devInfo.fw} 不在一代 hw_v1 白名单 [${KNOWN_V1_FW.join(", ")}] 内。二代设备与其他变体的配置功能不同,已拦截。`);
                        return false;
                    }
                    // round69: API 是协议/硬件信息标识, 0x10(1.5.x) 与 0x11(v1.6) 都是一代设备,
                    // 不应因 API 升级而拦截旧固件——仅拒绝低于一代最低 API 的情况。
                    if (devInfo.api !== null && devInfo.api < 0x10) {
                        await gateRejectDevice(`API Level 0x${devInfo.api.toString(16)} 低于一代固件最低要求 (0x10),可能为二代/其他变体设备。`);
                        return false;
                    }
                } else {
                    log("无法读取设备固件信息(设备可能开机时已处于配置模式),将以配置内容 hwVer 做最低限度校验", "warn");
                }
            }

            configMode = true;
            setStatus("配置模式", "");
            updateUI();
            setEnterExitBtnLabel(true);
            unpackConfig(r.cfg);
            log(`已进入配置模式 (0xB3),HID 输入已暂停;配置读取成功: ${r.line1} | ${r.line2}`);
            crossCheckProbe();
            // round57: 配置模式心跳(每 30s 发 0xC3 重置固件 60s 自动退出计时器)
            startCfgKeepalive();
            return true;
        } catch (e) { log("进入配置模式失败: " + e.message, "error"); return false; }
    }

    // round86 #9: 「退出并重启」由 confirm() 弹窗改为与「保存并重启」一致的
    // 按钮内两段式确认(首次点击变「继续？」,3s 内再点执行,超时复原)。
    // 注意: 与 setupConfirmAction 的通用形态不同,退出动作需读写 configMode/
    // calPendingBackfill,故仍内联实现,只是交互对齐。
    (() => {
        const btn = $("btnEnterConfig");
        let isConfirming = false, confirmTimer = null;
        btn.addEventListener("click", () => withSerialLock(async () => {
            // 配置模式下:退出并重启(两段式确认)
            if (configMode) {
                if (!isConfirming) {
                    isConfirming = true;
                    btn.classList.add("btn-confirming");
                    setEnterExitBtnLabel(true, "继续？");
                    confirmTimer = setTimeout(() => {
                        isConfirming = false;
                        btn.classList.remove("btn-confirming");
                        setEnterExitBtnLabel(true);
                    }, 3000);
                    return;
                }
                if (confirmTimer) { clearTimeout(confirmTimer); confirmTimer = null; }
                isConfirming = false;
                btn.classList.remove("btn-confirming");
                setEnterExitBtnLabel(true);
                calPendingBackfill = false;  // round67: 未保存退出,放弃校准回填保护
                try {
                    await writeBytes(new Uint8Array([CMD.EXIT]));
                    log("已发送退出命令 (0xB9),设备正在重启");
                    configMode = false;
                    updateTcThresholdDisplay();  // round71: 退出配置,格子恢复压力基线
                    await sleep(200);
                    await closePort();
                } catch (e) { log("退出配置模式失败: " + e.message, "error"); }
                return;
            }
            await enterConfigMode();
        }));
    })();

    // 行等待的轻推与帧剥离(0xBC 自识别帧可无歧义剥离)
    async function stripProbeFramesFromHead(waitMs) {
        const t0 = performance.now();
        while (readBuffer.length > 0 && readBuffer[0] === CMD.DETECT) {
            if (readBuffer.length >= 6) { readBuffer = readBuffer.slice(6); continue; }
            if (performance.now() - t0 > waitMs) break;
            await nextTick();
        }
        while (readBuffer.length > 0 && readBuffer[0] === CMD.DEV_DETECT) readBuffer = readBuffer.slice(1);
    }

    async function waitForLineNudged(timeout) {
        await stripProbeFramesFromHead(200);
        try {
            return await waitForLine(timeout);
        } catch (e) {
            await writeBytes(new Uint8Array([CMD.DETECT]));
            await stripProbeFramesFromHead(800);
            return await waitForLine(timeout);
        }
    }

    // round63b: 保存前确认设备仍在配置模式。配置模式有 60s 空闲自动退出(固件保底),
    // 面板若在设备已退出/重启后仍发送 CFG_SET 载入流,128 字节会撞进普通模式命令流,
    // 超时后还可能被解码成 0xB9/0xBB 触发重置。判别命令改用 GET_STATUS(0xB8):
    // 配置模式返回换行结尾的 "get status...\n"(与面板状态查询同一机制,真机已验证),
    // 普通模式 cdc_respond 无 0xB8 分支(静默丢弃)。(round86 注: 0xBC 自 round86
    // 固件起已有普通模式专用处理器, 但其 6B 二进制帧仍不宜做存活探测 --
    // 0xB8 的换行文本语义与既有 waitForLine 机制更契合, 维持不变。)
    async function probeConfigAlive() {
        flushReadBuffer();
        await writeBytes(new Uint8Array([CMD.GET_STATUS]));
        try {
            const line = await waitForLine(700);
            if (!line.includes("get status")) return false;
            // 状态转储(ToF 数值等)是多余文本,必须按时间窗排空,否则会污染随后
            // CFG_SET 的响应行读取(真机/模拟器异步分批送达,缓冲区会在排空中
            // 再次收到后续行)。固定等待 ~250ms 让 getStatus() 输出全部落盘再清空。
            const t0 = performance.now();
            while (performance.now() - t0 < 250) {
                while (readBuffer.indexOf(10) >= 0) readBuffer = readBuffer.slice(readBuffer.indexOf(10) + 1);
                await nextTick();
            }
            flushReadBuffer();
            return true;
        } catch (e) {
            // 无响应/超时 = 设备已离开配置模式(60s 空闲自动退出或已重启)。
            // 真·连接丢失将由 readLoop 的 handleUnexpectedDisconnect 单独上报。
            return false;
        }
    }

    // round63h: 命令日志转储(0xCE 诊断)。固件 handleCommand 会把配置模式下
    // 收到的每个命令字节记入环形日志(最近 255 个),回读可判定设备实际收到
    // 多少字节——用于排查 CFG_SET 载入流是否被截断(byte 65 断流等)。
    // 真机: [0xCE] -> [len][len 个字节];mock: 同构。
    // 通过控制台调用: 连接后进入配置模式, 执行 dumpCfgCmdLog()。
    async function dumpCfgCmdLog() {
        if (!connected) { log("未连接", "warn"); return; }
        try {
            flushReadBuffer();
            await writeBytes(new Uint8Array([0xCE]));
            const n = (await waitForBytes(1, 1000))[0];
            log("设备命令日志(" + n + " 字节, 最旧→最新):");
            if (n > 0) {
                const buf = await waitForBytes(n, 1000);
                const hex = Array.from(buf).map(b => b.toString(16).padStart(2, "0").toUpperCase()).join(" ");
                log(hex);
            }
        } catch (e) { log("命令日志读取失败: " + e.message, "error"); }
    }
    window.dumpCfgCmdLog = dumpCfgCmdLog;

    async function doSaveConfig() {
        if (cfgVerMismatch) {
            log("设备 cfgVer 不匹配,禁止写入(固件 checkConfigBuf 也会拒绝)", "error");
            return false;
        }
        // 保存前先确认设备仍在配置模式,避免把 128 字节写到已退出的设备。
        const alive = await probeConfigAlive();
        if (!alive) {
            log("设备已离开配置模式(可能超过 60s 自动退出或已重启)。未写入配置,请重新进入配置模式后再保存。", "error");
            return false;
        }
        finishSliderAnims();  // 收敛在途滑条动画,防止打包中间值
        const cfg = packConfig();
        const localXor = calcXorSum(cfg);
        if (localXor !== cfg[127]) {
            log("配置校验和异常", "error");
            return false;
        }
        flushReadBuffer();
        // round63i: 真机 A/B 实测(2026-08-24, cplay 固件 Built Aug 24 20:49:44)确认:
        //   A) writeBytes(0xB7+128 共 129B 单次 write) -> read timeout at byte 65 (失败)
        //   B) writeBytes([0xB7]) 再 writeBytes(cfg)(两次独立 write, 与 ConfigApp
        //      serialib::writeChar(0xB7)+writeBytes(cfg,0x80) 逐字节一致) -> check ok (成功)
        // 单次 129B write 在 Web Serial/USB 驱动层被打成 [64][64][1] 三个包, 第二个包
        // (byte 65 起)撞上设备端单缓冲 OUT 端点未及时重武装而 NAK;两次 write 让固件
        // handleCommand 先吃掉 0xB7(单独 1B 包), 随后 setConfig() 从干净状态读 128B
        // 载入流, 逐包重武装, 稳定成功(真机连测 3 次全过)。必须拆成两次 write。
        // 注意: 此处绝不能用 waitForLineNudged——设备此刻仍在 setConfig() 载入流
        // 读取中, 0xBC"轻推"会被当成第 65 个配置字节注入并错位整个配置。
        // CFG_SET 响应只能等固件读完 128 字节后由 handleCommand 打出, 用纯
        // waitForLine(总宽限 3s)。
        await writeBytes(new Uint8Array([CMD.CFG_SET]));
        await writeBytes(cfg);
        const line = await waitForLine(3000);
        log("CFG_SET 响应: " + line);
        if (!line.includes("check ok")) {
            await sleep(20);
            while (readBuffer.length > 0) log("CFG_SET 额外输出: " + await waitForLine(200));
            return false;
        }
        await sleep(50);
        await writeBytes(new Uint8Array([CMD.CFG_SAVE]));
        // CFG_SAVE 阶段设备已回到 handleCommand 命令循环, 轻推安全(不注入载入流)。
        const saveLine = await waitForLineNudged(2000);
        log("配置已保存: " + saveLine);
        return true;
    }

    async function doSaveAndReboot() {
        if (!configMode) { log("请先进入配置模式", "warn"); return; }
        try {
            const dirtyChips = $("ckMbr3116").checked
                ? Object.keys(mbrDirty).filter(k => mbrDirty[k] && mbrTableCache[k]) : [];
            if (dirtyChips.length && !(await mbrBurnQueue(dirtyChips))) {
                log("NVRAM 未通过校验；已停止保存和重启", "error");
                return;
            }
            const ok = await doSaveConfig();
            if (!ok) { log("保存未成功,取消重启", "warn"); return; }
            calPendingBackfill = false;  // round67: 校准回填已写入设备,恢复正常读回
            await sleep(100);
            await writeBytes(new Uint8Array([CMD.EXIT]));
            log("已保存并发送重启命令,设备正在重启");
            configMode = false;
            await sleep(200);
            await closePort();
            startSaveRebootReconnect();
        } catch (e) { log("保存并重启失败: " + e.message, "error"); }
    }

    // round63j: 保存并重启后自动重连。设备 reboot 后以同一 VID/PID 重新枚举,
    // 与刷写流程的 startReconnectWatch 不同: 那是 flash UI 专用(setFlashPhase/
    // verifyFlashResult), 这里走普通连接路径(openPort + autoHandshake + 输入轮询),
    // 用独立定时器避免与 flash 的 reconnectWatch/热插拔监听互相干扰。
    let saveRebootWatch = null;
    let saveRebootDeadline = 0;
    function stopSaveRebootReconnect() {
        if (saveRebootWatch) { clearInterval(saveRebootWatch); saveRebootWatch = null; }
    }
    async function saveRebootReconnectOnce() {
        if (connected) { stopSaveRebootReconnect(); return true; }
        try {
            const ports = await navigator.serial.getPorts();
            const ny = ports.find(p => {
                const i = p.getInfo();
                return i.usbVendorId === 0xCAFE && i.usbProductId === 0x4009;
            });
            if (!ny) return false;
            const ok = await openPort(ny, true);
            if (!ok) return false;
            log("保存并重启完成,已自动重连");
            await autoHandshake();
            // round70: 统一启动入口(自动开压力会话,INPUT TEST 显示真实压力)
            await startInputPolling();
            stopSaveRebootReconnect();
            return true;
        } catch (e) { return false; }
    }
    function startSaveRebootReconnect() {
        stopSaveRebootReconnect();
        saveRebootDeadline = Date.now() + 15000;
        saveRebootWatch = setInterval(async () => {
            if (Date.now() > saveRebootDeadline) {
                stopSaveRebootReconnect();
                log("保存并重启后 15 秒内未自动重连,请点击「连接串口」手动连接", "warn");
                return;
            }
            await saveRebootReconnectOnce();
        }, 1000);
    }

    // round75: 意外断开(设备看门狗复位/掉电/重枚举)后的自动重连。此前只有
    // 保存重启(startSaveRebootReconnect)与刷写(startReconnectWatch)两条流程
    // 有自动重连, 普通断开后必须手点「连接串口」——0xBA 缺陷时代设备频繁
    // 2s 看门狗复位, 面板每次都停在"连接已断开"等用户手动恢复。复用
    // save-reboot 的轮询机制, 15s 内每秒尝试重开同一 VID/PID 端口。
    let unplugWatch = null;
    let unplugDeadline = 0;
    function stopUnplugReconnect() {
        if (unplugWatch) { clearInterval(unplugWatch); unplugWatch = null; }
    }
    async function unplugReconnectOnce() {
        if (connected) { stopUnplugReconnect(); return; }
        try {
            const ports = await navigator.serial.getPorts();
            const ny = ports.find(p => {
                const i = p.getInfo();
                return i.usbVendorId === 0xCAFE && i.usbProductId === 0x4009;
            });
            if (!ny) return;
            const ok = await openPort(ny, true);
            if (!ok) return;
            stopUnplugReconnect();
            log("设备已重新出现,已自动重连");
            await autoHandshake();
            // round70: 统一启动入口(自动开压力会话,INPUT TEST 显示真实压力)
            await startInputPolling();
        } catch (e) { /* 轮询失败静默重试至截止时间 */ }
    }
    function startUnplugReconnect() {
        if (reconnectWatch) return;  // 刷写重连激活时让位, 避免双定时器抢开端口
        // round75 复查: 刷写会话进行中(0xBB→BOOTSEL→选盘符→写盘→重连验证)不启动,
        // 否则用户在盘符选择器停留超 15s 会打出误导性的"设备未重新出现"提示,
        // 且重连成功也不会跑 verifyFlashResult, 刷写结果展示会停留 stale。
        if (!["idle", "done", "error"].includes(flashPhase)) return;
        stopUnplugReconnect();
        unplugDeadline = Date.now() + 15000;
        unplugWatch = setInterval(async () => {
            if (Date.now() > unplugDeadline) {
                stopUnplugReconnect();
                log("设备 15 秒内未重新出现,请点击「连接串口」手动连接", "warn");
                return;
            }
            await unplugReconnectOnce();
        }, 1000);
    }

    async function doEraseConfig() {
        if (!configMode) { log("请先进入配置模式", "warn"); return; }
        try {
            flushReadBuffer();
            await writeBytes(new Uint8Array([CMD.CFG_ERASE]));
            const text = await readAllText(500);
            log("已擦除配置 (0xB6): " + (text.trim() || "(无输出)") + ";设备将在下次重启后使用默认配置");
            lastReadConfig = null;
            rawLightLimit = { byte: null, pct: null };
        } catch (e) { log("擦除配置失败: " + e.message, "error"); }
    }

    // ================================================================
    // 状态查询 / ToF
    // ================================================================
    async function doGetStatus(tailMs, quiet) {
        if (!configMode) { if (!quiet) log("请先进入配置模式", "warn"); return; }
        try {
            flushReadBuffer();
            await writeBytes(new Uint8Array([CMD.GET_STATUS]));
            await waitForLine(500);
            const text = await readAllText(tailMs ?? 500);
            statusLog(text || "无状态输出");
            updateStatusSummary(text);
            parseTofFromStatus(text);
            if (!quiet) log("状态读取完成");
        } catch (e) { if (!quiet) log("读取状态失败: " + e.message, "error"); }
    }

    function updateStatusSummary(text) {
        const el = $("statusSummary");
        const parts = [];
        const hw = text.match(/hwVer:\s*(\d+)/);
        if (hw) {
            const v = parseInt(hw[1], 10);
            const size = (v === 2 || v === 4) ? "32寸" : (v === 1 || v === 3) ? "27寸" : "?";
            parts.push(`hwVer ${v} (${size})`);
            if (v >= 1 && v <= 4 && v !== hwVerValue) { setHwVer(v, true); log(`状态返回 hwVer=${v},已同步硬件版本选择与 ToF 显隐`); }
        }
        const page = text.match(/using config in page\s*(\d+)/);
        if (page) parts.push(`配置页 ${page[1]}`);
        const build = text.match(/Nyanithm build\s+(.+)/);
        if (build) parts.push(`build ${build[1].trim()}`);
        const warns = [...text.matchAll(/ToF sensor #(\d+) warning/g)].map(m => `ToF${m[1]}`);
        if (warns.length) parts.push(`⚠ ${warns.join(", ")} 超量程警告`);
        el.textContent = parts.length ? parts.join(" · ") : "未解析到状态字段";
    }

    function parseTofFromStatus(text) {
        const m = text.match(/tof0\s*=\s*(-?\d+)\s+tof1\s*=\s*(-?\d+)\s+tof2\s*=\s*(-?\d+)\s+tof3\s*=\s*(-?\d+)(?:\s+tof4\s*=\s*(-?\d+))?/);
        if (!m) return;
        const vals = [parseInt(m[1]), parseInt(m[2]), parseInt(m[3]), parseInt(m[4])];
        if (m[5] !== undefined) vals.push(parseInt(m[5]));
        const max = 2000;
        for (let i = 0; i < vals.length; i++) {
            const v = vals[i];
            const valEl = $("tof" + i + "val");
            const barEl = $("tof" + i + "bar");
            if (valEl) valEl.textContent = v;
            if (barEl) {
                const pct = Math.max(0, Math.min(100, v / max * 100));
                barEl.style.width = pct + "%";
            }
            const rowEl = $("tof" + i + "bar")?.closest(".tof-row");
            if (rowEl) rowEl.classList.toggle("over", v < 0 || v >= max);
        }
    }

    function updateTofVisibility() {
        const is32 = (hwVerValue === 2 || hwVerValue === 4);
        const tof4Wrapper = $("tof4Wrapper");
        const off4Wrap = $("off4Wrap");
        if (tof4Wrapper) tof4Wrapper.style.display = is32 ? "" : "none";
        if (off4Wrap) off4Wrap.style.display = is32 ? "" : "none";
    }

    $("btnGetStatus").addEventListener("click", () => withSerialLock(() => doGetStatus()));

    $("btnPollTof").addEventListener("click", () => {
        if (tofPollId) { stopTofPoll(); return; }
        if (!configMode) { log("请先进入配置模式", "warn"); return; }
        $("btnPollTof").textContent = "停止 ToF";
        log("开始连续 ToF 读取 (250ms)");
        const gen = ++tofPollGen;
        tofPollId = setInterval(() => {
            if (!tofPollId) return;
            withSerialLock(async () => {
                if (gen !== tofPollGen) return;
                await doGetStatus(120, true);
            });
        }, 250);
    });

    function stopTofPoll() {
        tofPollGen++;
        if (tofPollId) { clearInterval(tofPollId); tofPollId = null; }
        const btn = $("btnPollTof");
        if (btn) btn.textContent = "连续 ToF";
    }

    // ================================================================
    // 逐键阈值 UI(v1.6, fw>=1.6.0 门禁; round70: 移除参数调节区 32 格网格,
    // 仅保留 INPUT TEST 气泡编辑;气泡滑条复用"参数调节"区 slider-row 样式)
    // ================================================================
    let pkSelectedKey = -1;  // 0-31 或 -1(未选)

    function updatePerKeyUi() {
        // 参数调节区网格已移除;仅用于气泡可用性提示(配置模式 + 固件支持)
        const hint = $("perKeyHint");
        if (hint) hint.style.display = (perKeyFwSupport && configMode) ? "" : "none";
    }

    // ================================================================
    // round71: 配置模式下 INPUT TEST 格子显示生效触摸/释放阈值。
    // 配置模式进入时输入轮询已停,不能挂 renderInput 逐帧;此函数事件驱动:
    // 进配置解包后 / 改全局或逐键滑条时刷新;退出配置/断开时恢复压力基线。
    // 触摸+释放都有则上下两行,仅触摸(继承 0 或 MBR)单值居中;颜色统一 accent。
    // ================================================================
    function effectiveKeyThresholds(i) {
        const globTouch = parseInt($("rgThTouch").value, 10) || 0;
        const globRelease = parseInt($("rgThRelease").value, 10) || 0;
        return {
            touch: perKeyTouch[i] || globTouch,
            release: perKeyIsMbr() ? 0 : (perKeyRelease[i] || globRelease),
            custom: !!perKeyTouch[i],
        };
    }
    function updateTcThresholdDisplay() {
        for (let i = 1; i <= CFG_NUM_KEYS; i++) {
            const tc = tcs[i];
            if (!tc) continue;
            if (!configMode || !perKeyFwSupport) {
                // 恢复压力基线: 清掉阈值 DOM 与缓存标记(内容由 renderInput/clearInputDisplay 接管)
                if (tc._thMode) {
                    tc._thMode = false;
                    tc._thSig = "";
                    tc.innerHTML = "";
                    tc.title = "";
                    tc.style.color = "";
                    tc.classList.remove("th-mode");  // round72: 恢复 BASE 通道数字伪元素
                }
                continue;
            }
            const t = effectiveKeyThresholds(i - 1);
            const sig = `${t.touch}|${t.release}`;
            if (tc._thSig === sig && tc._thMode) continue;
            tc._thSig = sig;
            tc._thMode = true;
            tc.classList.add("th-mode");  // round72: 配合 CSS 隐藏通道数字伪元素
            tc.classList.remove("active");
            tc.style.opacity = "";
            if (t.touch > 0 && t.release > 0) {
                tc.innerHTML = `<span class="tc-th-touch">${t.touch}</span><span class="tc-th-release">${t.release}</span>`;
                tc.title = `tc${i}: 触摸 ${t.touch} / 释放 ${t.release}` + (t.custom ? " (逐键)" : "");
            } else {
                const only = t.touch > 0 ? t.touch : t.release;
                tc.innerHTML = `<span class="tc-th-single">${only}</span>`;
                tc.title = `tc${i}: 阈值 ${only}` + (t.custom ? " (逐键)" : "");
            }
        }
    }

    // 气泡数显更新: initSliderAnimations 已对数显做 odometer 化,直接
    // textContent 会破坏滚动数字结构;odometer 感知地写值。
    function setPkVal(el, text) {
        if (!el) return;
        if (el._odometer) {
            const n = parseInt(text, 10);
            if (!isNaN(n)) setOdometerValue(el, n);
            else { el._odometer = null; el.classList.remove("odometer"); el.innerHTML = ""; el.textContent = text; }
        } else {
            el.textContent = text;
        }
    }

    // round69/70: 气泡编辑——配置模式下点 INPUT TEST 格子弹出
    function openPerKeyBubble(i) {
        if (!perKeyFwSupport || !configMode || i < 0 || i >= CFG_NUM_KEYS) return;
        pkSelectedKey = i;
        const modal = $("pkBubbleModal");
        if (!modal) return;
        const rng = perKeyRange();
        $("pkBubbleTitle").textContent = `键 tc${i + 1}`;
        $("pkBubbleState").textContent = perKeyTouch[i] ? `自定义: ${perKeyTouch[i]}` : "继承全局";
        const tsl = $("pkThTouch");
        const tslOut = $("pkThTouchv");
        tsl.min = rng.min; tsl.max = rng.max; tsl.step = 1;
        // 触发滑条: 0 由"恢复继承"表达;滑条实际值落在有效区间,数显展示存储字节
        tsl.value = perKeyTouch[i] || rng.min;
        tsl.disabled = false;
        setPkVal(tslOut, perKeyTouch[i] ? String(perKeyTouch[i]) : "0");
        tsl.oninput = () => {
            const v = parseInt(tsl.value, 10);
            perKeyTouch[i] = v;
            $("pkBubbleState").textContent = `自定义: ${v}`;
            setPkVal(tslOut, String(v));
            updateSliderFill(tsl);
            updateTcThresholdDisplay();
        };
        updateSliderFill(tsl);
        // 释放滑条: MBR 无意义,置灰
        const isMbr = perKeyIsMbr();
        const rsl = $("pkThRelease");
        const rslOut = $("pkThReleasev");
        const trk = $("pkReleaseTrack");
        const rrow = $("pkReleaseRow");
        const rhint = $("pkReleaseHint");
        if (isMbr) {
            if (trk) trk.style.display = "none";
            if (rrow) rrow.style.display = "";
            if (rhint) rhint.textContent = "MBR3116 不支持逐键释放,始终继承全局";
            setPkVal(rslOut, "继承");
            rsl.disabled = true;
            perKeyRelease[i] = 0;
        } else {
            if (trk) trk.style.display = "";
            if (rrow) rrow.style.display = "";
            if (rhint) rhint.textContent = "0 = 继承全局 th_release";
            rsl.min = rng.min; rsl.max = rng.max; rsl.step = 1;
            rsl.value = perKeyRelease[i] || (rng.min + 1);
            rsl.disabled = false;
            setPkVal(rslOut, perKeyRelease[i] ? String(perKeyRelease[i]) : "0");
            rsl.oninput = () => {
                const v = parseInt(rsl.value, 10);
                perKeyRelease[i] = v;
                setPkVal(rslOut, String(v));
                updateSliderFill(rsl);
                updateTcThresholdDisplay();
            };
            updateSliderFill(rsl);
        }
        $("pkInheritBtn").onclick = () => {
            perKeyTouch[i] = 0;
            perKeyRelease[i] = 0;
            $("pkBubbleState").textContent = "继承全局";
            tsl.value = rng.min;
            setPkVal(tslOut, "0");
            updateSliderFill(tsl);
            if (!isMbr) {
                rsl.value = rng.min + 1;
                setPkVal(rslOut, "0");
                updateSliderFill(rsl);
            }
            updateTcThresholdDisplay();
        };
        $("pkCloseBtn").onclick = closePerKeyBubble;
        // 打开(带入场动画: flash-modal 的 fadeIn/fadeUp 自动触发)
        openModalAnimated(modal);
    }

    // round71: 通用弹窗关闭助手(抽自 closePerKeyBubble)——加 .closing 播放
    // fadeOut/fadeUpOut, animationend 后隐藏并移除类;400ms 兜底防动画异常。
    // 所有 flash-modal 系弹窗(firmware 更新/设备详情/逐键气泡/校准向导)统一走这里,
    // 保证退出都有动画。_hideTok 代际令牌防竞态: 关闭后 400ms 内重开时,
    // 旧定时器/旧 animationend 监听不得把新弹窗隐藏(复查 C1)。
    function closeModalAnimated(modal) {
        if (!modal || modal.style.display === "none") return;
        const tok = modal._hideTok = {};
        modal.classList.add("closing");
        const hide = () => {
            if (modal._hideTok !== tok) return;  // 已被新一次打开作废
            modal._hideTok = null;
            modal.style.display = "none";
            modal.classList.remove("closing");
            modal.removeEventListener("animationend", onEnd);
        };
        const onEnd = (e) => { if (e.target === modal) hide(); };
        modal.addEventListener("animationend", onEnd, { once: true });
        setTimeout(() => { if (modal._hideTok === tok) hide(); }, 400);
    }
    // round71: 配套打开助手——清旧 closing 态并作废旧 hide 代际,统一入场。
    function openModalAnimated(modal) {
        if (!modal) return;
        modal._hideTok = null;  // 作废未触发的 hide 定时器/监听
        modal.classList.remove("closing");
        modal.style.display = "flex";
    }

    function closePerKeyBubble() {
        const modal = $("pkBubbleModal");
        if (!modal || modal.style.display === "none") return;
        pkSelectedKey = -1;
        closeModalAnimated(modal);
    }

    // ================================================================
    // 一键阈值检测向导(round67, 移植 calibrate_thresholds.ps1 两阶段统计法)
    // Phase 1 静置 20s: 每键 idleMax[k] 与直方图; Phase 2 划全滑条 15s:
    // 每键 touchMin[k]。建议: 全局 th_touch = clamp(p85(idleMax)+2);
    // 异常键(idleMax[k]+2 > 全局)设 thTouchKey[k]; 释放 = th-1(MPR)/继承(MBR)。
    // 数据源 = inputLoop 的 GET_INPUT 帧(压力模式开启时 0-255 模拟量)。
    // ================================================================
    // round70b: 校准报告内容用 escapeHtml 转义防注入。
    function escapeHtml(s) {
        return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    }
    // round71: 校准改为三屏向导弹窗(intro 规则说明 -> running 环形倒计时 -> result 报告),
    // 取代 round70b 的报告 Toast。测量循环由 tick 回调驱动倒计时,calAbort 支持中途取消;
    // Mock(?mock=)下时长 ÷20 加速,真机仍为 20s/15s。
    const CAL_IS_MOCK = /[?&]mock/.test(location.search);
    function calPhaseSeconds(sec) { return CAL_IS_MOCK ? Math.max(1, Math.round(sec / 20)) : sec; }

    function calShowScreen(id) {
        for (const s of ["calScreenIntro", "calScreenRunning", "calScreenResult"]) {
            $(s).style.display = (s === id) ? "" : "none";
        }
    }
    function calOpenWizard() {
        const modal = $("calWizardModal");
        if (!modal) return;
        calShowScreen("calScreenIntro");
        openModalAnimated(modal);
    }
    function calCloseWizard() {
        closeModalAnimated($("calWizardModal"));
    }
    // 倒计时渲染:剩 remain 秒,ratio 为已消耗比例(0-1)。环形进度用 conic-gradient。
    let calRingLastRatio = -1;
    function calRenderRing(remain, ratio) {
        const num = $("calCountdown");
        if (num && num.textContent !== String(remain)) num.textContent = remain;
        const ring = $("calRing");
        if (ring && Math.abs(ratio - calRingLastRatio) > 0.004) {
            const deg = Math.round(Math.min(1, Math.max(0, ratio)) * 360);
            ring.style.background = `conic-gradient(var(--c-accent) ${deg}deg, var(--c-surface-3, #262a33) ${deg}deg)`;
            calRingLastRatio = ratio;
        }
    }

    let calRunning = false;
    let calAbort = false;
    // round86 #7: 校准路由。startCalibration 先确保硬件探测(普通模式 0xBC,
    // 旧固件回退表单 ckMbr3116),按主控类型填充 intro 屏文案:
    //   MPR121 → 既有两轮统计校准(runCalibrationSequence);
    //   MBR3116 → 悬空阈值校准(runHoverCalSequence,向导化)。
    let calRouteMbr = false;
    function calFillIntroMpr() {
        $("calWizardApply").disabled = false;
        $("calIntroTitle").textContent = "一键校准阈值 (MPR121)";
        $("calIntroBody").innerHTML =
            '<p class="cal-intro-p">校准分两轮运行，请按提示操作：</p>' +
            '<div class="cal-phase-row"><span class="cal-phase-num">1</span>' +
            '<div class="cal-phase-text"><strong>静置（20 秒）</strong>：不要触碰触摸板，双手离开滑条，让面板采集每键底噪。</div></div>' +
            '<div class="cal-phase-row"><span class="cal-phase-num">2</span>' +
            '<div class="cal-phase-text"><strong>触摸（15 秒）</strong>：用手指轻触或在触摸板上轻轻滑动，<strong>最好每个键都摸到</strong>。</div></div>' +
            '<p class="cal-intro-note">两轮结束后将给出建议的触摸/释放阈值；点击「确认并开始修改」会自动进入配置模式并填入建议值。</p>';
        $("calWizardStart").textContent = "开始校准";
    }
    function calFillIntroMbr() {
        $("calIntroTitle").textContent = "悬空信号观察 (MBR3116)";
        $("calWizardApply").disabled = true;
        $("calIntroBody").innerHTML =
            '<p class="cal-intro-p">本入口仅观察悬空信号（6 秒采样）：</p>' +
            '<div class="cal-phase-row"><span class="cal-phase-num">1</span>' +
            '<div class="cal-phase-text"><strong>悬停（6 秒）</strong>：把手指放在需要观察的悬空位置，保持不动，不要触碰表面。</div></div>' +
            '<p class="cal-intro-note">没有有效轻触样本、区域定位与噪声裕量验证，单个悬空峰值无法产生可信阈值或毫米距离。本入口不自动回填、不写入芯片。</p>';
        $("calWizardStart").textContent = "开始观察";
    }
    async function startCalibration() {
        if (calRunning) { log("校准向导已在运行"); return; }
        if (!connected) { alert("需要先连接手台"); return; }
        if (configMode) { alert("请先退出配置模式再开始校准"); return; }
        if (!rawReportSupported) { alert("固件低于 1.6.0,不支持压力上报,无法校准"); return; }
    // round86 #7: 自动探测主控(普通模式 0xBC);探测失败回退表单勾选。
    // 每次点击校准都重新探测(设备可能更换/重枚举;探测 1-3s 可接受),
    // 探测失败时回退本次会话缓存或表单勾选。
    // 路由优先级: MPR 在位→MPR 校准; 否则 MBR 在位→悬空校准;
    // 都在位(罕见,如探测串扰)以配置「使用 3116」勾选裁决; 全无(探测帧
    // 异常)回退表单勾选。
    probeInfo = null;
    normalProbeDone = false;
    const probed = await normalModeProbe();
        let useMbr = perKeyIsMbr();
        if (probed && (probeInfo.mprMask || probeInfo.mbrMask)) {
            if (probeInfo.mprMask && probeInfo.mbrMask) {
                useMbr = perKeyIsMbr();
                log("探测同时发现 MPR121 与 MBR3116,按配置「使用 3116」" + (useMbr ? "勾选→路由 3116 校准" : "未勾选→路由 MPR 校准"), "warn");
            } else {
                useMbr = !!probeInfo.mbrMask;
            }
        }
        calRouteMbr = useMbr;
        if (useMbr) calFillIntroMbr(); else calFillIntroMpr();
        calRunning = false;
        calAbort = false;
        calShowScreen("calScreenIntro");
        calOpenWizard();
    }

    // 向导实际执行体(从 intro 屏「开始校准」进入)。沿用 round67 两阶段统计法:
    // Phase1 静置采 idleMax+直方图, Phase2 划键采 touchMin,建议全局 th_touch=p85(idleMax)+2,
    // 异常键逐键抬升。差异仅在 UI:每帧刷新倒计时/进度环/阶段文案,可中止。
    async function runCalibrationSequence() {
        if (calRunning) return;
        calRunning = true;
        calAbort = false;
        if ($("calWizardStart")) $("calWizardStart").disabled = true;
        // 需在配置模式读到的配置基础上写回: 若未进过配置模式, 用当前表单值
        if (!lastReadConfig) {
            log("提示: 尚未读取设备配置,将基于表单当前值给出建议(保存前请先读配置)", "warn");
        }
        // 校准依赖 GET_INPUT 帧流; 若输入测试没在跑, 先自动开启(并同步按钮状态)。
        // round70: 统一入口(自动开压力会话——校准的 Phase 1/2 需要真实压力采样)
        if (!inputPolling) await startInputPolling();
        const touch = [];
        const release = [];
        for (let i = 0; i < CFG_NUM_KEYS; i++) { touch[i] = 0; release[i] = 0; }

        const samples = { idleMax: new Array(CFG_NUM_KEYS).fill(0), idleHist: [] };
        for (let i = 0; i < CFG_NUM_KEYS; i++) samples.idleHist.push(new Array(256).fill(0));
        const touchMin = new Array(CFG_NUM_KEYS).fill(256);
        const touchHit = new Array(CFG_NUM_KEYS).fill(0);

        // 收集即弃: inputLoop 每帧把最新帧放 latestInputData, 这里直接读共享变量
        const probeInputFn = () => latestInputData;
        // round86: 校准采样统一走 level 2 (原始物理读数, 未缩放原生尺度),
        // 这样 MPR (0-63) 和 MBR (0-255) 均直接采样原生物理读数, 避免折算失真,
        // calScale 统一为 1.
        const calUseMbr = calRouteMbr;
        const calScale = 1;
        const calPrevMode = inputRawMode;

        let aborted = false;
        try {
            const ph1 = calPhaseSeconds(20), ph2 = calPhaseSeconds(15);
            calShowScreen("calScreenRunning");
            $("calRunTitle").textContent = "正在校准 · 第 1 轮 (静置)";
            $("calRunHint").textContent = "第一轮：请静置，不要触碰触摸板";

            log("--- 一键校准 Phase 1: 请离开滑条 20s ---");
            await setRawReportMode(2);
            const phase1Start = performance.now();
            while ((performance.now() - phase1Start) / 1000 < ph1) {
                if (calAbort) { aborted = true; break; }
                await nextTick();
                const remain = Math.max(0, Math.ceil(ph1 - (performance.now() - phase1Start) / 1000));
                calRenderRing(remain, (performance.now() - phase1Start) / 1000 / ph1);
                const f = probeInputFn();
                if (!f) continue;
                for (let i = 0; i < CFG_NUM_KEYS; i++) {
                    const v = Math.min(255, Math.round(f[i] * calScale));
                    if (v > samples.idleMax[i]) samples.idleMax[i] = v;
                    samples.idleHist[i][v]++;
                }
            }
            if (!aborted) log(`Phase 1 完成: idleMax = [${samples.idleMax.join(",")}]`);

            if (!aborted) {
                $("calRunTitle").textContent = "正在校准 · 第 2 轮 (触摸)";
                $("calRunHint").textContent = "第二轮：请轻触或在触摸板上轻轻滑动，最好每个键都摸到";
                log("--- 一键校准 Phase 2: 请用一根手指划完全部滑条 15s ---");
                const phase2Start = performance.now();
                while ((performance.now() - phase2Start) / 1000 < ph2) {
                    if (calAbort) { aborted = true; break; }
                    await nextTick();
                    const remain = Math.max(0, Math.ceil(ph2 - (performance.now() - phase2Start) / 1000));
                    calRenderRing(remain, (performance.now() - phase2Start) / 1000 / ph2);
                const f = probeInputFn();
                if (!f) continue;
                for (let i = 0; i < CFG_NUM_KEYS; i++) {
                    const v = Math.min(255, Math.round(f[i] * calScale));
                    if (v < touchMin[i]) touchMin[i] = v;
                    if (v > 0) touchHit[i]++;
                }
            }
            if (!aborted) log(`Phase 2 完成: touchMin = [${touchMin.join(",")}] 命中 = [${touchHit.join(",")}]`);
            }

            if (aborted) {
                log("校准已取消", "warn");
                calRevertBackfill();  // 复查 B1: 中止同样撤销回填
                calCloseWizard();
                return;
            }

            // 统计: 全局 p85(idleMax) = 取所有键 idleMax 排序第 85 百分位
            const sorted = samples.idleMax.slice().sort((a,b)=>a-b);
            const p85 = sorted[Math.floor(sorted.length * 0.85)];
            const globTh = Math.max(1, Math.min(63, p85 + 2));
            log(`建议全局 th_touch = ${globTh} (p85(idleMax)=${p85}+2)`);

            // round86 审查修复(P2): 同 calUseMbr -- 按路由而非表单勾选
            const useMbr = calRouteMbr;
            const rng = perKeyRange();
            let customCount = 0;
            for (let i = 0; i < CFG_NUM_KEYS; i++) {
                const idleMax = samples.idleMax[i];
                if (idleMax + 2 > globTh) {
                    // round67: MBR 有效下限 129(计划 D4.1, ≤128 只等价默认 80, 无收紧效果),
                    // 用 rng.min 而非 1 作为下限, 避免生成"无效收紧"建议值误导用户。
                    let v = Math.max(rng.min, Math.min(rng.max, idleMax + 2));
                    touch[i] = v;
                    release[i] = useMbr ? 0 : ((v > 1) ? v - 1 : 1);
                    customCount++;
                } else {
                    touch[i] = 0;  // 继承
                    release[i] = 0;
                }
            }
            log(`建议逐键设置: ${customCount} 个异常键需抬升,其余继承全局`);

            // 回填 UI(perKey 状态 + 全局滑条)
            calPendingBackfill = true;  // 保护回填值,进配置模式读回时不覆盖
            setSlider($("rgThTouch"), globTh, { quiet: true });
            for (let i = 0; i < CFG_NUM_KEYS; i++) {
                perKeyTouch[i] = touch[i];
                perKeyRelease[i] = release[i];
            }
            if (useMbr) {
                // MBR: 释放无意义, 但滑条的全局 th_release 仍然保留表单值
            } else {
                setSlider($("rgThRelease"), Math.max(1, globTh - 1), { quiet: true });
            }
            updatePerKeyUi();
            updateUI();

            // round71: 报告展示于 result 屏;确认按钮=「确认并开始修改」,自动进配置模式
            const detail = [];
            for (let i = 0; i < CFG_NUM_KEYS; i++) {
                if (touch[i]) {
                    detail.push(`tc${i+1}: 建议 ${touch[i]} (idleMax=${samples.idleMax[i]}, touchMin=${touchMin[i]===256?"-":touchMin[i]})`);
                } else if (touchMin[i] === 256) {
                    detail.push(`tc${i+1}: 未检测到按下(可能失灵)`);
                }
            }
            const lines = [
                `建议全局 th_touch = <b>${globTh}</b>`,
                customCount
                    ? `<div style="margin-top:8px">${customCount} 个键建议独立抬升:<br>${detail.slice(0, 8).map(d => escapeHtml(d)).join("<br>")}${detail.length > 8 ? `<br>…(其余 ${detail.length - 8} 个见 INPUT TEST 气泡)` : ""}</div>`
                    : "<div style='margin-top:8px'>所有键建议继承全局阈值</div>",
                "<div style='margin-top:10px' class='cal-report-note'>点击「确认并开始修改」将自动进入配置模式并填入上述建议值，保存并重启后生效。</div>",
            ];
            $("calReportBody").innerHTML = lines.join("");
            calShowScreen("calScreenResult");
            log("--- 一键校准完成: 请查看报告并确认 ---");
        } catch (e) {
            log("校准向导出错: " + e.message, "error");
            calCloseWizard();
        } finally {
            calRunning = false;
            if ($("calWizardStart")) $("calWizardStart").disabled = false;
            // round86: 校准退出恢复用户原本的报送模式偏好
            await setRawReportMode(calPrevMode);
        }
    }

    // 向导按钮接线(intro 开始/取消、running 中止、result 应用/取消)。
    // round71 复查 B1: 回填发生在测量完成时;结果屏「取消」必须撤销——
    // 复位 calPendingBackfill 并还原校准前的全局滑条与逐键数组快照,
    // 否则用户视角"取消"了,表单却带着建议值静默等待保存。
    let calPreTouch = null, calPreRelease = null, calPreGlobTouch = null, calPreGlobRel = null;
    function calSnapshotBefore() {
        calPreTouch = perKeyTouch.slice();
        calPreRelease = perKeyRelease.slice();
        calPreGlobTouch = $("rgThTouch").value;
        calPreGlobRel = $("rgThRelease").value;
    }
    function calRevertBackfill() {
        calPendingBackfill = false;
        if (!calPreTouch) return;
        perKeyTouch.splice(0, CFG_NUM_KEYS, ...calPreTouch);
        perKeyRelease.splice(0, CFG_NUM_KEYS, ...calPreRelease);
        setSlider($("rgThTouch"), parseInt(calPreGlobTouch, 10) || 1, { quiet: true });
        setSlider($("rgThRelease"), parseInt(calPreGlobRel, 10) || 1, { quiet: true });
        updatePerKeyUi();
        updateUI();
        calPreTouch = null;
    }
    (() => {
        if (!$("calWizardModal")) return;
        // round86 #7: 开始按钮按路由分流 -- MPR 走统计校准(需快照以便取消回滚),
        // MBR 走悬空采样(确认前不写表单,无需快照)。
        $("calWizardStart").addEventListener("click", () => {
            if (calRouteMbr) { runHoverCalSequence(); }
            else { calSnapshotBefore(); runCalibrationSequence(); }
        });
        $("calWizardCancelIntro").addEventListener("click", () => calCloseWizard());
        // round86 #7: result 屏「取消」按路由回滚 -- MPR 撤销已回填的建议值,
        // MBR 仅结束信号观察,没有参数回填。
        $("calWizardCancelResult").addEventListener("click", () => {
            if (calRouteMbr) { hoverCalResult = null; log("已结束本次悬空信号观察"); }
            else calRevertBackfill();
            calCloseWizard();
        });
        $("calWizardApply").addEventListener("click", () => {
            calCloseWizard();
            if (calRouteMbr) {
                hoverCalResult = null;
                log("MBR 单悬空观察不应用参数：需要有效轻触样本和分离裕量验证", "warn");
                return;
            }
            calPreTouch = null;  // 已确认,快照作废(复查 B1)
            // 确认修改:自动进入配置模式(回填值已在上面写入 perKeyTouch/perKeyRelease,
            // calPendingBackfill=true 保证 unpackConfig 不覆盖)。若已在配置模式则直接更新 UI。
            // round71 复查 D1: 校准刚结束 inputPolling 仍在跑,必须持事务锁再发 0xB3,
            // 否则 GET_INPUT 帧可与配置读取流交错(与其余 enterConfigMode 调用点一致)。
            if (configMode) { updatePerKeyUi(); updateUI(); }
            else { withSerialLock(() => enterConfigMode()); }
            log("校准建议已回填,进入配置模式确认后请点「保存并重启」应用", "info");
        });
        $("calWizardAbort").addEventListener("click", () => { calAbort = true; });
        // 遮罩点击不关闭(running 中误点遮罩会丢两轮采样),仅 running 屏的取消按钮可中止
    })();

    /* 原 startCalibration 测量主体已迁移至 runCalibrationSequence(round71 向导化) */

    // ================================================================
    // 触摸 UI 联动(MPR121 / 3116)
    // ================================================================
    function updateTouchUi() {
        const use3116El = $("ckMbr3116");
        // v2 布局(hwVer 3/4)的固件管线只读 3116,未勾选属退化组合,直接联动勾选
        if ((hwVerValue === 3 || hwVerValue === 4) && !use3116El.checked) {
            use3116El.checked = true;
            log("hwVer " + hwVerValue + " 为 v2 布局(仅 3116),已自动勾选「使用 3116」", "warn");
        }
        const use3116 = use3116El.checked;
        // round86 #5: 参数调节/高级参数区按触摸主控显隐 --
        // MPR 专有: 触摸/释放阈值、触发/释放消抖(dt/dr 固件只写 MPR setDebounce);
        // 3116 专有: 芯片触摸阈值(THRESHOLD)、触摸/释放消抖(SENSOR_DEBOUNCE)、
        //   灵敏度(SENSITIVITY)、悬空抑制(mbrTouchGate)。
        // AIR/亮度/延迟/ToF 等与主控无关,恒显。
        document.querySelectorAll("[data-mpr-only]").forEach(el => el.style.display = use3116 ? "none" : "");
        document.querySelectorAll("[data-mbr-only]").forEach(el => el.style.display = use3116 ? "" : "none");
        const mbrGateRow = $("rgMbrGate")?.closest(".slider-row");
        if (mbrGateRow) mbrGateRow.style.display = use3116 ? "" : "none";
        $("mbrSection").style.display = (use3116 && configMode) ? "" : "none";
        if (use3116 && !mbrTable) loadMbrTemplate();
        // round86 #11: sb3 大数显跟随主控(TH TOUCH / THRESHOLD)
        updateSb3ForChip();
        updateTofVisibility();
        updatePerKeyUi();
    }

    // round54: 阈值区间标定提示(依据固件实测:空闲噪声底 ≤13,真实触摸 20-50)
    // round56: 增加消抖 dt/dr 警告提示与滑条/数显的橙红渐变(超过警告线 25% 触发)。
    function checkThresholdHints() {
        const tt = parseInt($("rgThTouch").value);
        const tr = parseInt($("rgThRelease").value);
        const tw = $("thTouchWarn");
        if (!isNaN(tt)) {
            if (tt > 20) { tw.textContent = `⚠ ${tt} 偏高:轻触(差值约 20–50)可能漏触`; tw.style.display = ""; }
            else if (tt < 4) { tw.textContent = `⚠ ${tt} 偏低:基线噪声(实测底 ≤13)易误触`; tw.style.display = ""; }
            else tw.style.display = "none";
        } else tw.style.display = "none";
        const rw = $("thReleaseWarn");
        if (!isNaN(tt) && !isNaN(tr) && tr >= tt) {
            rw.textContent = `⚠ 释放阈值应低于触摸阈值(当前 ${tr} ≥ ${tt}),无迟滞易触发改释放抖动`;
            rw.style.display = "";
        } else if (!isNaN(tr) && tr > 8) {
            rw.textContent = `⚠ ${tr} 偏高:建议 3–8`;
            rw.style.display = "";
        } else rw.style.display = "none";

        // 消抖警告:dt/dr 推荐 1–3 挡,>3 起提示,>= 警告线 25% 时数显+滑条转橙红
        const dt = parseInt($("rgDt").value);
        const dr = parseInt($("rgDr").value);
        const dw = $("dtWarn"), rrw = $("drWarn");
        if (!isNaN(dt) && dt > 3) { dw.textContent = `⚠ 触发消抖 ${dt} 挡偏高:输入响应会明显变慢,建议 1–3 挡`; dw.style.display = ""; }
        else if (dw) dw.style.display = "none";
        if (!isNaN(dr) && dr > 3) { rrw.textContent = `⚠ 释放消抖 ${dr} 挡偏高:建议 1–3 挡`; rrw.style.display = ""; }
        else if (rrw) rrw.style.display = "none";

        // 滑条/数显渐变:警告线 = 触摸(4/20) 释放(3/8) 消抖(1/3);达到警告线 125% 即转橙红
        updateThresholdSliderWarn($("rgThTouch"), tt, 4, 20);
        updateThresholdSliderWarn($("rgThRelease"), tr, 3, 8);
        updateThresholdSliderWarn($("rgDt"), dt, 1, 3);
        updateThresholdSliderWarn($("rgDr"), dr, 1, 3);
    }

    // 单个阈值滑条:超过警告线 25%(即值 >= 推荐上限*1.25 或低于推荐下限/1.25)时,
    // 在 <input> 与 <output> 上切换 .warn/.danger 类,由 CSS 平滑过渡颜色。
    function updateThresholdSliderWarn(slider, val, lo, hi) {
        if (!slider || isNaN(val)) return;
        const out = $(slider.id + "v");
        const overHigh = val >= Math.ceil(hi * 1.25);
        const overLow = lo > 0 && val <= Math.floor(lo / 1.25);
        const critical = overHigh || overLow;
        slider.classList.toggle("warn", critical);
        if (out) out.classList.toggle("warn", critical);
    }

    function updateLightLimitHint() {
        const v = Math.round(parseInt($("rgBright").value) * 255 / 100);
        $("rgBright").title = `lightLimit = ${v} / 255 (≈${$("rgBright").value}%)`;
    }

    // ================================================================
    // MBR3116 芯片选择与寄存器表
    // ================================================================
    function mbrChipAddr() { return parseInt($("mbrChip").value, 16); }

    function refreshMbrChips() {
        const sel = $("mbrChip");
        const prev = sel.value;
        let addrs = [];
        let hint = "";
        if (probeInfo && probeInfo.mbrMask) {
            MBR_ADDRS.forEach((a, i) => { if (probeInfo.mbrMask & (1 << i)) addrs.push(a); });
            hint = "来自 0xBC 硬件探测(实机在位)";
        }
        if (!addrs.length) {
            const v2 = (hwVerValue === 3 || hwVerValue === 4);
            addrs = v2 ? ["0x43", "0x44"] : ["0x40", "0x41", "0x42"];
            hint = (probeInfo ? "探测未见 3116 芯片," : "") +
                (v2 ? "按 hwVer 推断:v2 布局两片 0x43/0x44" : "按 hwVer 推断:v1 布局三片 0x40-0x42") +
                (probeInfo ? "" : "(连接后探测可自动识别)");
        }
        sel.innerHTML = "";
        addrs.forEach(a => {
            const o = document.createElement("option");
            o.value = a;
            o.textContent = `${a}(固件${MBR_TABLES[a] ? "内置模板" : "无模板"})`;
            sel.appendChild(o);
        });
        if (prev && addrs.includes(prev)) sel.value = prev;
        $("mbrChipHint").textContent = hint;
        if (!mbrTable || (prev && sel.value !== prev)) loadMbrTemplate();
    }

    function renderMbrHex() {
        if (!mbrTable) return;
        const lines = [];
        for (let r = 0; r < 8; r++) {
            lines.push(Array.from(mbrTable.slice(r * 16, r * 16 + 16))
                .map(b => b.toString(16).padStart(2, "0").toUpperCase()).join(" "));
        }
        $("mbrHexTable").value = lines.join("\n");
    }

    // round86 #12: 每芯片表缓存。mbrTable 仍是"当前编辑目标芯片"的表;
    // mbrTableCache 保存全部目标芯片的最新表, mbrDirty 标记"该芯片缓存相对
    // 其上次烧录(或 0xC6 读回)有未落 NVM 的编辑"。
    // round86 审查修复(P1): dirty ≠ untrusted。滑条编辑「同步调整所有目标芯片」
    // -- change 处理器把新值同步写进全部芯片缓存(全部标脏), BurnAll 烧的正是
    // 这些编辑值;0xC6 读回是该芯片的 NVM 实值, 读回后清脏。唯一拒绝烧录的情形
    // 是"该芯片从未有缓存"(模板未读回且未编辑) -- 防止用模板覆盖芯片实值。
    let mbrTableCache = {};
    let mbrDirty = {};
    let mbrReadBases = {};
    let mbrWriting = false;
    const mbrWriteBackups = [];
    window.__mbrWriteBackups = mbrWriteBackups;

    function resetMbrSession() {
        mbrTableCache = {}; mbrDirty = {}; mbrReadBases = {};
        mbrTable = null; mbrCurChip = null;
    }

    function mbrSetWriteStatus(message, failed = false) {
        $("mbrWriteStatus").textContent = message;
        $("mbrWriteStatus").classList.toggle("warn", failed);
        if ($("mbrRegWriteStatus")) $("mbrRegWriteStatus").textContent = message;
    }

    function mbrKey(addr) {
        return "0x" + parseInt(addr, 16).toString(16).toUpperCase();
    }
    function mbrAllRead() {
        const chips = [...$("mbrChip").options];
        return chips.length > 0 && chips.every(o => !!mbrReadBases[mbrKey(o.value)]);
    }
    function mbrCanProgram() {
        const bid = devInfo && devInfo.buildId;
        const parsed = typeof bid === "string" ? bid.match(/^round(\d+)[a-z]*$/) : null;
        if (!parsed || parsed[0] !== bid || !Number.isSafeInteger(Number(parsed[1]))) return false;
        return configMode && mbrGateFwSupport && MBR_CRC_OK && devInfo &&
            cmpBuildId(devInfo.buildId) >= cmpBuildId("round88d");
    }
    // 把"以当前表为基准的编辑"传播到全部目标芯片缓存:
    // 各芯片在自己缓存(或当前表)的基础上应用编辑器写法, 保留各片 SENSOR_EN
    // 使能位差异 -- 只同步阈值/消抖/灵敏度三组语义值, 不整表覆盖。
    function mbrPropagateEdits(th, db, sn, field) {
        const chips = [...$("mbrChip").options].map(o => o.value);
        chips.forEach(c => {
            const base = mbrTableCache[c] || (mbrKey(c) === mbrKey($("mbrChip").value) ? mbrTable : null);
            if (!base || !mbrReadBases[mbrKey(c)]) return;
            const t = new Uint8Array(base);
            const en = (t[0x00] | (t[0x01] << 8)) & 0xFFFF;
            for (let i = 0; i < 16; i++) {
                if (field === "mbrThreshold" && (en & (1 << i))) t[0x0C + i] = th;
            }
            if (field === "mbrDebounce") t[0x1C] = (t[0x1C] & 0xF0) | db;
            for (let i = 0; i < 16; i++) {
                if (field !== "mbrSensitivity" || !(en & (1 << i))) continue;
                const reg = 0x08 + (i >> 2);
                const shift = (i & 3) * 2;
                t[reg] = (t[reg] & ~(0x03 << shift)) | ((sn & 0x03) << shift);
            }
            mbrTableCache[c] = t;
            mbrUpdateTableCrc(t);
            mbrDirty[c] = !mbrTablesEqual(t, mbrReadBases[mbrKey(c)]);
        });
    }
    function mbrCacheStore(addr, table, trusted) {
        const key = mbrKey(addr);
        mbrTableCache[key] = new Uint8Array(table);
        if (trusted) {
            mbrReadBases[key] = new Uint8Array(table);
            mbrDirty[key] = false;
        }
    }
    function mbrCacheGet(addr) {
        return mbrTableCache[mbrKey(addr)] || null;
    }

    function syncMbrFields() {
        if (!mbrTable) return;
        // round82: 阈值/消抖滑块化 -- setSlider 同步数显 odometer 与滑轨填充;
        // 值超出滑块量程(导入外部表)时 setSlider 自动扩展 min/max。
        // round85: SENSITIVITY 0x08-0x0B 每字节 4 传感器 × 2 位, 滑块显示
        // byte0 的 sensor0 档位(模板全表同值), 显示为 pF 值。
        setSlider($("mbrThreshold"), mbrTable[0x0C], { quiet: true });
        setSlider($("mbrDebounce"), mbrTable[0x1C] & 0x0F, { quiet: true });
        setSlider($("mbrSensitivity"), mbrTable[0x08] & 0x03, { quiet: true });
        checkMbrThresholdHint();
        checkMbrSensitivityHint();
        renderMbrHex();
    }

    // round86 #12: 载入当前目标芯片的表缓存;无缓存时回退固件模板(untrusted)。
    function loadMbrForChip() {
        if (!MBR_CRC_OK) return;
        const key = $("mbrChip").value || "0x40";
        const cached = mbrCacheGet(key);
        if (cached) {
            mbrTable = new Uint8Array(cached);
            log(`已切换到 ${key} 表缓存(未烧录修改${mbrDirty[key] ? "存在" : "无"})`);
        } else {
            const tpl = MBR_TABLES[key] || MBR_TABLES["0x40"];
            mbrTable = new Uint8Array(tpl);
            mbrCacheStore(key, mbrTable, false);
            log(`已载入 ${key} 固件内置模板 (128 字节,未与芯片实值核对)`);
        }
        syncMbrFields();
        mbrCurChip = key;
        updateUI();
        // round88: 悬浮窗开着时同步刷新寄存器输入框(syncMbrRegInputs 在下方定义, 函数声明提升可用)
        if ($("mbrRegModal") && $("mbrRegModal").style.display !== "none") syncMbrRegInputs();
    }
    // round71 兼容旧调用点(模板/芯片切换), 语义并入 loadMbrForChip
    function loadMbrTemplate() { loadMbrForChip(); }

    function checkMbrThresholdHint() {
        const el = $("mbrThresholdWarn");
        if (!el) return;
        const v = parseInt($("mbrThreshold").value);
        if (isNaN(v)) { el.style.display = "none"; return; }
        if (v > 200) { el.textContent = `⚠ ${v} 偏高:可能明显漏触(内置表基准 128)`; el.style.display = ""; }
        else if (v < 32) { el.textContent = `⚠ ${v} 偏低:空闲噪声易误触(内置表基准 128)`; el.style.display = ""; }
        else el.style.display = "none";
    }

    $("btnMbrTemplate").addEventListener("click", () => {
        const key = mbrKey($("mbrChip").value);
        if (!MBR_TABLES[key]) return;
        if (mbrDirty[key] && !confirm("查看模板将丢弃当前未写入修改。继续？")) return;
        mbrTable = new Uint8Array(MBR_TABLES[key]);
        mbrCacheStore(key, mbrTable, false);
        delete mbrReadBases[key]; mbrDirty[key] = false;
        syncMbrFields(); syncMbrRegInputs(); updateUI();
        log("模板仅供查看；请读取芯片后编辑");
    });
    // 切换保留编辑；写入只由明确按钮触发。
    $("mbrChip").addEventListener("change", () => {
        mbrCurChip = $("mbrChip").value;
        loadMbrForChip();
    });
    let mbrCurChip = null;

    // round82: 滑块写回内存表。THRESHOLD 0x0C..0x1B 仅写 SENSOR_EN 使能位
    // (模板对禁用传感器保留 0x7F, 不再整段覆盖); 0x1C 低 4 位 GLOBAL_DEBOUNCE。
    // round85: SENSITIVITY 0x08-0x0B 每字节 4 传感器 × 2 位(值 0-3 = 0.1-0.4pF),
    // 写入器对全部 4 字节的使能传感器置同档位并保留同字节其他传感器位。
    function mbrWriteThreshold(th) {
        const en = (mbrTable[0x00] | (mbrTable[0x01] << 8)) & 0xFFFF;  // SENSOR_EN 0x00/0x01
        for (let i = 0; i < 16; i++) {
            if (en & (1 << i)) mbrTable[0x0C + i] = th;
        }
    }
    function mbrWriteSensitivity(step) {
        const en = (mbrTable[0x00] | (mbrTable[0x01] << 8)) & 0xFFFF;
        for (let i = 0; i < 16; i++) {
            if (!(en & (1 << i))) continue;
            const reg = 0x08 + (i >> 2);          // 0x08-0x0B
            const shift = (i & 3) * 2;            // 每字节 4 传感器 × 2 位
            mbrTable[reg] = (mbrTable[reg] & ~(0x03 << shift)) | ((step & 0x03) << shift);
        }
    }
    function checkMbrSensitivityHint() {
        const el = $("mbrSensitivityWarn");
        if (!el) return;
        const v = parseInt($("mbrSensitivity").value);
        if (isNaN(v)) { el.style.display = "none"; return; }
        const pf = ["0.1", "0.2", "0.3", "0.4"][v] || String(v);
        el.textContent = `当前档位 ${pf}pF`;
        el.style.display = "";
    }
    ["mbrThreshold", "mbrDebounce", "mbrSensitivity"].forEach(id => {
        $(id).addEventListener("change", () => {
            if (!mbrTable || mbrWriting) return;
            if (!mbrAllRead()) { log("请先读取全部芯片", "warn"); return; }
            const th = Math.max(31, Math.min(200, parseInt($("mbrThreshold").value) || 31));
            const db = Math.max(1, Math.min(15, parseInt($("mbrDebounce").value) || 1));
            const sn = Math.max(0, Math.min(3, parseInt($("mbrSensitivity").value) || 0));
            if (id === "mbrThreshold") mbrWriteThreshold(th);
            if (id === "mbrDebounce") mbrTable[0x1C] = (mbrTable[0x1C] & 0xF0) | db;
            if (id === "mbrSensitivity") mbrWriteSensitivity(sn);
            mbrUpdateTableCrc(mbrTable);
            checkMbrThresholdHint();
            checkMbrSensitivityHint();
            renderMbrHex();
            // round86 审查修复(P1): 编辑同步写全部目标芯片缓存(标脏),
            // 「同步烧录全部芯片」烧的正是这些编辑值 -- 滑条 hint 的
            // 「同步调整所有目标芯片」自此与数据流一致。
            mbrPropagateEdits(th, db, sn, id);
            mbrTable = new Uint8Array(mbrCacheGet($("mbrChip").value));
            syncMbrRegInputs();
            updateSb3ForChip();
        });
    });

    // C6 回读完整配置块。
    async function mbrReadChipTable(addr, timeoutMs = 3000) {
        flushReadBuffer();
        await writeBytes(new Uint8Array([CMD.READ3116CONFIG]));
        await writeBytes(new Uint8Array([parseInt(addr, 16)]));
        const data = await waitForBytes(128, timeoutMs);
        return new Uint8Array(data.slice(0, 128));
    }

    function mbrTablesEqual(a, b) {
        if (!a || !b || a.length !== 128 || b.length !== 128) return false;
        for (let i = 0; i < 128; i++) if (a[i] !== b[i]) return false;
        return true;
    }

    // 所有写入入口共用原表校验、写前备份和全表回读。
    async function mbrBurnOne(addr) {
        const key = mbrKey(addr);
        const target = parseInt(addr, 16);
        if (!mbrCanProgram()) { log("写入 NVRAM 需 round88d 或更新固件", "error"); return false; }
        const cached = mbrCacheGet(addr);
        if (!cached || !mbrReadBases[key]) { log(`${key} 请先读取芯片`, "error"); return false; }
        const table = new Uint8Array(cached);
        const prepared = mbrValidateTable(table, target, mbrReadBases[key]);
        if (!prepared.valid) { log(`${key} 写入被拒绝：${prepared.reasons.join("；")}`, "error"); return false; }
        mbrWriting = true; updateUI();
        let backedUp = false;
        try {
            mbrSetWriteStatus(`${key} · 读取写前备份`);
            const before = await mbrReadChipTable(key, 4000);
            const readCheck = mbrValidateTable(before, target);
            if (!readCheck.valid) throw new Error("写前表无效：" + readCheck.reasons.join("；"));
            if (!mbrTablesEqual(before, mbrReadBases[key])) throw new Error("芯片原值已改变；请重新读取");
            const freshCheck = mbrValidateTable(table, target, before);
            if (!freshCheck.valid) throw new Error("芯片原值已改变；请重新读取");
            mbrWriteBackups.push({ address: key, time: new Date().toISOString(), table: Array.from(before) });
            backedUp = true;
            $("btnMbrBackup").disabled = false;
            if (mbrTablesEqual(before, table)) {
                mbrCacheStore(key, before, true);
                mbrSetWriteStatus(`${key} · 无变化，已跳过`);
                return true;
            }
            const payload = new Uint8Array(129);
            payload[0] = target; payload.set(table, 1);
            mbrSetWriteStatus(`${key} · 已备份，正在写入`);
            flushReadBuffer();
            await writeBytes(new Uint8Array([CMD.LOAD3116CONFIG]));
            await writeBytes(payload);
            const line1 = await waitForLine(3000);
            const line2 = await waitForLine(10000);
            if (!line1.includes("programing 3116 chip") || line2.trim() !== "done") throw new Error("设备未确认写入：" + line1 + " / " + line2);
            mbrSetWriteStatus(`${key} · 回读校验`);
            const readback = await mbrReadChipTable(key, 4000);
            if (!mbrTablesEqual(readback, table)) throw new Error("128 字节回读不一致");
            mbrCacheStore(key, readback, true);
            mbrSetWriteStatus(`${key} · 已写入并校验 128/128`);
            log(`${key} NVRAM 已写入并校验 128/128`);
            return true;
        } catch (e) {
            mbrSetWriteStatus(`${key} · 失败，已停止`, true);
            log(`${key} ${e.message}${backedUp ? "；写前备份已保留" : "；未写入"}`, "error");
            return false;
        } finally {
            mbrWriting = false; updateUI();
        }
    }

    async function mbrBurnQueue(chips) {
        for (const c of chips) {
            const key = mbrKey(c);
            const check = mbrValidateTable(mbrTableCache[key], parseInt(c, 16), mbrReadBases[key]);
            if (!mbrReadBases[key] || !check.valid) {
                mbrSetWriteStatus(`${key} · 请读取芯片并检查参数`, true);
                log(`${key} 写入被拒绝：${check.reasons.join("；") || "未经芯片读取"}`, "error");
                return false;
            }
        }
        for (let i = 0; i < chips.length; i++) {
            log(`NVRAM ${i + 1}/${chips.length} · ${chips[i]}`);
            if (!(await mbrBurnOne(chips[i]))) return false;
        }
        const key = mbrKey($("mbrChip").value);
        if (mbrTableCache[key]) mbrTable = new Uint8Array(mbrTableCache[key]);
        syncMbrFields(); syncMbrRegInputs();
        return true;
    }

    function mbrRestoreSafeParams(addr) {
        const key = mbrKey(addr);
        const base = mbrReadBases[key], template = MBR_TABLES[key];
        if (!base || !template) { log(`${key} 请先读取芯片`, "warn"); return false; }
        const table = new Uint8Array(mbrTableCache[key]);
        for (let a = 0; a < 0x7E; a++) {
            const mask = mbrEditableMask(a, base);
            table[a] = (table[a] & ~mask) | (template[a] & mask);
        }
        mbrUpdateTableCrc(table);
        mbrCacheStore(key, table, false); mbrDirty[key] = true;
        if (key === mbrKey($("mbrChip").value)) mbrTable = table;
        return true;
    }

    $("btnMbrRestoreAll").addEventListener("click", () => {
        const chips = [...$("mbrChip").options].map(o => o.value);
        if (chips.some(c => !mbrReadBases[mbrKey(c)] || !MBR_TABLES[mbrKey(c)])) { log("请先读取全部目标芯片", "warn"); return; }
        chips.forEach(mbrRestoreSafeParams);
        syncMbrFields(); syncMbrRegInputs();
        mbrSetWriteStatus("已恢复模板触摸参数；待写入");
    });

    async function mbrBurnAll() {
        const chips = [...$("mbrChip").options].map(o => o.value).filter(c => mbrDirty[mbrKey(c)]);
        if (!chips.length) { mbrSetWriteStatus("无待写入修改"); return; }
        if (!confirm(`写入 ${chips.length} 片芯片的修改？\n写前备份，写后校验。`)) return;
        if (await mbrBurnQueue(chips)) mbrSetWriteStatus(`完成 · ${chips.length} 片已核对`);
    }
    $("btnMbrBurnAll").addEventListener("click", () => withSerialLock(() => mbrBurnAll().catch(e => log("同步烧录失败: " + e.message, "error"))));

    // NVRAM 详细设置。
    let mbrRegRisk = { severe: false, warn: false, reasons: [] };

    function buildMbrRegUI() {
        const body = $("mbrRegBody");
        body.innerHTML = '<div class="mbr-reg-group-title">常用参数</div><div class="mbr-reg-grid" id="mbrSafeGrid"></div><details class="adv-details"><summary>逐通道阈值与灵敏度</summary><div class="mbr-reg-grid" id="mbrChannelGrid"></div></details><details class="adv-details"><summary>硬件与基线参数 · 只读</summary><div class="mbr-reg-grid" id="mbrReadOnlyGrid"></div></details>';
        const primary = [0x4D, 0x4F, 0x1D, 0x1C];
        const ordered = [...primary.map(a => MBR_REG_DEFS.find(d => d.a === a)), ...MBR_REG_DEFS.filter(d => !primary.includes(d.a))];
        ordered.forEach(def => {
            const editable = !!mbrEditableMask(def.a);
            const item = document.createElement("div"); item.className = "mbr-reg-item";
            const label = document.createElement("label"); label.className = "field-label";
            label.textContent = def.a >= 0x0C && def.a <= 0x1B ? `CS${def.a - 0x0C} 阈值` : def.n;
            const special = [0x1D, 0x4D, 0x4F].includes(def.a);
            const input = document.createElement(special ? "select" : "input");
            input.id = "mbrReg_" + def.a.toString(16).toUpperCase().padStart(2, "0");
            label.htmlFor = input.id;
            input.className = special ? "sel-input" : "num-input";
            if (special) {
                const options = def.a === 0x4D ? [[0, "关闭"], [1, "中值"], [2, "IIR 平滑"], [3, "中值 + IIR"]]
                    : def.a === 0x4F ? [[8, "自动阈值"], [0, "手动阈值"]]
                    : [[-1, "自动迟滞"], ...Array.from({ length: 32 }, (_, i) => [i, `手动 ${i}`])];
                options.forEach(([v, text]) => input.add(new Option(text, String(v))));
            } else {
                input.type = "number"; input.min = def.min; input.max = def.max; input.step = 1;
            }
            input.disabled = true;
            input.dataset.editable = editable ? "1" : "0";
            const desc = document.createElement("span"); desc.className = "field-hint";
            desc.textContent = def.a >= 0x0C && def.a <= 0x1B ? "31–200；手动阈值模式生效"
                : def.a === 0x1D ? "ON=FT+迟滞；OFF=FT−迟滞"
                : def.a >= 0x08 && def.a <= 0x0B ? "每传感器 2 位；亦可用灵敏度滑条"
                : !editable && ![0x1F, 0x20, 0x21, 0x4C, 0x52, 0x55].includes(def.a) ? "只读；保持芯片值" : def.d;
            item.append(label, input, desc);
            $(primary.includes(def.a) ? "mbrSafeGrid" : editable ? "mbrChannelGrid" : "mbrReadOnlyGrid").appendChild(item);
        });
    }

    function syncMbrRegInputs() {
        if (!mbrTable) return;
        MBR_REG_DEFS.forEach(def => {
            const el = $("mbrReg_" + def.a.toString(16).toUpperCase().padStart(2, "0"));
            if (!el || document.activeElement === el) return;
            el.value = def.a === 0x4D ? mbrTable[def.a] & 3
                : def.a === 0x4F ? mbrTable[def.a] & 8
                : def.a === 0x1D ? (mbrTable[def.a] & 0x80 ? mbrTable[def.a] & 31 : -1)
                : def.a === 0x1C ? mbrTable[def.a] & 15 : mbrTable[def.a];
        });
        updateMbrRegStatus(); evaluateMbrRegRisk();
    }

    function updateMbrRegStatus() {
        if (!mbrTable) return;
        const key = mbrKey($("mbrChip").value);
        const ath = !!(mbrTable[0x4F] & 8);
        const hysOn = !!(mbrTable[0x1D] & 0x80);
        const hys = mbrTable[0x1D] & 31;
        const ft = mbrTable[0x0C];
        const filter = ["关闭", "中值", "IIR", "中值 + IIR"][mbrTable[0x4D] & 3];
        $("mbrRegStatus").textContent = `${mbrReadBases[key] ? (mbrDirty[key] ? "已读芯片 · 待写入" : "已读芯片") : "模板 · 请先读取芯片"} · 滤波 ${filter} · ${ath ? "自动阈值" : "手动阈值"} · 迟滞 ${hysOn ? hys : "自动"}` +
            (!ath && hysOn ? ` · CS0 ON≥${ft + hys} / OFF≤${ft - hys}` : "");
    }

    function evaluateMbrRegRisk() {
        const key = mbrKey($("mbrChip").value);
        const check = mbrValidateTable(mbrTable, mbrChipAddr(), mbrReadBases[key]);
        const reasons = [...check.reasons];
        if (!mbrReadBases[key]) reasons.unshift("请先读取芯片");
        if (configMode && !mbrCanProgram()) reasons.unshift("写入需 round88d 或更新固件");
        mbrRegRisk = { severe: reasons.length > 0, warn: false, reasons };
        $("btnMbrRegWrite").disabled = !configMode || mbrWriting || !MBR_CRC_OK || mbrRegRisk.severe;
        $("mbrRegAckRow").style.display = "none";
        const global = $("mbrRegGlobal");
        if (global) {
            global.disabled = !configMode || mbrWriting || !mbrAllRead();
            if (!mbrAllRead()) global.checked = false;
        }
        $("btnMbrRegRestore").disabled = !configMode || mbrWriting || !mbrReadBases[key];
        const old = $("mbrRegRiskBox"); if (old) old.remove();
        if (reasons.length) {
            const box = document.createElement("div"); box.id = "mbrRegRiskBox"; box.className = "mbr-reg-risk";
            box.textContent = reasons.join("；"); $("mbrRegBody").appendChild(box);
        }
        MBR_REG_DEFS.forEach(def => {
            const el = $("mbrReg_" + def.a.toString(16).toUpperCase().padStart(2, "0"));
            if (el) el.disabled = !configMode || mbrWriting || !mbrReadBases[key] || !mbrEditableMask(def.a, mbrReadBases[key]) ||
                (def.a >= 0x0C && def.a <= 0x1B && !!(mbrTable?.[0x4F] & 8));
        });
    }

    function mbrRegEdit(addrHex, value, maskOverride = null) {
        if (!mbrTable || mbrWriting) return;
        const addr = parseInt(addrHex, 16);
        const key = mbrKey($("mbrChip").value);
        if (!mbrReadBases[key]) return;
        if ($("mbrRegGlobal").checked && !mbrAllRead()) { log("请先读取全部芯片", "warn"); return; }
        const chips = $("mbrRegGlobal").checked ? [...$("mbrChip").options].map(o => o.value) : [key];
        chips.forEach(c => {
            const chipKey = mbrKey(c), base = mbrReadBases[chipKey], table = mbrTableCache[chipKey];
            if (!base || !table) return;
            const mask = mbrEditableMask(addr, base) & (maskOverride === null ? 255 : maskOverride);
            if (!mask) return;
            table[addr] = (table[addr] & ~mask) | (value & mask);
            mbrUpdateTableCrc(table);
            mbrDirty[chipKey] = !mbrTablesEqual(table, base);
        });
        mbrTable = new Uint8Array(mbrTableCache[key]);
        syncMbrFields(); syncMbrRegInputs(); updateSb3ForChip(); updateUI();
    }

    function openMbrRegWindow() {
        if (!configMode) { log("请先进入配置模式", "warn"); return; }
        if (!MBR_CRC_OK) { log("CRC 自检未通过,寄存器编辑已禁用", "error"); return; }
        // 采样传感器下拉: 按使能位列出
        const sel = $("mbrDbgSensor");
        sel.innerHTML = "";
        if (mbrTable) {
            const en = (mbrTable[0x00] | (mbrTable[0x01] << 8)) & 0xFFFF;
            for (let i = 0; i < 16; i++) {
                if (!(en & (1 << i))) continue;
                const o = document.createElement("option");
                o.value = String(i);
                o.textContent = `CS${i}`;
                sel.appendChild(o);
            }
        }
        const w = $("mbrRegModal");
        $("mbrRegTitle").textContent = `3116 设置 · ${$("mbrChip").value}`;
        syncMbrRegInputs();
        openModalAnimated(w);
    }

    // 0xC7 单传感器采样: 双写铁律 [0xC7] + [addr][sensor], 回 11B 或文本行
    async function mbrDebugRead() {
        if (!configMode) { log("请先进入配置模式", "warn"); return; }
        if (!mbrDebugFwSupport) { log("0xC7 调试读数需固件 >= 1.6.5", "warn"); return; }
        const addr = mbrChipAddr();
        const sensor = parseInt($("mbrDbgSensor").value) || 0;
        const out = $("mbrDbgOut");
        flushReadBuffer();
        await writeBytes(new Uint8Array([CMD.MBR3116_DEBUG]));
        await writeBytes(new Uint8Array([addr, sensor]));
        try {
            const data = await waitForBytes(11, 2000);
            if (data[0] !== CMD.MBR3116_DEBUG) throw new Error("响应首字节错位 0x" + data[0].toString(16));
            const diff = data[5] | (data[6] << 8);
            const base = data[7] | (data[8] << 8);
            const raw = data[9] | (data[10] << 8);
            out.textContent =
                `CS${sensor} @0x${addr.toString(16).toUpperCase()} sync=${data[3]} cp=${data[4]}pF\n` +
                `DIFF=${diff}${diff >= 255 ? "（可能饱和/裁剪）" : ""}  baseline=${base}  raw=${raw}\n未经距离标定，不换算毫米。`;
        } catch (e) {
            let extra = "";
            try { extra = await waitForLine(500); } catch (e2) { /* 无文本 */ }
            out.textContent = `采样失败: ${e.message}${extra ? " / " + extra : ""}`;
        }
    }
    $("btnMbrDbgRead").addEventListener("click", () => withSerialLock(() => mbrDebugRead()));

    $("btnMbrRegRestore").addEventListener("click", () => {
        if (mbrRestoreSafeParams($("mbrChip").value)) {
            syncMbrFields(); syncMbrRegInputs();
            mbrSetWriteStatus("已恢复模板触摸参数；待写入");
        }
    });

    $("btnMbrRegWrite").addEventListener("click", () => withSerialLock(async () => {
        const chips = $("mbrRegGlobal").checked
            ? [...$("mbrChip").options].map(o => o.value).filter(c => mbrDirty[mbrKey(c)])
            : [$("mbrChip").value];
        if (await mbrBurnQueue(chips)) mbrSetWriteStatus(chips.length ? `完成 · ${chips.length} 片已核对` : "无待写入修改");
    }));

    $("btnMbrRegWin").addEventListener("click", openMbrRegWindow);
    $("mbrRegClose").addEventListener("click", () => closeModalAnimated($("mbrRegModal")));
    $("mbrRegModal").addEventListener("click", (e) => {
        if (e.target === $("mbrRegModal")) closeModalAnimated($("mbrRegModal"));
    });
    MBR_REG_DEFS.forEach(def => {
        const id = "mbrReg_" + def.a.toString(16).toUpperCase().padStart(2, "0");
        document.addEventListener("change", e => {
            if (!e.target || e.target.id !== id || !e.target.closest("#mbrRegBody")) return;
            const v = Number(e.target.value);
            if (!Number.isInteger(v)) { syncMbrRegInputs(); return; }
            if (def.a === 0x1D) mbrRegEdit("1D", v < 0 ? 0 : 0x80 | v, v < 0 ? 0x80 : 0x9F);
            else mbrRegEdit(def.a.toString(16), Math.max(def.min, Math.min(def.max, v)));
        });
    });
    (function initMbrRegUI() {
        buildMbrRegUI();
        const row = document.createElement("label"); row.className = "checkbox-item mbr-reg-global";
        row.style.justifyContent = "flex-start";
        row.innerHTML = '<input type="checkbox" id="mbrRegGlobal" class="form-check-input" checked><span class="form-check-label">同步修改全部芯片（先读取全部）</span>';
        $("mbrRegModal").querySelector(".flash-modal-body").prepend(row);
    })();

    // round86 #12: 预设按钮已移除(阈值/消抖/灵敏度滑条并入参数调节与高级参数区)。
    // 保留 mbrApplyPreset 供潜在调用,标准预设=模板,其余映射到滑条值。
    function mbrApplyPreset(kind) {
        if (!mbrTable) { log("寄存器表为空", "warn"); return; }
        if (!MBR_CRC_OK) { log("CRC 自检未通过,预设已禁用", "error"); return; }
        if (kind === "std") {
            loadMbrTemplate();
            log("已应用标准预设(=固件内置模板)");
        }
    }

    async function mbrReadForEdit(addr) {
        if (!configMode || !mbrGateFwSupport || !MBR_CRC_OK) return false;
        const key = mbrKey(addr);
        try {
            const table = await mbrReadChipTable(key, 4000);
            const check = mbrValidateTable(table, parseInt(key, 16));
            if (!check.valid) throw new Error(check.reasons.join("；"));
            mbrCacheStore(key, table, true);
            if (key === mbrKey($("mbrChip").value)) mbrTable = new Uint8Array(table);
            syncMbrFields(); syncMbrRegInputs(); updateUI();
            mbrSetWriteStatus(`${key} · 已读取，地址与 CRC 正确`);
            return true;
        } catch (e) {
            mbrSetWriteStatus(`${key} · 读取失败`, true);
            log(`${key} 读取失败：${e.message}`, "error");
            return false;
        }
    }
    $("btnMbrReadChip").addEventListener("click", () => withSerialLock(async () => {
        const key = mbrKey($("mbrChip").value);
        if (mbrDirty[key] && !confirm("重新读取将丢弃当前未写入修改。继续？")) return;
        await mbrReadForEdit(key);
    }));
    $("btnMbrRegRead").addEventListener("click", () => $("btnMbrReadChip").click());
    $("btnMbrReadAll").addEventListener("click", () => withSerialLock(async () => {
        if (Object.values(mbrDirty).some(Boolean) && !confirm("重新读取将丢弃未写入修改。继续？")) return;
        for (const option of [...$("mbrChip").options]) if (!(await mbrReadForEdit(option.value))) return;
        mbrSetWriteStatus("全部芯片已读取");
    }));
    $("btnMbrBackup").addEventListener("click", () => {
        if (!mbrWriteBackups.length) return;
        downloadBlob(new Blob([JSON.stringify({ format: "NYANITHM-MBR3116-BACKUP-1", backups: mbrWriteBackups }, null, 2)], { type: "application/json" }), "3116_write_backups.json");
    });

    // round89a: 旧单悬空峰值向导仅作信号观察。缺少有效轻触样本和区域定位，
    // 无法验证两类信号是否可分，禁止生成阈值或自动回填芯片/既有 gate。
    let hoverCalRunning = false;
    let hoverCalResult = null;  // 保留旧调用点兼容；观察流程始终不产生回填值
    let hoverCalPrevMode = 2;   // round86 审查修复(P3): 采样前用户报送档位(finally 恢复)
    async function runHoverCalSequence() {
        if (hoverCalRunning) { log("悬空截止校准已在运行"); return; }
        hoverCalRunning = true;
        hoverCalResult = null;
        if ($("calWizardStart")) $("calWizardStart").disabled = true;
        try {
            const SECONDS = CAL_IS_MOCK ? 2 : 6;
            calShowScreen("calScreenRunning");
            $("calRunTitle").textContent = "悬空信号观察 · 采样中";
            $("calRunHint").textContent = "请在需要观察的位置悬停，不要触碰表面；本次不生成阈值";
            log("--- 悬空信号观察: 请保持悬停 " + SECONDS + "s ---");
            if (!inputPolling) await startInputPolling();
            // 强制原始会话采样(level 2; 旧固件自动回退 level 1, MBR 两档等价)
            hoverCalPrevMode = inputRawMode;
            inputRawMode = 2;
            await setRawReportMode(2);
            updateRawModeBtn();
            const perLaneMax = new Array(CFG_NUM_KEYS).fill(0);
            let frames = 0;
            calAbort = false;  // round86: running 屏「取消校准」对悬空采样同样生效
            const t0 = performance.now();
            while ((performance.now() - t0) / 1000 < SECONDS) {
                if (calAbort) {
                    // round86 审查修复(P3): 报送档位恢复统一在 finally
                    log("悬空阈值校准已取消", "warn");
                    calCloseWizard();
                    return;
                }
                await nextTick();
                if (!connected) throw new Error("连接中断");
                const remain = Math.max(0, Math.ceil(SECONDS - (performance.now() - t0) / 1000));
                calRenderRing(remain, (performance.now() - t0) / 1000 / SECONDS);
                if (latestInputData) {
                    for (let i = 0; i < CFG_NUM_KEYS; i++) {
                        const v = latestInputData[i];
                        if (v > perLaneMax[i]) perLaneMax[i] = v;
                    }
                    latestInputData = null;
                    frames++;
                }
            }
            // 恢复按钮态语义(会话 level 回退到用户所选)
            const peak = Math.max(...perLaneMax);
            const hotLanes = perLaneMax
                .map((v, i) => ({ v, i })).filter(x => x.v >= peak * 0.8)
                .sort((a, b) => b.v - a.v).slice(0, 6);
            log(`悬空采样完成: ${frames} 帧, 全板原始 diff 峰值 = ${peak}, 热区 tc${hotLanes.map(x => x.i + 1).join("/tc")} = [${hotLanes.map(x => x.v).join(",")}]`);
            $("calReportBody").innerHTML = [
                `悬空 DIFF 峰值: <b>${peak}</b> · ${frames} 帧`,
                peak >= 255 ? "<div class='cal-report-note'>信号已达 255，存在裁剪/饱和，不能据此确定触发距离。</div>" : "",
                "<div style='margin-top:10px' class='cal-report-note'>没有有效轻触样本、指定区域定位与分离裕量验证；本次仅供观察，不能生成可信阈值或毫米距离。自动应用已禁用，设备参数未修改。</div>",
            ].join("");
            $("calWizardApply").disabled = true;
            calShowScreen("calScreenResult");
            log("--- 悬空观察完成：仅记录信号，不推荐阈值、不自动应用 ---");
        } catch (e) {
            log("悬空阈值校准出错: " + e.message, "error");
            calCloseWizard();
        } finally {
            // round86 审查修复(P3): prevMode 恢复挪到 finally -- 中止/低峰值/
            // 异常路径统一恢复用户报送档位偏好, 正常路径落到结果屏也已恢复。
            inputRawMode = hoverCalPrevMode;
            updateRawModeBtn();
            hoverCalRunning = false;
            if ($("calWizardStart")) $("calWizardStart").disabled = false;
        }
    }
    // 兼容别名(旧注释/潜在调用点): 悬空校准向导执行体
    async function runHoverCutoffCalibration() {
        calSnapshotHover();
        await runHoverCalSequence();
    }
    function calSnapshotHover() { /* 信号观察不回填参数,无需快照 */ }

    // round86: 独立「悬空截止校准」按钮已移除 -- 校准入口统一到「一键校准阈值」
    // (btnCalibrate)按硬件探测路由(#7)。runHoverCutoffCalibration 保留为路由目标。

    $("mbrHexTable").addEventListener("change", () => {
        const txt = $("mbrHexTable").value;
        const bytes = (txt.match(/[0-9a-fA-F]{2}/g) || []).map(s => parseInt(s, 16));
        if (bytes.length !== 128) {
            log(`寄存器表格式错误: 需要 128 字节,解析到 ${bytes.length} 字节`, "error");
            renderMbrHex();
            return;
        }
        mbrTable = new Uint8Array(bytes);
        // round86 审查修复(P1): 寄存器表手改 = 对当前芯片的整表编辑,
        // 写缓存并标脏(仅当前芯片,整表不做逐芯片语义传播)。
        mbrUpdateTableCrc(mbrTable);
        mbrCacheStore($("mbrChip").value, mbrTable, false);
        mbrDirty[mbrKey($("mbrChip").value)] = true;
        syncMbrFields(); syncMbrRegInputs();
    });

    // 0xBA 应用(双重确认按钮,避免误写 NVM)
    function setupMbrApply() {
        const btn = $("btnMbrApply");
        const originalHTML = btn.innerHTML;
        let confirmTimer = null, isConfirming = false;
        function resetConfirm() {
            btn.innerHTML = originalHTML;
            btn.classList.remove('btn-confirming');
            isConfirming = false;
            if (confirmTimer) { clearTimeout(confirmTimer); confirmTimer = null; }
        }
        btn.addEventListener("click", () => withSerialLock(async () => {
            if (!configMode) { log("请先进入配置模式", "warn"); return; }
            if (!mbrTable) { log("寄存器表为空", "error"); return; }
            if (!MBR_CRC_OK) { log("CRC 自检未通过,表应用已禁用", "error"); return; }
            if (isConfirming) {
                resetConfirm();
                const addr = "0x" + mbrChipAddr().toString(16).toUpperCase();
                const size = (probeInfo && probeInfo.tofCount === 5) ? "32寸" : "27寸";
                log(`向芯片 ${addr} 烧录 128 字节寄存器表(${size} 设备)...`);
                const ok = await mbrBurnOne(addr);
                if (!ok) log(`芯片 ${addr} 未通过 NVM 完整校验`, "error");
            } else {
                isConfirming = true;
                btn.classList.add('btn-confirming');
                btn.textContent = "确认写入 NVRAM";
                confirmTimer = setTimeout(resetConfirm, 3000);
            }
        }));
    }
    setupMbrApply();

    $("btnMbrSaveFile").addEventListener("click", () => {
        if (!mbrTable) { log("寄存器表为空", "warn"); return; }
        const addr = $("mbrChip").value || "0x40";
        mbrUpdateTableCrc(mbrTable);
        downloadBlob(new Blob([mbrTable]), `3116_cfg_${addr}.bin`);
        log(`已导出 3116 寄存器表 3116_cfg_${addr}.bin`);
    });

    $("btnMbrLoadFile").addEventListener("click", () => $("mbrFileInput").click());
    $("mbrFileInput").addEventListener("change", async (e) => {
        const f = e.target.files[0];
        e.target.value = "";
        if (!f) return;
        if (!MBR_CRC_OK) { log("CRC 自检未通过,表编辑已禁用", "error"); return; }
        try {
            const bytes = new Uint8Array(await f.arrayBuffer());
            if (bytes.length !== 128) throw new Error("文件应为 128 字节,实际 " + bytes.length);
            const check = mbrValidateTable(bytes, mbrChipAddr(), mbrReadBases[mbrKey($("mbrChip").value)]);
            if (!check.valid) throw new Error(check.reasons.join("；"));
            mbrTable = bytes;
            mbrCacheStore($("mbrChip").value, mbrTable, false);
            mbrDirty[mbrKey($("mbrChip").value)] = true;
            syncMbrFields(); syncMbrRegInputs();
            log(`已导入 3116 寄存器表: ${f.name}(应用时会重算 CRC)`);
        } catch (err) { log("导入 3116 表失败: " + err.message, "error"); }
    });

    // ================================================================
    // 配置文件导出 / 导入
    // ================================================================
    function downloadBlob(blob, name) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = name;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 5000);
    }

    $("btnExportCfg").addEventListener("click", () => withSerialLock(async () => {
        try {
            let out;
            if (configMode && lastReadConfig && lastReadConfig.length === CFG_SIZE) {
                // 配置模式下:导出设备读取的真实配置
                out = lastReadConfig.slice();
            } else {
                // 普通模式:导出当前表单构建的配置(含 cfg2/cfg3 等所有字段),
                // 便于备份面板当前编辑状态。
                out = packConfig();
            }
            downloadBlob(new Blob([out]), "config.bin");
            log("已导出配置 config.bin (" + CFG_SIZE + " 字节)" + (configMode ? "(设备读取值)" : "(表单值)"));
        } catch (e) { log("导出配置失败: " + e.message, "error"); }
    }));

    $("btnImportCfg").addEventListener("click", () => $("cfgFileInput").click());
    $("cfgFileInput").addEventListener("change", async (e) => {
        const f = e.target.files[0];
        e.target.value = "";
        if (!f) return;
        try {
            const bytes = new Uint8Array(await f.arrayBuffer());
            if (bytes.length !== CFG_SIZE) throw new Error(`文件应为 ${CFG_SIZE} 字节,实际 ${bytes.length}`);
            if (bytes[0] !== CFG_MAGIC) throw new Error("Magic 不匹配: 0x" + bytes[0].toString(16));
            if (bytes[1] !== CFG_VERSION) throw new Error("cfgVer 不匹配: 0x" + bytes[1].toString(16) + "(面板支持 0x02)");
            const xor = calcXorSum(bytes);
            if (xor !== bytes[127]) throw new Error(`xorSum 校验失败: 文件 0x${bytes[127].toString(16).padStart(2, "0")},计算 0x${xor.toString(16).padStart(2, "0")}`);
            unpackConfig(bytes);
            crossCheckProbe();
            log(`已导入配置 ${f.name} 并填入表单;进配置模式后点"保存并重启"写回设备`);
        } catch (err) { log("导入 config.bin 失败: " + err.message, "error"); }
    });

    // ================================================================
    // 灯光测试
    // ================================================================
    // round71: 读取当前主题高亮色(暗色=工业黄 #FFD60A / 亮色=蓝 #0D44D4)。
    // CSS 变量只存在于样式层,这里是全文件首个 getComputedStyle 调用点。
    function getAccentHex() {
        const v = getComputedStyle(document.documentElement).getPropertyValue("--c-accent").trim();
        return /^#[0-9a-fA-F]{6}$/.test(v) ? v : "#ffd60a";
    }
    // round71: Light Test 默认准备色与主题 accent 联动(覆盖 HTML 写死的初始值)。
    // 仅更新取色器+本地预览;是否发送由调用方决定(未连接/配置模式/动画中不发)。
    // round76: 用户手动选过颜色(预设/取色器/自定义)后联动让位——否则亮色主题
    // 加载/切换会把用户所选色静默顶回 accent 蓝 #0D44D4。
    let ledColorTouched = false;
    let ledAnimWarned = false;  // round76 审查: 动画中取色警告按会话去重,避免拖拽取色器刷屏
    function syncLedDefaultColor(send) {
        if (ledColorTouched) return;
        const input = $("ledColor");
        if (!input) return;
        const hex = getAccentHex();
        if (input.value.toLowerCase() !== hex.toLowerCase()) {
            input.value = hex;
            setLedPreview(solidColors(...hexToRgb(hex)));
        }
        if (send && connected && !configMode && !inputPolling && !ledAnimId) {
            sendLedColors(solidColors(...hexToRgb(hex)));
        }
    }

    function initLedStrip() {
        const strip = $("ledStrip");
        for (let i = 0; i < 31; i++) {
            const d = document.createElement("div");
            d.className = "led-pixel";
            d.id = "l" + i;
            strip.appendChild(d);
        }
    }

    function setLedPreview(colors) {
        for (let i = 0; i < 31; i++) {
            const [r, g, b] = colors[i] || [0, 0, 0];
            const el = $("l" + i);
            el.style.background = (r || g || b) ? `rgb(${r},${g},${b})` : "var(--c-surface-3)";
            el.style.boxShadow = (r || g || b) ? `0 0 8px rgba(${r},${g},${b},0.6)` : "none";
        }
    }

    function buildLedPacket(colors) {
        const limit = parseInt($("ledLimit").value) || 255;
        const pkt = new Uint8Array(97);
        pkt[0] = CMD.SET_LED;
        for (let i = 0; i < 31; i++) {
            let [r, g, b] = colors[i] || [0, 0, 0];
            r = Math.round(r * limit / 255);
            g = Math.round(g * limit / 255);
            b = Math.round(b * limit / 255);
            pkt[1 + i * 3 + 0] = b;  // 每灯字节序 b,r,g
            pkt[1 + i * 3 + 1] = r;
            pkt[1 + i * 3 + 2] = g;
        }
        return pkt;
    }

    async function sendLedColors(colors) {
        if (!connected || configMode) return;
        try {
            // round63: 灯光写同样串行化。0xB2 虽为单向写入(无应答),但若与输入轮询
            // 的 GET_INPUT 请求在导线层交错,会把面板的字节读取器弄乱(33 字节边界
            // 无法辨识)。走 withSerialLock 让灯光写排到当前事务之后,避免与读交换序。
            await withSerialLock(async () => {
                if (!connected || configMode) return;
                await writeBytes(buildLedPacket(colors));
            });
            setLedPreview(colors);
        } catch (e) { log("发送灯光失败: " + e.message, "error"); }
    }

    function hexToRgb(hex) {
        const n = parseInt(hex.slice(1), 16);
        return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    }

    function solidColors(r, g, b) { return Array(31).fill([r, g, b]); }

    function stopLedAnim() {
        if (ledAnimId) { cancelAnimationFrame(ledAnimId); ledAnimId = null; }
        ledAnimWarned = false;
    }

    function ledFpsTick(state, now) {
        state.count++;
        if (now - state.last >= 1000) {
            $("ledFps").textContent = "FPS: " + state.count;
            state.count = 0;
            state.last = now;
        }
    }

    $("ledOff").addEventListener("click", () => { ledColorTouched = true; stopLedAnim(); sendLedColors(solidColors(0, 0, 0)); });
    $("ledWhite").addEventListener("click", () => { ledColorTouched = true; stopLedAnim(); sendLedColors(solidColors(255, 255, 255)); });
    $("ledRed").addEventListener("click", () => { ledColorTouched = true; stopLedAnim(); sendLedColors(solidColors(255, 0, 0)); });
    $("ledGreen").addEventListener("click", () => { ledColorTouched = true; stopLedAnim(); sendLedColors(solidColors(0, 255, 0)); });
    $("ledBlue").addEventListener("click", () => { ledColorTouched = true; stopLedAnim(); sendLedColors(solidColors(0, 0, 255)); });
    $("ledCustom").addEventListener("click", () => { ledColorTouched = true; stopLedAnim(); sendLedColors(solidColors(...hexToRgb($("ledColor").value))); });
    $("ledColor").addEventListener("input", () => {
        ledColorTouched = true;
        if (ledAnimId) {
            if (!ledAnimWarned) { log("灯光动画运行中,请先点「停止动画」再选色", "warn"); ledAnimWarned = true; }
            return;
        }
        sendLedColors(solidColors(...hexToRgb($("ledColor").value)));
    });
    $("ledLimit").addEventListener("input", () => { if (!ledAnimId) sendLedColors(solidColors(...hexToRgb($("ledColor").value))); });

    $("ledChase").addEventListener("click", () => {
        if (!connected || configMode) return;
        stopLedAnim();
        const rgb = hexToRgb($("ledColor").value);
        let pos = 0;
        const speed = parseInt($("ledSpeed").value) || 50;
        let last = performance.now();
        const fpsState = { count: 0, last: performance.now() };
        const step = () => {
            if (!ledAnimId) return;
            const now = performance.now();
            if (now - last < speed) { ledAnimId = requestAnimationFrame(step); return; }
            last = now;
            const colors = Array(31).fill([0, 0, 0]);
            for (let i = 0; i < 31; i++) {
                const d = Math.abs(i - pos);
                if (d < 4) colors[i] = [rgb[0] >> d, rgb[1] >> d, rgb[2] >> d];
            }
            sendLedColors(colors);
            pos = (pos + 1) % 31;
            ledFpsTick(fpsState, now);
            ledAnimId = requestAnimationFrame(step);
        };
        ledAnimId = requestAnimationFrame(step);
    });

    $("ledRainbow").addEventListener("click", () => {
        if (!connected || configMode) return;
        stopLedAnim();
        let offset = 0;
        const speed = parseInt($("ledSpeed").value) || 50;
        let last = performance.now();
        const fpsState = { count: 0, last: performance.now() };
        const step = () => {
            if (!ledAnimId) return;
            const now = performance.now();
            if (now - last < speed) { ledAnimId = requestAnimationFrame(step); return; }
            last = now;
            const colors = [];
            for (let i = 0; i < 31; i++) {
                const h = (offset + i * 8) % 360;
                colors.push(hslToRgb(h / 360, 1, 0.5));
            }
            sendLedColors(colors);
            offset = (offset + 4) % 360;
            ledFpsTick(fpsState, now);
            ledAnimId = requestAnimationFrame(step);
        };
        ledAnimId = requestAnimationFrame(step);
    });

    $("ledStop").addEventListener("click", () => {
        stopLedAnim();
        sendLedColors(solidColors(0, 0, 0));
    });

    function hslToRgb(h, s, l) {
        let r, g, b;
        if (s === 0) { r = g = b = l; } else {
            const hue2rgb = (p, q, t) => {
                if (t < 0) t += 1;
                if (t > 1) t -= 1;
                if (t < 1 / 6) return p + (q - p) * 6 * t;
                if (t < 1 / 2) return q;
                if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
                return p;
            };
            const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
            const p = 2 * l - q;
            r = hue2rgb(p, q, h + 1 / 3);
            g = hue2rgb(p, q, h);
            b = hue2rgb(p, q, h - 1 / 3);
        }
        return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
    }

    // ================================================================
    // UF2 刷写(round54 全自动流程)
    // ================================================================
    function renderUf2Info(p, v) {
        const el = $("uf2Info");
        if (!p) { el.textContent = "未选择固件文件"; return; }
        const lines = [
            `文件: ${uf2FileName} (${p.blocks} 块 / ${(uf2Buf.byteLength / 1024).toFixed(1)} KB)`,
            `family: 0x${(p.family ?? 0).toString(16)}${p.family === RP2040_FAMILY_ID ? " (RP2040 ✓)" : ""}`,
            `烧写范围: 0x${p.flashStart.toString(16)} - 0x${p.flashEnd.toString(16)}${p.contiguous ? "" : "(非连续!)"}`,
            `固件版本: ${v.version ?? (p.versionCandidates.length ? "候选 " + p.versionCandidates.join("/") : "未知")}`,
            `构建变体: ${v.variant ?? "未知(旧固件)"}`,
        ];
        if (v.errors.length) lines.push(...v.errors.map(e => "✗ " + e));
        if (v.warnings.length) lines.push(...v.warnings.map(w => "⚠ " + w));
        if (!v.errors.length && !v.warnings.length) lines.push("✓ 校验通过,可以刷写(需先进入配置模式)");
        el.textContent = lines.join("\n");
    }

    function updateFlashUi() {
        const picked = !!uf2Parsed;
        const blocking = picked && uf2Errors.length === 0;
        const needOverride = picked && uf2Warnings.length > 0;
        $("flashOverride").disabled = !needOverride || !configMode;
        const overridden = $("flashOverride").checked;
        const flowActive = !["idle", "done", "error", "bootsel-manual", "manual-reconnect"].includes(flashPhase);
        // 弹窗内始终可点,由点击处理器校验错误/覆盖/配置模式
        $("btnStartFlash").disabled = flowActive;
        $("btnWriteUf2").disabled = flowActive || !(bootselReady && uf2Buf && window.showDirectoryPicker);
        if (!needOverride) $("flashOverride").checked = false;
        if ($("flashFileName")) $("flashFileName").textContent = uf2FileName ? uf2FileName : "未选择";
    }

    const FLASH_PHASE_TEXT = {
        "idle": "待选择固件文件",
        "bootsel": "正在进入 BOOTSEL…",
        "bootsel-manual": "已进入 BOOTSEL,请用「手动选择盘符写入」或手动复制文件",
        "picking": "请在弹窗中选择 RPI-RP2 盘符…",
        "writing": "正在写入固件…",
        "waitingReconnect": "等待设备重启并重新上线…",
        "verifying": "已重连,正在验证固件版本…",
        "manual-reconnect": "未自动重连,请点击「重新连接并验证」",
        "done": "完成",
        "error": "出错,见运行日志"
    };

    function setFlashPhase(phase, textOverride) {
        flashPhase = phase;
        const el = $("flashStatus");
        el.textContent = textOverride || FLASH_PHASE_TEXT[phase] || phase;
        el.className = phase === "error" ? "err" : (phase === "done" ? "ok" : "");
        updateFlashUi();
    }

    function hideFlashModal() { closeModalAnimated($("flashConfirmModal")); }

    function sanitizeUF2Name(name) {
        if (!name) return "Nyanithm.uf2";
        let n = name.replace(/[\\/:*?"<>|]/g, "_");
        if (n.length > 100) n = n.slice(0, 96) + ".uf2";
        if (!n.toLowerCase().endsWith(".uf2")) n += ".uf2";
        return n;
    }

    async function readBootselText(dir, name) {
        try {
            const fh = await dir.getFileHandle(name);
            return await (await fh.getFile()).text();
        } catch (e) { log(`读取 ${name} 失败 (${e.name})`); return null; }
    }

    async function listBootselEntries(dir) {
        const names = [];
        try { for await (const n of dir.keys()) names.push(n); } catch (e) {}
        return names;
    }

    // round88b: 盘符识别宽容化。真机反馈「找盘符与校验盘符环节失败」——
    // RPI-RP2 的 FAT 卷不带长文件名项, Windows 经 FSA 列目录偶发只返回
    // 8.3 短名( INFO_UF2.TXT → INFO_UF2.1XT 等截断变体)或 keys() 抛错/为空,
    // 旧严格校验(infoName 正则 + index.htm 同时存在)随即落入"强制写入"确认,
    // 体验为"校验盘符失败"。现改为: 列目录为空/异常时直接尝试读三个已知
    // 标识文件名; 名单命中即认盘; 全部失败才走用户强制确认。
    const BOOTSEL_INFO_NAMES = ["INFO_UF2.TXT", "UF2INFO.TXT", "INFO.TXT", "INDEX.HTM"];
    async function probeBootselSignature(dir) {
        for (const n of BOOTSEL_INFO_NAMES) {
            try {
                const fh = await dir.getFileHandle(n);
                const t = await (await fh.getFile()).text();
                if (/RP2040|RPI-RP2|UF2\s*Bootloader|Raspberry Pi RP2/i.test(t)) return { ok: true, via: n };
            } catch (e) { /* 该名不存在/暂不可读, 试下一个 */ }
        }
        return { ok: false, via: null };
    }

    // 校验所选目录确为 RP2040 BOOTSEL 盘并写入 UF2;全自动与手动备用路径共用。
    // round88b: 校验宽容化(probeBootselSignature)——FSA 在 RPI-RP2 上列目录
    // 偶发为空/短名截断, 不再依赖 entries 正则命中。
    async function validateAndWriteToBootsel(dir) {
        const volName = (dir.name || "").trim();
        log(`已选择目录「${volName || "?"}」,正在识别 RP2040 BOOTSEL 盘…`);
        const entries = await listBootselEntries(dir);
        if (entries.length) log(`目录内容: ${entries.join(", ")}`);
        else log("目录列举为空(FAT 短名/权限限制常见, 不影响识别), 直接探测标识文件…");
        const infoName = entries.find(n => /^(info_uf2|info|uf2info)\.txt$/i.test(n)) || null;
        const hasIndex = entries.some(n => /^index\.htm(l)?$/i.test(n));
        let bootSig = false;
        if (infoName && hasIndex) bootSig = true;
        else if (infoName) {
            const t = await readBootselText(dir, infoName);
            bootSig = t !== null && /RP2040|RPI-RP2|UF2\s*Bootloader|Raspberry Pi RP2/i.test(t);
        }
        if (!bootSig) {
            const probe = await probeBootselSignature(dir);
            if (probe.ok) {
                bootSig = true;
                log(`已确认 RP2040 BOOTSEL 盘(经 ${probe.via} 标识校验),开始写入…`);
            }
        }
        if (bootSig) log("已确认 RP2040 BOOTSEL 盘(标识文件校验通过),开始写入…");
        if (!bootSig) {
            const go = confirm(`未能确认「${volName || "?"}」是 RP2040 BOOTSEL 盘\n(未读到 INFO_UF2.TXT / UF2INFO.TXT / INFO.TXT 的 RP2040 标识)。\n\n若这确实是 RPI-RP2 盘,点"确定"强制写入;\n选错目录可能覆盖其他磁盘的数据!点"取消"中止。`);
            if (!go) {
                log("已中止写入(用户取消强制写入确认)", "warn");
                setFlashPhase("bootsel-manual");
                return false;
            }
            log("未检测到 RP2040 标识文件,经用户确认强制写入", "warn");
        }
        setFlashPhase("writing");
        const writeName = sanitizeUF2Name(uf2FileName);
        try {
            log(`写入 ${writeName}(${uf2Buf.byteLength} 字节)…`);
            const fh = await dir.getFileHandle(writeName, { create: true });
            const w = await fh.createWritable();
            await w.write(uf2Buf);
            await w.close();
            log("固件已写入 RPI-RP2,设备接收完镜像后会自动重启…");
        } catch (e) {
            if (e.name === "NotFoundError" || (e.name === "NotAllowedError" && bootselReady)) {
                log("写入期间 RPI-RP2 盘符消失——通常表示固件已接收完成并自动重启", "warn");
            } else if (e.name === "AbortError") {
                log("写入已取消", "warn");
                setFlashPhase("bootsel-manual");
                return false;
            } else {
                log(`写入失败 (${e.name}): ${e.message}`, "error");
                setFlashPhase("error", `写入失败 (${e.name})`);
                return false;
            }
        }
        bootselReady = false;
        updateFlashUi();
        await sleep(1000);
        startReconnectWatch();
        return true;
    }

    // ================================================================
    // round78f: RPI-RP2 盘符句柄存档与全自动写盘
    // showDirectoryPicker 要求"用户激活"(点击后 ~5s 内),而 round78e 的重启
    // 验证窗普遍超过激活寿命——首刷之后的弹框必抛 NotAllowedError。根治:
    // 首次取得的目录句柄存入 IndexedDB;此后每次刷写在「开始刷写」点击激活
    // 期内完成 queryPermission/requestPermission(小确认框,非文件框),
    // BOOTSEL 出现后轮询卷就绪直接写入,零弹窗。浏览器无法凭空创建句柄,
    // 首次使用(或句柄失效)仍需一次选择。
    // ================================================================
    const RP2_DIR_KEY = "rp2BootselDir";
    let rp2DirHandle = null;  // 会话内缓存(免 IndexedDB 往返)

    function idbHandles() {
        return new Promise((resolve) => {
            try {
                const req = indexedDB.open("nyanithm-panel", 1);
                req.onupgradeneeded = () => req.result.createObjectStore("fsHandles");
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => resolve(null);
            } catch (e) { resolve(null); }  // file:// 等异常环境:降级为会话内缓存
        });
    }
    async function idbGet(key) {
        const db = await idbHandles();
        if (!db) return undefined;
        return new Promise((resolve) => {
            try {
                const rq = db.transaction("fsHandles").objectStore("fsHandles").get(key);
                rq.onsuccess = () => resolve(rq.result);
                rq.onerror = () => resolve(undefined);
            } catch (e) { resolve(undefined); }
        });
    }
    async function idbSet(key, val) {
        const db = await idbHandles();
        if (!db) return;
        try { db.transaction("fsHandles", "readwrite").objectStore("fsHandles").put(val, key); } catch (e) {}
    }
    async function idbDel(key) {
        const db = await idbHandles();
        if (!db) return;
        try { db.transaction("fsHandles", "readwrite").objectStore("fsHandles").delete(key); } catch (e) {}
    }

    async function loadStoredRp2Dir() {
        if (rp2DirHandle) return rp2DirHandle;
        const stored = await idbGet(RP2_DIR_KEY);
        if (stored) rp2DirHandle = stored;
        return rp2DirHandle;
    }
    async function storeRp2Dir(h) {
        rp2DirHandle = h;
        await idbSet(RP2_DIR_KEY, h);
        log("已记住此盘符——下次刷写将全程无弹窗自动写入");
    }
    async function clearRp2Dir() {
        rp2DirHandle = null;
        await idbDel(RP2_DIR_KEY);
    }

    // 「开始刷写」点击激活期内调用:取回已存句柄并落实读写权限(必要时弹一个
    // 小的"允许编辑"确认)。失败则清档,交由本次的选择框/手动路径兜底。
    async function prepareRp2DirAtClick() {
        if (MOCK) return null;
        const h = await loadStoredRp2Dir();
        if (!h) return null;
        try {
            let perm = await h.queryPermission({ mode: "readwrite" });
            if (perm !== "granted") {
                log("正在请求已保存盘符的写入权限…");
                perm = await h.requestPermission({ mode: "readwrite" });
            }
            if (perm === "granted") return h;
            log("已保存盘符的写入权限被拒绝,本次将弹盘符选择框", "warn");
        } catch (e) {
            log(`已保存盘符不可用 (${e.name}),本次将弹盘符选择框`, "warn");
        }
        await clearRp2Dir();
        return null;
    }

    // 轮询 BOOTSEL 卷就绪:句柄能读到 INFO_UF2.TXT 且带 RP2040 标识才返回。
    // 不直接调 validateAndWriteToBootsel——卷未挂载时它会把 entries=[] 误判为
    // "非 BOOTSEL 盘"而弹强制写入确认框。
    async function waitRp2VolumeReady(h, ms) {
        const end = performance.now() + ms;
        while (performance.now() < end) {
            // round88b: 复用宽容化探测(标识文件直读), 不依赖目录列举
            const probe = await probeBootselSignature(h);
            if (probe.ok) return h;
            await sleep(300);
        }
        return null;
    }

    async function runFlashSequence(readyDir, earlyPicker) {
        setFlashPhase("bootsel");
        try {
            await withSerialLock(async () => {
                flushReadBuffer();
                // 0xBB 必须紧跟确认字节 0xA5(round51 防命令流错位变砖的保护)。
                // round78e: 两字节合并为一次 write——一个 chunk 一次 WriteFile
                // 一次 USB OUT 包,物理上不存在包间隙(Electron 台架实测:同毫秒
                // 连发的三笔单字节写会在宿主栈内卡死 >11s 不达设备,而所有间隔
                // 发出的单笔写都瞬时到达;WICG/serial #166 维护者亦确认合并单写
                // 是"立即发完"的正解)。固件侧 round78c 起为状态化确认:0xBB 武装
                // 30s 窗,0xA5 任意时刻落地即触发,合并写/分离写均兼容。
                // round76b 的"必须分两笔写"结论仅适用于旧的阻塞式确认窗。
                await writeBytes(new Uint8Array([CMD.FLASHING, 0xA5]));
            });
            log("已发送刷写命令 (0xBB+0xA5 合并单笔),设备正在重启进入 BOOTSEL 模式...");
        } catch (e) {
            log("发送刷写命令失败: " + e.message, "error");
            setFlashPhase("error", "发送刷写命令失败");
            return;
        }
        configMode = false;
        updateUI();
        // round78: 盲发改为验证——等设备真的重启(串口自行消失;readLoop 的意外
        // 断开处理会把 connected/port 清空)后才弹盘符框。
        // round78e: 窗口 11s→35s 并周期重发。台架实测宿主栈可能把刷写字节扣留
        // >11s(closePort 才送达,甚至被 PURGE 丢弃),11s 窗必然误报;固件武装窗
        // 为 30s,面板窗覆盖之。每 1.5s 重发一次合并对——每笔重发都是独立的单笔
        // 写(台架实测该形态总能瞬时到达),任意一笔落地即触发 boot;0xBB 亦会
        // 重置配置模式 60s 自动退出计时,长窗内设备不会自行掉线。等待期间绝不
        // closePort(Chromium 关闭走 PurgeComm(PURGE_TXCLEAR) 是丢弃而非冲刷,
        // 依赖"关闭冲出滞留字节"不可靠)。
        const sendT0 = performance.now();
        let wentAway = false, denied = false;
        while (performance.now() - sendT0 < 35000) {
            const waitEnd = performance.now() + 1500;
            while (performance.now() < waitEnd) {
                await sleep(80);
                // round78e(审查 P3): deny 文本先于断开判定——断开清理会清
                // readBuffer,反序会让同轮的 deny 丢失
                if (!denied && readBuffer.length && new TextDecoder().decode(readBuffer).includes("flashing denied")) {
                    denied = true; break;
                }
                if (!connected || !port) { wentAway = true; break; }
            }
            if (wentAway || denied) break;
            // 重发(尽力而为:设备已离开时 write 会抛错,属 boot 进行中的正常现象)
            try {
                await withSerialLock(async () => {
                    await writeBytes(new Uint8Array([CMD.FLASHING, 0xA5]));
                });
            } catch (e) { /* port gone -> next inner loop 观察 wentAway */ }
        }
        if (!wentAway) {
            await closePort();
            // round78e: 35s 窗到期仍无重启——不再指望"迟到进 BOOTSEL"(Chromium
            // close 语义是丢弃),直接引导重试/手动。bootselReady 保留,手动选择
            // 盘符路径仍可用(若字节最终极晚送达而进入 BOOTSEL)。
            bootselReady = true;
            updateFlashUi();
            log(denied
                ? "设备拒绝了刷写(0xA5 确认未按时到达,固件回 flashing denied)。请重试;若反复出现请反馈日志"
                : "设备未在窗口期内重启。请重试一次;若仍失败,请按住板载 BOOTSEL 键插拔 USB 手动进入后用「手动选择盘符写入」",
                "error");
            setFlashPhase("error", denied ? "✗ 刷写被固件拒绝" : "✗ 设备未进入 BOOTSEL");
            return;
        }
        bootselReady = true;
        await closePort();  // 幂等清理(端口已被断开处理清空)并停掉通用重连轮询
        if (!window.showDirectoryPicker) {
            log("当前浏览器不支持直接写入(需要 Chrome/Edge 的 File System Access API)。请手动打开 RPI-RP2 盘符复制固件文件", "warn");
            setFlashPhase("bootsel-manual", "已进入 BOOTSEL——请手动复制固件文件到 RPI-RP2");
            return;
        }
        // 等 Windows 完成挂载 RPI-RP2(断开已确认,再给枚举+卷挂载留时间)
        await sleep(1500);
        // round88c: 移除旧 softReboot 检查。
        // 旧代码使用 navigator.serial.getPorts() 检查所谓的"重新枚举软重启",
        // 但在 Windows Chromium 下 getPorts() 会一直返回历史已授权的端口对象,
        // 导致即使设备已彻底进入 BOOTSEL 且 RPI-RP2 盘符已就绪, 仍被误判为
        // "设备重启了,但未进入 BOOTSEL", 粗暴掐断后续全部写盘分支。
        // 现在设备既然断开, 就直接信任进入写盘分支(已保存句柄/早弹选择器/手动选择)。
        bootselReady = true;
        updateFlashUi();
        // round78f: 三分支写盘——①已存句柄(点击时权限已落实):轮询卷就绪直接
        // 写,零弹窗;②首刷早弹的选择框(点击瞬间弹出,用户在框内等 RPI-RP2 出现
        // 后点选):取回句柄写入并存档;③Mock/无 FSA:维持手动提示。
        if (readyDir) {
            log("正在等待 RPI-RP2 卷挂载(使用已保存的盘符访问,全程无弹窗)…");
            const dir = await waitRp2VolumeReady(readyDir, 12000);
            if (dir) {
                await validateAndWriteToBootsel(dir);
                return;
            }
            await clearRp2Dir();
            log("保存的盘符在本次 BOOTSEL 中未能就绪(句柄可能已失效)。请点击「手动选择盘符写入」,下次刷写将重新自动", "warn");
            updateFlashUi();
            setFlashPhase("bootsel-manual");
            return;
        }
        if (earlyPicker) {
            setFlashPhase("picking");
            const dir = await earlyPicker;
            if (dir) {
                // 句柄已在选择框 resolve 时入档(btnStartFlash 处)
                await validateAndWriteToBootsel(dir);
                return;
            }
            log("已取消盘符选择。设备仍在 BOOTSEL 中,可点击「手动选择盘符写入」重试", "warn");
            updateFlashUi();
            setFlashPhase("bootsel-manual");
            return;
        }
        if (MOCK) {
            // round78f: Mock 无真实盘符——模拟"写入→设备消失→重连验证"闭环,
            // 使 ?mock=1 能走通与真机相同的刷写终态。Mock 壳会自行自动重连
            // ("自动连接模拟设备"),故不走 startReconnectWatch(其 connected
            // 自停分支会在 verifyFlashResult 之前退出,终态卡在等待重连)。
            log("Mock: 模拟 UF2 写入 RPI-RP2,设备接收完镜像后自动重启…");
            setFlashPhase("writing");
            await sleep(600);
            bootselReady = false;
            updateFlashUi();
            setFlashPhase("verifying");
            await autoHandshake();
            await startInputPolling();
            verifyFlashResult();
            return;
        }
        log("当前浏览器不支持直接写入(需要 Chrome/Edge 的 File System Access API)。请手动打开 RPI-RP2 盘符复制固件文件", "warn");
        setFlashPhase("bootsel-manual", "已进入 BOOTSEL——请手动复制固件文件到 RPI-RP2");
    }

    function stopReconnectWatch() {
        if (reconnectWatch) { clearInterval(reconnectWatch); reconnectWatch = null; }
    }

    async function attemptReconnect(p, quiet) {
        if (connected) return true;
        const ok = await openPort(p || null, quiet);
        if (!ok) return false;
        setFlashPhase("verifying");
        await autoHandshake();
        // round70: 统一启动入口(自动开压力会话,INPUT TEST 显示真实压力)
        await startInputPolling();
        verifyFlashResult();
        return true;
    }

    function startReconnectWatch() {
        stopReconnectWatch();
        stopUnplugReconnect();  // round75: 刷写重连接管, 停掉意外断开重连轮询
        setFlashPhase("waitingReconnect");
        reconnectDeadline = Date.now() + 20000;
        reconnectWatch = setInterval(async () => {
            if (Date.now() > reconnectDeadline) {
                stopReconnectWatch();
                $("btnReconnectAfterFlash").classList.remove("hidden");
                setFlashPhase("manual-reconnect", "20 秒内未检测到设备重新上线(固件可能已刷写成功)");
                log("未检测到设备自动重连——固件可能已刷写成功。请确认设备重启完成后点击「重新连接并验证」", "warn");
                return;
            }
            if (connected) { stopReconnectWatch(); return; }
            try {
                const ports = (await navigator.serial.getPorts()).filter(x => {
                    const i = x.getInfo();
                    return i.usbVendorId === 0xCAFE && i.usbProductId === 0x4009;
                });
                for (const p of ports) {
                    if (await attemptReconnect(p, true)) { stopReconnectWatch(); break; }
                }
            } catch (e) { /* 轮询失败静默重试 */ }
        }, 1000);
    }

    function expectedUf2Identity() {
        if (!uf2Parsed) return { version: null, variant: null, buildId: null, hasSig: false };
        if (uf2Parsed.sig) return { version: uf2Parsed.sig.version, variant: uf2Parsed.sig.variant, buildId: uf2Parsed.sig.buildId || null, hasSig: true };
        return { version: uf2Parsed.versionHeuristic || null, variant: null, buildId: null, hasSig: false };
    }

    function verifyFlashResult() {
        $("btnReconnectAfterFlash").classList.add("hidden");
        const exp = expectedUf2Identity();
        if (!devInfo || !devInfo.fw) {
            setFlashPhase("done", "已重连,但未能读取设备固件信息——请用「读取设备信息」手动确认");
            log("刷写后无法解析设备信息,跳过自动版本比对", "warn");
            return;
        }
        const got = devInfo.fw, gotVar = devInfo.var;
        if (!exp.version) {
            setFlashPhase("done", `已重连:设备运行 ${got}${gotVar ? " (" + gotVar + ")" : ""}(固件文件无版本信息,跳过比对)`);
        } else if (got !== exp.version) {
            setFlashPhase("error", `⚠ 设备当前固件 ${got} 与固件文件 ${exp.version} 不一致`);
            log(`⚠ 版本不一致:设备当前 ${got},固件文件 ${exp.version}——可能刷入了错误的文件`, "warn");
        } else if (exp.hasSig && exp.variant && gotVar !== exp.variant) {
            setFlashPhase("error", `⚠ 版本一致但变体不符:设备 ${gotVar ?? "未知"},文件 ${exp.variant}`);
        } else if (exp.buildId && devInfo.buildId !== exp.buildId) {
            setFlashPhase("error", `⚠ 固件版本相同但构建不符:设备 ${devInfo.buildId ?? "无标识"},文件 ${exp.buildId}`);
            log(`精确构建校验失败:设备 BID=${devInfo.buildId ?? "无"},文件 BID=${exp.buildId}`, "error");
        } else if (exp.hasSig && exp.buildId) {
            setFlashPhase("done", `✅ 刷写成功并精确验证:固件 ${got}${gotVar ? " (" + gotVar + ")" : ""} / ${exp.buildId}`);
            log(`✅ 刷写成功并精确验证:设备运行 ${got}/${gotVar}/${exp.buildId},与固件文件一致`);
        } else if (exp.hasSig) {
            setFlashPhase("done", `⚠ 已重连:固件 ${got}${gotVar ? " (" + gotVar + ")" : ""}(旧固件无构建 ID,仅验证语义版本)`);
            log("设备/固件文件缺少精确构建 ID；只确认了版本与变体，不能证明是同一构建", "warn");
        } else {
            setFlashPhase("done", `✅ 刷写成功:固件 ${got}(旧固件无签名,无法校验变体)`);
        }
    }

    // round56: 更新固件改为独立弹窗 UI。点击直接打开弹窗,文件选择/校验/刷写
    // 全部在弹窗内完成,不再依赖内嵌折叠功能区。
    $("flashBtn").addEventListener("click", () => {
        openFlashModal();
    });

    function openFlashModal() {
        openModalAnimated($("flashConfirmModal"));
        if (!uf2Parsed) {
            setFlashPhase("idle");
            // 自动唤起文件选择(用户手势内,满足 FSA 激活要求)
            $("uf2FileInput").click();
        }
    }

    $("btnPickUf2").addEventListener("click", () => { $("uf2FileInput").click(); });
    $("flashFileName").textContent = uf2FileName ? uf2FileName : "未选择";

    $("uf2FileInput").addEventListener("change", async (e) => {
        const f = e.target.files[0];
        e.target.value = "";
        if (!f) return;
        try {
            uf2Buf = await f.arrayBuffer();
            uf2FileName = f.name;
            uf2Parsed = parseUf2(uf2Buf);
            const v = validateUf2ForDevice(uf2Parsed, devInfo);
            uf2Errors = v.errors;
            uf2Warnings = v.warnings;
            bootselReady = false;
            if (!["bootsel", "picking", "writing", "waitingReconnect", "verifying"].includes(flashPhase)) setFlashPhase("idle");
            renderUf2Info(uf2Parsed, v);
            updateFlashUi();
            log(`固件文件已解析: ${f.name},版本 ${v.version ?? "?"},变体 ${v.variant ?? "未知"}` +
                (v.errors.length ? `,${v.errors.length} 项错误` : "") + (v.warnings.length ? `,${v.warnings.length} 项警告` : ""));
        } catch (err) {
            uf2Parsed = null; uf2Buf = null; bootselReady = false;
            uf2Errors = [err.message]; uf2Warnings = [];
            if (!["bootsel", "picking", "writing", "waitingReconnect", "verifying"].includes(flashPhase)) setFlashPhase("idle");
            $("uf2Info").textContent = "✗ 解析失败: " + err.message;
            log("固件文件解析失败: " + err.message, "error");
            updateFlashUi();
        }
    });

    $("flashOverride").addEventListener("change", updateFlashUi);

    // round56: 弹窗内"开始刷写"即最终确认(不再弹二次确认框)。校验失败时在
    // 弹窗内展示原因,不打断流程。round58: 未进配置模式时自动先进入配置模式。
    $("btnStartFlash").addEventListener("click", async () => {
        if (!uf2Buf || !uf2Parsed) { log("请先选择有效的固件文件", "warn"); return; }
        if (!configMode) {
            log("尚未进入配置模式,先自动进入再刷写", "warn");
            const ok = await withSerialLock(() => enterConfigMode());
            if (!ok) { setFlashPhase("error", "✗ 无法进入配置模式"); return; }
        }
        const v = validateUf2ForDevice(uf2Parsed, devInfo);
        if (uf2Parsed.sig && uf2Parsed.sig.buildId) {
            log(`固件精确构建标识: ${uf2Parsed.sig.buildId}`);
        }
        renderUf2Info(uf2Parsed, v);
        // 弹窗内展示确认摘要,供最终核对(不阻塞刷写)
        const summary =
            `固件: ${uf2FileName}\n版本: ${v.version ?? "未知"} / 变体: ${v.variant ?? "未知"}\n` +
            `当前设备: ${devInfo ? `${devInfo.fw}${devInfo.var ? " (" + devInfo.var + ")" : ""}` : "未知"}\n\n` +
            (v.warnings.length ? "警告:\n" + v.warnings.map(w => "⚠ " + w).join("\n") + "\n\n" : "") +
            "确认后设备将擦除引导区并重启进入 BOOTSEL,随后自动写入 RPI-RP2 盘符、\n自动重连并验证固件版本。";
        const bodyEl = $("flashConfirmBody");
        const summaryBox = $("flashConfirmSummary");
        if (bodyEl) bodyEl.textContent = summary;
        if (summaryBox) summaryBox.style.display = "";
        if (v.errors.length) {
            log("固件文件校验未通过,无法刷写", "error");
            setFlashPhase("error", "✗ 校验未通过:" + v.errors.join(";"));
            return;
        }
        if (v.warnings.length && !$("flashOverride").checked) {
            log("存在警告,请勾选「我已知晓警告」后再刷写", "warn");
            setFlashPhase("idle", "存在警告,请确认后勾选强制刷写");
            return;
        }
        // round78f: 趁点击激活期(浏览器只允许激活后 ~5s 内弹文件框)落实盘符
        // 访问——已存句柄做权限确认;首次使用立即弹选择框(不 await,与刷写命令
        // 并行,选择框里等 RPI-RP2 挂载出现后点选,与旧版 UX 一致)。BOOTSEL
        // 出现之后再弹任何框都会因激活过期抛 NotAllowedError,这是 round78e
        // 之后"面板不再弹盘符框"的根因。
        const readyDir = await prepareRp2DirAtClick();
        let earlyPicker = null;
        if (!readyDir && !MOCK && window.showDirectoryPicker) {
            // 选定即入档(验证前):即使 35s 验证窗先报错、用户之后才在选择框里
            // 点完盘符,句柄也已捕获,下次刷写即全自动
            earlyPicker = window.showDirectoryPicker({ mode: "readwrite" })
                .then((d) => { if (d) storeRp2Dir(d); return d; })
                .catch(() => null);
        }
        runFlashSequence(readyDir, earlyPicker);
    });

    $("flashConfirmCancel").addEventListener("click", hideFlashModal);
    $("flashConfirmModal").addEventListener("click", (e) => {
        if (e.target.id === "flashConfirmModal") hideFlashModal();
    });
    window.addEventListener("keydown", (e) => { if (e.key === "Escape") hideFlashModal(); });

    $("btnReconnectAfterFlash").addEventListener("click", () => attemptReconnect(null, false));
    $("btnWriteUf2").addEventListener("click", async () => {
        if (!bootselReady || !uf2Buf) return;
        if (!window.showDirectoryPicker) { log("浏览器不支持 File System Access API", "error"); return; }
        try {
            const dir = await window.showDirectoryPicker({ mode: "readwrite" });
            const ok = await validateAndWriteToBootsel(dir);
            // round78f: 手动选中的盘符(经卷校验)同样入档,下次刷写全自动
            if (ok) await storeRp2Dir(dir);
        } catch (e) {
            if (e.name === "AbortError") log("已取消选择盘符。可再次点击「手动选择盘符写入」", "warn");
            else log("打开盘符选择器失败: " + e.message, "error");
        }
    });

    // ================================================================
    // 连接 / 断开
    // ================================================================
    // round86 #10: 连接串口单击/长按分流。
    // 单击 = 自动回连上次设备(含已授权单设备直连);
    // 长按 ≥500ms = 直接在长按触发的瞬间弹出系统设备选择列表, 无需松手。
    (() => {
        const btn = $("connectBtn");
        let pressTimer = null, longHandled = false;
        const LONG_MS = 500;

        btn.addEventListener("contextmenu", (e) => {
            // 防止触屏长按触发右键上下文菜单截胡
            e.preventDefault();
        });

        btn.addEventListener("pointerdown", (e) => {
            if (connected) return;  // 已连接: click 统一走断开
            if (e.button !== undefined && e.button !== 0) return; // 仅限主按键/触屏单指
            longHandled = false;
            pressTimer = setTimeout(async () => {
                pressTimer = null;
                longHandled = true;  // 标记本次交互已由长按接管
                btn.classList.remove("pressing");
                log("检测到长按手势, 正在打开设备选择器...", "info");
                const ok = await openPort(null, false, { manualPicker: true });
                if (ok) {
                    log("已连接手动选择的设备");
                    setStatus("串口已连接", "");
                    await autoHandshake();
                    await normalModeProbe();
                    await startInputPolling();
                }
            }, LONG_MS);
            btn.classList.add("pressing");
        });

        const cancelPress = () => {
            if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; }
            btn.classList.remove("pressing");
        };
        btn.addEventListener("pointerup", cancelPress);
        btn.addEventListener("pointerleave", cancelPress);
        btn.addEventListener("pointercancel", cancelPress);

        btn.addEventListener("click", async () => {
            if (longHandled) {
                // 长按已在定时器中触发选口并处理, 松手产生的 click 必须忽略
                longHandled = false;
                return;
            }
            if (connected) { await closePort(); return; }
            const ok = await openPort(null, false, { manualPicker: false });
            if (ok) {
                setStatus("串口已连接", "");
                await autoHandshake();
                await normalModeProbe();
                await startInputPolling();
            }
        });
    })();

    // ================================================================
    // 硬件版本分段选择器
    // ================================================================
    const hwSeg = $("hwSegmented");
    const hwIndicator = $("hwIndicator");
    const hwBtns = hwSeg.querySelectorAll(".segmented-btn");
    function setHwVer(v, quiet) {
        hwVerValue = v;
        hwBtns.forEach((btn) => btn.classList.toggle("active", parseInt(btn.dataset.hw, 10) === v));
        if (hwIndicator) hwIndicator.style.transform = `translateX(${(v - 1) * 100}%)`;
        if (!quiet) { updateTofVisibility(); updateTouchUi(); refreshMbrChips(); }
    }
    hwBtns.forEach((btn) => {
        btn.addEventListener("click", () => setHwVer(parseInt(btn.dataset.hw, 10)));
    });

    // ================================================================
    // 二次确认(应用/恢复,三代组件)
    // ================================================================
    function setupConfirmAction(btn, confirmText, action) {
        const originalHTML = btn.innerHTML;
        let confirmTimer = null;
        let isConfirming = false;
        function setTextWithAnim(text) {
            const svg = btn.querySelector("svg");
            btn.innerHTML = "";
            if (svg) btn.appendChild(svg);
            const span = document.createElement("span");
            span.className = "btn-text-anim";
            span.textContent = text;
            btn.appendChild(span);
            void span.offsetWidth;
        }
        function resetConfirm() {
            setTextWithAnim(originalHTML.replace(/<[^>]+>/g, "").trim());
            btn.classList.remove("btn-confirming");
            isConfirming = false;
            if (confirmTimer) { clearTimeout(confirmTimer); confirmTimer = null; }
        }
        btn.addEventListener("click", async () => {
            if (isConfirming) {
                resetConfirm();
                try { await action(); }
                catch (e) { log("操作失败: " + (e.message || e), "error"); }
            } else {
                isConfirming = true;
                btn.classList.add("btn-confirming");
                setTextWithAnim(confirmText);
                confirmTimer = setTimeout(resetConfirm, 3000);
            }
        });
    }

    // round57: 保存设置按钮已从工具栏移除;保存并入"保存并重启"(二级确认)
    setupConfirmAction($("btnSaveAndReboot"), "继续？", () => withSerialLock(async () => {
        if (!configMode) { log("请先进入配置模式", "warn"); return; }
        await doSaveAndReboot();
    }));

    setupConfirmAction($("eraseConfigBtn"), "继续？", () => withSerialLock(doEraseConfig));
    $("btnDevInfo").addEventListener("click", () => withSerialLock(async () => {
        if (!connected) { log("请先连接设备", "warn"); return; }
        try { await queryDevInfo(); } catch (e) { log("读取设备信息失败: " + e.message, "error"); }
    }));

    // round61: 点击"固件版本"卡弹出设备完整详细信息。
    $("infoFwCard").addEventListener("click", () => {
        const body = $("infoDetailBody");
        if (devInfo && devInfo.raw) body.textContent = devInfo.raw;
        else body.textContent = "尚未读取设备信息。请先连接设备并点「读取设备信息」。";
        openModalAnimated($("infoDetailModal"));
    });
    $("infoDetailClose").addEventListener("click", () => closeModalAnimated($("infoDetailModal")));
    $("infoDetailModal").addEventListener("click", (e) => { if (e.target.id === "infoDetailModal") closeModalAnimated($("infoDetailModal")); });
    window.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModalAnimated($("infoDetailModal")); });

    // ================================================================
    // UI 总开关状态
    // ================================================================
    function setStatus(text, kind) {
        const tip = $("tip");
        tip.style.opacity = "0";
        setTimeout(() => { tip.innerText = text; tip.style.opacity = "1"; }, 150);
        if (kind === "connected") $("statusDot").className = "status-dot connected";
        else if (kind === "error") $("statusDot").className = "status-dot error";
        else $("statusDot").className = "status-dot";
    }

    function updateUI() {
        const inCfg = configMode;
        const chip = $("modeChip");
        chip.textContent = inCfg ? "配置模式" : connected ? "普通模式" : "未连接";
        chip.className = "chip" + (inCfg ? " cfg" : "") + (!connected ? " err" : "");

        const connectBtn = $("connectBtn");
        connectBtn.lastChild.textContent = connected ? " 断开连接" : " 连接串口";
        // round71: 语义高亮——未连接=高亮黄(主要入口引导),已连接=红(破坏性断开)。
        // btn-connect-acc / btn-disconnect-danger 由 head_patch.css 定义。
        connectBtn.classList.toggle("btn-connect-acc", !connected);
        connectBtn.classList.toggle("btn-disconnect-danger", connected);

        const normalIds = ["btnDevInfo"];
        normalIds.forEach(id => $(id).disabled = !connected);
        $("flashBtn").disabled = !connected;
        $("flashBtn").classList.add("btn-flash-warm");  // round71: 固件刷写橙色警示
        // 连接串口始终可点(它是连接的总入口);未连接时其余交互控件全部禁用。
        $("connectBtn").disabled = false;

        // 配置模式内的工具:连接中且处于配置模式才可用
        const cfgTools = ["btnGetStatus", "btnPollTof"];
        cfgTools.forEach(id => $(id).disabled = !connected || !inCfg);
        // round67: 一键校准(普通模式实时压力流):连接 + 非配置模式 + 固件 1.6.0+
        const btnCal = $("btnCalibrate");
        if (btnCal) btnCal.disabled = !connected || inCfg || !rawReportSupported;
        // round85: 原始/模拟报送切换按钮:连接 + 非配置模式 + 固件 1.6.0+
        // (level 2 能力不足时 setRawReportMode 内部自动回退 level 1, 按钮仍可用)。
        const btnRawMode = $("btnRawMode");
        if (btnRawMode) btnRawMode.disabled = !connected || inCfg || !rawReportSupported;
        // 导入/导出:已连接即可用。导入只填表单(不写设备),导出优先导出设备
        // 读取值(普通模式下导出当前表单构建的配置)。
        $("btnImportCfg").disabled = !connected;
        $("btnExportCfg").disabled = !connected;
        // 合并按钮:普通模式=进入配置模式(可用),配置模式=退出并重启(可用)
        $("btnEnterConfig").disabled = !connected;
        setEnterExitBtnLabel(inCfg);

        const writable = connected && inCfg && !cfgVerMismatch;
        $("eraseConfigBtn").disabled = !connected || !inCfg;
        $("btnSaveAndReboot").disabled = !writable;

        const inputs = ["ckForce16", "ckMbr3116", "ckDarkerGap", "ckKbSlider", "ckKbAir", "ckLampArray",
            "rgAirMin", "rgAirMax", "rgThTouch", "rgThRelease", "rgBright",
            "rgDt", "rgDr", "rgHeight", "rgLatency", "off0", "off1", "off2", "off3", "off4"];
        inputs.forEach(id => $(id).disabled = !inCfg);
        // round86 #12: MBR 滑条已迁入参数调节/高级参数区,门禁 = 配置模式 + 3116
        const mbrSliderIds = ["mbrThreshold", "mbrDebounce", "mbrSensitivity"];
        mbrSliderIds.forEach(id => $(id).disabled = !inCfg || mbrWriting || !$("ckMbr3116").checked || !mbrAllRead() || (id === "mbrThreshold" && !!(mbrTable?.[0x4F] & 8)));
        hwBtns.forEach(b => b.disabled = !inCfg);
        // round68: ckGameRaw 在配置模式可用, 但需 1.6.0 固件(旧固件 sanitize
        // 会丢弃该位)+ fw 门禁在 0xBD 处理同步(旧固件置灰并清勾选)。
        $("ckGameRaw").disabled = !inCfg || !perKeyFwSupport;
        // round81: 悬空抑制滑块需固件 >= 1.6.2-beta1(旧固件该字节为 reserved)。
        $("rgMbrGate").disabled = !inCfg || !mbrGateFwSupport;

        // round86 #12: 预设/悬空截止校准按钮已移除;btnMbrBurnAll 为同步烧录入口。
        const mbrIds = ["mbrChip", "mbrHexTable", "btnMbrTemplate", "btnMbrLoadFile", "btnMbrSaveFile", "btnMbrApply", "btnMbrBurnAll", "btnMbrRestoreAll", "btnMbrRegWin", "btnMbrReadAll", "btnMbrRegRead"];
        const mbrEnabled = inCfg && MBR_CRC_OK && !mbrWriting;
        mbrIds.forEach(id => $(id).disabled = !mbrEnabled);
        ["btnMbrApply", "btnMbrBurnAll"].forEach(id => $(id).disabled = !mbrEnabled || !mbrCanProgram());
        // round82: 从芯片读取(0xC6)额外需要固件 >= 1.6.2-beta1。
        $("btnMbrReadChip").disabled = !mbrEnabled || !mbrGateFwSupport;
        $("btnMbrReadAll").disabled = !mbrEnabled || !mbrGateFwSupport;
        $("btnMbrRegRead").disabled = !mbrEnabled || !mbrGateFwSupport;
        $("btnMbrBackup").disabled = !mbrWriteBackups.length;
        evaluateMbrRegRisk();
        // round88: 悬浮窗内 0xC7 采样按钮需固件 1.6.5+。
        $("btnMbrDbgRead").disabled = !mbrEnabled || !mbrDebugFwSupport;
        // round86: 独立悬空截止校准按钮已移除(统一入口 btnCalibrate,#7)。

        // 0xB2 仅普通模式处理(配置模式会变 "unknown command" 文本污染响应流)
        const ledIds = ["ledOff", "ledWhite", "ledRed", "ledGreen", "ledBlue", "ledChase", "ledRainbow", "ledStop", "ledCustom", "ledColor", "ledLimit"];
        ledIds.forEach(id => $(id).disabled = !connected || inCfg);
        $("ledSpeed").disabled = false;

        $("mbrSection").style.display = (inCfg && $("ckMbr3116").checked) ? "" : "none";
        $("mbrSignalContainer").style.display = (inCfg && mbrSignalUsesMbr()) ? "" : "none";
        updateMbrSignalUi();

        // round86 #2: 未进入配置模式时,四个配置分区(通用设置/参数调节/高级参数/
        // MBR 高级配置)整体半透明且不可交互,替代此前"控件各自 disabled 但分区
        // 外观无变化"的低对比呈现。进入配置模式后恢复不透明。
        document.querySelectorAll(".panel-config .config-section").forEach(sec => {
            sec.classList.toggle("config-locked", !inCfg);
        });

        updateFlashUi();
    }

    // ================================================================
    // 折叠区块 / 日志清空
    // ================================================================
    document.querySelectorAll(".config-section.collapsible .section-subtitle").forEach(el => {
        el.addEventListener("click", () => {
            el.parentElement.classList.toggle("collapsed");
        });
    });
    $("btnClearLog").addEventListener("click", () => { $("mainLog").textContent = ""; });

    // ================================================================
    // round56: Log 运行日志窗口自适应。左列(test-column)与右列(config)
    // 高度不齐(差值 >15px)时,把 Log 平滑移动到较矮一侧下方;反之回到全宽。
    // Log 是 .app-main 的网格项,默认占第 2 行全宽;不齐时 dock 到矮列。
    // ================================================================
    // round62: Log 固定置于左侧栏(.test-column)内、设备状态(panel-tof)下方,
    // 宽度与左栏一致,不再做任何自适应/网格 dock 迁移。它现在是 .test-column
    // 的 flex 子项(flex-direction:column),宽度自然撑满左栏,高度紧随内容。
    function initLogAutoDock() {
        const logPanel = document.querySelector(".panel-log");
        if (!logPanel) return;
        // 强制清除历史 dock 类/内联 gridColumn,避免旧机制残留干扰宽度。
        logPanel.classList.remove("auto-docked", "dock-left");
        logPanel.style.gridColumn = "";
    }
    initLogAutoDock();

    $("ckMbr3116").addEventListener("change", () => { updateTouchUi(); refreshMbrChips(); updateUI(); });
    // round67: 一键校准阈值向导(压力上报 + 统计法)
    const btnCal = $("btnCalibrate");
    if (btnCal) btnCal.addEventListener("click", () => startCalibration());

    // ================================================================
    // 启动初始化
    // ================================================================
    initLedStrip();
    initSliderAnimations();
    // round77: 页头面板版本标识(值来自 app_core.js 的 PANEL_VERSION)
    const panelVerEl = $("panelVer");
    if (panelVerEl) panelVerEl.textContent = "Panel v" + PANEL_VERSION;
    syncLedDefaultColor(false);  // round71: Light Test 默认色对齐当前主题 accent
    // round71 终审: THEME TOGGLE 是独立顶层 IIFE, 看不到本作用域的 syncLedDefaultColor;
    // 经 window 桥接(视觉审查发现的 ReferenceError 被空 catch 吞掉导致联动失效)。
    window.__syncLedDefaultColor = syncLedDefaultColor;
    // 输入测试字体亮度与主题联动桥接
    window.__updateThemeLuminance = () => {
        updateThemeLuminanceCache();
        syncAllTouchTextColors();
    };
    updateThemeLuminanceCache();
    syncAllTouchTextColors();
    setHwVer(1, true);
    updateTofVisibility();
    updateTouchUi();
    refreshMbrChips();
    updateLightLimitHint();
    checkThresholdHints();
    resetInputBtn();
    updateUI();
    if (!MBR_CRC_OK) {
        log("MBR3116 表 CRC 自检失败:内嵌模板表尾与计算不符,3116 表编辑/应用已禁用(只读)", "error");
    }
    if (MOCK) {
        // mock 下自动连接便于快速走查
        setTimeout(async () => {
            log("Mock: 自动连接模拟设备…");
            $("connectBtn").click();
        }, 2800);
    }

    window.addEventListener("beforeunload", () => { if (connected) closePort(); });

    // 串口热插拔监听(刷写后自动重连的关键通道)
    async function onSerialConnect(e) {
        try {
            const p = e.port || e.target;
            if (!p || typeof p.getInfo !== "function") return;
            const info = p.getInfo();
            if (info.usbVendorId === 0xCAFE && info.usbProductId === 0x4009 && reconnectWatch && !connected) {
                log("检测到设备重新上线,正在自动重连...");
                if (await attemptReconnect(p, true)) stopReconnectWatch();
            }
        } catch (err) { /* 自动重连失败交由轮询/手动按钮兜底 */ }
    }
    if (navigator.serial && !MOCK) {
        navigator.serial.addEventListener("connect", onSerialConnect);
        navigator.serial.addEventListener("disconnect", () => {
            if (connected) handleUnexpectedDisconnect("串口连接已断开(设备重启或拔出)");
        });
    }
})();

// ================================================================
// LOGO CLICK: Replay entrance animation without page reload
// ================================================================
(function initLogoClick() {
    var brandLogos = document.querySelectorAll('.header-brand, .header-master');
    brandLogos.forEach(function (el) {
        el.addEventListener('click', function () {
            window.replayIntroAnimation();
        });
    });
})();

// ================================================================
// THEME TOGGLE
// ================================================================
(function initThemeToggle() {
    const toggle = document.getElementById('themeToggle');
    if (!toggle) return;

    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    } else {
        var hour = new Date().getHours();
        if (hour >= 8 && hour < 18) {
            document.documentElement.setAttribute('data-theme', 'light');
        }
    }
    // round76 审查: 主 IIFE 的初始 syncLedDefaultColor 跑在本 IIFE 应用已存主题之前,
    // 初始默认色会 stale 一拍——应用主题后补一次对齐(send=false 仅刷取色器/预览)。
    try { if (typeof window.__syncLedDefaultColor === "function") window.__syncLedDefaultColor(false); }
    catch (e) { /* 桥接未就绪时忽略,首次切换主题后自愈 */ }
    try { if (typeof window.__updateThemeLuminance === "function") window.__updateThemeLuminance(); }
    catch (e) { /* 桥接未就绪时忽略 */ }

    let isTransitioning = false;
    toggle.addEventListener('click', () => {
        if (isTransitioning) return;
        isTransitioning = true;
        toggle.style.pointerEvents = 'none';

        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';

        document.body.classList.add('theme-transition');
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);

        // 主题切换后立即同步输入测试字体亮度颜色映射
        try {
            if (typeof window.__updateThemeLuminance === "function") {
                window.__updateThemeLuminance();
            }
        } catch (e) {}

        // round71: 主题切换后 Light Test 默认准备色跟随新主题 accent;
        // 已连接且未在输入轮询/动画中时补发一次,让灯条即时跟随。
        // 延迟到过渡结束后执行,避免与 theme-transition 全属性过渡抢帧。
        // round71 终审: syncLedDefaultColor 在主 IIFE 作用域,经 window 桥接调用。
        // 桥接缺失(未来重命名)时告警而非静默,避免同类 bug 再被吞。
        setTimeout(() => {
            try {
                if (typeof window.__syncLedDefaultColor !== "function") {
                    console.warn("[round71c] __syncLedDefaultColor 桥接缺失,主题联动灯色跳过");
                    return;
                }
                window.__syncLedDefaultColor(true);
            } catch (e) { console.warn("[round71c] 主题联动灯色失败:", e); }
        }, 1150);

        setTimeout(() => {
            document.body.classList.remove('theme-transition');
            isTransitioning = false;
            toggle.style.pointerEvents = '';
        }, 1100);
    });
})();
