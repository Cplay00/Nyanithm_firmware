/* ================================================================
   ControlPanel v2 — 协议核心(源自 ControlPanel_v1.html,DOM 无关部分)
   目标设备: Nyanithm hw_v1 / cplay (API 0x10, cfgVer 0x02)
   ================================================================ */

// ====== v1 协议常量 ======
const CMD = {
    GET_API_LEVEL: 0xAF,
    DEV_DETECT: 0xB0,
    GET_INPUT: 0xB1,
    SET_LED: 0xB2,
    CONFIG_MODE: 0xB3,
    CFG_READ: 0xB4,
    CFG_SAVE: 0xB5,
    // round51: 与固件 NyanithmCmd 枚举对齐 (CMD_CFG_ERASE=0xB6, CMD_CFG_SET=0xB7)。
    // 此前 SET/ERASE 互换: "保存配置"实际执行擦除, 且后续128字节配置
    // 被固件当作命令流解析 (值0xB9=重启 / 0xBB=变砖), 为面板全部
    // 配置功能失效的根因。
    CFG_SET: 0xB7,
    CFG_ERASE: 0xB6,
    GET_STATUS: 0xB8,
    EXIT: 0xB9,
    LOAD3116CONFIG: 0xBA,
    FLASHING: 0xBB,
    DETECT: 0xBC,
    GET_VERSION: 0xBD,
    // round57: 配置模式心跳。固件 0xC3 静默重置 60s 自动退出计时器。
    CFG_KEEPALIVE: 0xC3,
    // round66: 逐键压力上报开关(会话态,仅普通模式)。0xC4 查询返回 RAW=0|1\n;
    // 0xC5 跟 1B 0/1 设置后回 RAW=0|1\n。仅固件 1.6.0+ 可用(版本门禁,
    // 见 queryDevInfo 的 rawReportSupported; API 恒为 0x10,不作命令门禁)。
    // round84/85: 载荷升级为 level -- 0=关, 1=模拟(MPR ×2 报送), 2=原始
    // (pressureSnap 原值直报; MBR 两档相同); 回显 RAW=0|1|2。旧固件对 2
    // 落空忽略, 面板侧按固件 >= 1.6.3-beta1 门禁后才发 2。
    GET_RAW_STATUS: 0xC4,
    SET_RAW_REPORT: 0xC5,
    // round80/82: 读回 3116 芯片当前 128B 配置块(仅配置模式)。铁律: 主机必须
    // 分两次 write -- 先 [0xC6], 再 [addr](与 CFG_SET 双写铁律同源)。白名单同
    // 0xBA; 成功回 128B 二进制(0x7E/0x7F CRC 原值), 失败回文本行。需固件
    // >= 1.6.2-beta1。
    READ3116CONFIG: 0xC6,
    // round88: 单传感器调试读数(仅配置模式)。铁律: 先 [0xC7], 再 2B
    // [addr][sensor]。成功回 11B 二进制(全小端):
    // [0]=0xC7 [1]=addr [2]=sensor [3]=sync [4]=cp(pF)
    // [5..6]=diff [7..8]=baseline [9..10]=raw。
    // 失败回文本行 "3116 debug fail"。需固件 >= 1.6.5。
    MBR3116_DEBUG: 0xC7
};

const CFG_MAGIC = 0x88;
const CFG_VERSION = 0x02;
const CFG_SIZE = 128;

// round64: v1.6 逐键阈值偏移(lane 0-31, 0=继承全局)。与固件
// include/share/nyanithm_shared.h 的 controller_config 布局一致。
const CFG_OFF_TH_TOUCH_KEY = 26;
const CFG_OFF_TH_RELEASE_KEY = 58;
const CFG_NUM_KEYS = 32;
// round80: MBR3116 悬空抑制门(controller_config.mbrTouchGate, 0=旧行为)。
// 需固件 >= 1.6.2-beta1(旧固件该字节为 reserved, sanitize 不清零但也不生效)。
const CFG_OFF_MBR_TOUCH_GATE = 90;
// round89a: 与 nyanithm_shared.h 的 8B 实验性持续信号门扩展一致。
const CFG_OFF_MBR_SIGNAL_PROFILE = 91;
const MBR_SIGNAL_MAGIC = 0xD6;
const MBR_SIGNAL_VERSION = 1;
const MBR_SIGNAL_CHECK_SEED = 0xA7;
const MBR_SIGNAL_MIN_FW = "1.6.6-beta1";

// This additive feature requires both a numeric version and its known build
// floor. Legacy cmpVersion treats a beta patch as NaN and must not gate it.
function supportsMbrSignalFirmware(firmware, buildId) {
    const version = typeof firmware === "string" && firmware.match(/^(\d+)\.(\d+)\.(\d+)(?:-beta([1-9]\d*))?$/);
    const build = typeof buildId === "string" && buildId.match(/^round(\d+)([a-z]*)$/);
    if (!version || !build) return false;
    const parts = version.slice(1, 4).map(Number);
    const floor = [1, 6, 6];
    if (parts.some(n => !Number.isSafeInteger(n)) || !Number.isSafeInteger(Number(build[1]))) return false;
    let atLeast = true;
    for (let i = 0; i < 3; i++) {
        if (parts[i] !== floor[i]) { atLeast = parts[i] > floor[i]; break; }
    }
    return atLeast && (Number(build[1]) > 89 ||
        (Number(build[1]) === 89 && build[2] >= "a"));
}

function validateMbrSignalProfile(profile) {
    const errors = [];
    if (!profile || typeof profile.enabled !== "boolean") errors.push("启用状态必须为布尔值");
    for (const name of ["zero", "full", "onPercent", "offPercent"]) {
        if (!profile || !Number.isInteger(profile[name])) errors.push(name + " 必须为整数");
    }
    if (profile) {
        if (profile.zero < 0 || profile.zero > 254) errors.push("DIFF 零点 Z 须为 0–254");
        if (profile.full < 1 || profile.full > 255 || profile.full <= profile.zero) errors.push("满点 F 须大于 Z 且不超过 255");
        if (profile.onPercent < 1 || profile.onPercent > 100) errors.push("ON 比例须为 1–100%");
        if (profile.offPercent < 0 || profile.offPercent >= profile.onPercent) errors.push("OFF 比例须为 0% 以上且小于 ON");
    }
    return { valid: errors.length === 0, errors };
}

function decodeMbrSignalProfile(buf) {
    const o = CFG_OFF_MBR_SIGNAL_PROFILE;
    const defaults = { enabled: false, zero: 0, full: 255, onPercent: 70, offPercent: 50 };
    if (!buf || buf.length !== CFG_SIZE) return { ...defaults, valid: false, legacy: true };
    let check = MBR_SIGNAL_CHECK_SEED;
    for (let i = 0; i < 7; i++) check ^= buf[o + i];
    const profile = { enabled: !!(buf[o + 2] & 1), zero: buf[o + 3], full: buf[o + 4], onPercent: buf[o + 5], offPercent: buf[o + 6] };
    const valid = buf[o] === MBR_SIGNAL_MAGIC && buf[o + 1] === MBR_SIGNAL_VERSION &&
        (buf[o + 2] & ~1) === 0 && buf[o + 7] === check && validateMbrSignalProfile(profile).valid;
    return valid ? { ...profile, valid: true, legacy: false } : { ...defaults, valid: false, legacy: true };
}

function encodeMbrSignalProfile(buf, profile) {
    if (!buf || buf.length !== CFG_SIZE) throw new Error("配置长度必须为 128 字节");
    const result = validateMbrSignalProfile(profile);
    if (!result.valid) throw new Error(result.errors.join("；"));
    const o = CFG_OFF_MBR_SIGNAL_PROFILE;
    buf.set([MBR_SIGNAL_MAGIC, MBR_SIGNAL_VERSION, profile.enabled ? 1 : 0,
        profile.zero, profile.full, profile.onPercent, profile.offPercent], o);
    let check = MBR_SIGNAL_CHECK_SEED;
    for (let i = 0; i < 7; i++) check ^= buf[o + i];
    buf[o + 7] = check;
    return buf;
}

// Match the firmware extension sanitizer before CFG_SET/readback comparisons.
// Points are preserved when switching to MPR; only this MBR opt-in is cleared.
function sanitizeMbrSignalProfile(buf) {
    if (!buf || buf.length !== CFG_SIZE) throw new Error("配置长度必须为 128 字节");
    const profile = decodeMbrSignalProfile(buf);
    if (!profile.valid) {
        buf[CFG_OFF_MBR_SIGNAL_PROFILE + 2] = 0;
        buf[CFG_OFF_MBR_SIGNAL_PROFILE + 7] = 0;
    } else if (!(buf[3] & 0b00000010) && buf[2] < 3) {
        encodeMbrSignalProfile(buf, { ...profile, enabled: false });
    }
    return buf;
}

// 仅评估同一量纲的按钮 DIFF(0–255)，不把 RAW/BASELINE 转换成 DIFF。
// 样本形状: { lane, targetLane, diff, clipped? }。targetLane 是采样时明确指定
// 的物理区域；不能通过“哪个通道最大”替代定位。结果只供评估，不自动启用或写设备。
function evaluateMbrCalibration(input) {
    const errors = [], stats = [];
    const lanes = input && input.requiredLanes;
    const minSamples = input && input.minSamplesPerLane !== undefined ? input.minSamplesPerLane : 20;
    const margin = input && input.noiseMargin !== undefined ? input.noiseMargin : 5;
    if (!input || input.quantity !== "DIFF") errors.push("必须使用同一量纲的 DIFF 样本，RAW/BASELINE 不可混用");
    if (!Array.isArray(lanes) || !lanes.length || new Set(lanes).size !== lanes.length ||
        lanes.some(lane => !Number.isInteger(lane) || lane < 0 || lane >= CFG_NUM_KEYS)) errors.push("必需区域列表无效");
    if (!Number.isInteger(minSamples) || minSamples < 2) errors.push("每区最少样本数须为至少 2 的整数");
    if (!Number.isInteger(margin) || margin < 1 || margin > 127) errors.push("噪声裕量须为 1–127 的整数");
    const groups = [input && input.prohibitedSamples, input && input.contactSamples];
    if (groups.some(group => !Array.isArray(group) || !group.length)) errors.push("禁止悬空与有效轻触两组均须有样本");
    if (errors.length) return { valid: false, errors, stats, proposal: null };
    const required = new Set(lanes);
    groups.forEach((samples, groupIndex) => {
        samples.forEach((sample, index) => {
            if (!sample || !required.has(sample.lane) || sample.targetLane !== sample.lane) {
                errors.push(`${groupIndex ? "轻触" : "悬空"}样本 ${index + 1} 未命中指定区域`);
            }
            if (!sample || !Number.isInteger(sample.diff) || sample.diff < 0 || sample.diff > 255) {
                errors.push(`样本 ${index + 1} DIFF 须为 0–255 的整数`);
            } else if (sample.clipped || sample.diff === 255) {
                errors.push(`样本 ${index + 1} 已裁剪或饱和，不能建立可信两点标定`);
            }
        });
    });
    if (errors.length) return { valid: false, errors, stats, proposal: null };
    for (const lane of lanes) {
        const hover = groups[0].filter(s => s.lane === lane).map(s => s.diff);
        const touch = groups[1].filter(s => s.lane === lane).map(s => s.diff);
        if (hover.length < minSamples || touch.length < minSamples) errors.push(`区域 ${lane + 1} 样本不足（悬空 ${hover.length} / 轻触 ${touch.length}）`);
        const hoverMax = hover.length ? Math.max(...hover) : null;
        const contactMin = touch.length ? Math.min(...touch) : null;
        const gap = hoverMax !== null && contactMin !== null ? contactMin - hoverMax : null;
        if (touch.length && touch.every(value => value === 0)) errors.push(`区域 ${lane + 1} 轻触全为 0，未取得有效接触信号`);
        if (gap !== null && gap <= 0) errors.push(`区域 ${lane + 1} 悬空与轻触信号重叠`);
        else if (gap !== null && gap <= margin * 2) errors.push(`区域 ${lane + 1} 分离裕量不足（${gap} ≤ ${margin * 2}）`);
        stats.push({ lane, prohibitedCount: hover.length, contactCount: touch.length, hoverMax, contactMin, gap });
    }
    const zero = Math.max(...stats.map(s => s.hoverMax === null ? 255 : s.hoverMax)) + margin;
    const full = Math.min(...stats.map(s => s.contactMin === null ? 0 : s.contactMin)) - margin;
    if (zero >= full) errors.push("跨区域信号范围重叠或全局裕量不足，全局门限不能可靠分离");
    return { valid: !errors.length, errors, stats,
        proposal: errors.length ? null : { enabled: false, zero, full, onPercent: 70, offPercent: 50 },
        note: "只评估本次样本；不是毫米距离或全环境零误触保证，不自动应用" };
}

const BIT_FORCE16 = 0b00000001;
const BIT_MBR3116 = 0b00000010;
const BIT_DARKER_GAP = 0b00000100;
const BIT_KB_SLIDER = 0b00000001;
const BIT_KB_AIR = 0b00000010;
// round55 cfg2 bit0:置 1 = 关闭 LampArray / Windows 动态照明(disable 语义,旧配置默认开启)
const BIT_DISABLE_LAMP_ARRAY = 0b00000001;
// round68 cfg2 bit1:游戏内压力报送(实验,默认关;开启后 GET_INPUT 按下键报压力、释放 0)
const BIT_GAME_RAW_SLIDER = 0b00000010;

// 一代 hw_v1 固件版本白名单:0xBC 探测不可用(旧固件)时的回退门禁依据。
// round86: 1.6.4-beta1 = 0xBC 下放普通模式(连接即自动探测)。
// round88: 1.6.5 = 0xC7 调试通道 + 0xBA 烧录序列官方化(正式版号, 不带 beta)。
const KNOWN_V1_FW = ["1.5.1", "1.5.2", "1.5.3", "1.6.0", "1.6.1-beta1", "1.6.1-beta2", "1.6.2-beta1", "1.6.3-beta1", "1.6.4-beta1", "1.6.5", "1.6.6-beta1"];
// round77/78: 面板自身版本标识(显示于页头品牌区)。round89a 修复 beta 补丁段
// 的数值解析；新 profile 另要求严格版本格式和精确构建下限。
// round85: 0xC5=2(原始报送)与悬空截止校准按固件 >= 1.6.3-beta1 门禁
// (cmpVersion 主版本 3>2 天然成立,无需特判)。
// round88: 0xC7 调试通道按固件 >= 1.6.5 门禁(纯三段数值, cmpVersion 天然可用)。
const PANEL_VERSION = "1.1.1-beta9";

// ====== UF2 固件文件解析(刷写前校验) ======
const UF2_MAGIC0 = 0x0A324655;   // "UF2\n"
const UF2_MAGIC1 = 0x9E5D5157;
const UF2_MAGIC_END = 0x0AB16F30;
const UF2_FLAG_FAMILY = 0x00002000;
const RP2040_FAMILY_ID = 0xE48BFF56;
const RP2040_FLASH_BASE = 0x10000000;
const RP2040_FLASH_SIZE = 2 * 1024 * 1024;

// ====== CY8CMBR3116 ======
const MBR_ADDRS = ["0x37", "0x40", "0x41", "0x42", "0x43", "0x44"];

// 固件 cy8cmbr3116.cpp 内置的 6 张 128 字节寄存器表(按芯片地址命名),
// 作为 MBR3116 高级配置的模板基底;表尾 0x7E/0x7F 为芯片校验 CRC。
const MBR_TABLES = {
"0x37": [
    0xFF, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80,
    0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x7F, 0x7F, 0x7F, 0x7F, 0x03, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x01, 0x01,
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x03, 0x01, 0x48,
    0x00, 0x37, 0x01, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAD, 0x32
],
"0x40": [
    0xFF, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0x00, 0x80, 0x80, 0x80, 0x80,
    0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x7F, 0x7F, 0x7F, 0x7F, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x01, 0x01,
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x68,
    0x00, 0x40, 0x01, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x34, 0x5D
],
"0x41": [
    0xFF, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0x00, 0x80, 0x80, 0x80, 0x80,
    0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x7F, 0x7F, 0x7F, 0x7F, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x01, 0x01,
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x68,
    0x00, 0x41, 0x01, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x89
],
"0x42": [
    0xFF, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0x00, 0x80, 0x80, 0x80, 0x80,
    0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x7F, 0x7F, 0x7F, 0x7F, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x01, 0x01,
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x68,
    0x00, 0x42, 0x01, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x53, 0xE5
],
"0x43": [
    0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x80, 0x80, 0x80, 0x80,
    0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x01, 0x01,
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x10, 0x00, 0x01, 0x68,
    0x00, 0x43, 0x01, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x72, 0x68
],
"0x44": [
    0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x80, 0x80, 0x80, 0x80,
    0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x01, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x01, 0x01,
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x10, 0x00, 0x01, 0x68,
    0x00, 0x44, 0x01, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xD9, 0x64
]
};

// ====== CY8CMBR3116 表 CRC ======
// 芯片对寄存器 0x00..0x7D 计算 CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF,
// 无反射/无异或) 并与 0x7E/0x7F 比较(0x7E=低字节, 0x7F=高字节)。
function mbrCrc16(table) {
    let crc = 0xFFFF;
    for (let i = 0; i < 0x7E; i++) {
        crc ^= table[i] << 8;
        for (let b = 0; b < 8; b++) {
            crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
        }
    }
    return crc;
}

function mbrUpdateTableCrc(table) {
    const crc = mbrCrc16(table);
    table[0x7E] = crc & 0xFF;
    table[0x7F] = (crc >> 8) & 0xFF;
}

// CRC 自检: JS 实现必须复现全部内置表的表尾, 否则禁用表编辑/应用(降级只读)。
const MBR_CRC_OK = Object.keys(MBR_TABLES).every(k => {
    const t = MBR_TABLES[k];
    const crc = mbrCrc16(t);
    return t[0x7E] === (crc & 0xFF) && t[0x7F] === ((crc >> 8) & 0xFF);
});

// ====== round88: CY8CMBR3116 寄存器元数据(配置区 0x00-0x5F, 面板悬浮窗) ======
// 依据: CapSense Express Registers TRM (001-91082 Rev. *E) §1.5.1-§1.5.63 与
// CY8CMBR3xxx CapSense Design Guide Table 6-2(调参比例)。每项:
//   a=地址(16-bit 寄存器为 2 项), n=名称, d=直白说明, min/max=合法区间,
//   r=风险等级 0=常规 1=警告(写前二次确认) 2=严重(改动直接拒绝烧录),
//   u=单位/格式提示, nvm=写入后需 CTRL_CMD 0x86 命令落 NVM 才生效(配置区皆然)。
// 16-bit 寄存器(SENSOR_EN/FSS_EN/TOGGLE_EN/CONFIG_CRC)按低字节/高字节拆两项。
const MBR_REG_DEFS = [
    { a: 0x00, n: "SENSOR_EN 低字节", d: "传感器 CS0-7 使能位。关闭某个传感器 = 该键彻底失联", min: 0, max: 255, r: 1 },
    { a: 0x01, n: "SENSOR_EN 高字节", d: "CS8-15 使能位。三芯片布局使用 CS0-11；双芯片布局使用 CS0-15", min: 0, max: 255, r: 1 },
    { a: 0x02, n: "FSS_EN 低字节", d: "邻键抑制组开关。开启后相邻双押会被吞掉——音游严禁开启", min: 0, max: 255, r: 1 },
    { a: 0x03, n: "FSS_EN 高字节", d: "邻键抑制组开关(CS8-15), 音游必须保持 0", min: 0, max: 255, r: 1 },
    { a: 0x08, n: "SENSITIVITY0", d: "传感器 0-3 灵敏度档位, 每片 2 位: 0=0.1pF 最灵敏/悬空最远 → 3=0.4pF 最迟钝", min: 0, max: 255, r: 0 },
    { a: 0x09, n: "SENSITIVITY1", d: "传感器 4-7 灵敏度档位(每片 2 位, 0.1-0.4pF)", min: 0, max: 255, r: 0 },
    { a: 0x0A, n: "SENSITIVITY2", d: "传感器 8-11 灵敏度档位(每片 2 位, 0.1-0.4pF)", min: 0, max: 255, r: 0 },
    { a: 0x0B, n: "SENSITIVITY3", d: "传感器 12-15 灵敏度档位(每片 2 位, 0.1-0.4pF)", min: 0, max: 255, r: 0 },
    { a: 0x0C, n: "FINGER_THRESHOLD0", d: "传感器 0 触发判定阈值。悬空误触发调大、漏触调小。仅当 DEVICE_CFG2.ATH_EN=0(手动阈值)时生效!", min: 31, max: 200, r: 0 },
    { a: 0x0D, n: "FINGER_THRESHOLD1", d: "传感器 1 触发判定阈值(31-200)。ATH_EN=0 时生效", min: 31, max: 200, r: 0 },
    { a: 0x0E, n: "FINGER_THRESHOLD2", d: "传感器 2 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x0F, n: "FINGER_THRESHOLD3", d: "传感器 3 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x10, n: "FINGER_THRESHOLD4", d: "传感器 4 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x11, n: "FINGER_THRESHOLD5", d: "传感器 5 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x12, n: "FINGER_THRESHOLD6", d: "传感器 6 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x13, n: "FINGER_THRESHOLD7", d: "传感器 7 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x14, n: "FINGER_THRESHOLD8", d: "传感器 8 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x15, n: "FINGER_THRESHOLD9", d: "传感器 9 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x16, n: "FINGER_THRESHOLD10", d: "传感器 10 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x17, n: "FINGER_THRESHOLD11", d: "传感器 11 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x18, n: "FINGER_THRESHOLD12", d: "传感器 12 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x19, n: "FINGER_THRESHOLD13", d: "传感器 13 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x1A, n: "FINGER_THRESHOLD14", d: "传感器 14 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x1B, n: "FINGER_THRESHOLD15", d: "传感器 15 触发判定阈值(31-200)", min: 31, max: 200, r: 0 },
    { a: 0x1C, n: "按下消抖", d: "连续扫描次数；只影响按下，增大会变慢", min: 1, max: 15, r: 0 },
    { a: 0x1D, n: "触摸迟滞", d: "自动或 0–31；ON=FT+迟滞，OFF=FT−迟滞", min: 0, max: 255, r: 0 },
    { a: 0x1F, n: "低基线复位 LBR", d: "连续低 RAW 样本数；保持芯片值", min: 0, max: 255, r: 0 },
    { a: 0x20, n: "负噪声阈值 NNT", d: "人工比例须依据实触信号；保持芯片值", min: 0, max: 255, r: 0 },
    { a: 0x21, n: "噪声阈值 NT", d: "人工比例须依据实触信号；保持芯片值", min: 0, max: 255, r: 0 },
    { a: 0x26, n: "PROX_EN", d: "接近感应复用: 把 CS0/CS1 变成接近传感器。会牺牲这两个按键电极——音游严禁", min: 0, max: 3, r: 1 },
    { a: 0x4C, n: "特殊输出 SPO_CFG", d: "硬件输出配置；只读", min: 0, max: 255, r: 0 },
    { a: 0x4D, n: "按钮信号滤波", d: "中值抑制尖峰；IIR 平滑会增加响应时间", min: 0, max: 255, r: 0 },
    { a: 0x4E, n: "DEVICE_CFG1", d: "系统诊断开关(SYSD_EN bit0)。官方建议保持 0", min: 0, max: 1, r: 0 },
    { a: 0x4F, n: "触摸阈值模式", d: "自动：芯片定阈值；手动：使用 FT。保留 ARST 等开关", min: 0, max: 255, r: 0 },
    { a: 0x50, n: "DEVICE_CFG3", d: "供电配置(bit0 SUPPLY_LOW_POWER)。本机 5V 内部稳压必须保持 0, 改 1 可能损坏芯片", min: 0, max: 1, r: 2 },
    { a: 0x51, n: "I2C_ADDR", d: "芯片 I2C 地址(8-119)。改错 = 固件彻底找不到芯片 = 变砖, 烧录时会被面板直接拒绝", min: 8, max: 119, r: 2 },
    { a: 0x52, n: "低功耗刷新间隔", d: "REFRESH_CTRL 低 6 位，1–25；每档 20ms，只读", min: 0, max: 255, r: 0 },
    { a: 0x55, n: "状态超时", d: "STATE_TIMEOUT 低 6 位，0–63 秒；只读", min: 0, max: 255, r: 0 }
];

// 仅开放官方触摸参数位；硬件映射和基线机制保持原值。
function mbrEditableMask(addr, base) {
    const enabled = base ? base[0] | (base[1] << 8) : 0xFFFF;
    if (addr >= 0x08 && addr <= 0x0B) {
        let mask = 0;
        for (let i = 0; i < 4; i++) if (enabled & (1 << ((addr - 0x08) * 4 + i))) mask |= 3 << (i * 2);
        return mask;
    }
    if (addr >= 0x0C && addr <= 0x1B) return enabled & (1 << (addr - 0x0C)) ? 0xFF : 0;
    return ({ 0x1C: 0x0F, 0x1D: 0x9F, 0x4D: 0x03, 0x4F: 0x08 })[addr] || 0;
}

function mbrValidateTable(table, addr, base = null, checkCrc = true) {
    const reasons = [];
    if (!table || table.length !== 128) return { valid: false, reasons: ["需要 128 字节表"] };
    if (!Number.isInteger(addr) || addr < 8 || addr > 119 || table[0x51] !== addr) reasons.push("表内地址与目标芯片不一致");
    const crc = mbrCrc16(table);
    if (checkCrc && (table[0x7E] !== (crc & 255) || table[0x7F] !== (crc >> 8))) reasons.push("表 CRC 不一致");
    if ((table[0x1C] & 15) < 1) reasons.push("按下消抖须为 1–15");
    if (table[0x1D] & 0x60) reasons.push("迟滞保留位须为 0");
    const enabled = table[0] | (table[1] << 8);
    for (let i = 0; i < 16; i++) {
        if ((enabled & (1 << i)) && (table[0x0C + i] < 31 || table[0x0C + i] > 200)) reasons.push(`CS${i} 阈值须为 31–200`);
    }
    if (base) {
        for (let i = 0; i < 0x7E; i++) {
            if ((table[i] ^ base[i]) & ~mbrEditableMask(i, base)) {
                reasons.push(`0x${i.toString(16).toUpperCase().padStart(2, "0")} 修改超出安全参数`);
                break;
            }
        }
    }
    return { valid: reasons.length === 0, reasons };
}

function calcXorSum(buf) {
    let s = 0;
    for (let i = 0; i < CFG_SIZE - 1; i++) s ^= buf[i];
    return s;
}

// ====== 流头消费(round54e, 纯函数) ======
// frame = 完整 6 字节 0xBC 探测帧;  partial = 单元未收齐;
// echo  = 遗留 0xB0 回显字节;        magic  = 配置块首字节 0x88;
// line  = 完整文本行;                empty  = 缓冲区空
function streamConsumeHead(buf) {
    if (buf.length === 0) return { type: "empty" };
    const b0 = buf[0];
    if (b0 === CMD.DETECT) {
        return buf.length >= 6 ? { type: "frame", data: buf.slice(0, 6), used: 6 } : { type: "partial" };
    }
    if (b0 === CMD.DEV_DETECT) return { type: "echo", used: 1 };
    if (b0 === CFG_MAGIC) return { type: "magic" };
    const nl = buf.indexOf(10);
    return nl >= 0 ? { type: "line", data: buf.slice(0, nl + 1), used: nl + 1 } : { type: "partial" };
}

function parseProbeFrame(f) {
    return { mprMask: f[1], mbrMask: f[2], tofCount: f[3], flags: f[4], cfgHwVer: f[5] };
}

// 由探测结果推断硬件真值 hwVer(芯片布局决定触摸管线):
// MPR121 在位 -> 1/2; MBR@0x43/0x44 (v2 布局) -> 3/4; MBR@0x40-0x42 (v1 布局) -> 1/2
function hwVerFromProbe(p) {
    const is32 = p.tofCount === 5;
    if (p.mprMask) return is32 ? 2 : 1;
    if (p.mbrMask & 0b110000) return is32 ? 4 : 3;
    if (p.mbrMask & 0b001110) return is32 ? 2 : 1;
    return null;
}

// round81: hwVer → 「代际·尺寸」全称(固件权威映射: hw1=27寸三主控/v1 布局,
// hw2=32寸三主控/v1 布局, hw3=27寸双主控/v2 布局, hw4=32寸双主控/v2 布局)。
// 「API / 硬件」信息框用全称消歧——裸 "v2" 是 hwVer 数值, 曾被用户误读为
// "二代机"(32寸一代机 = hw2, 显示应为 v1·32寸)。
function hwVerLabel(v) {
    if (!(v >= 1 && v <= 4)) return "-";
    const size = (v === 2 || v === 4) ? "32寸" : "27寸";
    const gen = (v === 3 || v === 4) ? "v2" : "v1";
    return `${gen}·${size}`;
}

// ====== UF2 解析 ======
// 解析 UF2(512B 块结构)并重建镜像用于字符串扫描。RP2040 镜像按地址
// 连续排列(elf2uf2 输出), 串可能跨 256B payload 边界, 故重建后整体解码。
function parseUf2(buf) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    if (u8.length === 0 || u8.length % 512 !== 0) throw new Error(`文件大小 ${u8.length} 不是 512 的整数倍,不是有效的 UF2`);
    const parts = [];
    const res = { blocks: 0, totalBlocks: 0, family: null, mixedFamily: false, noFamilyBlocks: 0,
                  flashStart: null, flashEnd: null, contiguous: true, image: null,
                  sig: null, fwMarker: false, versionCandidates: [] };
    let expectedAddr = null;
    for (let off = 0; off < u8.length; off += 512) {
        const m0 = dv.getUint32(off, true), m1 = dv.getUint32(off + 4, true);
        const mend = dv.getUint32(off + 508, true);
        if (m0 !== UF2_MAGIC0 || m1 !== UF2_MAGIC1 || mend !== UF2_MAGIC_END) {
            throw new Error(`块 ${off / 512} UF2 magic 不匹配,文件已损坏或不是 UF2 格式`);
        }
        const flags = dv.getUint32(off + 8, true);
        const addr = dv.getUint32(off + 12, true);
        const payloadSize = dv.getUint32(off + 16, true);
        const blockNo = dv.getUint32(off + 20, true);
        const total = dv.getUint32(off + 24, true);
        const famOrSize = dv.getUint32(off + 28, true);
        if (payloadSize > 476) throw new Error(`块 ${blockNo} payload 大小异常: ${payloadSize}`);
        if (flags & UF2_FLAG_FAMILY) {
            if (res.family === null) res.family = famOrSize;
            else if (res.family !== famOrSize) res.mixedFamily = true;
        } else {
            res.noFamilyBlocks++;
        }
        if (blockNo !== res.blocks) throw new Error(`块序号不连续: 期望 ${res.blocks},实际 ${blockNo}`);
        if (res.flashStart === null || addr < res.flashStart) res.flashStart = addr;
        if (addr + payloadSize > res.flashEnd) res.flashEnd = addr + payloadSize;
        if (expectedAddr !== null && addr !== expectedAddr) res.contiguous = false;
        expectedAddr = addr + payloadSize;
        parts.push(u8.subarray(off + 32, off + 32 + payloadSize));
        res.blocks++;
        res.totalBlocks = total;
    }
    if (res.totalBlocks !== res.blocks) throw new Error(`总块数不匹配: 头部 ${res.totalBlocks},实际 ${res.blocks}`);
    if (res.flashStart < RP2040_FLASH_BASE || res.flashEnd > RP2040_FLASH_BASE + RP2040_FLASH_SIZE) {
        throw new Error(`烧写地址范围 0x${res.flashStart.toString(16)}-0x${res.flashEnd.toString(16)} 不在 RP2040 flash (0x10000000-0x10200000) 内`);
    }
    // 重建镜像并做 Latin-1 解码(ASCII 字符串扫描用)
    const img = new Uint8Array(res.flashEnd - res.flashStart);
    let cur = res.flashStart;
    for (const p of parts) { img.set(p, cur - res.flashStart); cur += p.length; }
    res.image = img;
    let text = "";
    for (let i = 0; i < img.length; i += 4096) {
        text += String.fromCharCode.apply(null, img.subarray(i, Math.min(i + 4096, img.length)));
    }
    const sig = text.match(/NYANFW1;([^;\x00\s]+);([^;\x00\s]+)(?:;BID=([^;\x00\s]+))?/);
    if (sig) res.sig = { version: sig[1], variant: sig[2], buildId: sig[3] || null };
    res.fwMarker = text.includes("FW:%s API:0x");
    // 旧固件版本启发式: FW 版本宏串在 rodata 中紧邻 "FW:%s API" 格式串(隔 NUL),
    // 比"全镜像唯一 semver"更准(镜像里还有 SDK 版本 2.2.0 等干扰串)。
    if (res.fwMarker) {
        const fi = text.indexOf("FW:%s API:0x");
        const win = text.slice(Math.max(0, fi - 32), fi);
        const vm = win.match(/(\d+\.\d+\.\d+)\x00*$/);
        res.versionHeuristic = vm ? vm[1] : null;
    }
    const sem = text.match(/[^0-9A-Za-z_.](\d+\.\d+\.\d+)[^0-9A-Za-z_.]/g) || [];
    res.versionCandidates = [...new Set(sem.map(s => s.replace(/[^0-9.]/g, "")))];
    return res;
}

function cmpVersion(a, b) {
    const pa = a.split(".").map(p => parseInt(p, 10)), pb = b.split(".").map(p => parseInt(p, 10));
    for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0); }
    return 0;
}

// round88f: BID("roundNNx")单调序比较。N = 主序, 字母后缀按
// round88 < round88a < ... < round88z < round89 排序(多字母取首字母,
// 与字典序一致)。无法解析/缺 BID 返回 -Infinity,与白名单拒绝同判。
// 取代 round88e 的硬编码枚举白名单: 每发一个新构建都要同步加白名单,
// 否则设备升级到新固件后"安全恢复"即被自身旧面板拒绝(前向兼容断裂)。
function cmpBuildId(bid) {
    const m = (bid || "").match(/^round(\d+)([a-z]?)/);
    if (!m) return -Infinity;
    return Number(m[1]) + (m[2] ? (m[2].charCodeAt(0) - 96) / 26 : 0);
}

// devInfo: {fw, api, hwVer, var, sig, raw} 或 null
function validateUf2ForDevice(p, devInfo) {
    const errors = [], warnings = [];
    if (p.family !== RP2040_FAMILY_ID) errors.push(`UF2 family 0x${(p.family ?? 0).toString(16)} 不是 RP2040 (0x${RP2040_FAMILY_ID.toString(16)}),拒绝刷写`);
    if (p.mixedFamily) errors.push("混合 family ID,拒绝刷写");
    let version = null, variant = null;
    if (p.sig) {
        version = p.sig.version;
        variant = p.sig.variant;
        if (!["hw_v1", "cplay"].includes(variant)) warnings.push(`未知变体 "${variant}"`);
    } else {
        if (!p.fwMarker) warnings.push("未找到 Nyanithm 固件标记(FW:%s / NYANFW1),可能不是 Nyanithm 固件");
        else warnings.push("旧版固件(无 NYANFW1 签名,<1.5.3):变体无法校验");
        version = p.versionHeuristic || (p.versionCandidates.length === 1 ? p.versionCandidates[0] : null);
        variant = null;
    }
    if (devInfo) {
        if (devInfo.var && variant && devInfo.var !== variant) {
            warnings.push(`变体不匹配:固件=${variant},当前设备=${devInfo.var}。cplay 特调(电极阈值/孤立电极惩罚)刷到标准 hw_v1 设备(或反向)会改变触摸手感甚至引脚行为`);
        }
        if (!devInfo.var) warnings.push("当前设备固件较旧(无变体信息),无法自动校验设备匹配性");
        if (devInfo.fw && version && cmpVersion(version, devInfo.fw) < 0) {
            warnings.push(`版本降级:设备当前 ${devInfo.fw} → 文件 ${version}`);
        }
    } else {
        warnings.push("未连接设备或未读取设备信息,跳过设备匹配检查");
    }
    return { errors, warnings, version, variant };
}
