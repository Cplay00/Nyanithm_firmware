# ControlPanel v1 翻新 - 开发日志(三代 webui -> 一代 hw_v1 合并)

日期:2026-08-24
基线:三代 `nyanithm-control-panel/ControlPanel_Master.html`(v3-beta)+ 一代
`Nyanithm_firmware_hw_v1/ControlPanel_v1.html`(2644 行,round54e 版,固件 1.5.3)

## 产物

- `ControlPanel_v2.html`(约 1.13 MB,单文件)——三代 UI 壳 + 一代协议引擎 + 一代功能全集
- `preview_mock_dark.png` —— Mock 模式下的整页预览

## 构建管线(可重跑)

```
py -3 extract_base.py   # 上游 25.53MB → ControlPanel_v2.base.html(1.03MB,剥 404 个 Noto Sans SC 子集)
py -3 build.py          # base + src/ 四个源文件 → ControlPanel_v2.html
```

`src/` 目录:
| 文件 | 内容 |
|---|---|
| `head_patch.css` | 新增区块样式(指标行/ToF/LED/日志/弹窗/输入控件),全部复用三代设计令牌 |
| `body_main.html` | 新 `<main>` 区域;`{{INPUTTEST}}` 占位符从 base 切片回填(base64 版画不手抄) |
| `app_core.js` | 协议核心:命令表/配置位/MBR 六张表+CRC/UF2 解析校验/纯函数(与一代面板逐字对齐) |
| `app_ui.js` | 一代引擎(串口事务锁/流式会话/门禁/刷写状态机)+ 三代组件(odometer/滑条/双确认/主题/入场动画)+ Mock 设备 |

本地查看:`py -3 -m http.server 8765` 后开
`http://127.0.0.1:8765/ControlPanel_v2.html?mock=1`(Mock 全自动演示);无 `?mock=1` 为真机模式。

## 与一代基线的对应关系

- 协议命令、配置结构体(cfgVer 0x02 / hwVer 1-4 / MPR121 阈值 / 去抖 / airMax/Min /
  heightOffset[5] / lightLimit / heightRange / xorSum)、0xBC 门禁、round54e 流式会话、
  round54 全自动刷写(BOOTSEL 盘识别→FS Access 写入→自动重连→版本验证)全部按
  ControlPanel_v1.html 原样移植。
- 三代仅存的 `0xB7 重启进 BOOTSEL` 刷写路径未采用,保留一代 `0xBB 0xA5` 全流程。
- UI:三代开场动画/主题/页头/输入测试版画原样保留;状态栏 odometer 改为
  AIR低/AIR高/触摸阈值/亮度;新增灯光测试、ToF 状态、日志面板;设置面板为一代字段全集
  (hwVer 四档分段选择器替代原下拉)。
- 署名:NyaLab/CATIUM/NEKOTECH 页脚与 LOGO 原样保留。

## 本轮浏览器验证(Mock,2026-08-24)

已通过:无 JS 报错/无横向溢出;自动连接→握手→API 0x10→0xBD 版本显示;
输入轮询(FPS/包数/压感渲染);进配置模式(流式会话+0xBC 门禁+交叉核对);
配置读取(滑条/odometer/状态栏同步,数值 200/500/6/4/100);ToF 状态解析;
保存双确认(0xB7"check ok"→0xB5);退出重启(confirm);重连;彩虹灯光+FPS+停止;
MBR 区随「使用 3116」显隐(芯片列表/阈值 128);主题切换。

## 遗留事项(发布前)

1. **devDiag 错误诊断条**:`body_main.html` 顶部的红条 `window.onerror` 钩子为开发期
   辅助,发布前移除(约 20 行)。
2. **真机验证清单**(浏览器无法覆盖):
   - VID 0xCAFE/PID 0x4009 过滤选口、错误设备拦截(0xBC 门禁失败路径)
   - 配置读→改→存→重启→回读一致性;触摸手感(HID 游戏内)
   - 0xB2 灯光(31/16 灯、b,r,g 字节序、lightLimit 缩放)
   - ToF 连续轮询;0xBA 烧录 3116(NVM 写入耗时数秒)
   - UF2 全自动刷写(选文件→校验→BOOTSEL→写盘→自动重连→版本/变体验证)
   - cplay 设备交叉(VAR:cplay 与 UF2 变体校验)
3. **许可证**:上游 CC-BY-NC-ND 4.0,ND 条款不授权再分发修改版;本合并版仅限
   内部/授权范围使用,公开发布前需解决授权。
4. 可选优化:32" 设备上 ToF4/偏移字段显隐联动已实现,但未在 32 寸真机回归。

## 踩坑记录(对未来维护有用)

- `navigator.serial` 在原型上只有 getter,严格模式直接赋值抛 TypeError——Mock 注入
  必须用 `Object.defineProperty`。
- build.py 曾用 `find("    <script>")` 定位主脚本,匹配到了头部 8 空格缩进预载脚本
  的子串,把整个 `<body>` 吞掉(页面只剩 CSS 动画在跑)。现锚定
  `    <script>\n        (function () {` 并断言位于 `</main>` 之后。
- 健全性检查要选"只可能来自页面主体"的标记(toggleInputBtn/ledStrip/app-footer 等),
  否则脚本内容会让误报通过。
- updateUI 中"配置模式工具组"与"进入配置模式"按钮的禁用逻辑方向相反,拆成两组。

## round55 阶段(阶段2,2026-08-24):cfg2/cfg3 新功能 + 发布就位

- 定性改为一代面板翻新(仍 v1);`--release` 构建已剥 devDiag 诊断条
- 固件(hw_v1 与 cplay 双树同步):
  - `nyanithm_shared.h`: `CFG2_BIT_DISABLE_LAMP_ARRAY`(bit0,disable 语义)、`INPUT_LATENCY_MAX_MS=15`
  - `lamp_array.cpp`: cfg2 bit0 门禁 + 一次性清灯(clearedOnDisable 锁存)
  - `chuni_io.cpp`: CMD_GET_INPUT seqlock 成功分支加帧龄门禁(memcmp 变更检测 + latencyFrameMs;
    cfg3=0 与 round47b 逐字节等价)
  - `controller_config.cpp`: sanitizeConfig cfg2 掩码 / cfg3 钳位;checkConfigBuf 未动(完全后向兼容)
- 面板:`ckLampArray` 复选框(勾=开)+ `rgLatency` 滑条 0-15ms;pack buf[5]/buf[6],
  unpack 反向;禁用态表/sliderDigits(2位)/mock 默认 0/擦除时 rawLightLimit 复位
- 审计修复回归:lightLimit 原字节保真(rawLightLimit,读->不改->存回写原字节);
  保存前 finishSliderAnims() 收敛在途动画;手台模式确认固件无字段(byte7=th_touch)不加
- 验证:Mock 往返(关灯+7ms 回读一致/复位归零/lightLimit 255 保真)、gen2 门禁(3×ToF 拦截,
  alert 阻塞为预期)、无 JS 错误;test_round50_migration 43/43;双变体编译
  (hw_v1 SHA1 668D81EA…,cplay SHA1 B572DACE…)
- 就位:release HTML 已覆盖两树 `ControlPanel_v1.html`(旧版备份于
  `_dev_archive/controlpanel_backup_2026-08-24/`);更新日志两树已加 round55 条目;未提交
- 真机待办:cfg3 手感调校、LampArray 开关实际效果、旧配置升级路径(旧固件会把非零
  cfg2/cfg3 原样存 flash,升级 round55 后生效)


## round56 阶段(2026-08-24):按钮合并 / 固件弹窗 / 文字与 UI 调整

- 按钮合并: 读取并入进入配置模式; 退出并重启并入进入配置模式按钮(进入后图标切换); 恢复默认独立; 工具栏精简为 连接串口/保存设置/更新固件
- 固件刷写独立弹窗: flashBtn 直接开弹窗; 选文件/校验/覆盖/手动/自动/状态全在弹窗内; btnStartFlash 即最终确认
- 普通模式直读 hwVer(0xBD)并同步硬件版本选择器
- 文字: 三主控/双主控; 备注补 v1 支持两种主控; 导入/导出配置 + 图标
- 文字 UI: field-hint/section-subtitle/副标题统一 fs-sm+opacity 0.4; 警告红; 阈值+消抖滑条 >=125% 警告线转橙红(.warn/.danger 类)
- Log 自适应: 纳入 app-main 网格, 高度差>15px dock 到矮列, 平滑过渡
- 验证: Mock 全流程 + 43/43 迁移 + 25/25 逻辑 + 5/5 UF2; 双树部署字节一致; 未提交


## round57 阶段(2026-08-24):Log 修正 + 工具栏精简 + 配置模式心跳

- Log: 仅 2 列布局且高度差>15px 才 dock; 单列(窄屏)保持全宽(修复 grid-column:2/3 落空列恒占全宽 bug)
- 工具栏: 移除保存设置; 连接/更新固件均分拉伸
- 按钮: 保存并重启/恢复默认 进入配置前禁用; 保存并入保存并重启(二级确认); 导入/导出移到按钮区下方
- 心跳(新): CMD_CFG_KEEPALIVE=0xC3 固件静默重置 60s 计时器; 面板每 30s 发送, 退出/断开停止
- 验证: 43/43 + 25/25 + 5/5; 双树含 keepalive 编译通过; Mock 24s 心跳无污染; 未提交


## round58 阶段(2026-08-24):禁用灰度 + 导入导出修复 + 刷写自动进配置 + 文案

- 全局 disabled 灰度(opacity 0.7 + 文字变灰 + not-allowed); 未连接全部禁用(仅连接串口保留, 更新固件未连接禁用)
- 文案 重新插拔→重启
- 导入/导出放宽为已连接可用; 导出普通模式=表单值/配置模式=设备值
- 刷写未进配置自动进入(抽 enterConfigMode 复用)
- 验证: 43/43+25/25+5/5; Mock 全过; html 未更新实为 IAB 浏览器缓存(服务端文件已新版), 部署后刷新即见效
- 未提交


## round58b 阶段(2026-08-24):Log dock 修复

- 核对服务端/部署文件均为 round58 新版, html"未更新"为 IAB cache; 部署后硬刷新即见效
- Log 恒占全宽根因: build 后 .panel-log 落在 <body> 下(非 .app-main grid 子项), grid-column:2/3 无效 → 改 JS 把 Log 移入 .app-main
- 判定改用内容自然高(scrollHeight), 避免 grid stretch 拉平两列容器掩盖真实高度差
- 效果: Log dock 到右列下方, 宽与右列一致; 截图确认
- 未提交

## round58c(2026-08-24): Log 初始全宽 + load 后就绪判断
- 初始不立即测量(全宽默认), 统一 window.load + 120ms 后实时判高度差; 规则①/②确认
- 未提交

## round58d(2026-08-24): Log 初始 2s 全宽 + 实判
- dockingEnabled 门控 2s 内抑制重测; 2s 后按两栏内容自然高 dock; 右栏展开增高超过左栏时切 dock-left
- 未提交

## round59(2026-08-24): 品牌文字 Gen 1 + Log dock 规则重设
- 开屏副标题 For Gen 1; 顶部 MASTER→CONTROLLER GEN 1(文本替换图片)
- Log dock: 用户确认普通模式全宽/差异明显才收窄 → 阈值 90px, 用两栏内容自然高(scrollHeight); 普通模式差值 ~76px 保持全宽
- 未提交

## round60(2026-08-24): Log 固定左栏 + 开屏/页头文字
- Log 改为固定左栏下方(弃高度差 dock 迁移); 开屏 'CONTROL PANEL FOR GEN 1'; 页头 'CONTROLLER GEN 1' 字体增至 24px(高26=logo26)
- 未提交

## round61(2026-08-24): 移除设备信息窗口 + 固件版本点击弹详情 + 信息格自适应
- 移除 devInfoVal 宽窗口; 固件版本卡点击弹 infoDetailModal(显示 0xBD info), hover 高亮; 四格换行/增高/对齐(grid-auto-rows 1fr)
- 未提交

## round62(2026-08-24): Log 固定置于左侧栏、设备状态下方
- Log 从 app-main 网格拆出, 放入 .test-column 内 panel-tof 之后, width:100% 撑满左栏; 不再用网格自适应
- 未提交

## round70(2026-08-26): 移除逐键网格 + 气泡复用 slider-row + INPUT TEST 始终真实压力
- 需求1: 移除参数调节区 perKeySection 32 格网格区块(HTML/JS/CSS 全清, 含 .pk-cell 样式);
  保留 perKeyHint 单行提示(配置模式+固件支持时显示"点击 INPUT TEST 格子可编辑")
- 需求2: 逐键气泡(pkBubbleModal)复用参数调节区 slider-row 结构:
  触发阈值/th_touch (per-key) + 释放阈值/th_release (per-key) 各一套
  slider-label + slider-label-en + slider-value(odometer 2位) + slider-track 滑条 + field-hint;
  数显走 initSliderAnimations 的 odometer 路径, 新 setPkVal() odometer 感知写值
- 需求3: 统一 startInputPolling() 入口(自动开 0xC5 压力会话 + 启动轮询), 替换
  connectBtn/保存重启重连/刷写重连/校准向导四处重复启动逻辑; 修复"连接后 INPUT TEST
  只报 128"根因(此前自动路径不发会话开关, 固件只能回 1.5.x 二进制帧);
  toggleInputBtn 回调改 async
- 校准文案: "逐键网格" → "逐键阈值"/"INPUT TEST 气泡"
- 验证: release 构建(devDiag=0); Mock 全链路(连接即真实压力 tc1:当前7/阈值42、
  气泡开合/滑条联动/恢复继承/保存重启重连、gen2 门禁 3×ToF 拦截); 68/68 迁移测试;
  无 JS 错误(仅 favicon 404); 已部署两树 ControlPanel_v1.html(SHA1 28eb781f…)
- 未提交

## round71(2026-08-27): 面板易用性优化(校准向导/阈值展示/语义高亮/主题联动)
- 需求1: 一键校准改三屏向导弹窗(#calWizardModal 取代 round70b 报告 Toast):
  intro(两轮规则说明:20s 静置+15s 触摸)→ running(conic-gradient 环形倒计时+
  阶段文案,calAbort 可中止)→ result(报告+「确认并开始修改」按钮更名,
  沿用 calPendingBackfill+自动进配置模式);Mock 下时长 ÷20 加速,真机不变
- 需求2: "配置模式下点击 INPUT TEST 格子可编辑阈值"提示从裸 field-hint 升级为
  Configuration 区 .config-warning 叹号行(#perKeyHint 移位,显隐逻辑不变)
- 需求3: 配置模式下 INPUT TEST 格子显示生效触摸/释放阈值(updateTcThresholdDisplay,
  事件驱动:进配置解包/改滑条/气泡编辑时刷新,退出/断开恢复压力基线;
  两值上下两行/单值居中,颜色 var(--c-accent) 随主题)
- 需求3b: 格子压力亮度按传感器原生量程线性映射(MPR 63/MBR 255,原固定 /255 导致
  MPR 满按只有 0.51 亮度);未开压力会话的恒定 128 判定帧直接全亮
- 需求4: 低强调文字提亮 ≈15%:--c-text-tertiary 暗色 #606060→#6f6f72、
  亮色 #8A8B8E→#999a9e(补丁层覆写);说明小字 opacity .4→.55;
  .input-test-hint .5→.65
- 需求5: 按钮语义高亮:连接串口=黄(btn-connect-acc,updateUI 切)/断开连接=红
  (btn-disconnect-danger)/更新固件=橙警示(btn-flash-warm,变砖风险);
  顺手补恢复默认红描边/保存并重启绿描边
- 需求6: 图标更换:连接串口十字形→USB 插头,更新固件闪电→芯片+下箭头
- 需求7: closeModalAnimated 通用退出动画助手(抽自 closePerKeyBubble),应用于
  固件更新弹窗/设备详情弹窗/校准向导/逐键气泡;openModalAnimated 配套
  (_hideTok 代际令牌防"关后 400ms 内重开被旧定时器杀掉"竞态)
- 需求8: Light Test 默认准备色随主题 accent(getAccentHex 读 --c-accent,
  初始化+主题切换后 1150ms 联动,已连接且空闲时补发一次 0xB2)
- review-agent 复查修复 4 项:D1 calWizardApply 裸调 enterConfigMode 改
  withSerialLock(防与输入轮询撞车);C1 closeModalAnimated 代际令牌;
  A1 handleUnexpectedDisconnect 补 updateTcThresholdDisplay;
  B1 校准取消/中止时 calRevertBackfill 撤销回填并还原滑条快照
- 验证: release 构建(devDiag=0);Mock 全链路(向导 intro→倒计时→报告→确认→
  自动进配置→格子阈值 13/12 两行展示→取消路径滑条还原 13→6→apply 路径回填保持;
  气泡快速关-开竞态存活;MPR 量程亮度 v=10→0.45;主题切换暗黄↔亮蓝跟随;
  保存链路 CFG_SET "read 128 byte. check ok"+"保存并重启完成,已自动重连";
  gen2 门禁 3×ToF 拦截);仅 favicon 404,无 JS 错误;未经真机验证
- 已部署两树 ControlPanel_v1.html(SHA1 db9d37c4…);未提交

## round71b(2026-08-27): odometer 数字带 9→0 连续滚动(旋转计数器式)
- 需求: 数字翻滚动画中 9→0 不再"倒转回去"(translateY -9em→0em 反向),改为与
  机械计数器一致连续下滚:条带末尾追加 0 副本(第 11 格),9→0 滚到副本位,
  transitionend(+450ms 兜底,页签隐藏时 transitionend 不触发)后无动画瞬间归位
- 实现(app_ui.js createOdometer/setOdometerValue): digits 增加 pos/snapTimer 状态;
  snapOdometerStrip 关 transition 强制回流后还原;setOdometerValue 遇 pos=10 先
  立即归零再计算本次位移(副本与 0 视觉同位,无闪烁);非 9→0 路径清兜底定时器
- base 开屏动画内同名 odometer 为独立作用域,未改动;smoothSliderTo 走
  updateSliderOut→setOdometerValue 自动兼容
- 验证(Mock): 9→10 末位滚向副本 0 后 snap 归位、11 继续 +1;29→30/59→60/69→70/
  79→80/89→90/99→100(三位同时 9→0)/109→110/159→160/199→200/299→300/399→400/
  499→500/599→600/999→1000 连续滚动截图确认;中间帧抓拍显示 9→0 为下滚无倒转;
  反向 0→9(200→199)正常回滚;大跨度跳变正常;终态 pos 干净(无残留 10);
  量程外(r AirMax 250-800 之外)钳制行为不变。仅 favicon 404 无 JS 错误
- release 构建(devDiag=0)已部署两树 ControlPanel_v1.html(SHA1 c8375729…);未提交

## round71c(2026-08-27): 终审视觉审查修复——主题联动灯色作用域 bug
- 终审(视觉审查)发现: initThemeToggle 是独立顶层 IIFE, 引用主 IIFE 内的
  syncLedDefaultColor 触发 ReferenceError, 被空 catch 静默吞掉 =>
  主题切换后 Light Test 默认色从不联动(亮色应 #0d44d4 实际停留 #ffd60a)
- 修复: 主 IIFE 启动序列挂 window.__syncLedDefaultColor = syncLedDefaultColor;
  THEME TOGGLE 回调改为 window.__syncLedDefaultColor(true)
- 回归: 暗↔亮双向切换灯色跟随(#ffd60a↔#0d44d4,1400ms 处读取确认);
  视觉审查其余项(暗/亮主题、向导三屏、running 环形倒计时、result 报告、
  配置模式格子阈值两行展示、叹号提示行、按钮语义高亮、图标)全部通过
- release 构建(devDiag=0)已部署两树 ControlPanel_v1.html(SHA1 001fb562…);未提交

## round71d(2026-08-27): 终审 P3 加固 + 真机验证收尾
- review-agent 终审结论「可发布,无 P0-P2」;两条 P3 已落:
  1) handleUnexpectedDisconnect 中 calRunning 时置 calAbort,断线中止校准向导
     (防跑完弹出基于陈旧帧的伪统计报告)
  2) THEME TOGGLE 桥接处空 catch 改 console.warn + 桥接缺失前置检查
     (防同类作用域 bug 再被静默吞掉)
- 终审同时确认: withSerialLock 对 ()=>enterConfigMode() 完整 await(锁释放在
  配置模式建立/失败返回之后);odometer snap 双路径互斥幂等;e.target===strip
  过滤挡住 theme-transition 子 span 的 color transitionend;innerText setter
  整体替换子节点(阈值 span 与压力数字无残留叠加);CFG_SET 两次写入/0xC3 心跳/
  0xB2/0xC5 时序全部零触碰
- 真机验证(COM1, cplay 固件 1.6.0 API 0x10, _dev_tools/realtest_round71_final.py):
  0xBD 版本 PASS / 0xC5 开会话 RAW=1 PASS / 0xB1 帧×30 PASS(静止压力 max=4) /
  压力值域 PASS / 0xC5 关会话 RAW=0 PASS / 0xB3 进配置 PASS(判据=0xBD→
  unknown command;固件 Core1→Core0 异步移交,无即时响应文本——v1 脚本等响应文本
  判定属测试方法错误,非固件问题) / 0xB4 读配置 PASS(magic 0x88 ver 0x02) /
  0xB9 退出重启后 0xB1 恢复 PASS
- release 构建(devDiag=0)已部署两树 ControlPanel_v1.html(SHA1 c1d11d80…);未提交

## round75(2026-08-29): 0xBA 烧录链路加固(双写+verify 行)+ 意外断开自动重连 + 按钮代号清理
- 用户(v1 3116 三主控)实机报告:阈值无法烧录 / 经常连接不上 / 游戏内触摸抬手卡住;
  截图日志 22:34:41 面板 3116 操作 → 22:34:43 "The device has been lost"——间隔恰为固件 2s 看门狗
- **根因(固件侧,同轮修)**:0xBA 处理器无界 `getchar()` 读 1+128B,不泵 tud_task/不喂狗;
  面板单次 130B 写被 USB 层拆 [64][64][2],尾包 NAK 后固件永等 → Core0 卡死 → 2s 复位
  (round63c 在 0xB7 修过的同款机制,0xBA/0xBB 漏修;round63i 双写铁律未覆盖 0xBA)
- 面板修复:
  1. **0xBA 改双写**(对齐 doSaveConfig 的 CFG_SET round63i 模式):先单独 `writeBytes([0xBA])`
     再 `writeBytes(addr+128B)`,固件进入载荷读取后逐包重武装,稳定续流;
  2. **verify 诊断行**:新固件烧录后回读阈值寄存器 0x0C 追加 `verify ok/mismatch/skipped`
     行,面板 done 后短超时(600ms)可选读取展示——"阈值无法烧录"从此可见真因;
  3. **意外断开自动重连**:此前仅保存重启/刷写两条流程有自动重连,普通断开(设备看门狗
     复位/掉电)后面板停在"连接已断开"必须手点连接。新增 unplugWatch(15s/1s 轮询,
     复用 save-reboot 机制,openPort(quiet)+autoHandshake+startInputPolling),
     从 handleUnexpectedDisconnect 触发;closePort 停表、startReconnectWatch 接管时停表,
     刷写重连激活时让位不双开;
  4. **「应用于手台 (0xBA)」按钮代号清理** → 「应用于手台」(用户要求);
  5. Mock:LOAD3116CONFIG 与 CFG_SET 同理状态化累积(mbrPending,129B 跨 write),
     应答追加 "verify ok" 行——双写后旧 Mock 会把第二笔 write 当 unknown command。
- 配套固件(app_link.cpp/production_mode.cpp):readCdcPayload 有界读取(0xBA 1s/0xBB 500ms
  超时)、0xBA 地址白名单(0x37/0x40-0x44)、烧录后 verify 回读;详见 更新日志_固件.md round75
- **注意**:旧固件下仅更新面板无法避免复位(无界 getchar 在设备端),该用户必须同时刷新固件
  UF2 + 更新面板;刷好后对 0x40/0x41/0x42 逐颗「载入固件模板→应用于手台」覆盖恢复坏状态
- 验证:build --release devDiag=0;Mock ?mock=1 走 3116 区双写烧录+verify 行;
  **未经真机验证**(0xBA 真机三芯片烧录、断开重连回归待硬件在手)
- **审查轮(2026-08-30)**: 双 SecReviewer 只读审查(固件+面板)+CDC 状态机 Python 仿真
  10/10+elf2uf2 白名单三场景实测。修复审查发现:①[P2]elf2uf2 仓库根改 CMakeLists.txt
  标记向上派生——复制到 D:\Nyanithm_build 的 fallback 副本此前会经 parents[1] 把白名单
  放宽到整个 D 盘,现派生不出仓库根即只允许 D:\Nyanithm_build;②verify 读取窗 600→800ms
  (固件最坏 ~600ms 发出行);③0xBA 载荷改 129B 直建(删 pkt[0] 死存储);④Mock mbrPending
  补 1s 断流超时(mbrArm/mbrComplete,镜像固件);⑤openPort 入口幂等守卫 `if (connected)
  return true`(自动重连与手动点击竞态双开,存量+新增窗口一并关闭)。审查确认:双写时序
  无注入窗口(withSerialLock 全程持锁)、迟到 verify 行不污染任何后续事务(全部读路径
  先 flush)、三套重连定时器互斥干净、flashPhase allowlist 正确(bootsel-manual/
  manual-reconnect 本就被压制)。重新 build --release 部署(devDiag=0)。
  已知 Mock 局限:sendText delay 为 no-op,Mock 无法演练真机 600ms verify 窗口真实时延。
- **tools/ 去跟踪(用户决定,2026-08-30)**: mimosa git-gate 对 elf2uf2.py 的 argv 写入
  模式为模式级硬拦(白名单校验不认、移出暂存不认,按工作区变更扫),tools/ 整体移出
  版本控制(.gitignore+git rm --cached,本地保留,elf2uf2 白名单加固随本地文件生效);
  elf2uf2 仓库根探测为 CMakeLists.txt 标记法(复制副本无法放宽白名单)。

## round76(2026-08-29): 修 LED「无论如何只显示蓝色」——DTR 在位抑制 LampArray 抢写 + 主题默认色收敛
- 同一 v1 3116 用户报告灯带无论选什么颜色最终都只有蓝色。三路 Explore 全链路排查结论:
  - 固件全树无硬编码蓝(rainbow 蓝色扇区为死代码);面板/固件 0xB2 字节序一致(均 b,r,g);
    固定 31 灯无 hwVer 分叉;灯带唯一能"覆盖用户所选色"的机制=Windows 动态照明(LampArray)
  - **根因**:chuni_io.cpp standby 超时 CDC 静默 5s → game_connected=false → lamp_array_apply
    放行 Windows 按系统强调色(默认蓝)重刷灯带;cfg2 bit0 默认 0=LampArray 默认开启。
    LightTest 单帧 0xB2 后轮询一停/断开/复位,5s 后必被刷回;固件无法区分"面板还开着"与"已离开"
  - **帮凶**:round71 亮色主题 accent #0D44D4(蓝)页面加载即覆盖取色器默认值,主题切换还主动推帧
- 面板修复:
  1. **openPort 显式拉高 DTR**:`port.open()` 后 `setSignals({dataTerminalReady:true})`
     (try/catch,MockPort 补 no-op)——固件 standby 超时改为仅当 DTR 断开才回落 game_connected,
     面板/游戏握着端口期间 Windows 全程让位,端口真正关闭才恢复接管;
  2. **ledColorTouched 收敛主题联动**:预设/取色器/自定义发送置位,syncLedDefaultColor 开头
     让位——用户选过颜色后主题加载/切换不再覆盖取色器、不再推蓝帧;未动过用户保留 round71 体验;
  3. 动画运行中取色由静默忽略改为日志提示「先停止动画」
- 配套固件(chuni_io.cpp):standby 分支 `tud_cdc_connected()` 判定;详见 更新日志_固件.md round76
- 交付自诊断(终版用户):白光测试显示白=链路/字节序正常→查 Windows 动态照明或面板勾选关闭;
  白光异常=字节序/面板来源问题→核对面板版本(该用户此前截图面板为工作区外来源)
- 验证:固件 UF2 239616B SHA1 EF890529;release 面板 devDiag=0 部署 SHA1 3D0E439F;
  Mock ?mock=1 回归;**未经真机验证**(DTR 抑制/恢复时序需真机)
- **审查轮(SecReviewer,无 P0/P1,「可发布」)**:采纳加固——①setSignals 失败记 warn
  (原 catch 空吞,修复失效零痕迹);②closePort 显式 `setSignals({dataTerminalReady:false})`
  兜底(P2 前置保险:若 OS 在 port.close() 不反断言 DTR,"关闭面板→动态照明恢复"会退化为
  需重插);③动画中取色警告按会话去重(ledAnimWarned,stopLedAnim 复位),防取色器拖拽刷屏;
  ④亮色主题初始取色器 stale 对齐(主 IIFE 的 syncLedDefaultColor 早于主题 IIFE 应用已存
  主题执行)。核实通过项:game_connected 全树唯一读者=lamp_array.cpp:81;Core1 调
  tud_cdc_connected() 有 round66 先例且在 tud_task 泵后;49.7 天回绕安全;配置模式早退
  先于 standby 分支行为不变;非 DTR 宿主(DLL)行为与旧版逐字节等价;fresh 用户 round71
  链路不变;部署件与源码逐标记一致。**P2 真机验证项**:面板开→选色→关面板→6s→
  Windows 重绘应恢复;另补测直接关标签页路径。

## round76b(2026-08-30): 修「更新固件」无法进 BOOTSEL——0xBB/0xA5 双写 + 固件确认窗 5s
- 用户报告:面板更新固件,实体设备不进 BOOTSEL、无 RPI-RP2 盘符
- **真机诊断(_dev_tools/round76_bootsel_diag.py,A/B 场景)**:
  - 场景 A(旧面板单笔 2B 写 [0xBB,0xA5]):固件回 `read timeout at byte 0 of 1` + `flashing denied`
    ——0xA5 在 500ms 内不可见;静默 3s 仍不来;**下一笔任意主机写把它"冲"出来**(探针 1 字节回显
    两条 unknown command = 迟到的 0xA5 + 探针),真机实测迟到 ~4s
  - 场景 B(两次独立写 [0xBB] / [0xA5]):**0.5s 内进 BOOTSEL**
  - 与 round63i CFG_SET 尾包物理同源:usbser 把拆分后的尾包扣到下一笔主机写才发出。
    round75 前无界 getchar() 无限等所以从未暴露;round75 的 500ms 确认窗把扣包变成确定性 denied
- **修复**:
  1. `runFlashSequence` 改两次独立 writeBytes(round63i 铁律),注释写明物理依据;
  2. MockPort FLASHING 状态化(flashingPending + 5s 超时 denied,跨 write 等确认字节,
     对齐 mbrPending 模式);
  3. 固件 0xBB 确认窗 500ms→5000ms(readCdcPayload 全程泵 tud_task+watchdog,
     容忍 ≤5s 扣压;超时仍 denied)
- **验证**:真机 COM1(fw Built Aug 30 20:34:45):双写 0.5s 进 BOOTSEL,UF2 经 RPI-RP2 回刷
  恢复复验两轮;Mock 全链路(选 UF2→校验→自动进配置→双写→无 denied/unknown→盘符阶段);
  round50 68/68;单笔写在 5s 窗口下仍 denied(usbser 扣包无时限,宿主侧死路,面板已改双写根治)
- 产物:固件 UF2 239616B SHA1 D0CAAF22;release 面板 SHA1 97E597D5(devDiag=0)
- 教训:**CDC 多字节命令的"命令字节+确认/载荷"一律两次独立 write**(round63i 由此再 +1 例证);
  有界化旧无界等待时,必须审计宿主侧是否存在同型扣包时序(round75 漏了 0xBB 这条)

## round76c(2026-08-30): 真机全链路回归——0xBC 门禁探测看门狗隐患修复 + 门禁超时 8s
- 设备在手,按 §8 对 round74-76b 做真机回归(_dev_tools/round76c_realtest.py,字节级复刻面板流程)
- **回归通过**: 配置保存→重启→回读 128/128 一致(§8 保存回归);刷写双写 0.3-0.5s 进 BOOTSEL
  + UF2 回刷 ×3;0BB 拒绝/接受、0BA 白名单、0B1 帧界零残留、0C5、0xB2 五色扫描、0xC3 静默;
  **单笔 129B CFG_SET 扣压在当前固件仍复现 → 双写铁律保持必要(特征化)**
- **真机缺陷修复(P1,既有非近期回归)**: 0xBC 门禁探测在 handleCommand 内 ~15 次 findI2CDevice
  + mux 扫描,真机实测耗时 1-6s 波动;阻塞期间 updateInputState 停喂 2s 看门狗 → 越线复位
  → 面板"连接不上"的第二根因。修复: 探测循环逐次 tud_task()+watchdog_update()(readCdcPayload 同款)
- **面板**: readConfigStream 本有 500ms 轻推 + 总超时;真机数据支持 5s→8s(round76c 回随发布)
- 测试伪影记录(重要,防未来误判): pyserial 紧密短超时读会诱发 usbser 写扣压/迟到送达,
  0BC/0CE 的"静默"均为伪影——0BC 应答帧逐字节证实正确 [BC 07 00 04 01 01](本机 3×MPR121
  无 3116、4×ToF、hwVer=1);面板连续长读 + 轻推模式不受影响。测试脚本应模拟面板的
  载荷冲洗/轻推模式,而非纯短窗读取
- **残留(需目标硬件)**: 0BA 真实 3116 烧录(本机无 3116,白名单+协议路径已验);DTR→LampArray
  视觉确认;游戏内 DLL 字节序
- 产物: 固件 UF2 239616B SHA1 BDAF7216;release 面板 SHA1 E3EDB3F1(devDiag=0);
  round50 68/68;测试工具 _dev_tools/round76c_realtest.py / round76c_probe.py / round76c_bc_probe.py

## round77(2026-08-30): 版本发布——固件 1.6.1-beta1 / 面板 1.1.1-beta1
- 固件: NYANITHM_FW_VERSION + pico_set_program_version → "1.6.1-beta1"(0xBD 与 NYANFW1 签名随宏)
- 面板:
  1. **确立版本标识**: PANEL_VERSION="1.1.1-beta1"(app_core.js),页头品牌区新增徽标
     `#panelVer`(base.html header-master + head_patch.css .panel-version 描边小徽标),
     页面标题同步 "v1.1.1-beta1 · hw_v1"
  2. **门禁白名单** KNOWN_V1_FW += "1.6.1-beta1"(app_ui.js:1503 是硬 includes 检查,
     漏加会让门禁拒绝新固件——版本号发布必须联动此表)
  3. Mock GET_VERSION 串同步 1.6.1-beta1
- 版本格式要点: cmpVersion 对 "1-beta1" 补丁段 NaN||0=0,即 1.6.1-beta1 在功能门禁中等价
  1.6.0 照常通过;NYANFW1 签名正则 [^;\x00\s]+ 兼容连字符;UF2 校验/刷后比对为字符串相等
- 验证: 固件 9813B9DB 真机刷入(0xBD 报 1.6.1-beta1,长度前缀 102='f' 属正常可打印字符);
  Mock 标题/徽标/门禁/逐键门禁全过;round50 68/68;面板 devDiag=0

## round72d(2026-08-28): 修实机首次进配置阈值展示/警告/变色 stale + 警告 span 归位
- 用户实机反馈:首次打开面板并首次进配置模式,INPUT TEST 格子独立阈值与设备实际应用不一致
  (截图格子 6/4,设备全局实际 13/12);参数调节侧缺失警告与变色提醒
- 根因:unpackConfig 用 smoothSliderTo(600ms rAF 动画)把设备值写入全局阈值滑条,
  程序化动画不触发 input 事件;unpack 尾部同步调用的 updateTcThresholdDisplay/
  checkThresholdHints 读到动画起点旧值(DOM 初始 6/4),动画结束后再无刷新时机——
  格子/警告/变色永久停留在旧值。普通拖动路径走 input 监听正常,故只发生在
  "程序化写入≠初始值"的场景;Mock 设备模板恰为 6/4 与初始值相同,diff=0 跳过
  动画,问题被完全掩盖(实机 13/12 才触发),这也是"Mock 全过、实机翻车"的原因
- 修复:smoothSliderTo 落地(else 分支)调用新助手 notifySliderSettled(sliderId),
  按滑条身份广播——rgThTouch/rgThRelease 触发 checkThresholdHints + updateTcThresholdDisplay,
  rgDt/rgDr 触发 checkThresholdHints,rgBright 触发 updateLightLimitHint;与用户拖动
  的 input 监听器同源,unpack 后位即最终值
- 附带:thTouchWarn/thReleaseWarn 原挂在 config-section 尾部(渲染在"附加延迟"行下方,
  与截图红框吻合)、dtWarn/drWarn 挂在高级参数区 slider 行外——全部移入所属 slider-row,
  提示紧贴对应滑条;Mock 增加 window.__mockPort 桥接(与 dumpCfgCmdLog 同惯例)供注入设备侧配置
- 验证(Playwright ?mock=1,注入设备 cfg th=13/release=12 构造真机 diff):
  进配置 250ms 时格子暂显旧值(动画中,属过渡),~700ms 落地后格子=13/12、
  「⚠ 12 偏高:建议 3–8」出现、数显与滑条轨道均转橙红 rgb(255,138,61)、
  警告 span 在释放阈值行内;退出重启→重连→再注入→再进配置同样对齐;保存收敛
  (finishSliderAnims)与校准回填路径经核查无需改动。release(devDiag=0)发两树
  SHA1 一致 36522802…(取代 a3bc1c5d)
- 审查:独立只读 agent 两次空返回(环境问题),改为人工逐点核查首次进配置链路
  (calPendingBackfill 回填路径正确、finishSliderAnims 保存收敛正确、气泡不受全局
  动画窗口影响、th-mode/_thSig 缓存在断开重进时正确失效),未发现其他 P0/P1

## round72c(2026-08-28): 修逐键气泡 9↔0 双向滚动消失(同落点续写不得 finalize)
- 用户反馈:独立按键阈值弹窗里"9"和"0"之间的双向滚动动画消失(普通数字滚动正常)
- 根因(Playwright 采样实锤):气泡滑条同时挂 initSliderAnimations 通用 input 监听
  与气泡自身 oninput,一次拖动对同一 odometer 连写两笔同值。第一笔发起 9→0 wrap
  (挂 onEnd+兜底定时器),第二笔 setOdometerValue 见 pending 即 odoFinalize——
  无过渡归位当帧执行,动画未渲染第一帧即被杀(采样:27ms→34ms 间 -360px 直接跳
  -36px,零中间帧)。非 wrap 不留 pending,第二笔是 no-op,故仅 9↔0 受害;
  主滑条只有单监听器,不受影响——与用户观察完全吻合
- 修复:setOdometerValue 的 finalize 条件加 `d.cur !== digit`——落点与进行中进位
  相同时让动画自然走完(onEnd/兜底照常归位),目标不同才打断收尾
- 附带修复:smoothSliderTo 程序化逐帧同值续写路径的跨界动画同样被旧逻辑当帧杀死
  (如 99→100 长滚),一并恢复
- 验证(Playwright ?mock=1,修复后):9→0 全程 ~40 帧插值 -360→-396(尾部副本,
  1px 弹性过冲与普通滚动同级)后无感归位;0→9 反向同理;15→16 普通进位仍有中间帧;
  20↔19 以 120ms 间隔连打 6 次后 tens/units 精确落回静止位(-72/-360),状态机无残留;
  release 产物本体冒烟 28 个中间帧。release(devDiag=0)发两树 SHA1 一致 a3bc1c5d…

## round72b(2026-08-27): 修 9→0 进位"飞出空白后闪现"(副本终点 -12em→-11em)
- 用户反馈:参数数字 9→0 动画快速飞上去、区域变白、结束后突然闪出 0
- 根因:round72 重写时尾部 0 副本(idx11)的完整可见位应为 translateY(-11em),
  实写 -12em——窗口整个滑出条带底缘(条带总高恰 12em),过渡尾段全空白,收尾
  snap 回 -1em 本位后同字形瞬时出现即"闪现";缓动 bezier(0.34,1.3,…) 的过冲放大观感
- 头部 9 副本 idx0 对应 0em 经复核本来就正确(0→9 无此问题)
- 验证:Playwright 对进位全程 25ms 间隔采样窗口覆盖率,9→0 最低 96.9%(修复前尾段=0
  全空白),过程中仅出现 9/0 两字形;0→9 最低 97%(3% 为缓动过冲瞬隙,与上游普通滚动同级)
- release(devDiag=0)重发两树,SHA1 一致 73f8cac3…

## round72(2026-08-27): 修 odometer 几何错位(幽灵9)+ 倒计时数字被 mask 裁剪 + sb 启动同步
- 用户实机截图反馈:①校准倒计时数字不在圆环中心且残缺;②参数数字与真实值不一致、滚动动画残缺
- **根因1(odometer)**:round71e 头部插入 9 副本后,所有位移公式仍是上游的 translateY(-digit em),
  整体错位一格——静止的 0 位显示头部幽灵 9(叠加 leading-zero 淡显即用户截图中的浅色9),
  进位落点/归位同样偏移;round71b/e 当时用内部 pos 状态做验证而非可见字形,信号选错未发现
- **重写状态机**:条带 [9副本][0..9][0副本] 12 格,数字 k 静止位恒为 translateY(-(k+1)em);
  `odoFinalize` 收尾上一笔动画(清定时器/onEnd 监听器、瞬态副本位无动画归位后强制回流恢复过渡,
  副本与本位同形故无视觉跳变)再从静止位起滚;进位保留 round71b/e 双向长弧语义;
  transitionend 守卫改为存引用+`d.onEnd!==onEnd` 比对(修复旧实现监听器泄漏);
  createOdometer 初始 transform=odRest(0)
- **根因2(倒计时)**:#calCountdown 是 .cal-ring 的子元素,.cal-ring 为 absolute+radial mask
  (只留外圈 8px 不透明),数字既吃不到 wrap 的 flex 居中又被 mask 裁成弧边残字;移出为
  .cal-ring-wrap 直接子元素(在流内被 flex 居中,z 序在环之上),顺带注释防止回归
- **补缺(sb 状态栏)**:initSliderAnimations 对 sbMap 四个状态栏只建 odometer 不赋初值,
  页面加载到首次拖滑条之间恒显 000 与滑条真实值不一致;创建后立即按源滑条当前值同步一次
- 新增 Number.isFinite 入参守卫(setOdometerValue);检查 hidden 元素时 computed transform 为 none
  属浏览器行为,离屏 pk 占位数显为此前就存在的无害占位(openPerKeyBubble 打开时会 setPkVal 显式同步)
- 验证(Mock+Playwright/Edge):①可见字形读取器按 strip 实际 computed transform 反算可见格,
  rgThTouch 全值域 63→1→63 快速连发竞态、12 步慢速逐格过界(X9↔X0)、rgAirMin 百位进位
  199↔200 系列,每步 settle 断言 16 个数显实例全部与滑条值一致(sb1-4 同步过);
  ②校准向导 intro→running 21 个采样点 #calCountdown 与环心 dx/dy 均=0,不被 mask 裁剪,
  20→1 计时正常,result 屏按钮正常;③主题切换无 __syncLedDefaultColor 桥接告警;
  ④?mock=gen2 门禁 alert 正常拦截(ToF=3)。暗色主题截图确认 hero 横幅 063/100 等
  前导零渲染为淡色 0 而非幽灵 9
- **双路 agent 只读审查后的追加修复**(app_ui.js 审查结论"可发布"+集成审查发现 P1):
  [P1] body_main.html 尾部孤儿 </div>(div 净平衡 -1,栈模拟证实为纯多余闭合、浏览器
  容错忽略故渲染一直正常)已删除,平衡归零;
  [P2] ledLimit/ledSpeed 迷你滑条先被通用循环 odometer 化又被文本直写摧毁成僵尸表
  (_odometer 指向孤立节点,未来 setSlider 会静默失更新)——MINI_TEXT_SLIDERS 排除建表、
  删独立迷你监听器块,统一走通用 input 监听的 textContent 分支(实测直显与更新正常);
  [P3] odoMove 兜底 timer 路径补 removeEventListener(旧实现同类泄漏的收尾遗漏);
  [P3] smoothSliderTo 同滑条 600ms 内二次调用时 cancel 旧 rAF 环+按身份 delete 登记
  (修复旧环误删新环登记窗口);[P3] .cal-ring-unit 显式 left/right+text-align 居中加固;
  [P3] 删除死选择器 `.warn + .slider-fill`;[P3] 配置模式格子阈值态挂 .th-mode 类隐藏
  BASE 通道数字伪元素(消除顶部挤靠),三个 tc-th 数显统一 text-align:center 且单值补
  left/right 锚定(编辑时误删的 .div_touch_channel 定位规则已当场恢复)
- 终验(round72b/c 构建):连发后 rgThTouchv=63/sb3=063;倒计时 14 采样偏移恒 0(20→1);
  tc5 thMode→::before none→断开后恢复 block+清空 innerHTML 全链路;ledLimitv 直显 255→input 后 180
- release(devDiag=0)部署两树 ControlPanel_v1.html,三文件 SHA1 一致 45b0ac34…;未提交

## round71e(2026-08-27): odometer 0→9 反向进位补全(双向旋转计数器)
- 用户反馈 round71b 只实现了 9→0 下滚,0→9 仍是 0 短路径倒转回 9
- 补全: 条带头部追加 9 副本(pos=-1,translateY(1em) 位置);0→9 时向上滚到头部
  副本位,transitionend+450ms 兜底后无动画 snap 归位到 pos=9——与机械计数器
  反向进位一致连续上滚;snapOdometerStrip 加 sym 参数归位到 9;setOdometerValue
  开头同时清理 pos=10 与 pos=-1 两种挂起态;新增 pos===0 && digit===9 分支
- 条带 12 格: [9副本][0..9][0副本];头部副本在常规路径永不可见(仅 pos=-1 时
  上一格露出,且 .odometer-digit overflow:hidden 裁剪)
- 验证(Mock, sb3 触摸阈值数显): 10→9 中间帧 pos=[0,0,-1] tf=translateY(1em)
  →settled [0,0,9];20→19 十位常规+个位头部副本同时进位 [0,1,9];
  63→62/62→61 常规反向;61→60→59 链式(十位 6→5+个位 0→9) [0,5,9];
  10→9→10 往返(两种进位先后触发) [0,1,0];快速连续 9→10(300ms 间隔,
  pos=10 挂起时又设值)snap-then-roll 正确归 [0,1,0];9→8/60→63 常规路径回归
- release 构建(devDiag=0)已部署两树 ControlPanel_v1.html(SHA1 b2019da7…);未提交

## round78(2026-08-30): 刷写引导修复——重启验证才弹盘符框 + Mock 确认链路重写

- 现象: round76b 后实机仍偶发「面板刷写走完但 RPI-RP2 盘符不出现」。根因之一在面板:
  `runFlashSequence` 盲发 0xBB+0xA5 后固定 sleep 就关端口弹盘符框,若 0xBB 落空
  (设备 60s 空闲自动退出重启→配置模式失同步,固件正常模式 Core1 此前静默忽略 0xBB,
  固件侧已同步修复),弹窗里永远等不到盘符且无任何报错。
- 面板修复:
  1. **重启验证**: 发完 0xBB+0xA5 后轮询最多 3s 等「端口自行消失」(readLoop 的
     handleUnexpectedDisconnect 置 connected=false),确认设备真的重启才 sleep 挂载
     等待并弹盘符框;超时→明确报错(读缓冲含 "flashing denied" 时提示"刷写被固件
     拒绝"),不再无提示打开空弹窗。bootselReady 只在确认重启后才置 true。
  2. **Mock 确认链路重写(round76b 遗留缺陷)**: 旧 FLASHING 处理器的内层循环在
     两笔 write 模式下从不执行(单字节 write 无续段),第二笔 [0xA5] 落到顶层
     `unknown command`——确认链路从未走通,dev.closed 实际来自 closePort 的
     reader.cancel。现按 cfgSetPending/mbrPending 同模式: 顶部 flashingPending
     pre-check 消费下一笔 write 首字节(readCdcPayload 语义),新增
     flashingArm(5s 确认窗)/flashingConsume(0xA5→BOOTSEL 模拟断开 dev.closed;
     非 0xA5→denied 且剩余字节回命令分发);兼容旧式合并写。
- 验证(Mock, Playwright): 选 UF2→校验→自动进配置→双写→模拟断开→重启验证→
  优雅落 bootsel-manual(自动化环境 showDirectoryPicker 无用户激活被拒属预期;
  真机浏览器 2.7s 内打开弹窗在激活窗口内);reads 无 unknown command 残留;
  release 构建(devDiag=0)部署 SHA1 3CC9623C…。真机验收待设备重插后进行。

## round78b(2026-08-31): 0xA5 确认被 Chrome 串口栈滞留——尾随 0xC3 冲刷写

- 用户实测仍失败:面板 3s 验证报「设备未进入 BOOTSEL」,报错关端口后设备才断连
  进 BOOTSEL(用户所见异常断连);INPUT TEST API LEVEL 显示 0xb0(流错位旁证)。
- 根因:Chrome Web Serial 无 flush 语义,最后一笔 write 的尾字节滞留到下一笔
  主机写或 ~4s 惰性超时才发出。[0xBB][0xA5] 后无后续写→0xA5 滞留→固件确认
  等待中设备不动→3s 验证窗超时→closePort 冲出积压→设备迟进 BOOTSEL。
  pyserial 无 flush 也 51ms 送达(rig 实测)→rig 永远复现不出;round76b 双写
  只是把"永远被扣"变成"~4s 迟到",恰在固件 5s 确认窗边缘→一直偶发;round78
  的先验证后弹框使窗口矛盾显性化(3s<4s),偶发变必现。
- 修复:①[0xBB][0xA5] 后补发尾随 0xC3(CFG_KEEPALIVE,配置模式静默心跳/正常
  模式忽略,滞留无害),借"下一笔写冲出上一笔滞留"物理立即送达 0xA5;尽力而为
  try/catch(设备在两写间离开时 writer 已被断开处理置空——Mock 回归暴露此竞态)。
  ②验证窗 3s→5.5s,循环内见 "flashing denied" 提前退出精确归因。
- 验证:Mock 全链路通过(含 writer 置空竞态修复);Chrome 真机时序验证待用户实测
  (rig 无法复现 Chrome 批处理)。release 部署 SHA1 0F14B3C2…。

## round78f(2026-08-31): 固件 1.6.1-beta2 / 面板 1.1.1-beta2 发布——RPI-RP2 句柄持久化与零弹窗写盘

- 背景: round78e 解决 BOOTSEL 引导后，Edge 因点击激活期（~5s）过期拦截了 BOOTSEL 挂载后的 `showDirectoryPicker()` 弹窗（抛 NotAllowedError），导致不自动刷入。
- 机制:
  1. 句柄持久化: 首次选中的 RPI-RP2 目录句柄存 IndexedDB（`nyanithm_v1_storage:rp2_dir_handle`），下次直接复用。
  2. 点击激活期验证: 点「开始刷写」瞬间立即取回句柄并 `requestPermission`/`queryPermission`；首刷无句柄时立即弹选择框（与刷写命令并行发送），点选后自动入档。
  3. 零弹窗自动刷盘: 进入 BOOTSEL 后轮询 `INFO_UF2.TXT` 就绪直接自动写入 UF2 镜像，完成重连校验闭环。
  4. 版本发布: 控制面板升级至 `1.1.1-beta2`，固件升级至 `1.6.1-beta2`。
- 验证: 固件编译 242176 字节 (SHA1 `7DCCBB93`), round50 43/43 PASS, Release 面板部署 (SHA1 `18402352`), Mock 全链路自动化测试 PASS。

## round78e(2026-08-31): 刷写确认合并单笔写 + 35s 周期重发——Electron 真实 Chromium 台架定位

- 用户复测仍失败。建成 Electron 台架 `_dev_tools/round78e_electron/`（npm 装 electron@33
  走代理；dist 二进制 npmmirror 直下 + path.txt 手写；`select-serial-port` session 事件
  自动授权,无 chooser）。Electron ≥26 签名坑:`(event, portList, webContents, callback)`
  4 参(旧 5 参写法在 log 参数求值时就抛异常→静默 NotFoundError);vendorId/productId 可能
  是字符串,必须 Number() 比较;requestPort 无条件走 chooser,自动化授权走 session 事件或
  企业策略 SerialAllowUsbDevicesForUrls(getPorts 免 UI,无 CDP/开关可用)。
- 台架端到端两次复现用户失败:面板同毫秒连发 [0xBB][0xA5][0xC3] 三笔单字节写→宿主栈
  全部扣住不达设备(一轮 60s 未达直到配置自动退出重启;一轮 closePort 后 ~2s 迟到送达→
  迟到 BOOTSEL,与用户"设备躺在 BOOTSEL"一致);间隔单笔写(0xB3/0xBC/0xB4)全部瞬时达。
  Chromium 源码调研(独立报告):写路径四层无任何定时器,write resolve=进 mojo 管道,
  close=PurgeComm(PURGE_TXCLEAR) 是丢弃——"closePort 冲出滞留字节"假设不成立。
- 修复 runFlashSequence:①0xBB+0xA5 合并一次 write(单 chunk 单 WriteFile,与所有能瞬时
  到达的写同形态;round76b"双写"结论仅适用旧阻塞窗,固件状态化确认两形态通吃),删除 0xC3
  尾笔;②验证窗 11s→35s(覆盖固件 30s 武装窗),每 1.5s 重发合并对(第一笔仍可能被扣
  ~1.6s≈DETECT 时长,重发那笔瞬时达即触发;0xBB 顺带重置配置 60s 自动退出);③等待期间
  绝不 closePort,35s 到期才报错+保留手动盘符。
- 验证:台架端到端 PASS(合并写 t=2633→重发 t=4245 送达→56ms 断开→5.97s RPI-RP2→自动写
  UF2→7.9s 回连,全周期 ~10s);Mock 严格终态 PASS(判定须匹配「已进入 BOOTSEL」终态,
  "正在进入 BOOTSEL…"会假阳性);固件零改动,round50 豁免。部署双树 SHA1 762B3D81。

## round78d(2026-08-31): 武装窗 30s + 0xCD 诊断(固件侧,面板仅验证窗 5.5s→11s)

- 0xCE 取证 BB/A5 均达设备但未 BOOT→加 CMD_FLASH_DIAG(0xCD)事后归因(code/rc/gapMs,
  双模式);武装窗 10s→30s 覆盖"closePort 才冲出的迟到确认"。真机:12s 迟到确认→13.2s
  BOOTSEL/close-flush 最坏→13.5s/diag 实测 code=3 gap=301ms;round50 68/68。

## round78c(2026-08-31): 0xBB 确认改状态机——Chrome 滞留超过 5s 后的根治

- round78b 后用户实测仍 deny:0xA5 被 Chrome 滞留超过 5s,尾随 0xC3 冲刷写也不可靠
  (滞留并非"下一笔写必冲出")。任何阻塞式确认窗都可能短于 Chrome 的实际延迟。
- 固件改状态机:0xBB 仅武装 10s 窗(flashingArmed/flashingArmedAt,双模式共享,
  Core1/Core0 不同时运行)立即返回;0xA5 任意时刻落地即触发(正常模式 pending_
  flashing→Core0);其它字节立即 deny(配置模式吞字节=旧确认读语义,正常模式继续
  分发);超时后下一字节触发 deny;宿主 0xBB 重试=重武装。删除两处阻塞等待
  (readCdcPayload(5s) 与正常模式 2s)——顺带消除审查 P3-4 的 GET_INPUT 停顿。
- 面板:失败路径保留「手动选择盘符写入」+提示(closePort 冲出滞留字节→设备可能
  "迟到"进 BOOTSEL,手动路径仍可用)。
- 验证(真机,round78c_statemachine_test.py 全过):n-delay 4s 迟到确认→5.2s
  BOOTSEL(旧固件 2s deny)/c-delay 6s 迟到→BOOTSEL(旧固件 5s deny)/deny 杂
  字节→立即 deny/expire 10.5s→精确 deny+存活/retry 重武装→BOOTSEL;round50
  68/68;postflash 3/3。release 部署 D7DB1EB6…。Chrome 时序由用户实测确认。

## round81 (2026-09-06): 标签消歧 + ToF 偏移注释 + 悬空抑制滑块 + MPR ×2 尺度联动

- **hwVer 分段按钮**改为「v1 · 27寸 / v1 · 32寸 / v2 · 27寸 / v2 · 32寸」(v1/v2=布局代际,
  27/32=尺寸);「API / 硬件」信息框由裸 `v2`(hwVer 数值,曾被误读为二代机)改为
  `hwVerLabel()` 全称渲染(如 `0x10 / v1·32寸`);原始数值保留在日志与详情弹窗。
- **ToF 偏移注释**(高级参数 cols-5 网格下): 方向依据固件 `meas=raw+offset` +
  Kalman `v<0=手抬高`(测距变小=手抬高)——调大=手需抬更高才触发原档位;实现前曾
  写反方向,按代码三处证据纠正(Agent B 质疑成立)。
- **悬空抑制滑块** `rgMbrGate`(参数调节区,th_release 之后): 字节偏移 90
  (`CFG_OFF_MBR_TOUCH_GATE`),pack/unpack 同步;`mbrGateFwSupport` 按
  cmpVersion≥1.6.2-beta1 门禁(旧固件该字节是 reserved);hint 含 200-220 起调、
  gate≥200 抬高快路径阈值属预期。
- **MPR ×2 尺度联动**(round80 固件报送层 ×4→×2): Mock inputFrame 同步
  (game 映射 ×2、rawReport 会话 MPR 输出 ×2);**校准向导采样减半折算回原生
  阈值尺度**(calScale=perKeyIsMbr()?1:0.5),否则建议值整体翻倍被 63 钳顶;
  校准报告加 ×2 尺度说明行(MPR)。
- **版本联动**: PANEL_VERSION 1.1.1-beta3;KNOWN_V1_FW += 1.6.2-beta1;
  Mock 0xBD 串同步 1.6.2-beta1。
- **Mock 验证**(Playwright/Edge, 8765): ?mock=1 连接→握手 1.6.2-beta1→
  infoApi「0x10 / v1·27寸」;进配置 rgMbrGate 启用,设 200→保存→截获 CFG_SET
  载荷字节 90=200、Mock check ok(Mock 重启后不持久化配置属既有 Mock 差异,
  真机保存回归另测);ToF 注释/hint 渲染 ✓;?mock=gen2 门禁 alert 拒绝+断开 ✓。
- **坑**: 本机无 chrome channel,playwright-cli 需 `--browser msedge`;8765 端口
  旧僵尸 http.server 与新实例双 LISTENING 导致 ERR_EMPTY_RESPONSE(taskkill
  旧 PID 解决);playwright-cli 无 `navigate` 命令,重载用 `open`。
- release 构建 devDiag=0,SHA1 a066f715…,已部署 Nyanithm_firmware_hw_v1/ControlPanel_v1.html。

## round82 (2026-09-06): MBR3116 友好调节层 -- 滑块化 + 预设 + 0xC6 芯片回读

- **TRM/官方资料取证**(结论入档): Infineon 社区 moderator(2025-12)官方建议
  「threshold=80% 信号, HYS/NNT/NT=40%, LBR 勿过高」+ 配置实例(0x91/0x92/0x90/0xB2,
  bit7=override);TRM 位定义无法从公开渠道 100% 确证 → 按纪律 0x1D/0x1F/0x20/0x21
  不进预设/滑块, 预设只动已确证的 0x0C(THRESHOLD)/0x1C(SENSOR_DEBOUNCE 低 4 位)。
- **阈值/消抖滑块化**: mbrThreshold(96-220)/mbrDebounce(0-15)由数字输入改为
  slider-row(odometer 数显);导入外部表超量程时 setSlider 自动扩 min/max;
  写回仅覆盖 SENSOR_EN 使能位(模板禁用位 0x7F 不再被整段覆盖)。
- **预设按钮组**: 标准(=固件模板 128/1)/抗悬空(176/2, 官方建议量程 160-180)/
  高灵敏(96/1);只改 0x0C/0x1C, 其余字节不动, 烧录仍走「应用于手台」0xBA 双写。
- **「从芯片读取」(0xC6)**: 双写 [0xC6]+[addr];成功 128B 填表同步滑块/高级表
  (表尾 CRC 芯片原值, 应用时重算), 失败/超时按文本行报错;门禁 mbrGateFwSupport
  (固件 ≥ 1.6.2-beta1)。Mock 端 mbrCfg 存最近烧录表 + read3116Pending 跨 write
  累积 + 1s 断流超时。
- **Mock 全链路**(Playwright/Edge): 预设 176/2 → 0xBA 烧录(programing→done→
  verify ok) → 0xC6 回读滑块 176/2 ✓;高灵敏 96/1、标准 128/1 ✓;禁用位 0x7F
  保留 ✓;0xC6 门禁与按钮状态 ✓。
- release 构建 devDiag=0,SHA1 bddbed8e…,已部署 Nyanithm_firmware_hw_v1/ControlPanel_v1.html。

## round86 (2026-09-07): 12 项 UX 重组 -- 校准统一路由 + MBR 区收缩 + 分区锁定 + sb3 主控切换

- **用户 12 项清单**(逐条落地见 更新日志_固件.md round86 条目): 关键交互重构为
  校准统一路由(#7: btnCalibrate→重新探测→MPR 统计校准 / MBR 悬空阈值校准)、
  MBR 区收缩(#12: 滑条迁出+预设移除+同步烧录全部芯片+每芯片表缓存 trusted/untrusted)、
  分区锁定(#2/#5: config-locked + data-mpr-only/data-mbr-only 显隐)。
- **#3 根因取证**: rgLatencv 为 HTML id 拼写错误(少 y)。$(slider.id+'v') 查找
  落空 → odometer 从未创建 → 数显空白。Playwright 实证: id 修复后 odometer 2 位。
- **#10 长按连接**: pointerdown 600ms 定时器分流单击/长按; localStorage
  nyanithm.lastPortIdx 记忆上次设备(枚举序索引, 同 VID/PID 无唯一 ID 的局限注释)。
  openPort 重构: getPorts() 快照只取一次(Mock 的 getPorts 每调用发新实例的副作用)。
- **#11 sb3 防串台**: updateStatusBar 互斥守卫 -- 3116 下 rgThTouch 动画(unpack
  smoothSliderTo)不得回写 sb3; mbrThreshold change 显式联动 sb3。
- **#7 路由语义**(首版 bug 修复): 探测优先级 = MPR 在位→MPR, 否则 MBR 在位→悬空,
  双在位按 ckMbr3116 裁决, 全无回退表单; 每次点击重新探测(normalProbeDone 复位,
  设备可换)。Mock 走查时发现缓存探测导致路由 stale -- 已改为强制刷新。
- **构建**: release devDiag=0, SHA1 29A27E46…, 部署 hw_v1 树; 版本 1.1.1-beta5
  (KNOWN_V1_FW += 1.6.4-beta1, Mock 版本串同步)。

## round86d (2026-09-07): 修复开始测试时按键背景板透明/隐形问题 & MBR3116 0-255 线性变化

- **现象与根因**: 用户反馈输入测试开始时按键背景板变透明。查实 `renderInput` 在默认的
  `rawSession`（0xC5 level 2 原始物理读数）模式下，未触摸时通道读数 `v` 为 0（MPR121）或
  底噪 ~128（MBR3116）；此前无条件计算 `op`（MPR121 得 0.00，MBR3116 得 0.35）并赋予
  `tc.style.opacity = op`。内联样式覆盖了 CSS 规则，使未激活按键方块 100% 透明隐形或半透明。
- **修复**:
  1. 严格约束内联 `opacity`：未激活态（`!on`）时统一清空 `tc.style.opacity = ""`，恢复 CSS
     默认 `background: var(--c-surface-2)` 的 100% 不透明实心背景板，数字读数正常显示。
  2. 仅激活态（`on === true`）根据读数或压力赋予内联 `style.opacity`：
     - MPR121: 激活起步 0.20 保底保证可见性，随读数 0~100 线性提升，100（或 128 标准判定）满亮 1.00。
     - MBR3116: 依照原始触摸值 0~255 线性变化（`v / 255.0`），达到 255 满亮 1.00（二值判定 128 直接 1.00 满亮）。
  3. `toggleInputBtn` 暂停测试时追加 `clearInputDisplay()`，立即重置按键待机态。
  4. `build.py` 增强：`--release` 模式下自动写入 `Nyanithm_firmware_hw_v1/ControlPanel_v1.html`
     并断言 `devDiag == 0`，保证单点构建与部署同构。
- **验证**: `_dev_tools/verify_input_test_opacity.py` 状态机仿真全过；`test_round50_migration.py`
  117/117 全过；release 构建部署通过（devDiag=0）。

## round87b (2026-09-07): 输入测试高对比度字体算法与背景压感解耦（消除灰色文字）

- **背景与问题根因**: 用户反馈背景亮度 5%-20% 区间明显应为黑色的文字反而变成了灰色。
  深挖发现根因在于此前将压感反馈直接施加在容器本身的 `tc.style.opacity = op` 上，由于 CSS
  继承性，容器透明度导致其内部全部文本与伪元素字体一并被降至 20%~30% 透明度，在深色底色下
  泛灰发虚；同时此前仅用硬编码 35% 且伪元素带 85% alpha，削弱了边缘锐利度。
- **高对比度新算法规范与重构**:
  1. **背景压感解耦**: 触碰按压的高亮渐变改为使用 `backgroundColor = rgba(rAcc, gAcc, bAcc, alpha)`
     在底色层上叠加，彻底弃用按键容器级的 `tc.style.opacity` 衰减。所有文字和序号元素在 DOM 树中
     恒定保持 100% 实体呈现，杜绝文字发灰发虚现象。
  2. **高对比度门禁与自适应算法**:
     - 亮度 L = 0（及未激活待机状态）: 保持实体纯白色（`#ffffff`），通道序号使用 `rgba(255, 255, 255, 0.96)`，
       并赋予微细轮廓阴影（`0 1px 2px rgba(0,0,0,0.45)`），大幅降低灰度和透明度，白字锐利清晰。
     - 亮度 L ≥ 45%: 严格默认纯黑色（`#000000`），文字与序号均以 100% 实心黑色显示，无任何透明度或灰阶模糊。
     - 其它亮度区间 (0% < L < 45%): 解除固定限制，采用以最大辨识度为目标的动态高对比度分流策略
       （中间过渡点在 35% 感知亮度，经 WCAG 对比度公式核算全区间对比度均维持在 3.5:1 ~ 20.2:1 高位）。
  3. **样式与伪元素优化**: `head_patch.css` 完善 `.tc-text-light` 与 `.tc-text-dark` 规则，全面覆盖
     32 键按键读数、`::before` 通道序号以及 6 个 AIR 通道 `::after` 文本。
- **验证**:
  1. 自动化测试脚本 `_dev_tools/verify_input_font_color.py` 扫描暗色与亮色主题下全域压感变化，
     确认 L=0 纯白、L>=45% 纯黑、过渡段对比度均达标，全量断言通过。
  2. `build.py --release` 构建成功，生成 `ControlPanel_v1_refit.html` 并自动同步部署到
     `Nyanithm_firmware_hw_v1/ControlPanel_v1.html`（文件大小 1.314 MB，严格校验 `devDiag == 0`）。

## round88 阶段(2026-09-07): 寄存器详细设置悬浮窗 + 抗悬空预设 + 保存联动烧录 + 0xC7 调试读数

- **背景**: MBR3116 悬空触发需寄存器级根治(ATH_EN 疑点 + FT/HYS/NT 组合)，
  用户要求把 TRM 寄存器数据表翻译成可交互参数项(悬浮窗)，并对寄存器修改
  落地链路做统一整合。固件侧配套新增 0xC7 单传感器调试通道(1.6.5)。
- **面板 1.1.1-beta6 变更**:
  1. `app_core.js`: 新增 `MBR_REG_DEFS`(37 项寄存器元数据，含功能说明/合法
     区间/风险等级 0-2，逐条对标 TRM 001-91082 Rev. *E)与
     `MBR_ANTIHOVER_PRESET`(FT=200，HYS=0x80|25，NNT/NT=0x80|80，LBR=0x80|50，
     debounce=2，0x4F=0x60；ARST 保持 20s——官方 DG p.48 否决 5s：吞长按)。
     KNOWN_V1_FW 加 1.6.5，CMD 加 0xC7，PANEL_VERSION → 1.1.1-beta6。
  2. `body_main.html`: MBR 区新增「寄存器详细设置」按钮(btnMbrRegWin) +
     `mbrRegModal` 悬浮窗(状态卡片 / 0xC7 调试读数区 / 参数编辑区 /
     风险确认勾选 / 全局应用开关；foot: 抗悬空预设 / 恢复模板 / 关闭 / 写入芯片)。
  3. `app_ui.js`: 悬浮窗逻辑——按 MBR_REG_DEFS 生成分组编辑网格；编辑写当前
     芯片缓存并标脏，「全局应用」(默认开，用户决策)同步全部有缓存芯片；风险
     校验(评审建议)：I2C_ADDR≠目标地址 或 FT+HYS>255 → 严重违例直接禁烧；
     FSS_EN 非 0 / 本机 SENSOR_EN 关键位被关 / 0x4F EMC|GUARD 置位 → 警告级
     需勾选「已知晓风险」；状态卡实时显示 ATH/FT+HYS(ON=)/NT/ARST；
     「写入芯片」复用 mbrBurnOne(0xBA 双写铁律)，全局模式逐片写其余芯片。
     0xC7 采样：双写 [0xC7]+[addr][sensor]，11B 小端回包解析，
     diff 悬空换算显示(h ≈ 10 − 8·diff/255 mm)。门禁 mbrDebugFwSupport
     (固件 ≥ 1.6.5)。
  4. **保存联动烧录(用户决策)**: `doSaveAndReboot` 在 CFG_SET 前检测
     `mbrDirty` 非空(且「使用 3116」勾选)时先逐片 0xBA 烧录全部有编辑的
     芯片，失败不阻断保存但醒目告警——寄存器编辑不再依赖「应用于手台」
     单独入口，统一整合进保存链路。
  5. Mock: 0xC7 应答(mbrDbgPending 跨 write 累积，仿真 diff/cp/base/raw)；
     GET_VERSION 版本串同步 1.6.5。
  6. `head_patch.css`: mbr-reg-* 样式(状态卡/分组网格/风险着色/严重红框)。
- **验证(Playwright + Mock 全链路， 2026-09-07)**:
  - 悬浮窗打开 37 项/7 分组；抗悬空预设写入后状态卡显示「手动阈值生效中 ·
    触发 200 + 迟滞 25 (ON=225) · 基线冻结 80 · ARST 20s」。
  - 0xC7 Mock 采样回包解析正常(CS0 diff=117 → ≈悬空 6.3mm)。
  - I2C_ADDR 改 0x44 → 写入按钮禁用+红框(严重拦截)；FT=0xFE+HYS=255(hex 表
    手改) → FT+HYS>255 拦截生效；FSS_EN=1 → 警告勾选行显示(bubbles 事件)。
  - 保存并重启联动：编辑 0x0C=190 → 「保存并重启」日志依次出现
    「检测到 1 片芯片有未写入 NVM 的寄存器编辑」「芯片 0x40 烧录： done」
    「联动烧录完成」「check ok」「已自动重连」；重进配置后状态卡 FT=190
    持久。此前几次"未触发"为重连后未重新勾选 3116/未进配置模式所致，
    非代码缺陷；确认「全局应用」开关与按钮门禁都正常。
  - release 构建部署 `Nyanithm_firmware_hw_v1/ControlPanel_v1.html`
    (1.353 MB， devDiag == 0 断言通过)。
- **未经真机验证**: 0xC7 真实芯片读数、烧录序列修正后的 0xBA 时序、
  抗悬空预设的实机悬空效果——需用户在场真机回归(§8)。

## round88b 阶段(2026-09-07): 真机回归三缺陷修复（P0 烧录形状 + P1 级联错位 + 盘符校验宽容化）

- **背景**: 用户真机(32寸 v2, 固件 1.6.4→1.6.5)回归发现——①烧录大量
  `CTRL_CMD timeout, burn aborted.` 且触摸行为错乱；②多芯片连烧级联
  「写入失败」错位日志；③「更新固件」找盘符/校验盘符环节失败。
- **P0 固件（详见固件 round88b 条目）**: 1.6.5 首版烧录轮询把
  `i2c_read` 末参(nostop)当"阻塞"用，write+read 组合从不产生 STOP，
  芯片读回永远无效 → 误判 timeout → 不发软复位 → 新配置停在 RAM。
  固件侧统一 `mbrReadReg()`（i2c_write_read 组合事务）修复。
- **面板修复（本轮）**:
  1. **verify 尾行消费(P1)**: `mbrBurnOne` done 后固件最坏 ~600ms 才发
     verify 诊断行，旧版不消费——多芯片连烧时该行与下一片
     `programing` 行错位，级联出大量"芯片 X 写入失败"假失败（真机日志
     20:02-20:04 段复现）。现在 done 后 900ms 短窗排掉该行并日志展示。
  2. **全局写入重写(P1)**: 首版"全局传播=其他芯片缓存同地址覆写"在
     0x51(I2C_ADDR) 上把当前芯片地址写进别人缓存（烧录时被 mbrBurnOne
     纠正但缓存/UI 校验被污染）；对无缓存芯片静默跳过造成"看似全局
     实则单片"。重写为 `MBR_REG_PER_CHIP`（0x00/0x01/0x02/0x03/0x51
     不跨片传播）+ 写入队列逐片独立（同 mbrBurnAll 形状），失败计数
     汇总报告。
  3. **恢复模板语义澄清(用户反馈"恢复后意外错误")**: 旧文案「未写入
     芯片」易被理解为"已恢复芯片行为"。明确为警示级：「仅编辑区——
     NVM 仍是芯片现值，需再点『写入芯片』才会烧回模板」。
  4. **盘符校验宽容化(问题1)**: RPI-RP2 的 FAT 卷经 FSA 列目录偶发为空/
     8.3 短名截断，旧严格校验(infoName 正则 + index.htm)落入"强制写入"
     confirm，表现为"校验盘符失败"。新增 `probeBootselSignature()`——
     目录列举失败/为空时直接尝试 INFO_UF2.TXT/UF2INFO.TXT/INFO.TXT/
     INDEX.HTM 四个已知标识文件；`validateAndWriteToBootsel` 与
     `waitRp2VolumeReady` 都改走该探测。
- **验证(Playwright Mock)**: ①预设→保存联动烧录→verify 行被消费
  (`芯片 0x40 校验: verify ok`)→check ok→自动重连；②三片各读缓存后
  BurnAll：每片 done+verify ok 配对、零错位、3/3 全部成功；③0x51 编辑
  →严重违例拦截仍在；④release 部署 1.357 MB、devDiag==0。
- **待真机**: 刷入 UF2 DC219041 后重走 0xBA 烧录（预期不再 timeout）、
  BOOTSEL 刷写全流程、抗悬空预设 A/B。

## round88d 阶段(2026-09-07): MBR3116 NVM 恢复闭环与精确构建校验

- 真正根因同时包含设备对象混淆与构建伪成功：新 UF2 只刷到 27 寸 MPR 设备；round88b 又因 `cur` 编译错误而由旧脚本继续链接陈旧对象。面板新增 BID 精确构建校验，`round88d` 之前的无 BID 1.6.5 不再获“精确验证成功”。
- `mbrBurnOne` 仅接受固件唯一终态 `done`，随后发 0xC6 全 128B 逐字节比对，只有 128/128 一致才清 dirty；Mock 支持真实延迟并持久化每片 NVM 表。
- “恢复模板值”现严格按地址取模板、缺表拒绝且标 dirty；新增“安全恢复 0x40–0x42 内置模板”：要求设备 BID=round88d 与 0xBC 三片实测在位，先备份三片，再逐片写入/全表校验；中途失败自动逆序回滚已完成芯片，备份保留在 `window.__mbrRestoreBackups`。
- release 构建部署 `Nyanithm_firmware_hw_v1/ControlPanel_v1.html`（1.358 MB，devDiag == 0）。固件 clean build 最终 UF2 SHA1 `11755C25F8A00DAF918300C9740536B188CE5FB4`。
- 真机恢复必须将该 UF2 刷到 32 寸 MBR3116 设备后执行，27 寸 MPR 设备不能验证 0xBA。

## round88c 阶段(2026-09-07): BOOTSEL 误判软重启假阳性根治

- **背景**: 用户真机实测日志显示设备已收到 0xBB 0xA5 并断开连接，Windows 系统已正常枚举并弹出 RPI-RP2 盘符，但控制面板日志立即报 `设备串口在刷写窗口内重新枚举——这是一次固件软重启...并非 BOOTSEL` 并弹出错误 `✗ 设备重启了,但未进入 BOOTSEL`，直接掐断后续写盘流程。
- **根因**: 旧代码在设备断开 2.6s 后调用 `navigator.serial.getPorts()` 轮询检查是否有 VID 0xCAFE / PID 0x4009 的串口以区分所谓的"软重启"。但在 Web Serial API 规范与 Chromium (Windows) 实际实现中，`getPorts()` 返回的是浏览器为该 Origin 持久授权过的**端口历史列表**，即使物理设备已进入 BOOTSEL 成为大容量存储设备，`getPorts()` 仍会始终返回该对象！导致 `cdcBack()` 永远为 true，判定为"持续在线软重启"引发 100% 假阳性拦截，更在代码中重复贴了两次。
- **修复**:
  1. 彻底移除错误的 `softReboot` / `cdcBack()` 守卫逻辑。
  2. 端口断开后直接将 `bootselReady = true`，平滑直达三分支写盘（已保存句柄直接写 / 早弹选择器写入 / 手动选择盘符写入），不再被错误的串口列表掐断。
  3. 重新构建并部署 `Nyanithm_firmware_hw_v1/ControlPanel_v1.html` (1.354 MB，devDiag == 0)。

## round88f 阶段(2026-09-09): 安全恢复门禁前向兼容 + 回滚路径防异常逃逸（24h 复核报告三项核实）

- **背景**: 上一会话对最近 24h 变更产出风险审查报告，三项发现逐一核实后两项与实际代码不符（详见固件 round88f 条目），属实两项于本轮修复。
- **修复 1（BID 门禁前向兼容）**: `mbrRestoreAllBuiltins` 的已验证构建白名单 `["round88d","round88e"]` 改为 `cmpBuildId()`（app_core.js 新增纯函数）单调序比较——`roundNN` 主序 + 小写字母后缀，`>= round88d` 放行。旧白名单要求每个新构建手动加表，设备升级到表外固件后「安全恢复」即被自身面板拒绝。无法解析/缺 BID 仍拒绝（含 round88e 前无 BID 构建，`-Infinity` 恒小于门槛）。
- **修复 2（回滚路径防异常逃逸）**: `mbrBurnOne` 内 `waitForLine` 超时是 throw；旧版 `mbrRestoreAllBuiltins` 主烧循环与回滚循环均未捕获——任一片超时异常直接散场，回滚一步不走、`backups` 引用也不落 window，三片原表随会话丢失。现：主烧循环逐片 try/catch（异常计入失败触发回滚）；回滚循环逐片 try/catch（异常计入 `rollbackFail`）；备份完成即挂 `window.__mbrRestoreBackups`（原为收尾时才挂）。
- **Mock 同步**: 版本串 BID=round88f。
- **验证**: `cmpBuildId` 源码级 node 测试 13/13（放行/拒绝/跨数字进位/多字母后缀/无 BID/乱串/大写）；Playwright（Edge `--browser msedge`）`?mock=1` 安全恢复两轮全过（三片备份→逐片 done+128/128 校验→完成报告），`window.__mbrRestoreBackups` 三键在位；release 构建 1.359 MB 部署 `Nyanithm_firmware_hw_v1/ControlPanel_v1.html`（devDiag==0，`verifiedBuilds` 旧串清零）。**真机回归待用户在场**。
- **坑位**: 本机 Chrome 未装，playwright-cli 需 `--browser msedge`（Edge 在 `Program Files (x86)`）；eval 里闭包变量（devInfo/configMode 等）不可见，状态断言走 DOM 日志（`#mainLog`）而非全局；对 `#mainLog` 做 `Object.defineProperty` instrumentation 会永久污染该元素（textContent 不可重定义且 getter 自递归栈溢出），换新页面重测即恢复正常——勿在同一页面上反复 instrument。





## 2026-10-01 round89a：实验性持续信号门，离线完成

固件1.6.6-beta1/round89a新增默认OFF的8Bprofile（controller_config字节91–98，128B不变）。面板PANEL_VERSION=1.1.1-beta7，配置区新增Z/F/ON%/OFF%及实际计数边界，匹配hw_v1签名/版本/BID后才可编辑。每次握手/断线清旧能力；hw3/4按固件强制MBR识别，切MPR清opt-in、保留合法点与check；CFG_SET继续双写/纯waitForLine。修正beta补丁段解析，保留新FW的C7能力。

单悬空峰值校准改为仅观察，无自动阈值/应用；evaluateMbrCalibration纯函数检查DIFF同单位、目标区域、样本数、重叠和裕量，建议仍关闭，尚未接完整采样向导。HYS与ATH生效说明、无标定毫米换算、低功耗刷新/GUARD/v2电极提示已修。Mock新增CFG_SAVE快照和同一活动端口枚举，两个CFG_SET入口sanitize新profile/重算XOR，GET_STATUS按当前hwVer返回。

生产helpers70/70；正式release Edge/Playwright Mock23/23，包含保存重连、MPR、hw3读存、旧FW、畸形握手和gen2拦截；favicon404及预期gen2拒绝console日志单列，无应用异常。release构建部署仅本地主维护树，devDiag=0。源码/原产物已提前备份；固件仓库随round89a本地提交，未推送/网站发布。本阶段未连真实设备，真实保存与游戏手感/距离验收待用户在场。详情见hw_v1/docs/MBR3116_round89a_离线实现与实机接续.md。

## 2026-10-01 round89b

面板1.1.1-beta8：精简修正SENSOR_EN高字节说明，三芯片CS0-11、双芯片CS0-15。没有改表、协议或保存行为。release/devDiag=0，纯函数70/70、Edge/Playwright Mock25/25（新增说明渲染与寄存器值保持检查）。备份在_dev_archive/round89b_before_20261001；实测确认DIFF悬空与轻触都可饱和255，后续仅推进固件和现有寄存器调整。详见hw_v1/docs/MBR3116_round89b_实测与固件寄存器路线.md。

## 2026-10-02 round89w

面板1.1.1-beta9：撤销fa64229后从备份源实现安全NVRAM调整。新增原生滤波/ATH/迟滞选择，硬件与基线只读；真实回读基底与安全掩码贯穿导入、单片/批量、保存重启。写前重新比对并备份、跳过无变化、完整128B回读、首错停止；未读禁写、旧BID禁写、断线清基底；切换保留草稿、读取/模板查看确认丢弃。所有普通写入复用mbrBurnOne。仅恢复模板触摸参数，不再整表覆盖硬件字段。

release为1.359MB/9812行/devDiag=0，部署仅hw_v1。46项参数/交互、27项严格BID、23项既有Mock链路通过；真机Web Serial16项覆盖B候选写/回读/原表恢复、保存重启/自动重连、128B配置不变与CE。真机回归后只收尾畸形BID门禁、版本与注释，写/保存实现不变。390px NVRAM弹窗无横向溢出，全页原输入测试溢出未扩修。

新A/B四组确认且恢复，B悬空仍有第15–18格最终输出，未获得稳定抗悬空配置；按用户要求暂停动作测试，候选不保留。完整复核/限制/源码证据包见hw_v1/docs/MBR3116_round89w_提交复核与原生滤波对照.md；仅本地提交，不推送。
