#!/usr/bin/env python3
"""Assemble ControlPanel_v1_refit.html from the extracted v3 base + v1 merge sources.

Inputs (all in this directory):
  ControlPanel_v1_refit.base.html  - stage-0 extraction from upstream ControlPanel_Master.html
  src/head_patch.css         - extra CSS for the new hw_v1 sections (v3 design tokens)
  src/body_main.html         - replacement <main> region ({{INPUTTEST}} placeholder kept
                               from the base file so the base64 INPUT TEST art survives)
  src/app_core.js            - protocol core (constants, MBR tables, UF2 parser, pure helpers)
  src/app_ui.js              - UI wiring (v3 components + v1 engine + mock device)

Output: ControlPanel_v1_refit.html
"""
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
SRC = HERE / "src"

HEADER_COMMENT = """<!--
 ============================================================================
 NYANITHM v1 Control Panel — refit edition(一代控制面板翻新)
 ============================================================================
 定位:一代 hw_v1 控制面板 (ControlPanel_v1.html) 的 UI 翻新,仍是 v1。
 三代 MASTER 控制面板 (NyaLab, CC-BY-NC-ND-4.0) 的 UI 壳
 + 一代 hw_v1 固件 (API 0x10 / cfgVer 0x02) 的串口引擎与功能集。

 结构:
   <style> #1  内嵌拉丁字体 (Chakra Petch / Saira / Sora;Noto Sans SC 子集
                已在阶段 0 剥除,中文回退系统字体)
   <style> #2  三代 UI 样式表(原样保留)
   <style> #3  hw_v1 翻新补丁样式(src/head_patch.css)
   <script>    早期主题预加载(原样保留)
   <body>      入场动画/页头/输入测试(原样保留)+ hw_v1 区块
               (src/body_main.html:指标行/状态栏/灯光测试/ToF/设置面板/日志)
   <script>    src/app_core.js + src/app_ui.js(一代引擎 + 三代组件)
               ?mock=1 启用内置设备模拟器;?mock=gen2 模拟非一代设备(门禁测试)

 上游版权与署名(NyaLab / CATIUM / NEKOTECH)按原样保留。
 本修改版仅限内部/授权范围内使用(CC-BY-NC-ND 不授权再分发修改版)。

 构建: py -3 build.py(先运行 extract_base.py 生成基线;
       --release 生成去掉开发期诊断条的发布版)
 ============================================================================
-->"""


def strip_devdiag(body: str) -> str:
    """--release:移除 body_main 中的开发期错误诊断条(标记块起至其 </script>)。"""
    start = body.find("<!-- 开发期错误诊断条:发布前移除 -->")
    if start < 0:
        print("FAIL: devDiag marker not found", file=sys.stderr)
        sys.exit(1)
    end = body.find("</script>", start)
    if end < 0:
        print("FAIL: devDiag closing script not found", file=sys.stderr)
        sys.exit(1)
    return body[:start] + body[end + len("</script>"):]


def main() -> int:
    release = "--release" in sys.argv
    base_path = HERE / "ControlPanel_v1_refit.base.html"
    base = base_path.read_text(encoding="utf-8")

    # 1) replace the stale upstream structure-map comment (first <!-- ... --> block)
    base, n = re.subn(r"<!--.*?-->", HEADER_COMMENT, base, count=1, flags=re.S)
    if n != 1:
        print("FAIL: header comment not found", file=sys.stderr)
        return 1

    # 2) title suffix
    base = base.replace("<title>NYANITHM Control Panel</title>",
                        "<title>NYANITHM Control Panel v1.1.1-beta6 · hw_v1</title>", 1)

    # 3) inject patch CSS as a third <style> right before the early-theme script
    patch_css = (SRC / "head_patch.css").read_text(encoding="utf-8")
    marker = "(function earlyThemeLoad()"
    mIdx = base.find(marker)
    if mIdx < 0:
        print("FAIL: early theme script marker not found", file=sys.stderr)
        return 1
    script_start = base.rfind("<script>", 0, mIdx)
    inject = "    <style>\n" + patch_css + "\n    </style>\n    "
    base = base[:script_start] + inject + base[script_start:]

    # 4) extract the INPUT TEST panel slice (base64 art must not be re-typed by hand)
    t0 = base.find("<!-- --- Input Test Panel --- -->")
    t1 = base.find("<!-- ========== STATUS BAR ==========")
    if t0 < 0 or t1 < 0 or t1 <= t0:
        print("FAIL: input-test slice markers not found", file=sys.stderr)
        return 1
    inputtest = base[t0:t1].rstrip() + "\n"

    # 5) replace the whole <main> region with the merged body
    body_main = (SRC / "body_main.html").read_text(encoding="utf-8")
    if release:
        body_main = strip_devdiag(body_main)
    body_main = body_main.replace("{{INPUTTEST}}", inputtest)
    m = re.search(r"<main class=\"app-main\">.*?</main>", base, re.S)
    if not m:
        print("FAIL: <main> region not found", file=sys.stderr)
        return 1
    base = base[:m.start()] + body_main.rstrip() + "\n" + base[m.end():]

    # 6) replace the main script block with core + ui
    core = (SRC / "app_core.js").read_text(encoding="utf-8")
    ui = (SRC / "app_ui.js").read_text(encoding="utf-8")
    main_marker = "    <script>\n        (function () {"
    s0 = base.find(main_marker)
    s1 = base.rfind("    </script>")
    main_end = base.rfind("</main>")
    if s0 < 0 or s1 < 0 or s1 <= s0:
        print("FAIL: main script block not found", file=sys.stderr)
        return 1
    if s0 < main_end:
        # 主脚本必须位于 </main> 之后;否则锚点误匹配到了头部的预载脚本
        print("FAIL: main script anchor resolved inside/before <main>", file=sys.stderr)
        return 1
    s1_end = s1 + len("    </script>")
    new_script = "    <script>\n" + core + "\n" + ui + "\n    </script>"
    base = base[:s0] + new_script + base[s1_end:]

    out = HERE / "ControlPanel_v1_refit.html"
    out.write_text(base, encoding="utf-8", newline="")
    print(f"built {out.name}: {out.stat().st_size/1e6:.3f} MB, {base.count(chr(10))+1} lines")

    if release:
        fw_target = HERE.parent / "Nyanithm_firmware_hw_v1" / "ControlPanel_v1.html"
        if fw_target.parent.exists():
            fw_target.write_text(base, encoding="utf-8", newline="")
            print(f"  deployed release build to {fw_target.name} ({fw_target.stat().st_size/1e6:.3f} MB)")
            assert base.count("devDiag") == 0, "devDiag count must be 0 in release deployment"

    # sanity greps — 只选"必须来自页面主体/页脚"的标记,防止被脚本内容糊弄
    for needle in ["toggleInputBtn", "ledStrip", "flashConfirmModal", "app-footer",
                   "panel-test", "panel-config", "hwSegmented", "mainLog"]:
        ok = needle in base
        print(f"  contains {needle!r}: {ok}")
        if not ok:
            print("FAIL: body marker missing", file=sys.stderr)
            return 1
    print(f"  <main> count: {base.count('<main')} (expect 1)")
    print(f"  real <body> tag count: {base.count(chr(10) + '<body>' + chr(10))} (expect 1)")
    print(f"  leftover v3 modeSegmented refs: {base.count('modeSegmented')} (expect 0)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
