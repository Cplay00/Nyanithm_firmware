round89w 本地证据包，2026-10-02。
四组确认动作/恢复已核对；preflight不计效果组。用户暂停后续配合测试，采样服务已关闭。
源码/数据按工作区相对路径保存；解压到新的目录进行离线复核，不覆盖当前工作区。
离线分析：py -3 _dev_tools/round89u_analyze.py
绘图：py -3.12 _dev_tools/round89w_plot.py（matplotlib）
面板重建：py -3 ControlPanel_v1_refit_dev/build.py --release
qa/包含实际测试脚本及测试时HTML；46项测试后仅改版本标记/注释，写/保存实现不变。
QA脚本原有本机路径需改为解压目录；Playwright依赖用本机安装路径。Mock不得连接真实设备。
真机回归在最终畸形BID门禁3行收尾前进行，report中保留真实断开/开发CSP日志。
真机脚本及候选仅作证据，继续前需要重新核对设备身份、当前配置/备份及用户测试状态。
未获得稳定抗悬空配置；设备保持原始三片NVRAM、现有controller_config与round89g。
ZIP中的manifest.json逐项保存SHA-256与大小；证据核对JSON保存ZIP SHA及恢复/发布检查。
