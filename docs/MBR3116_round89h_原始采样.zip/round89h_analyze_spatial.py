import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "round89h_spatial_20261001"
WINDOW = (6.0, 11.5)


def stats(values):
    if not values:
        return None
    values = sorted(values)
    return {"min": values[0], "p05": values[int((len(values) - 1) * .05)],
            "median": statistics.median(values), "p95": values[int((len(values) - 1) * .95)], "max": values[-1]}


def features(value):
    total, peak = sum(value), max(value)
    center = sum(i * v for i, v in enumerate(value)) / total if total else 0
    spread = (sum(v * (i - center) ** 2 for i, v in enumerate(value)) / total) ** .5 if total else 0
    result = {"peak": peak, "total": total, "concentration": peak / total if total else 0,
              "centroid": center + 1 if total else 0, "spread": spread, "lane17": value[16]}
    result.update({f"width_{threshold}": sum(v >= threshold for v in value) for threshold in (1, 80, 127, 179, 200, 255)})
    return result


def analyze():
    reports, known = [], []
    for path in sorted(ROOT.glob("*.json")):
        job = json.loads(path.read_text(encoding="utf-8"))
        if "mode" not in job or not path.with_suffix(".csv").exists():
            continue
        rows = list(csv.DictReader(path.with_suffix(".csv").open(encoding="utf-8", newline="")))
        held = [r for r in rows if r["phase"] == "hold" and r["phase_valid"] == "1" and not r["error"]
                and WINDOW[0] <= float(r["elapsed_s"]) <= WINDOW[1]]
        values = [bytes.fromhex(r["pressures"]) for r in held]
        fs = [features(v) for v in values]
        lanes = {str(i + 1): stats([v[i] for v in values]) for i in range(32) if any(v[i] for v in values)}
        report = {"id": job["id"], "mode": job["mode"], "user_confirmed": job.get("user_confirmed"),
                  "completed": job.get("completed", False), "valid_window_rows": len(held),
                  "features": {key: stats([v[key] for v in fs]) for key in fs[0]} if fs else {},
                  "lanes": lanes, "all_zero_rows": sum(not any(v) for v in values),
                  "request_ms": stats([float(r["request_ms"]) for r in held]),
                  "gate_failure_delta": (int(held[-1]["gate_failures"]) - int(held[0]["gate_failures"])) & 0xFFFFFFFF if held else None}
        reports.append(report)
        if job.get("user_confirmed") is True and job.get("completed"):
            known.extend((job["mode"], job["id"], float(row["elapsed_s"]), vector,
                          int(row["gate_failures"])) for row, vector in zip(held, values))
    matches = defaultdict(list)
    for mode, identifier, elapsed, vector, failures in known:
        if any(vector):
            matches[vector].append({"mode": mode, "id": identifier, "elapsed_s": elapsed, "gate_failures": failures})
    collisions = []
    for vector, records in matches.items():
        if any("hover" in r["mode"] for r in records) and any("contact" in r["mode"] for r in records):
            collisions.append({"vector_hex": vector.hex(), "examples": [next(r for r in records if "hover" in r["mode"]),
                                                                          next(r for r in records if "contact" in r["mode"])],
                               "matched_rows": len(records)})
    return {"window_s": list(WINDOW), "semantics": "Confirmed poses only for collision search; no signal-based subset selection. Heights are approximate. B1 pressure snapshots may contain retained sensor data; global gate counter is not per-pressure validity.",
            "jobs": reports, "cross_class_nonzero_vector_collisions": collisions}


if __name__ == "__main__":
    result = analyze()
    (ROOT / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for job in result["jobs"]:
        print(job["mode"], job["user_confirmed"], "n", job["valid_window_rows"],
              "features", job["features"], "gate_failures", job["gate_failure_delta"])
    print("NONZERO VECTOR COLLISIONS", len(result["cross_class_nonzero_vector_collisions"]))
    print(json.dumps(result["cross_class_nonzero_vector_collisions"][:4], indent=2))
