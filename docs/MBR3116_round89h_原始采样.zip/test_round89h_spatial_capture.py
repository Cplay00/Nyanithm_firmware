from types import SimpleNamespace

import round89h_spatial_capture as spatial


class Port:
    def __init__(self, content):
        self.content = bytearray(content)
        self.writes = []

    def read(self, count):
        part = bytes(self.content[:count])
        del self.content[:count]
        return part

    def write(self, value):
        self.writes.append(value)


pressure = bytes(range(33))
chain = bytes([0xAA, 0x55]) + bytes(range(44))
telemetry = bytearray(528)
telemetry[:4] = (12000).to_bytes(4, "little")
telemetry[36:40] = (15).to_bytes(4, "little")
port = Port(pressure + chain + telemetry)
row = spatial.read_spatial(port)
assert port.writes == [b"\xb1", b"\xc0", b"\xc1"] and not port.content
assert row["diff"] == 16 and row["air"] == 32
assert bytes.fromhex(row["pressures"]) == pressure[:32]
assert bytes.fromhex(row["hardware"]) == chain[2:8]
assert bytes.fromhex(row["verified"]) == chain[8:14]
assert bytes.fromhex(row["final"]) == chain[14:46]
assert row["gate_failures"] == 15 and row["uptime_ms"] == 12000
try:
    spatial.read_spatial(Port(pressure + b"\x00\x00" + chain[2:] + telemetry))
    raise AssertionError("bad frame accepted")
except RuntimeError:
    pass
print("PASS full-board snapshot parsing, separate transaction fields, counters, frame rejection")
