const assert=require('assert');
const path=require('path');
const {chromium}=require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
  const browser=await chromium.launch({channel:'msedge',headless:true});
  const page=await browser.newPage({viewport:{width:1100,height:850}});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
  let state={running:false,phase:'idle',message:'请先将整只手移开至少30 cm',jobs:[],end_ms:0};
  const requests=[];
  await page.route('**/*',async route=>{
    const p=new URL(route.request().url()).pathname;
    if(!['/status','/start','/label','/finish'].includes(p))return route.continue();
    if(p==='/start'){const mode=route.request().postDataJSON().mode;requests.push(mode);state={...state,running:true,phase:mode==='finger_hover3'?'preparing':'hold',message:mode==='finger_hover3'?'设备准备中，请继续保持手远离':'食指轻触同一点，保持不动',end_ms:mode==='finger_hover3'?0:Date.now()+8000};}
    if(p==='/label'){state.jobs.at(-1).user_confirmed=route.request().postDataJSON().valid;}
    if(p==='/finish'){state={...state,running:false,phase:'closed',message:'诊断已退出，设备恢复普通模式',end_ms:0};}
    return route.fulfill({contentType:'application/json',body:JSON.stringify(p==='/status'?{...state,now_ms:Date.now()}:{} )});
  });
  const captureUrl=process.env.CAPTURE_URL||'http://127.0.0.1:8766/';
  const isProx=captureUrl.includes('8769');
  const imagePrefix=isProx?'round89k_prox':captureUrl.includes('8768')?'round89i_pair':captureUrl.includes('8767')?'round89h_spatial':'round89h_timed';
  await page.goto(captureUrl);assert.equal(await page.title(),isProx?'原生参考模式对照':'触摸对照采样');
  if(captureUrl.includes('8767'))assert.equal(await page.locator('#mode option[value="multi_contact"]').count(),1);
  await page.getByText('请先将整只手移开至少30 cm',{exact:true}).waitFor();
  await page.locator('#mode').selectOption('finger_contact');
  await page.locator('#start').click();await page.locator('.cue.hold').waitFor();assert(await page.locator('#start').isDisabled());
  await page.waitForFunction(()=>/^\d+$/.test(document.getElementById('timer').textContent));
  assert(Number(await page.locator('#timer').textContent())>0);
  await page.screenshot({path:path.join(__dirname,imagePrefix+'_desktop.png')});
  if(isProx){state={...state,running:true,phase:'restoring',message:'采样结束，请保持手远离，正在恢复设置',end_ms:0};await page.getByText('正在恢复原设置',{exact:true}).waitFor();assert(await page.locator('#start').isDisabled());assert(await page.locator('#valid').isDisabled());assert(await page.locator('#finish').isDisabled());}
  state={...state,running:false,phase:'done',message:'采完了，请保持手远离，并确认这一组动作',end_ms:0,jobs:[{id:'fake',mode:'finger_contact',user_confirmed:null}]};
  await page.getByText('请确认本组动作',{exact:true}).waitFor();assert(await page.locator('#start').isDisabled());
  await page.locator('#valid').click();await page.getByText('食指轻触：已确认',{exact:true}).waitFor();assert(await page.locator('#start').isEnabled());
  if(isProx){state={...state,blocked:true};await page.waitForFunction(()=>document.getElementById('start').disabled&&document.getElementById('finish').disabled);state={...state,blocked:false};await page.waitForFunction(()=>!document.getElementById('start').disabled);}
  await page.locator('#mode').selectOption('finger_hover5');await page.locator('#start').click();assert.deepEqual(requests,['finger_contact','finger_hover5']);
  state={...state,running:false,phase:'done',end_ms:0,jobs:[...state.jobs,{id:'fake2',mode:'finger_hover5',user_confirmed:null}]};
  await page.locator('#invalid').click();await page.getByText('食指悬空5 mm：已作废',{exact:true}).waitFor();
  if(isProx){await page.locator('#mode').selectOption('finger_hover3');await page.locator('#start').click();await page.getByText('设备准备中，请继续保持手远离',{exact:true}).waitFor();assert(await page.locator('#valid').isDisabled());state={...state,phase:'restoring',message:'尚未开始动作采样，正在恢复设置，请保持手远离'};await page.getByText(state.message,{exact:true}).waitFor();state={...state,running:false,phase:'error',message:'采样未完成，原设置已恢复。请保持手远离后重试本组'};await page.getByText(state.message,{exact:true}).waitFor();assert(await page.locator('#start').isEnabled());assert(await page.locator('#valid').isDisabled());assert.equal(state.jobs.length,2);}
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(__dirname,imagePrefix+'_mobile.png')});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.locator('#finish').click();await page.getByText('设备已恢复普通模式',{exact:true}).waitFor();
  assert.deepEqual(errors,[]);await browser.close();console.log('PASS page, countdown, running guard, confirmation, discard, selected mode, mobile layout, finish, console; mock only; Browser plugin not available');
})().catch(e=>{console.error(e);process.exit(1)});
