import argparse
import json
import queue
import threading
import time
from pathlib import Path

import round89h_timed_capture as ui
import round89j_prox_idle as probe

ROOT = Path(__file__).resolve().parents[1]
ORIGINALS = {a: (probe.ARCHIVE / f"chip_{a:02x}.bin").read_bytes() for a in (0x40, 0x41, 0x42)}
CFG = (probe.ARCHIVE / "controller_config.bin").read_bytes()
DESIRED = probe.make_patch(ORIGINALS[probe.ADDRESS])
NATIVE = ui.read_native
STOP = threading.Event()
ui.OUT = ROOT / "_dev_tools/round89k_prox_20261001"
ui.ORIGIN = "http://127.0.0.1:8769"
ui.FIELDS += ["ref_sync", "ref_cp_pf", "ref_diff", "ref_baseline", "ref_raw", "ref_delta", "delta_ratio"]


def wait_ready(port, rows=None, timeout=6):
    rows = [] if rows is None else rows
    started = time.monotonic()
    while time.monotonic() - started < timeout:
        rows.extend(probe.samples(port, 1))
        window = rows[-10:]
        good = [row for row in window if not row["error"] and row.get("raw", 0) > 0 and row.get("baseline", 0) > 0]
        if len(window) == 10 and len(good) >= 9 and all(not row["error"] and row.get("raw", 0) > 0 and row.get("baseline", 0) > 0 for row in window[-2:]):
            return rows
    raise RuntimeError("device warmup did not become readable")


def load_history():
    jobs = []
    for path in sorted(ui.OUT.glob("*.json")):
        job = json.loads(path.read_text(encoding="utf-8"))
        if job.get("completed") and job.get("hardware", {}).get("restore_after_reboot"):
            jobs.append(job)
    with ui.LOCK:
        ui.STATE["jobs"] = jobs


def read_pair(port):
    center = NATIVE(port, 0x40, 7)
    if center["error"]:
        return {"error": "center: " + center["error"]}
    reference = NATIVE(port, 0x42, 0)
    if reference["error"]:
        return {"error": "reference: " + reference["error"]}
    result = dict(center)
    result.update({"ref_" + key: value for key, value in reference.items() if key != "error"})
    result["delta_ratio"] = reference["delta"] / center["delta"] if center["delta"] > 0 else ""
    return result


def run_job(job):
    folder = ui.OUT / (job["id"] + "_device")
    folder.mkdir()
    port = None
    entered, attempted = False, False
    report = {"programming_attempted": False, "candidate_applied": False, "restore_verified": False, "restore_after_reboot": False}
    job["hardware"] = report
    job["capture_started"] = False
    job["reference_mode"] = "0x42 CS0 Proximity 12-bit; center 0x40 CS7 button; sequential native C7"
    try:
        ui.update(phase="preparing", message="设备准备中，请继续保持手远离", end_ms=0)
        port, info = probe.connect_reboot_ready()
        firmware = ui.live.version(port)
        report["usb_serial"] = info.serial_number
        port.write(b"\xb3")
        entered = True
        ui.live.tail(port, .25)
        before = {a: probe.read_chip(port, a) for a in ORIGINALS}
        cfg, _ = ui.live.config_read(port)
        if before != ORIGINALS or cfg != CFG:
            ui.update(blocked=True)
            raise RuntimeError("current device differs from the verified backup")
        for a, table in before.items():
            (folder / f"chip_{a:02x}.bin").write_bytes(table)
        (folder / "controller_config.bin").write_bytes(cfg)
        attempted = True
        report["programming_attempted"] = True
        report["apply_reply"] = probe.program(port, DESIRED)
        candidate = {a: probe.read_chip(port, a) for a in ORIGINALS}
        if candidate[probe.ADDRESS] != DESIRED or any(candidate[a] != ORIGINALS[a] for a in ORIGINALS if a != probe.ADDRESS):
            raise RuntimeError("temporary configuration readback mismatch")
        report["candidate_applied"] = True
        report["warmup"] = []
        wait_ready(port, report["warmup"])
        job["capture_started"] = True
        ui.capture_job(port, job, firmware, reader=read_pair, publish=False)
        if any(job["summary"][phase]["valid"] < 10 or job["summary"][phase]["valid"] < job["summary"][phase]["rows"] * .5
               for phase in ("baseline", "hold", "release")):
            raise RuntimeError("too few valid native pairs")
    except Exception as error:
        report["error"] = repr(error)
    finally:
        try:
            if attempted:
                message = "动作记录完成，请保持手远离，正在恢复设置" if job["capture_started"] else "尚未开始动作采样，正在恢复设置，请保持手远离"
                ui.update(phase="restoring", message=message, end_ms=0)
                probe.restore(port, ORIGINALS, CFG, report)
        except Exception as error:
            report["restore_error"] = repr(error)
            ui.update(blocked=True)
        finally:
            try:
                if entered and (not attempted or report["restore_verified"]):
                    port.write(b"\xb9")
                    port.flush()
            except Exception as error:
                report["exit_error"] = repr(error)
                if attempted:
                    ui.update(blocked=True)
            finally:
                if port:
                    port.close()
                ui.save_job(job)
    if attempted and report["restore_verified"]:
        try:
            after = folder / "after_reboot"
            after.mkdir()
            ui.live.connect = probe.connect_reboot_ready
            ui.live.snapshot(after)
            report["restore_after_reboot"] = all((after / f"chip_{a:02x}.bin").read_bytes() == ORIGINALS[a] for a in ORIGINALS) and (after / "controller_config.bin").read_bytes() == CFG
            if not report["restore_after_reboot"]:
                raise RuntimeError("restoration after reboot mismatch")
        except Exception as error:
            report["reboot_error"] = repr(error)
            ui.update(blocked=True)
    success = report["restore_after_reboot"] and report["candidate_applied"] and not any(key in report for key in ("error", "restore_error", "exit_error", "reboot_error"))
    job["completed"] = bool(job.get("completed") and success)
    ui.save_job(job)
    if not job["completed"]:
        raise RuntimeError(json.dumps(report, ensure_ascii=False))
    with ui.LOCK:
        ui.STATE["jobs"].append(job)
    ui.update(running=False, phase="done", message="原设置已恢复，请确认本组动作", end_ms=0)


def worker():
    while not STOP.is_set():
        try:
            task = ui.TASKS.get(timeout=.2)
        except queue.Empty:
            continue
        with ui.LOCK:
            rejected = ui.STATE.get("blocked", False) or ui.STATE.get("stopping", False)
        if rejected:
            ui.update(running=False, phase="error", message="恢复尚未核实或服务正在关闭，请联系我", end_ms=0)
            continue
        if task == "finish":
            ui.update(running=False, phase="closed", message="设备已恢复普通模式，串口已关闭", end_ms=0)
            continue
        try:
            run_job(task)
        except Exception as error:
            print("ERROR", repr(error), flush=True)
            report = task.get("hardware", {})
            if report.get("programming_attempted") and not report.get("restore_after_reboot"):
                ui.update(blocked=True)
            if report.get("restore_after_reboot"):
                message = "采样未完成，原设置已恢复。请保持手远离后重试本组"
            else:
                message = "采样失败，恢复尚未核实。请保持手远离并联系我"
            ui.update(running=False, phase="error", message=message, end_ms=0)


class Handler(ui.Handler):
    def do_GET(self):
        if self.path != "/":
            return super().do_GET()
        page = Path(__file__).with_name("round89h_timed_capture.html").read_text(encoding="utf-8")
        page = page.replace("触摸对照采样", "原生参考模式对照")
        page = page.replace('value="finger_hover3"', 'value="finger_hover3" selected')
        page = page.replace("开始前整只手远离至少30 cm；", "高度可用尺子辅助手动估计。每组结束自动恢复原设置，期间会普通重启；请等恢复完成再确认。开始前整只手远离至少30 cm；")
        page = page.replace("state.running||unconfirmed", "state.running||state.blocked||unconfirmed")
        page = page.replace("$('finish').disabled=state.running", "$('finish').disabled=state.running||state.blocked")
        page = page.replace("设备已恢复普通模式'}", "设备已恢复普通模式',restoring:'正在恢复原设置'}")
        self.send(200, page.encode("utf-8"), "text/html; charset=utf-8")

    def do_POST(self):
        with ui.LOCK:
            blocked = ui.STATE.get("blocked", False) or ui.STATE.get("stopping", False)
        if blocked and self.path in ("/start", "/finish"):
            return self.send(409, {"error": "恢复尚未核实，请联系我"})
        if self.path == "/shutdown":
            if self.headers.get("Origin") != ui.ORIGIN:
                return self.send(403, {"error": "origin rejected"})
            with ui.LOCK:
                if ui.STATE["running"]:
                    return self.send(409, {"error": "请等当前恢复完成"})
                ui.STATE["stopping"] = True
            self.send(200, {"closing": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        return super().do_POST()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    if not args.serve:
        parser.error("use --serve")
    ui.OUT.mkdir(exist_ok=True)
    load_history()
    httpd = ui.ThreadingHTTPServer(("127.0.0.1", 8769), Handler)
    worker_thread = threading.Thread(target=worker, daemon=False)
    worker_thread.start()
    print("READY http://127.0.0.1:8769", flush=True)
    try:
        httpd.serve_forever()
    finally:
        ui.update(stopping=True)
        STOP.set()
        httpd.server_close()
        worker_thread.join()
