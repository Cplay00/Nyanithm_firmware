import hashlib
import json
import zipfile
from pathlib import Path

import round89i_analyze_pair as paired

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "_dev_tools/round89k_prox_20261001"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
paired.ROOT = DATA
analysis = paired.analyze()
analysis["semantics"] = "Sequential native C7; 0x40 CS7 button center and temporary 0x42 CS0 Proximity 12-bit ALP reference. Only completed and human-confirmed contact is accepted; all hover attempts excluded."
valid = [j for j in analysis["jobs"] if j["completed"] and j["user_confirmed"] is True]
if len(valid) != 1 or valid[0]["mode"] != "finger_contact" or valid[0]["windows"]["hold"]["valid"] != 42:
    raise RuntimeError("unexpected accepted sample set")
jobs = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(DATA.glob("*.json"))]
failed = [{"id": j["id"], "mode": j["mode"], "capture_started": j.get("phase_plan") is not None,
           "user_confirmed": j.get("user_confirmed"), "exclusion_reason": j.get("exclusion_reason"),
           "error": j.get("hardware", {}).get("error"), "reboot_error": j.get("hardware", {}).get("reboot_error")}
          for j in jobs if not j.get("completed")]
after = ROOT / "_dev_tools/round89l_before_repair_20261001"
before = ROOT / "_dev_archive/round89j_device_before_20261001"
equal = all((after / name).read_bytes() == (before / name).read_bytes() for name in ("controller_config.bin", "chip_40.bin", "chip_41.bin", "chip_42.bin"))
snapshot = json.loads((after / "snapshot.json").read_text(encoding="utf-8"))
if not equal or snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
    raise RuntimeError("device baseline not verified")
evidence = {"date": "2026-10-01", "accepted_samples": valid, "failed_attempts_excluded": failed,
            "device_after_failures": {"four_blocks_equal_to_backup": equal, "raw": snapshot["raw_status"], "slider_all_zero": True, "version": snapshot["version"]},
            "fixes": ["Replace last-eight perfection test with rolling 9/10 native readable rows plus last two valid; preserve all invalid rows",
                      "Distinguish preparation failure from completed pose capture", "Retry exact missing USB enumeration races while rejecting wrong firmware identity",
                      "Load confirmed contact history without admitting failed hover attempts"],
            "tests": {"probe": "7/7", "capture": "12/12", "common_parser": "PASS", "browser_mock": "PASS including preparation abort without success/confirmation", "independent_readonly_review": "12/12 pure memory cases; no hardware access"},
            "native_mode_fields_unchanged": True, "cpp_or_production_panel_edits": False,
            "limitations": ["No valid corresponding hover group exists, so no distance classifier or improvement conclusion", "Accepted Proximity reference was constant during contact; further data and filter investigation required", "Timeout windows are loop targets, not hard wall-clock deadlines"]}
files = {}
for directory, prefix in ((DATA, "samples"), (after, "device_after_failures")):
    for path in directory.rglob("*"):
        if path.is_file():
            files[f"{prefix}/{path.relative_to(directory).as_posix()}"] = path
for name in ("round89j_prox_idle.py", "round89k_prox_capture.py", "round89h_timed_capture.py", "round89h_timed_capture.html",
             "round89h_raw_capture.py", "round89g_latency_probe.py", "round89_live.py", "round89_live_debug.py",
             "round89i_analyze_pair.py", "round89h_analyze_timed.py", "test_round89j_prox_idle.py", "test_round89k_prox_capture.py",
             "test_round89h_timed_capture.py", "test_round89h_timed_ui.js", "round89l_package_evidence.py"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89l_采样修复证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
with zipfile.ZipFile(archive) as bundle:
    for name, digest in manifest.items():
        if hashlib.sha256(bundle.read(name)).hexdigest() != digest:
            raise RuntimeError("archive mismatch: " + name)
evidence["archive"] = {"name": archive.name, "files": len(manifest), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "size": archive.stat().st_size}
(DOCS / "MBR3116_round89l_采样修复证据.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "contact pairs", 42, "excluded attempts", len(failed))
