"""C8 completed-frame capture; no NVRAM writes or extra sensor reads."""
import argparse
import json
import struct
import threading
import time
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import round89x_dynamics_capture as sampler
from round89g_latency_probe import connect_target

SIGNATURE = "NYANFW1;1.6.6-beta5;hw_v1;BID=round89x"
ROOT = Path(__file__).resolve().parents[1]


class TraceHandler(sampler.Handler):
    def do_GET(self):
        if urlsplit(self.path).path == "/":
            html = Path(sampler.__file__).with_suffix(".html").read_text(encoding="utf-8")
            html = html.replace("触摸动态对照", "同帧信号对照").replace("依次完成四组", "依次完成三组")
            html = html.replace('<option value="fast_contact">3 · 快速真实点按</option>', "")
            html = html.replace("4 · 快速手掌悬空", "3 · 快速手掌悬空")
            return self.send(200, html.encode("utf-8"), "text/html; charset=utf-8")
        return super().do_GET()


def connect_checked():
    port, info = connect_target()
    try:
        if SIGNATURE not in sampler.live.version(port):
            raise RuntimeError("C8 requires round89x firmware")
        return port, info
    except Exception:
        port.close()
        raise


def parse_trace(data):
    if len(data) != 240 or data[:2] != b"\xc8\x01":
        raise ValueError("invalid C8 length/version")
    chip_count, flags = data[2:4]
    if chip_count not in (0, 2, 3) or flags & ~0x81:
        raise ValueError("invalid C8 header")
    frame, published = struct.unpack_from("<II", data, 4)
    counts = struct.unpack_from("<32H", data, 12)
    slider = data[76:108]
    if any(x not in (0, 128) for x in slider):
        raise ValueError("invalid C8 slider")
    chips = []
    names = ("read_calls", "io_failures", "sync_mismatches", "attempt_start_ms", "attempt_end_ms",
             "good_start_ms", "good_end_ms", "button_start_ms", "button_end_ms", "range_mask", "flags", "sync")
    for m in range(3):
        value = dict(zip(names, struct.unpack_from("<9IHBB", data, 120 + 40*m)))
        value["good_age_ms"] = (published - value["good_start_ms"]) & 0xffffffff
        value["usable"] = bool(flags & 1 and not flags & 128 and m < chip_count
                               and value["flags"] & 0x0e == 0x0e and value["good_age_ms"] <= 15)
        chips.append(value)
    return {"frame_id": frame, "published_ms": published, "report_flags": flags,
            "chip_count": chip_count, "counts": counts, "slider": slider,
            "hardware": data[108:114], "verified": data[114:120], "chips": chips}


def read_trace(port, origin):
    began = time.perf_counter()
    port.write(b"\xc8")
    first = sampler.live.exact(port, 1, 1)
    if first == b"\x00":
        raise RuntimeError("C8 BUSY; end transaction before retry")
    if first != b"\xc8":
        raise RuntimeError("unexpected C8 prefix; stop without sending another command")
    data = first + sampler.live.exact(port, 239, 1)
    ended = time.perf_counter()
    decoded = parse_trace(data)
    return began-origin, ended-origin, data, decoded


def capture(port, job):
    job.update(phase_plan=sampler.phase_plan(job["mode"]), completed=False,
               user_confirmed=None, cue_events=[], semantics=(
                   "One C8 completed host frame pairs 16-bit counts, BUTTON_STAT, verification and final output. "
                   "Chip reads are sequential, not simultaneous; SYNC is coherence, not scan freshness. "
                   "VALID means latest read attempt succeeded; age must also be checked. "
                   "COHERENT/HAS_GOOD describe retained counts even after failure. Counters reset on profile/layout change. "
                   "Only PROFILE gate reads are included. Cue time is not physical contact time."))
    started = time.perf_counter()
    epoch = time.time()*1000
    current = None
    rows = []
    while time.perf_counter()-started < job["phase_plan"][-1]["end_s"]:
        if sampler.ABORT.is_set():
            job["aborted"] = True
            break
        elapsed = time.perf_counter()-started
        phase = next((p for p in job["phase_plan"] if p["start_s"] <= elapsed < p["end_s"]), None)
        if phase is None:
            break
        if current != phase["cue_id"]:
            current = phase["cue_id"]
            job["cue_events"].append({"cue_id": current, "server_elapsed_s": elapsed})
            sampler.update(phase=phase["phase"], cue_id=current,
                           message=(f"第{phase['repeat']}次： " if phase["repeat"] else "")+phase["message"],
                           end_ms=epoch+phase["end_s"]*1000)
        tick = time.perf_counter()
        begin, end, data, decoded = read_trace(port, started)
        rows.append({"elapsed_s": (begin+end)/2, "start_s": begin, "end_s": end,
                     "phase": phase["phase"], "repeat": phase["repeat"], "trace_hex": data.hex()})
        time.sleep(max(0, .02-(time.perf_counter()-tick)))
    (sampler.OUT/(job["id"]+".trace.json")).write_text(json.dumps(rows, indent=2)+"\n", encoding="utf-8")
    job["rows"] = len(rows)
    job["completed"] = not job.get("aborted", False)


def preflight(out):
    out.mkdir(parents=True, exist_ok=False)
    port, info = connect_checked()
    try:
        result = {"usb_serial": info.serial_number, "firmware": sampler.live.version(port), "rows": []}
        started = time.perf_counter()
        for _ in range(150):
            begin, end, data, decoded = read_trace(port, started)
            result["rows"].append({"start_s": begin, "end_s": end, "trace_hex": data.hex()})
            time.sleep(.02)
        for m in range(3):
            frames = [parse_trace(bytes.fromhex(r["trace_hex"])) for r in result["rows"]]
            print("CHIP", hex(0x40+m), "usable", sum(f["chips"][m]["usable"] for f in frames),
                  "first", frames[0]["chips"][m], "last", frames[-1]["chips"][m], flush=True)
        port.write(b"\xc4")
        result["raw_status"] = sampler.live.tail(port)
        if result["raw_status"] != "RAW=0":
            raise RuntimeError("preflight RAW mode unexpected")
        (out/"preflight.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    finally:
        port.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--port", type=int, default=8774)
    parser.add_argument("--out", required=True)
    parser.add_argument("--backup")
    args = parser.parse_args()
    if args.preflight:
        preflight(Path(args.out).resolve())
    else:
        sampler.OUT = Path(args.out).resolve()
        sampler.OUT.mkdir(parents=True, exist_ok=True)
        sampler.BACKUP = Path(args.backup).resolve() if args.backup else None
        if sampler.BACKUP is None or not (sampler.BACKUP/"snapshot.json").is_file():
            parser.error("real capture requires verified backup")
        sampler.connect_checked = connect_checked
        sampler.capture = capture
        sampler.MODES.pop("fast_contact")
        sampler.ORIGIN = f"http://127.0.0.1:{args.port}"
        threading.Thread(target=sampler.worker, daemon=True).start()
        print("READY", sampler.ORIGIN, "C8 REAL", flush=True)
        ThreadingHTTPServer(("127.0.0.1", args.port), TraceHandler).serve_forever()
