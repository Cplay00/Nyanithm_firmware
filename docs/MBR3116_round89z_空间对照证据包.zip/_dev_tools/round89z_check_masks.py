"""Check row geometry, plateau counterexample, and candidate distinctions."""
import round89z_spatial as spatial

assert spatial.neighbors(0, True) == [2]
assert spatial.neighbors(1, True) == [3]
assert spatial.neighbors(16, True) == [14, 18]
assert spatial.neighbors(31, True) == [29]
for i in range(32):
    assert all(j % 2 == i % 2 and abs(i-j) == 2 for j in spatial.neighbors(i, True))
row = {"counts": [0]*32, "hardware": bytes(6), "slider": [0]*32}
row["counts"][16] = 255
row["slider"][16] = 1
assert all(m[16] for m in spatial.masks(row, True).values())
for i in (12, 14, 16, 18):
    row["counts"][i] = 255
    row["slider"][i] = 1
value = spatial.masks(row, True)
assert not any(value["width4"])
assert value["curvature1_when_width4"][12] and not value["curvature1_when_width4"][14]
assert not any(value["prominence32_when_width4"][i] for i in (12,14,16,18))
hardware = bytearray(6)
for i in (12,14,16,18):
    m,e = spatial.trace.base.LM[i], spatial.trace.base.LE[i]
    bits = int.from_bytes(hardware[2*m:2*m+2], 'little') | (1 << e)
    hardware[2*m:2*m+2] = bits.to_bytes(2, 'little')
row["hardware"] = bytes(hardware)
assert spatial.features(row)["native_count"] == 4
assert all(spatial.masks(row, True)["width4to7_native1to3"])
print('PASS geometry for all32, isolated peak, plateau, native-bit mapping and bounded-width distinction')
