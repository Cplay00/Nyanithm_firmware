"""Package frozen rules, raw gestures, clarifications and unchanged-device proof."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
repo = root/'Nyanithm_firmware_hw_v1'
out = root/'_dev_tools/round89z_trace_20261002'
doc = repo/'docs/MBR3116_round89z_两排空间候选对照.md'
archive = repo/'docs/MBR3116_round89z_空间对照证据包.zip'
check = repo/'docs/MBR3116_round89z_证据核对.json'
files = set()
queue = list((root/'_dev_tools').glob('round89z_*.py'))
while queue:
    file = queue.pop()
    if file in files:
        continue
    files.add(file)
    syntax = ast.parse(file.read_text(encoding='utf-8-sig'))
    for node in ast.walk(syntax):
        names = ([n.name for n in node.names] if isinstance(node,ast.Import) else
                 [node.module] if isinstance(node,ast.ImportFrom) and node.module else [])
        for name in names:
            candidate = root/'_dev_tools'/f'{name.split(".")[0]}.py'
            if candidate.is_file():
                queue.append(candidate)
for folder in (out, root/'_dev_archive/round89z_device_before_20261002', root/'_dev_tools/round89z_mock2_20261002'):
    files.update(p for p in folder.rglob('*') if p.is_file())
files.update([doc,repo/'更新日志_固件.md',root/'_dev_tools/round89x_dynamics_capture.html'])
for name in ('hw_devices.cpp','cy8cmbr3116.cpp','app_link.cpp'):
    files.add(repo/'src'/name)
files.add(repo/'include/share/nyanithm_shared.h')
for file in (root/'_dev_tools').glob('round89z_*'):
    if file.is_file():
        files.add(file)
for folder, ids in [('round89x_trace_20261002', ['1790935281503192800_slow_contact',
        '1790935345000467500_fast_finger_hover','1790935404013359900_fast_palm_hover']),
        ('round89y_trace_20261002',['1790944087787575400_slow_contact',
        '1790944123546157600_fast_contact','1790944218673835600_slide_contact'])]:
    for identifier in ids:
        for suffix in ('.json','.trace.json'):
            files.add(root/'_dev_tools'/folder/(identifier+suffix))
# The pre-layout trial is deliberately omitted; only the confirmed +/-2 replay is evidence.
files.discard(root/'_dev_tools/round89z_existing_global_x.json')
manifest = {str(p.relative_to(root)).replace('\\','/'):
            {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(files)}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in sorted(files):
        z.write(file,str(file.relative_to(root)).replace('\\','/'))
    z.writestr('evidence_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(manifest)+1
    for name, value in manifest.items():
        data=z.read(name)
        assert len(data)==value['bytes'] and hashlib.sha256(data).hexdigest()==value['sha256']
restored = json.loads((out/'restoration_check.json').read_text(encoding='utf-8'))
assert restored['verified'] and restored['five_confirmed_restored']
result = {'archive':archive.name,'bytes':archive.stat().st_size,
          'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'files':len(manifest)+1,'zip_integrity':True,'all_file_sha256_verified':True,
          'production_base':'d145468 / BID round89y','firmware_changes':False,
          'nvram_changes':False,'controller_changes':False,
          'gesture_groups':5,'palm_contact_repeat2_excluded':True}
check.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
