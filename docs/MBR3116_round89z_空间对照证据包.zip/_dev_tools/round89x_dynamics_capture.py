import argparse
import csv
import json
import queue
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import round89_live as live
from round89h_raw_capture import connect_checked
from round89h_spatial_capture import set_raw

MODES = {
    "slow_contact": ("慢轻触", "食指用4秒缓慢降到表面，刚好轻触", "保持轻触"),
    "fast_finger_hover": ("快速食指悬空", "食指快速下探到约3 mm，立即回到约1 cm；不要碰到表面", "保持食指悬空约1 cm"),
    "fast_contact": ("快速真实点按", "食指立即轻点一次，确实触板，然后抬到约1 cm", "保持食指悬空约1 cm"),
    "fast_palm_hover": ("快速手掌悬空", "手掌快速下探到约5 mm，立即回到约1 cm；整只手不要碰到表面", "保持手掌悬空约1 cm"),
}
FIELDS = [
    "elapsed_s", "phase", "repeat", "cue_id", "b1_start_s", "b1_end_s",
    "c0_start_s", "c0_end_s", "c1_start_s", "c1_end_s", "pressures",
    "hardware", "verified", "final", "air", "gate_failures", "uptime_ms",
    "telemetry_hex", "request_ms", "error",
]
TASKS = queue.Queue()
LOCK = threading.Lock()
ABORT = threading.Event()
STATE = {"running": False, "blocked": False, "phase": "idle",
         "message": "手远离30 cm，选择第一组", "end_ms": 0, "cue_id": "",
         "jobs": [], "raw_restored": True, "mock": False}
OUT = None
ORIGIN = None
BACKUP = None
MOCK = False
SCALE = 1.0


def update(**values):
    with LOCK:
        STATE.update(values)


def save_job(job):
    temporary = OUT / (job["id"] + ".pending")
    temporary.write_text(json.dumps(job, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(OUT / (job["id"] + ".json"))


def phase_plan(mode):
    plan = []
    def add(name, repeat, duration, message):
        start = plan[-1]["end_s"] if plan else 0
        plan.append({"phase": name, "repeat": repeat, "start_s": start,
                     "end_s": start + duration * SCALE, "message": message,
                     "cue_id": str(len(plan))})
    add("baseline", 0, 4, "整只手保持远离至少30 cm")
    for repeat in (1, 2):
        member = "手掌" if mode == "fast_palm_hover" else "食指"
        add("prepare", repeat, 2, member + "停在第17格上方约1 cm")
        add("action", repeat, 4 if mode == "slow_contact" else 2, MODES[mode][1])
        add("hold", repeat, 3 if mode == "slow_contact" else 2, MODES[mode][2])
        add("release", repeat, 4 if repeat == 1 else 6, "整只手立即移开至少30 cm")
    return plan


def read_full(port, origin):
    began = time.perf_counter()
    port.write(b"\xb1")
    pressure = live.exact(port, 33, 1)
    b1_end = time.perf_counter()
    port.write(b"\xc0")
    chain = live.exact(port, 46, 1)
    c0_end = time.perf_counter()
    if chain[:2] != b"\xaa\x55" or any(x not in (0, 128) for x in chain[14:46]):
        raise RuntimeError("invalid C0 frame")
    port.write(b"\xc1")
    telemetry = live.exact(port, 528, 1)
    ended = time.perf_counter()
    return {
        "b1_start_s": began - origin, "b1_end_s": b1_end - origin,
        "c0_start_s": b1_end - origin, "c0_end_s": c0_end - origin,
        "c1_start_s": c0_end - origin, "c1_end_s": ended - origin,
        "pressures": pressure[:32].hex(), "hardware": chain[2:8].hex(),
        "verified": chain[8:14].hex(), "final": chain[14:46].hex(), "air": pressure[32],
        "gate_failures": int.from_bytes(telemetry[36:40], "little"),
        "uptime_ms": int.from_bytes(telemetry[:4], "little"),
        "telemetry_hex": telemetry.hex(), "request_ms": (ended - began) * 1000,
        "error": "",
    }


def mock_read(origin):
    time.sleep(.006)
    now = time.perf_counter() - origin
    value = {k: now for k in ("b1_start_s", "b1_end_s", "c0_start_s",
                             "c0_end_s", "c1_start_s", "c1_end_s")}
    value.update(pressures="00" * 32, hardware="00" * 6, verified="00" * 6,
                 final="00" * 32, air=0, gate_failures=0, uptime_ms=int(now * 1000),
                 telemetry_hex="00" * 528, request_ms=6, error="")
    return value


def capture(port, job):
    job["phase_plan"] = phase_plan(job["mode"])
    job["completed"] = False
    job["user_confirmed"] = None
    job["cue_events"] = []
    job["semantics"] = (
        "B1 is a published DIFF32 snapshot, C0/C1 are separate later transactions. "
        "Host timestamps are transaction bounds, not electrode scan times. "
        "Global gate failures are not per-lane validity; repeated pressure may be stale. "
        "Cue times are instructions, not measured physical contact times. "
        "Mock/preflight data must not enter gesture analysis."
    )
    started = time.perf_counter()
    epoch = time.time() * 1000
    current = None
    count = 0
    with (OUT / (job["id"] + ".csv")).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        while time.perf_counter() - started < job["phase_plan"][-1]["end_s"]:
            if ABORT.is_set():
                job["aborted"] = True
                break
            elapsed = time.perf_counter() - started
            phase = next((p for p in job["phase_plan"] if p["start_s"] <= elapsed < p["end_s"]), None)
            if phase is None:
                break
            if phase["cue_id"] != current:
                current = phase["cue_id"]
                job["cue_events"].append({"cue_id": current, "server_elapsed_s": elapsed})
                update(phase=phase["phase"], cue_id=current,
                       message=(f"第{phase['repeat']}次： " if phase["repeat"] else "") + phase["message"],
                       end_ms=epoch + phase["end_s"] * 1000)
            tick = time.perf_counter()
            value = mock_read(started) if MOCK else read_full(port, started)
            writer.writerow(dict(elapsed_s=(value["b1_start_s"] + value["b1_end_s"]) / 2,
                                 phase=phase["phase"], repeat=phase["repeat"], cue_id=current, **value))
            count += 1
            stream.flush()
            time.sleep(max(0, .02 - (time.perf_counter() - tick)))
    job["rows"] = count
    job["completed"] = not job.get("aborted", False)


def worker():
    while True:
        task = TASKS.get()
        if task == "finish":
            update(running=False, phase="closed", message="采样结束，设备已恢复普通模式", end_ms=0)
            continue
        job = task
        port = None
        restored = MOCK
        activated = False
        try:
            update(phase="preparing", message="设备准备中，整只手保持远离", end_ms=0)
            if MOCK:
                job["firmware"] = "MOCK"
            else:
                port, info = connect_checked()
                job["usb_serial"] = info.serial_number
                job["firmware"] = live.version(port)
                port.write(b"\xc4")
                if live.tail(port) != "RAW=0":
                    raise RuntimeError("device is not in RAW=0; close other diagnostics")
                activated = True
                set_raw(port, 2)
            capture(port, job)
        except Exception as error:
            job["error"] = repr(error)
            job["completed"] = False
        finally:
            if port:
                try:
                    if activated:
                        set_raw(port, 0)
                        port.write(b"\xc4")
                        restored = live.tail(port) == "RAW=0"
                        if not restored:
                            raise RuntimeError("RAW=0 readback failed")
                except Exception as error:
                    job["restore_error"] = repr(error)
                    restored = False
                finally:
                    port.close()
            job["raw_restored"] = restored
            job["mock"] = MOCK
            job["backup"] = str(BACKUP) if BACKUP else None
            save_job(job)
            with LOCK:
                STATE["jobs"].append(job)
            ok = job["completed"] and restored
            update(running=False, blocked=not restored, raw_restored=restored,
                   phase="done" if ok else "error", end_ms=0, cue_id="",
                   message=MODES[job["mode"]][0] + "已采完并恢复普通模式，请确认动作" if ok else
                           "采样停止：" + job.get("restore_error", job.get("error", "动作中止；普通模式已恢复")))
            print("DONE", json.dumps({k: job.get(k) for k in
                                      ("id", "mode", "rows", "completed", "raw_restored", "error")}), flush=True)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def send(self, code, value, mime="application/json; charset=utf-8"):
        data = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.split("?")[0] == "/":
            return self.send(200, Path(__file__).with_suffix(".html").read_bytes(), "text/html; charset=utf-8")
        if self.path == "/status":
            with LOCK:
                snapshot = json.loads(json.dumps(STATE))
            snapshot["now_ms"] = time.time() * 1000
            return self.send(200, snapshot)
        if self.path == "/favicon.ico":
            return self.send(204, b"")
        self.send(404, {"error": "not found"})

    def do_POST(self):
        if self.headers.get("Origin") != ORIGIN:
            return self.send(403, {"error": "origin rejected"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 2048:
                raise ValueError("invalid request size")
            payload = json.loads(self.rfile.read(length))
            if self.path == "/start":
                mode = payload.get("mode")
                if mode not in MODES:
                    raise ValueError("invalid mode")
                with LOCK:
                    if STATE["running"] or STATE["blocked"]:
                        return self.send(409, {"error": "当前无法开始"})
                    if any(j["completed"] and j["user_confirmed"] is None for j in STATE["jobs"]):
                        return self.send(409, {"error": "请先确认上一组"})
                    STATE.update(running=True, raw_restored=False, phase="queued", message="手保持远离", end_ms=0)
                    ABORT.clear()
                identifier = f"{time.time_ns()}_{mode}"
                TASKS.put({"id": identifier, "mode": mode})
                return self.send(200, {"id": identifier})
            if self.path == "/label":
                with LOCK:
                    job = next((j for j in STATE["jobs"] if j["id"] == payload.get("id")), None)
                    if job is None or STATE["running"] or not job["completed"] or not job["raw_restored"]:
                        raise ValueError("group not ready for confirmation")
                    if not isinstance(payload.get("valid"), bool):
                        raise ValueError("invalid label")
                    job["user_confirmed"] = payload["valid"]
                    save_job(job)
                return self.send(200, {"saved": True})
            if self.path == "/abort":
                ABORT.set()
                return self.send(200, {"stopping": True})
            if self.path in ("/finish", "/shutdown"):
                with LOCK:
                    if STATE["running"]:
                        return self.send(409, {"error": "请先中止或等本组结束"})
                    if STATE["blocked"]:
                        return self.send(409, {"error": "恢复尚未确认"})
                if self.path == "/finish":
                    TASKS.put("finish")
                else:
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                return self.send(200, {"closing": True})
            self.send(404, {"error": "not found"})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.send(400, {"error": str(error)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true", required=True)
    parser.add_argument("--mock", action="store_true")
    parser.add_argument("--port", type=int, default=8774)
    parser.add_argument("--out", required=True)
    parser.add_argument("--backup")
    parser.add_argument("--test-scale", type=float, default=1)
    args = parser.parse_args()
    MOCK = args.mock
    if args.test_scale != 1 and not MOCK:
        parser.error("short timing is only allowed in mock")
    SCALE = args.test_scale
    OUT = Path(args.out).resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    BACKUP = Path(args.backup).resolve() if args.backup else None
    if not MOCK and (BACKUP is None or not (BACKUP / "snapshot.json").exists()):
        parser.error("real capture requires device backup")
    ORIGIN = f"http://127.0.0.1:{args.port}"
    update(mock=MOCK)
    threading.Thread(target=worker, daemon=True).start()
    print("READY", ORIGIN, "MOCK" if MOCK else "REAL", flush=True)
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
