import argparse
import time
from pathlib import Path

import serial.tools.list_ports

import round89_live_debug as capture
from round89g_latency_probe import SERIAL, connect_target


def connect_checked():
    deadline = time.perf_counter() + 15
    while not any(p.vid == 0xCAFE and p.pid == 0x4009 and p.serial_number == SERIAL
                  for p in serial.tools.list_ports.comports()):
        if time.perf_counter() >= deadline:
            raise RuntimeError("target did not re-enumerate")
        time.sleep(.2)
    port, info = connect_target()
    try:
        firmware = capture.version(port)
        if "BID=round89g" not in firmware:
            raise RuntimeError(f"unexpected firmware: {firmware}")
        return port, info
    except Exception:
        port.close()
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    out = Path(args.out).resolve()
    if out.exists() and any(out.iterdir()):
        raise RuntimeError("capture directory is not empty")
    out.mkdir(parents=True, exist_ok=True)
    capture.connect = connect_checked
    capture.run(out, 0x40, 7)
