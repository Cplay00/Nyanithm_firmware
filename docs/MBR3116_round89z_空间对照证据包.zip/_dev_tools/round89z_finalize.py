"""Close idle capture, independently read back the unchanged target configuration."""
import json
from pathlib import Path
from urllib.request import Request, urlopen
import round89c_flash_probe as flash
import round89g_latency_probe as target

root = Path(__file__).resolve().parents[1]
out = root / '_dev_tools/round89z_trace_20261002'
url = 'http://127.0.0.1:8774'
state = json.load(urlopen(url+'/status'))
expected = ['two_contact','three_contact','four_contact','palm_contact','palm_hover5']
assert not state['running'] and not state['blocked'] and state['raw_restored']
assert [j['mode'] for j in state['jobs']] == expected
assert all(j['completed'] and j['user_confirmed'] is True and j['raw_restored'] and not j['mock'] for j in state['jobs'])
(out/'final_capture_status.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for path in ('/finish','/shutdown'):
    request = Request(url+path, data=b'{}', headers={'Content-Type':'application/json','Origin':url}, method='POST')
    assert json.load(urlopen(request)).get('closing')
flash.live.connect = target.connect_target
before = json.loads((root/'_dev_archive/round89z_device_before_20261002/snapshot.json').read_text(encoding='utf-8'))
after = flash.device_snapshot(out/'after')
assert 'BID=round89y' in after['version'] and after['usb_serial'] == before['usb_serial']
assert after['raw_status'] == before['raw_status'] == 'RAW=0'
assert after['controller_config'] == before['controller_config']
assert set(after['chips']) == set(before['chips']) == {'0x40','0x41','0x42'}
assert all(after['chips'][a]['hex'] == before['chips'][a]['hex'] for a in before['chips'])
result = {'verified':True,'usb_serial':after['usb_serial'],'version':after['version'],
          'controller_equal':True,'three_nvram_equal':True,'raw_status':after['raw_status'],
          'initial_input_all_zero':not any(after['initial_input']),'nvram_writes':0,'firmware_flash':False,
          'before':str(root/'_dev_archive/round89z_device_before_20261002'),
          'after':str(out/'after'),'five_confirmed_restored':True}
(out/'restoration_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
