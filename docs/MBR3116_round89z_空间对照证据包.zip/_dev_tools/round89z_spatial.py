"""Exploratory shadow masks; no device writes or timing claims."""
from pathlib import Path
import json
import round89y_analyze_trace as trace

ROOT = Path(__file__).resolve().parents[1]


def features(row):
    counts = row["counts"]
    native = [bool(int.from_bytes(row["hardware"][2*trace.base.LM[i]:2*trace.base.LM[i]+2], "little") &
                   (1 << trace.base.LE[i])) for i in range(32)]
    return {"width120": sum(c > 120 for c in counts), "total": sum(counts), "peak": max(counts),
            "native_count": sum(native), "output_count": sum(bool(c) for c in row["slider"])}


def neighbors(i, two_rows):
    step = 2 if two_rows else 1
    return [j for j in (i-step, i+step) if 0 <= j < 32]


def masks(row, two_rows):
    counts, f = row["counts"], features(row)
    broad = f["width120"] >= 4
    result = {"width4": [not broad]*32,
              "width4to7_native1to3": [not (4 <= f["width120"] <= 7 and 1 <= f["native_count"] <= 3)]*32}
    for threshold in (1, 32, 64):
        result[f"curvature{threshold}_when_width4"] = [
            not broad or 2*counts[i]-sum(counts[j] for j in neighbors(i, two_rows)) >= threshold for i in range(32)]
    for threshold in (32, 64):
        result[f"prominence{threshold}_when_width4"] = [
            not broad or counts[i]-max((counts[j] for j in neighbors(i, two_rows)), default=0) >= threshold
            for i in range(32)]
    return result


def load(out):
    groups = []
    for path in sorted(out.glob("*.json")):
        if path.name.endswith(".trace.json"):
            continue
        job = json.loads(path.read_text(encoding="utf-8"))
        if not (job.get("completed") and job.get("user_confirmed") is True and job.get("raw_restored")
                and not job.get("mock")):
            continue
        data = out / (job["id"]+".trace.json")
        if data.is_file():
            groups.append((job, [trace.decode(r) for r in json.loads(data.read_text(encoding="utf-8"))]))
    return groups


def summarize(job, rows, two_rows):
    qualified = [r for r in rows if all(r["lane_usable"])]
    output = [r for r in qualified if any(r["slider"])]
    report = {"id": job["id"], "mode": job["mode"], "qualified": len(qualified), "baseline_on_frames": len(output),
              "width120": {"min": min((features(r)["width120"] for r in output), default=None),
                           "max": max((features(r)["width120"] for r in output), default=None)}, "candidates": {}}
    names = masks(qualified[0], two_rows) if qualified else {}
    for name in names:
        selected = [(r, masks(r, two_rows)[name]) for r in output]
        changed = [(r, mask) for r, mask in selected if any(v and not p for v, p in zip(r["slider"], mask))]
        report["candidates"][name] = {
            "changed_on_frames": len(changed),
            "removed_lane_on_observations": sum(sum(bool(v) and not p for v, p in zip(r["slider"], mask)) for r, mask in changed),
            "all_output_removed_frames": sum(not any(v and p for v, p in zip(r["slider"], mask)) for r, mask in changed),
            "example": ({"elapsed_s": changed[0][0]["elapsed_s"], "counts": changed[0][0]["counts"],
                         "slider": list(changed[0][0]["slider"]), "allowed": changed[0][1]} if changed else None)}
    return report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--two-rows", action="store_true")
    parser.add_argument("--out", required=True)
    parser.add_argument("--save", required=True)
    args = parser.parse_args()
    result = {"two_rows": args.two_rows, "semantics": "DIFF-only shadow masks on qualified final-ON observations; not deployed, not game rates.",
              "groups": [summarize(j, r, args.two_rows) for j, r in load(Path(args.out))]}
    Path(args.save).write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps([{k:v for k,v in g.items() if k!='candidates'} | {"changed_on_frames": {n:q["changed_on_frames"] for n,q in g["candidates"].items()}}
                      for g in result["groups"]], ensure_ascii=False, indent=2))
