"""Analyze confirmed C8 gestures using valid, age-limited per-chip reads."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

from round89x_trace_capture import parse_trace, ROOT

source = (ROOT/"Nyanithm_firmware_hw_v1/src/hw_devices.cpp").read_text(encoding="utf-8")
def lane_table(name):
    value = tuple(map(int, re.findall(r"\d+", re.search(rf"{name}\[32\] = \{{([^}}]+)\}}", source).group(1))))
    if len(value) != 32:
        raise ValueError("production lane map length")
    return value
LM, LE = lane_table("V1_LANE_M"), lane_table("V1_LANE_E")


def decode(row):
    value = parse_trace(bytes.fromhex(row["trace_hex"]))
    if value["chip_count"] != 3 and not (value["report_flags"] & 128 and value["chip_count"] == 0):
        raise ValueError("analysis is for backed-up three-chip hw2 only")
    value.update(row)
    value["lane_usable"] = [bool(value["chips"][LM[i]]["usable"] and
                                 value["chips"][LM[i]]["range_mask"] & (1 << LE[i]) and
                                 value["chips"][LM[i]]["flags"] & 16) for i in range(32)]
    return value


def summarize(rows):
    center = [r for r in rows if r["lane_usable"][16]]
    all_valid = [r for r in rows if all(r["lane_usable"])]
    result = {"host_frames": len(rows), "qualified_center_frames": len(center),
              "copy_failed_frames": sum(bool(r["report_flags"] & 128) for r in rows),
              "qualified_all_lanes_frames": len(all_valid),
              "center_counts": {"min": min((r["counts"][16] for r in center), default=None),
                                "max": max((r["counts"][16] for r in center), default=None)},
              "center_native_on_qualified": sum(bool(int.from_bytes(r["hardware"][:2], "little") & 128) for r in center),
              "center_final_on_qualified": sum(bool(r["slider"][16]) for r in center),
              "final_lanes_qualified": [i+1 for i in range(32) if any(r["slider"][i] and r["lane_usable"][i] for r in rows)],
              "all_valid_above120_width_max": max((sum(c > 120 for c in r["counts"]) for r in all_valid), default=0),
              "chips": []}
    for m in range(3):
        reported = [r for r in rows if r["chip_count"] == 3 and not r["report_flags"] & 128]
        if not reported:
            result["chips"].append({"address": hex(0x40+m), "metadata_frames": 0})
            continue
        first, last = reported[0]["chips"][m], reported[-1]["chips"][m]
        result["chips"].append({"address": hex(0x40+m),
            "metadata_frames": len(reported),
            "usable_frames": sum(r["chips"][m]["usable"] for r in rows),
            "latest_attempt_invalid_frames": sum(not r["chips"][m]["flags"] & 2 for r in reported),
            "button_invalid_frames": sum(not r["chips"][m]["flags"] & 16 for r in reported),
            "above_age_limit_frames": sum(r["chips"][m]["good_age_ms"] > 15 for r in reported),
            **{k+"_delta": (last[k]-first[k]) & 0xffffffff for k in ("read_calls", "io_failures", "sync_mismatches")}})
    # Approximate host-read trajectory only; no physical contact time or scan ID.
    comparisons = []
    for i, r in enumerate(center):
        options = [q for q in center[max(0,i-10):i] if .08 <= r["elapsed_s"]-q["elapsed_s"] <= .14
                   and r["chips"][0]["read_calls"] != q["chips"][0]["read_calls"]]
        if options:
            q = min(options, key=lambda q: abs(r["elapsed_s"]-q["elapsed_s"]-.1))
            comparisons.append(max(0, r["counts"][16]-q["counts"][16])*.1/(r["elapsed_s"]-q["elapsed_s"]))
    result["qualified_observed_rise_per_100ms_max"] = max(comparisons, default=None)
    return result


def analyze(out):
    report = {"semantics": ["Host frames/read times, not native independent scans or physical contact times.",
              "Qualified = PROFILE, successful latest attempt, retained coherent counts, host age <=15ms, lane range and BUTTON_STAT success.",
              "Full-vector overlap tests current DIFF-only spatial separation; it does not disprove all temporal or hardware methods.",
              "Gesture labels require completion, explicit confirmation and RAW restoration."], "jobs": [], "overlap": []}
    datasets = {}
    for path in sorted(out.glob("*.json")):
        if path.name.endswith(".trace.json") or path.name == "analysis.json":
            continue
        job = json.loads(path.read_text(encoding="utf-8"))
        if not (job.get("completed") and job.get("user_confirmed") is True and job.get("raw_restored") and not job.get("mock")):
            continue
        rows = [decode(r) for r in json.loads((out/(job["id"]+".trace.json")).read_text(encoding="utf-8"))]
        if not rows:
            continue
        datasets.setdefault(job["mode"], []).extend(rows)
        report["jobs"].append({"id": job["id"], "mode": job["mode"], "summary": summarize(rows),
            "phases": [{"phase": p["phase"], "repeat": p["repeat"], "summary": summarize(group)}
                       for p in job["phase_plan"] if (group := [r for r in rows if r["phase"] == p["phase"] and r["repeat"] == p["repeat"]])]})
    contact = {tuple(r["counts"]): r for r in datasets.get("slow_contact", [])
               if r["phase"] == "hold" and all(r["lane_usable"]) and any(r["counts"])}
    for mode in ("fast_finger_hover", "fast_palm_hover"):
        hover = {tuple(r["counts"]): r for r in datasets.get(mode, [])
                 if r["phase"] in ("action", "hold") and all(r["lane_usable"]) and any(r["counts"])}
        shared = sorted(set(contact)&set(hover))
        report["overlap"].append({"hover_mode": mode, "distinct_nonzero_vectors": len(shared),
            "examples": [{"counts": v, "contact_elapsed_s": contact[v]["elapsed_s"],
                          "hover_elapsed_s": hover[v]["elapsed_s"],
                          "contact_frame": contact[v]["frame_id"], "hover_frame": hover[v]["frame_id"]} for v in shared[:8]]})
    (out/"analysis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    value = analyze(Path(args.out).resolve())
    print(json.dumps({"jobs": [{"mode": j["mode"], **j["summary"]} for j in value["jobs"]], "overlap": value["overlap"]}, ensure_ascii=False, indent=2))
