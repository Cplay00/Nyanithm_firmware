import argparse
import csv
import hashlib
import json
import statistics
import time
from pathlib import Path

import serial
import serial.tools.list_ports


def stage_request(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, PermissionError, json.JSONDecodeError):
        return {}


def exact(port, size, timeout=3):
    data = bytearray()
    deadline = time.monotonic() + timeout
    while len(data) < size and time.monotonic() < deadline:
        data.extend(port.read(size - len(data)))
    if len(data) != size:
        raise RuntimeError(f"short response {len(data)}/{size}: {data.hex()}")
    return bytes(data)


def tail(port, duration=0.15):
    end = time.monotonic() + duration
    data = bytearray()
    while time.monotonic() < end:
        data.extend(port.read(port.in_waiting or 1))
    return data.decode("ascii", "replace").strip()


def split(port, command, payload):
    port.write(bytes([command]))
    port.flush()
    time.sleep(0.02)
    port.write(bytes(payload))
    port.flush()


def connect():
    found = [p for p in serial.tools.list_ports.comports()
             if p.vid == 0xCAFE and p.pid == 0x4009]
    if len(found) != 1:
        raise RuntimeError(f"expected one device, found {len(found)}")
    info = found[0]
    port = serial.Serial(info.device, 115200, timeout=0.03, write_timeout=2)
    port.dtr, port.rts = True, False
    time.sleep(0.15)
    tail(port)
    return port, info


def version(port):
    port.write(b"\xbd")
    return exact(port, exact(port, 1)[0]).decode("ascii", "replace")


def config_read(port):
    port.write(b"\xb4")
    cfg = exact(port, 128)
    trailer = tail(port)
    checksum = 0
    for value in cfg:
        checksum ^= value
    if cfg[:2] != b"\x88\x02" or checksum:
        raise RuntimeError(f"invalid controller config: {cfg.hex()}")
    return cfg, trailer


def snapshot(out):
    port, info = connect()
    entered = False
    result = {"port": info.device, "usb_serial": info.serial_number}
    try:
        result["version"] = version(port)
        port.write(b"\xbc")
        result["probe"] = exact(port, 6).hex()
        port.write(b"\xc4")
        result["raw_status"] = tail(port)
        port.write(b"\xb1")
        result["initial_input"] = list(exact(port, 33))
        port.write(b"\xb3")
        entered = True
        result["config_entry"] = tail(port, 0.3)
        cfg, result["config_trailer"] = config_read(port)
        (out / "controller_config.bin").write_bytes(cfg)
        result["controller_config"] = cfg.hex()
        result["profile"] = list(cfg[91:99])
        result["chips"] = {}
        for address in (0x40, 0x41, 0x42):
            split(port, 0xC6, [address])
            data = exact(port, 128)
            (out / f"chip_{address:02x}.bin").write_bytes(data)
            result["chips"][hex(address)] = {
                "hex": data.hex(), "sha256": hashlib.sha256(data).hexdigest(),
                "ath": bool(data[0x4f] & 8), "device_cfg2": data[0x4f],
                "ft": list(data[0x0c:0x1c]), "sensor_en": data[:2].hex(),
            }
        (out / "snapshot.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2), flush=True)
    finally:
        if entered:
            port.write(b"\xb9")
            port.flush()
        port.close()


def xor(data):
    result = 0
    for value in data:
        result ^= value
    return result


def set_config(out, path):
    cfg = Path(path).read_bytes()
    if len(cfg) != 128 or cfg[:2] != b"\x88\x02" or xor(cfg):
        raise RuntimeError("invalid config file")
    port, info = connect()
    entered = False
    report = {"requested": cfg.hex(), "port": info.device, "version": version(port)}
    try:
        port.write(b"\xb3")
        entered = True
        tail(port, 0.25)
        report["before"], report["before_trailer"] = config_read(port)
        report["before"] = report["before"].hex()
        port.write(b"\xb8")
        report["status"] = tail(port, 0.2)
        split(port, 0xB7, cfg)
        report["set_response"] = tail(port, 0.3)
        if "check ok. config changed." not in report["set_response"]:
            raise RuntimeError(f"CFG_SET rejected: {report['set_response']}")
        port.write(b"\xb5")
        report["save_response"] = tail(port, 0.4)
        if "saveConfig result: 0" not in report["save_response"]:
            raise RuntimeError(f"CFG_SAVE failed: {report['save_response']}")
        port.write(b"\xce")
        report["command_log"] = exact(port, exact(port, 1)[0]).hex()
        check, report["readback_trailer"] = config_read(port)
        report["readback_equal"] = check == cfg
        if check != cfg:
            raise RuntimeError(f"readback mismatch: {check.hex()}")
    finally:
        if entered:
            port.write(b"\xb9")
            port.flush()
        port.close()
        (out / "save_result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    time.sleep(1.5)
    port, _ = connect()
    try:
        report["reboot_version"] = version(port)
        port.write(b"\xb3")
        tail(port, 0.25)
        check, _ = config_read(port)
        report["reboot_equal"] = check == cfg
        if check != cfg:
            raise RuntimeError("config changed after reboot")
    finally:
        port.write(b"\xb9")
        port.flush()
        port.close()
        (out / "save_result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)


def verify_config(out, path):
    expected = Path(path).read_bytes()
    port, _ = connect()
    report = {"version": version(port)}
    try:
        port.write(b"\xb3")
        tail(port, 0.25)
        cfg, report["trailer"] = config_read(port)
        report["reboot_equal"] = cfg == expected
        report["config"] = cfg.hex()
        port.write(b"\xce")
        report["command_log"] = exact(port, exact(port, 1)[0]).hex()
        if cfg != expected:
            raise RuntimeError("reboot config mismatch")
    finally:
        port.write(b"\xb9")
        port.flush()
        port.close()
        (out / "verify_result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)


def capture(out, with_telemetry=False):
    port, _ = connect()
    identity = version(port)
    print("VERSION", identity, flush=True)
    if with_telemetry and not any("BID=" + bid in identity for bid in ("round89c", "round89e")):
        port.close()
        raise RuntimeError("gate failure capture requires round89c or round89e")
    rows = []
    current = None
    start = time.perf_counter()
    request_path = out / "stage.json"
    handled = set()
    fields = ["elapsed_s", "stage", "request_ms", "diff", "hardware", "verified", "final", "air"]
    if with_telemetry:
        fields.extend(["gate_failures", "telemetry_uptime_ms", "telemetry_host_elapsed_s"])
    try:
        split(port, 0xC5, [2])
        response = tail(port)
        if response != "RAW=2":
            raise RuntimeError(f"raw enable failed: {response}")
        with (out / "full_board.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            print("READY full board capture; waiting for stage.json", flush=True)
            while time.perf_counter() - start < 1800:
                request = stage_request(request_path)
                name = request.get("stage")
                if name == "stop":
                    break
                if name and name not in handled:
                    if current:
                        raise RuntimeError("new stage arrived before previous stage finished")
                    handled.add(name)
                    current = {"name": name, "start": time.perf_counter(),
                               "duration": min(30, max(3, float(request.get("duration_s", 10))))}
                    rows = []
                    print("START", name, flush=True)
                tick = time.perf_counter()
                port.write(b"\xb1")
                raw = exact(port, 33, 1)
                port.write(b"\xc0")
                chain = exact(port, 46, 1)
                if chain[:2] != b"\xaa\x55":
                    raise RuntimeError(f"invalid chain: {chain.hex()}")
                row = {"elapsed_s": round(tick - start, 6),
                       "stage": current["name"] if current else "between",
                       "request_ms": round((time.perf_counter() - tick) * 1000, 3),
                       "diff": raw[:32].hex(), "hardware": chain[2:8].hex(),
                       "verified": chain[8:14].hex(), "final": chain[14:46].hex(), "air": raw[32]}
                if with_telemetry:
                    port.write(b"\xc1")
                    tele = exact(port, 528, 1)
                    row.update({"gate_failures": int.from_bytes(tele[36:40], "little"),
                                "telemetry_uptime_ms": int.from_bytes(tele[:4], "little"),
                                "telemetry_host_elapsed_s": round(time.perf_counter() - start, 6)})
                writer.writerow(row)
                if current:
                    rows.append(row)
                    if time.perf_counter() - current["start"] >= current["duration"]:
                        lanes = {}
                        for lane in range(32):
                            values = [bytes.fromhex(r["diff"])[lane] for r in rows]
                            final = [bytes.fromhex(r["final"])[lane] != 0 for r in rows]
                            if max(values) or any(final):
                                lanes[str(lane + 1)] = {"min": min(values), "median": statistics.median(values),
                                    "max": max(values), "nonzero": sum(v != 0 for v in values),
                                    "final_on": sum(final), "n": len(values)}
                        summary = {"stage": current["name"], "n": len(rows), "lanes": lanes,
                                   "duration_s": time.perf_counter() - current["start"],
                                   "request_ms_median": statistics.median(r["request_ms"] for r in rows),
                                   "request_ms_max": max(r["request_ms"] for r in rows)}
                        if with_telemetry:
                            summary["gate_failure_delta"] = (rows[-1]["gate_failures"] - rows[0]["gate_failures"]) & 0xFFFFFFFF
                            summary["telemetry_note"] = "Global cumulative counter, separate C1 transaction after B1/C0; not an electrode/frame identity."
                        (out / f"{current['name']}.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
                        print("DONE", json.dumps(summary), flush=True)
                        stream.flush()
                        current = None
                time.sleep(max(0, 0.02 - (time.perf_counter() - tick)))
    finally:
        try:
            split(port, 0xC5, [0])
            print("RAW EXIT", tail(port), flush=True)
        finally:
            port.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["snapshot", "set", "verify", "capture"])
    ap.add_argument("--out", required=True)
    ap.add_argument("--config")
    ap.add_argument("--telemetry", action="store_true")
    args = ap.parse_args()
    output = Path(args.out).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if args.action == "snapshot":
        snapshot(output)
    elif args.action == "set":
        set_config(output, args.config)
    elif args.action == "verify":
        verify_config(output, args.config)
    else:
        capture(output, args.telemetry)
