import argparse
import contextlib
import hashlib
import io
import json
import shutil
import string
import struct
import time
from pathlib import Path

import serial.tools.list_ports

import round89_live as live


WORKSPACE = Path(__file__).resolve().parents[1]
OUT = WORKSPACE / "_dev_tools" / "round89c_live_20261001"
UF2 = WORKSPACE / "Nyanithm_firmware_hw_v1/build_round89c/Nyanithm.uf2"
EXPECTED_SHA256 = "726dafc39fcff28526c2534e75644e21b4c1091d38e60c1b05d2dc1df52acb88"
USB_SERIAL = "5303284739002C9C"
SIGNATURE = "NYANFW1;1.6.6-beta2;hw_v1;BID=round89c"
BASELINE_BUILD_ID = "round89a"
DEVICE_BACKUP = WORKSPACE / "_dev_archive/round89c_device_before_20261001"


def save(report):
    (OUT / "flash_probe.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


def device_snapshot(directory):
    directory.mkdir(parents=True, exist_ok=True)
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream):
        live.snapshot(directory)
    (directory / "console.txt").write_text(stream.getvalue(), encoding="utf-8")
    return json.loads((directory / "snapshot.json").read_text(encoding="utf-8"))


def rp2040_drives():
    drives = []
    for letter in string.ascii_uppercase[2:]:
        root = Path(f"{letter}:/")
        info = root / "INFO_UF2.TXT"
        try:
            if info.is_file() and "Board-ID: RPI-RP2" in info.read_text(errors="replace"):
                drives.append(root)
        except OSError:
            pass
    return drives


def telemetry(port):
    port.write(b"\xc1")
    data = live.exact(port, 528, 2)
    words = struct.unpack_from("<10I", data)
    return {"uptime_ms": words[0], "served_count": words[1], "edge_count": words[2],
            "loop_count": words[8], "gate_read_failures": words[9],
            "payload_size": len(data), "payload": data.hex()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume-bootsel", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=args.resume_bootsel)
    report = (json.loads((OUT / "flash_probe.json").read_text(encoding="utf-8"))
              if args.resume_bootsel else {"completed": False, "uf2": str(UF2), "signature": SIGNATURE})
    if args.resume_bootsel:
        if not report.get("bootsel_command_sent") or report.get("uf2_copied") or report["signature"] != SIGNATURE:
            raise RuntimeError("cannot resume this flash attempt")
        report["recovered_host_error"] = report.pop("error", None)
    try:
        data = UF2.read_bytes()
        report["uf2_sha256"] = hashlib.sha256(data).hexdigest()
        if report["uf2_sha256"] != EXPECTED_SHA256 or len(data) % 512:
            raise RuntimeError("UF2 hash/size mismatch")
        addresses, blocks = [], set()
        for offset in range(0, len(data), 512):
            m0, m1, flags, address, size, block, count, family = struct.unpack_from("<8I", data, offset)
            if (m0, m1, family) != (0x0A324655, 0x9E5D5157, 0xE48BFF56):
                raise RuntimeError("UF2 header/family mismatch")
            if flags != 0x2000 or size != 256 or count != len(data) // 512 or block in blocks:
                raise RuntimeError("UF2 block metadata mismatch")
            if not 0x10000000 <= address < 0x101FF000 or address + size > 0x101FF000:
                raise RuntimeError("UF2 writes outside firmware area or into config sector")
            if struct.unpack_from("<I", data, offset + 508)[0] != 0x0AB16F30:
                raise RuntimeError("UF2 trailing magic mismatch")
            addresses.append(address)
            blocks.add(block)
        if SIGNATURE.encode() not in b"".join(data[i + 32:i + 288] for i in range(0, len(data), 512)):
            raise RuntimeError("UF2 signature absent")
        report["uf2_size"] = len(data)
        report["flash_range"] = [min(addresses), max(addresses) + 256]
        if rp2040_drives() and not args.resume_bootsel:
            raise RuntimeError("pre-existing RP2040 BOOTSEL drive; cannot identify flash target")
        before = (json.loads((OUT / "before/snapshot.json").read_text(encoding="utf-8"))
                  if args.resume_bootsel else device_snapshot(OUT / "before"))
        report["before_version"] = before["version"]
        if before["usb_serial"] != USB_SERIAL or "NYANFW1;" not in before["version"]:
            raise RuntimeError("unexpected device identity")
        if "BID=" + BASELINE_BUILD_ID not in before["version"]:
            raise RuntimeError("unexpected firmware baseline")
        backup = DEVICE_BACKUP
        if not args.resume_bootsel:
            shutil.copytree(OUT / "before", backup)
        elif (backup / "controller_config.bin").read_bytes() != bytes.fromhex(before["controller_config"]):
            raise RuntimeError("resume backup mismatch")
        report["backup"] = str(backup)
        save(report)
        if not args.resume_bootsel:
            time.sleep(1.5)
            port, info = live.connect()
            try:
                if info.serial_number != USB_SERIAL:
                    raise RuntimeError("flash target changed")
                port.write(b"\xbb\xa5")
                port.flush()
                report["bootsel_command_sent"] = True
                save(report)
            finally:
                port.close()
        deadline = time.monotonic() + 20
        drives = []
        while time.monotonic() < deadline:
            drives = rp2040_drives()
            if drives:
                break
            time.sleep(0.25)
        if len(drives) != 1:
            raise RuntimeError(f"expected exactly one RP2040 drive, found {drives}")
        report["bootsel_drive"] = str(drives[0])
        print("BOOTSEL", drives[0], "UF2", len(data), flush=True)
        shutil.copyfile(UF2, drives[0] / "Nyanithm.uf2")
        report["uf2_copied"] = True
        save(report)
        deadline = time.monotonic() + 25
        while time.monotonic() < deadline:
            ports = [p for p in serial.tools.list_ports.comports()
                     if p.vid == 0xCAFE and p.pid == 0x4009 and p.serial_number == USB_SERIAL]
            if ports:
                break
            time.sleep(0.25)
        else:
            raise RuntimeError("device failed to re-enumerate")
        time.sleep(1)
        after = device_snapshot(OUT / "after")
        report["after_version"] = after["version"]
        if SIGNATURE not in after["version"] or after["usb_serial"] != USB_SERIAL:
            raise RuntimeError("new firmware identity mismatch")
        report["controller_config_equal"] = before["controller_config"] == after["controller_config"]
        report["chips_equal"] = {address: before["chips"][address]["hex"] == after["chips"][address]["hex"]
                                 for address in before["chips"]}
        if not report["controller_config_equal"] or not all(report["chips_equal"].values()):
            raise RuntimeError("configuration changed; preserve snapshots and investigate")
        report["raw_status_after"] = after["raw_status"]
        report["profile_after"] = after["profile"]
        save(report)
        time.sleep(1.5)
        port, _ = live.connect()
        try:
            if SIGNATURE not in live.version(port):
                raise RuntimeError("device firmware changed during probe")
            rows = []
            started = time.perf_counter()
            while time.perf_counter() - started < 12:
                tick = time.perf_counter()
                count = telemetry(port)
                port.write(b"\xb1")
                inputs = live.exact(port, 33)
                port.write(b"\xc0")
                chain = live.exact(port, 46)
                if chain[:2] != b"\xaa\x55":
                    raise RuntimeError("invalid DEBUG_CHAIN response")
                count.update({"elapsed_s": tick - started, "input": inputs.hex(),
                              "chain": chain.hex(), "host_transaction_ms": (time.perf_counter() - tick) * 1000})
                rows.append(count)
                time.sleep(max(0, 0.05 - (time.perf_counter() - tick)))
            (OUT / "uncontrolled_probe.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
            report["probe"] = {"duration_s": time.perf_counter() - started, "frames": len(rows),
                               "posture": "uncontrolled; not a no-contact acceptance test",
                               "first_gate_failures": rows[0]["gate_read_failures"],
                               "last_gate_failures": rows[-1]["gate_read_failures"],
                               "failure_delta": (rows[-1]["gate_read_failures"] - rows[0]["gate_read_failures"]) & 0xFFFFFFFF,
                               "all_inputs_zero": all(bytes.fromhex(row["input"])[:32] == bytes(32) for row in rows)}
            port.write(b"\xc4")
            report["raw_status_final"] = live.tail(port)
        finally:
            port.close()
        report["completed"] = True
        print(json.dumps({key: value for key, value in report.items() if key != "probe"}, indent=2), flush=True)
        print("PROBE", json.dumps(report["probe"]), flush=True)
    except Exception as error:
        report["error"] = repr(error)
        raise
    finally:
        save(report)


if __name__ == "__main__":
    main()
