"""Frozen spatial candidates, fixed interior holds; no deployment or game rates."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median

import round89z_spatial as spatial

EXPECTED = {"two_contact": [14, 16], "three_contact": [14, 16, 18],
            "four_contact": [12, 14, 16, 18]}


def evaluate(job, rows):
    result = spatial.summarize(job, rows, True)
    result["host_frames"] = len(rows)
    result["copy_failed"] = sum(bool(r["report_flags"] & 128) for r in rows)
    result["qualified_distinct_frame_ids"] = len({r["frame_id"] for r in rows if all(r["lane_usable"])})
    gaps = [b["elapsed_s"]-a["elapsed_s"] for a, b in zip(rows, rows[1:])]
    result["host_observation_interval_ms"] = {"median": 1000*median(gaps) if gaps else None,
                                             "max": 1000*max(gaps) if gaps else None}
    result["holds"] = []
    for phase in job["phase_plan"]:
        if phase["phase"] != "hold":
            continue
        inside = [r for r in rows if phase["start_s"]+.5 <= r["elapsed_s"] <= phase["end_s"]-.5]
        qualified = [r for r in inside if all(r["lane_usable"])]
        item = spatial.summarize(job, inside, True)
        item.pop("id")
        item.pop("mode")
        item.update(repeat=phase["repeat"], start_s=phase["start_s"]+.5, end_s=phase["end_s"]-.5,
                    host_frames=len(inside), qualified_distinct_frame_ids=len({r["frame_id"] for r in qualified}),
                    width120_histogram=dict(sorted(Counter(spatial.features(r)["width120"] for r in qualified).items())),
                    native_on_histogram=dict(sorted(Counter(spatial.features(r)["native_count"] for r in qualified).items())),
                    final_on_histogram=dict(sorted(Counter(spatial.features(r)["output_count"] for r in qualified).items())),
                    expected_lane_on={str(i+1): sum(bool(r["slider"][i]) for r in qualified) for i in EXPECTED.get(job["mode"], [])})
        item["physical_label_valid"] = not (job["mode"] == "palm_contact" and phase["repeat"] == 2)
        if not item["physical_label_valid"]:
            item["label_note"] = "User later confirmed movement or early lift in this hold; exclude from continuous-contact validation."
        for name, stat in item["candidates"].items():
            expected = EXPECTED.get(job["mode"], [])
            affected = [(r, spatial.masks(r, True)[name]) for r in qualified]
            stat["removed_expected_lane_on_observations"] = sum(
                sum(bool(r["slider"][i]) and not mask[i] for i in expected) for r, mask in affected)
            stat["changed_expected_on_frames"] = sum(
                any(r["slider"][i] and not mask[i] for i in expected) for r, mask in affected)
        result["holds"].append(item)
    return result


def analyze(out):
    groups = [evaluate(job, rows) for job, rows in spatial.load(out)]
    root = Path(__file__).parent
    report = {"semantics": [
        "All seven candidates frozen before these gestures; two physical rows, horizontal neighbor index +/-2.",
        "Only confirmed, completed, RAW-restored real groups; all 32 lanes qualified to evaluate a candidate.",
        "Fixed interior hold windows omit first/last 0.5 s; cues are not measured physical contact timestamps.",
        "Counts within a C8 host completed frame come from different chip read times, not simultaneous electrode scans.",
        "Suppression is applied to existing final ON observations, without replaying a deployed state machine.",
        "Observation counts are not independent taps/scans or game miss rates; preserved baseline ON does not prove HID feel.",
        "Zero changed frames is not safety proof; intended contact coverage must also be checked.",
        "Palm-contact repeat2 was later clarified as moved/early-lift; retain observations but exclude as continuous-contact reference.",
    ], "frozen_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                          [root/"round89z_frozen_plan.md", root/"round89z_spatial.py"]}, "groups": groups}
    (out/"spatial_analysis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps([{ "mode": g["mode"], "qualified":g["qualified"], "holds": [
        {k:v for k,v in h.items() if k in ("repeat","qualified","baseline_on_frames","width120_histogram","expected_lane_on")} |
        {"changed_frames": {n:s["changed_on_frames"] for n,s in h["candidates"].items()},
         "changed_expected_frames": {n:s["changed_expected_on_frames"] for n,s in h["candidates"].items()}}
        for h in g["holds"]]} for g in groups], ensure_ascii=False, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    analyze(Path(args.out).resolve())
