import argparse
import queue
import threading
import time
from pathlib import Path

import round89h_timed_capture as ui

FIELDS = ["elapsed_s", "phase", "phase_valid", "diff", "pressures", "hardware", "verified",
          "final", "air", "gate_failures", "uptime_ms", "request_ms", "error"]
MODE = {"multi_contact": "食指和中指同时轻触，相距约两格"}
ui.MODES.update(MODE)
ui.OUT = Path(__file__).resolve().parent / "round89h_spatial_20261001"
ui.ORIGIN = "http://127.0.0.1:8767"


def read_spatial(port):
    start = time.perf_counter()
    port.write(b"\xb1")
    pressure = ui.live.exact(port, 33, 1)
    port.write(b"\xc0")
    chain = ui.live.exact(port, 46, 1)
    if chain[:2] != b"\xaa\x55":
        raise RuntimeError("invalid C0 frame")
    port.write(b"\xc1")
    telemetry = ui.live.exact(port, 528, 1)
    return {"diff": pressure[16], "pressures": pressure[:32].hex(),
            "hardware": chain[2:8].hex(), "verified": chain[8:14].hex(), "final": chain[14:46].hex(),
            "air": pressure[32], "gate_failures": int.from_bytes(telemetry[36:40], "little"),
            "uptime_ms": int.from_bytes(telemetry[:4], "little"),
            "request_ms": (time.perf_counter() - start) * 1000, "error": ""}


def read_paced(port):
    start = time.perf_counter()
    value = read_spatial(port)
    time.sleep(max(0, .02 - (time.perf_counter() - start)))
    return value


def set_raw(port, level):
    ui.live.split(port, 0xC5, [level])
    reply = ui.live.tail(port)
    if reply != f"RAW={level}":
        raise RuntimeError(f"unexpected raw mode: {reply}")


def worker():
    port = None
    firmware = None
    while True:
        task = ui.TASKS.get()
        try:
            if task == "finish":
                if port:
                    try:
                        set_raw(port, 0)
                    finally:
                        port.close()
                        port = None
                ui.update(running=False, phase="closed", message="采样已结束，设备恢复普通模式", end_ms=0)
                continue
            if port is None:
                ui.update(phase="preparing", message="设备准备中，请保持手远离", end_ms=0)
                port, _ = ui.connect_checked()
                firmware = ui.live.version(port)
                set_raw(port, 2)
            task["source"] = "published_normalized_diff32"
            task["semantics"] = "B1 is one published snapshot; C0 and C1 are separate later transactions. Firmware read failures may retain old pressure; valid transport is not proof of fresh sensor data."
            ui.capture_job(port, task, firmware, reader=read_paced, fields=FIELDS)
        except Exception as error:
            if isinstance(task, dict):
                task["error"] = repr(error)
                task["completed"] = False
                ui.save_job(task)
            if port:
                try:
                    set_raw(port, 0)
                except Exception:
                    pass
                port.close()
                port = None
            ui.update(running=False, phase="error", message="采样失败，请保持手远离：" + str(error), end_ms=0)


class Handler(ui.Handler):
    def do_GET(self):
        if self.path == "/":
            page = Path(__file__).with_name("round89h_timed_capture.html").read_text(encoding="utf-8")
            page = page.replace("<h1>触摸对照采样</h1>", "<h1>全板触摸对照采样</h1>")
            page = page.replace('<option value="palm_contact">手掌轻贴</option>',
                                '<option value="palm_contact">手掌轻贴</option><option value="multi_contact">两指同时轻触</option>')
            self.send(200, page.encode("utf-8"), "text/html; charset=utf-8")
        else:
            super().do_GET()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    if not args.serve:
        parser.error("use --serve")
    ui.OUT.mkdir(exist_ok=True)
    threading.Thread(target=worker, daemon=True).start()
    print("READY http://127.0.0.1:8767", flush=True)
    ui.ThreadingHTTPServer(("127.0.0.1", 8767), Handler).serve_forever()
