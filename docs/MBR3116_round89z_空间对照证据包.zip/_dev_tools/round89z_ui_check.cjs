const {chromium}=require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1280,height:900}}), errors=[];
 page.on('pageerror',e=>errors.push(String(e)));
 page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.goto('http://127.0.0.1:8775/');
 await page.waitForFunction(()=>document.querySelectorAll('.cell').length===32);
 if(await page.title()!=='空间对照'||await page.locator('#mode option').count()!==5)throw Error('wrong page');
 const lanes=await page.locator('.cell').evaluateAll(cs=>cs.map(c=>Number(c.dataset.lane)));
 if(JSON.stringify(lanes)!==JSON.stringify(Array.from({length:16},(_,i)=>2*i).concat(Array.from({length:16},(_,i)=>2*i+1))))throw Error('wrong geometry');
 const fixture={counts:Array(32).fill(0),output:Array(32).fill(0),usable:Array(32).fill(true),copy_failed:false,masks:{width4:Array(32).fill(false)}};
 for(const i of [12,14,16,18]){fixture.counts[i]=255;fixture.output[i]=1}
 const status=await page.evaluate(async()=>await(await fetch('/status')).json());
 await page.route('**/status',r=>r.fulfill({json:{...status,signal:fixture,now_ms:Date.now()}}));
 await page.evaluate(s=>{renderSignal(s,true);if(document.querySelectorAll('.cell.on.rejected').length!==4)throw Error('shadow preview mismatch')},fixture);
 await page.screenshot({path:'_dev_tools/round89z_desktop.png',fullPage:true});
 await page.evaluate(s=>{s.copy_failed=true;renderSignal(s,true);if(!document.querySelector('#signalTitle').textContent.includes('读取无效')||[...document.querySelectorAll('.cell b')].some(c=>c.textContent!=='—'))throw Error('failed copy must hide counts')},fixture);
 await page.evaluate(s=>{s.usable[16]=false;s.masks=null;renderSignal(s,true);if(document.querySelector('.cell[data-lane="16"] b').textContent!=='—'||!document.querySelector('#signalTitle').textContent.includes('本帧不评估候选'))throw Error('invalid count must be unavailable')},fixture);
 await page.setViewportSize({width:390,height:844});
 await page.screenshot({path:'_dev_tools/round89z_mobile.png',fullPage:true});
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('body overflow');
 await page.unroute('**/status');
 await page.evaluate(()=>{renderSignal(null,false);if([...document.querySelectorAll('.cell b')].some(c=>c.textContent!=='—')||document.querySelectorAll('.cell.on').length)throw Error('missing signal must clear cached preview')});
 await page.setViewportSize({width:1280,height:900});
 for(const mode of ['two_contact','three_contact','four_contact','palm_contact','palm_hover5']){
  await page.waitForFunction(()=>!document.querySelector('#start').disabled);
  await page.selectOption('#mode',mode);
  await page.click('#start');
  await page.waitForFunction(()=>!document.querySelector('#valid').disabled);
  if(await page.isEnabled('#start'))throw Error('pending confirmation must block start');
  const job=await page.evaluate(async()=> (await(await fetch('/status')).json()).jobs.at(-1));
  if(job.mode!==mode||!job.mock||!job.raw_restored)throw Error('mock restoration mismatch');
  const text=await page.locator('#valid').textContent();
  if(!text.includes(mode.includes('hover')?'未触板':'确实触板'))throw Error('wrong confirmation label');
  await page.click('#valid');
  await page.waitForFunction(()=>document.querySelectorAll('#log div').length&&[...document.querySelectorAll('#log div')].at(-1).textContent.includes('已确认'));
  console.log('PASS',mode,'start -> restore -> confirm');
 }
 await page.click('#finish');
 await page.waitForFunction(()=>document.querySelector('#message').textContent.includes('采样结束'));
 if(errors.length)throw Error(errors.join('\n'));
 fs.writeFileSync('_dev_tools/round89z_ui_result.json',JSON.stringify({passed:true,url:'http://127.0.0.1:8775/',viewports:['1280x900','390x844'],browser:'Edge headless',fallback:'Browser plugin not available',checks:['page identity','32 cells odd/even rows','shadow preview','copy failure unavailable','invalid lane unavailable','mobile body no overflow','5 groups restore and confirmation','finish','no runtime errors']},null,2)+'\n');
 console.log('PASS UI 10 checks, MOCK ONLY');
 await Promise.race([browser.close(),new Promise((_,reject)=>setTimeout(()=>reject(Error('browser cleanup timeout')),15000))]);
 process.exit(0);
})().catch(e=>{console.error(e);process.exit(1)});
