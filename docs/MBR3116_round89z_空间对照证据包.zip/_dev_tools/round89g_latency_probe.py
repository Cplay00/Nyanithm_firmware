import argparse
import json
import statistics
import struct
import time
from pathlib import Path

import serial
import serial.tools.list_ports
import round89_live as live

SERIAL = "5303284739002C9C"


def connect_target():
    found = [p for p in serial.tools.list_ports.comports()
             if p.vid == 0xCAFE and p.pid == 0x4009 and p.serial_number == SERIAL]
    if len(found) != 1:
        raise RuntimeError(f"target enumeration: {found}")
    info = found[0]
    port = serial.Serial(info.device, 115200, timeout=0.03, write_timeout=2)
    port.dtr, port.rts = True, False
    time.sleep(0.15)
    live.tail(port)
    return port, info


def telemetry(port):
    port.write(b"\xc1")
    data = live.exact(port, 528, 2)
    words = struct.unpack_from("<10I", data)
    return dict(zip(("uptime_ms", "served", "edges", "rx", "tx", "min_us", "max_us",
                     "sum_us", "count", "gate_failures"), words))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--seconds", type=float, default=6)
    args = parser.parse_args()
    path = Path(args.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    port, info = connect_target()
    report = {"port": info.device, "serial": info.serial_number, "pose_controlled": False}
    try:
        report["version"] = live.version(port)
        if "NYANFW1;" not in report["version"]:
            raise RuntimeError("unexpected signature")
        port.write(b"\xc4")
        report["raw"] = live.tail(port)
        start = time.perf_counter()
        report["before"] = telemetry(port)
        frames = []
        while time.perf_counter() - start < args.seconds:
            begin = time.perf_counter()
            port.write(b"\xb1")
            data = live.exact(port, 33)
            port.write(b"\xc0")
            chain = live.exact(port, 46)
            if chain[:2] != b"\xaa\x55":
                raise RuntimeError("chain sync mismatch")
            frames.append({"elapsed_s": time.perf_counter() - start,
                           "transaction_ms": (time.perf_counter() - begin) * 1000,
                           "input": data.hex(), "chain": chain.hex()})
            time.sleep(max(0, .05 - (time.perf_counter() - begin)))
        report["after"] = telemetry(port)
        report["elapsed_s"] = time.perf_counter() - start
        report["frames"] = frames
        delta = {k: (report["after"][k] - report["before"][k]) & 0xFFFFFFFF
                 for k in ("uptime_ms", "sum_us", "count", "gate_failures", "edges")}
        report["delta"] = delta
        report["scan_hz"] = delta["count"] * 1000 / delta["uptime_ms"]
        report["mean_scan_us"] = delta["sum_us"] / max(1, delta["count"])
        report["host_median_ms"] = statistics.median(f["transaction_ms"] for f in frames)
        print(json.dumps({k: v for k, v in report.items() if k != "frames"}, indent=2), flush=True)
    finally:
        port.close()
        path.write_text(json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
