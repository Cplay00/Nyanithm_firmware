"""Real saved C8 frame mutations verify exclusion, never write a device."""
import json
from pathlib import Path
import struct
import round89y_analyze_trace as trace
import round89z_spatial as spatial

source = Path(__file__).parent / 'round89y_trace_20261002/1790944087787575400_slow_contact.trace.json'
row = next(r for r in json.loads(source.read_text()) if all(trace.decode(r)['lane_usable']))
assert all(trace.decode(row)['lane_usable'])
data = bytes.fromhex(row['trace_hex'])

def changed(patch):
    value = bytearray(data)
    patch(value)
    return trace.decode(row | {'trace_hex': value.hex()})

def flags(value, chip, mask):
    value[120+chip*40+38] &= mask

for chip in range(3):
    for flag in (2,4,8,16):
        decoded = changed(lambda b: flags(b,chip,255^flag))
        assert not all(decoded['lane_usable'])
        assert all(not decoded['lane_usable'][i] for i in range(32) if spatial.trace.base.LM[i]==chip)
    published = struct.unpack_from('<I', data, 8)[0]
    decoded = changed(lambda b: struct.pack_into('<I',b,120+chip*40+12,(published-16)&0xffffffff))
    assert not all(decoded['lane_usable'])
    decoded = changed(lambda b: struct.pack_into('<I',b,120+chip*40+20,(published-16)&0xffffffff))
    assert not all(decoded['lane_usable'])
for i in range(32):
    chip,e = spatial.trace.base.LM[i], spatial.trace.base.LE[i]
    def remove_range(b):
        offset=120+chip*40+36
        struct.pack_into('<H',b,offset,struct.unpack_from('<H',b,offset)[0] & ~(1<<e))
    assert not changed(remove_range)['lane_usable'][i]
assert not any(changed(lambda b:b.__setitem__(3, b[3]|128))['lane_usable'])
assert not any(changed(lambda b:b.__setitem__(3, b[3]&254))['lane_usable'])
print('PASS 52 exclusions: latest/good/coherent/button, whole-poll/good age, range, copy failure, PROFILE')
