"""Only confirmed/restored C8 groups; no invented contact timestamps."""
import json
from pathlib import Path
import round89x_analyze_trace as base

original_decode = base.decode


def decode(row):
    value = original_decode(row)
    for m, chip in enumerate(value["chips"]):
        chip["poll_age_ms"] = (value["published_ms"] - chip["attempt_start_ms"]) & 0xffffffff
        chip["usable"] = chip["usable"] and chip["poll_age_ms"] <= 15
    value["lane_usable"] = [bool(value["chips"][base.LM[i]]["usable"] and
                                 value["chips"][base.LM[i]]["range_mask"] & (1 << base.LE[i]) and
                                 value["chips"][base.LM[i]]["flags"] & 16) for i in range(32)]
    return value


def analyze(out):
    base.decode = decode
    report = base.analyze(out)
    report.pop("overlap", None)
    report["semantics"] = [
        "Confirmed/restored only; cue intervals are not measured physical contact times.",
        "Qualified additionally requires whole-poll age <=15ms; singleAttempt goodStart includes native wake retries.",
        "Host observations are not independent native scans or counts of taps.",
        "Sliding can cross physical gaps; native OFF alone does not establish a firmware micro-break.",
    ]
    for entry in report["jobs"]:
        job = json.loads((out / (entry["id"] + ".json")).read_text(encoding="utf-8"))
        rows = [decode(r) for r in json.loads((out / (entry["id"] + ".trace.json")).read_text(encoding="utf-8"))]
        entry["stable_holds"] = []
        if job["mode"] == "slow_contact":
            for p in job["phase_plan"]:
                if p["phase"] != "hold":
                    continue
                hold = [r for r in rows if p["start_s"]+.5 <= r["elapsed_s"] <= p["end_s"]-.5
                        and not r["report_flags"] & 128]
                entry["stable_holds"].append({"repeat": p["repeat"], "observations": len(hold),
                    "final_off": sum(not r["slider"][16] for r in hold),
                    "native_off": sum(not (int.from_bytes(r["hardware"][:2], "little") & 128) for r in hold),
                    "latest_difference_invalid": sum(not r["chips"][0]["flags"] & 2 for r in hold),
                    "qualified": sum(r["lane_usable"][16] for r in hold)})
        entry["native_on_final_all_off"] = sum(any(r["hardware"]) and not any(r["slider"])
                                                   for r in rows if not r["report_flags"] & 128)
    (out / "analysis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    out = Path(__file__).resolve().parent / "round89y_trace_20261002"
    report = analyze(out)
    print(json.dumps([{"mode": j["mode"], "holds": j["stable_holds"], "summary": j["summary"]}
                      for j in report["jobs"]], ensure_ascii=False, indent=2))
