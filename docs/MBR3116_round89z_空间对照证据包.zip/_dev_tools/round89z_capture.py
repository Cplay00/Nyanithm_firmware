"""C8 spatial validation; unchanged firmware/NVRAM, shadow masks only."""
import argparse
import json
import re
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import round89x_trace_capture as trace
from round89z_spatial import masks, trace as decoder

sampler = trace.sampler
trace.SIGNATURE = "NYANFW1;1.6.6-beta6;hw_v1;BID=round89y"
sampler.MODES = {
    "two_contact": ("两指相邻轻触", "食指和中指同时轻触第15、17格", "保持两指轻触"),
    "three_contact": ("三指相邻轻触", "三指同时轻触第15、17、19格", "保持三指轻触"),
    "four_contact": ("四指相邻轻触", "四指同时轻触第13、15、17、19格", "保持四指轻触"),
    "palm_contact": ("手掌轻贴", "以第17格为中心，手掌轻贴板面", "保持手掌轻贴"),
    "palm_hover5": ("手掌悬空5 mm", "以第17格为中心，手掌停在板面上方约5 mm，不能触板", "保持手掌悬空约5 mm，不能触板"),
}


def phase_plan(mode):
    plan = []
    def add(phase, repeat, duration, message):
        start = plan[-1]["end_s"] if plan else 0
        plan.append({"phase": phase, "repeat": repeat, "start_s": start, "end_s": start+duration*sampler.SCALE,
                     "message": message, "cue_id": str(len(plan))})
    add("baseline", 0, 4, "整只手保持远离至少30 cm")
    for repeat in (1, 2):
        add("prepare", repeat, 2, "按本组位置就位，先保持离板约1 cm")
        add("action", repeat, 2, sampler.MODES[mode][1])
        add("hold", repeat, 4, sampler.MODES[mode][2])
        add("release", repeat, 4 if repeat == 1 else 6, "整只手立即移开至少30 cm")
    return plan


original_read = trace.read_trace


def read_trace(port, origin):
    begin, end, data, value = original_read(port, origin)
    row = decoder.decode({"trace_hex": data.hex()})
    qualified = all(row["lane_usable"])
    sampler.update(signal={"frame": value["frame_id"], "counts": list(value["counts"]),
                           "output": list(value["slider"]), "usable": row["lane_usable"],
                           "copy_failed": bool(value["report_flags"] & 128),
                           "masks": masks(row, True) if qualified else None})
    return begin, end, data, value


PAGE_PATCH = r'''
<style>
.signalScroll{overflow-x:auto;margin-top:18px}.signals{min-width:760px;display:grid;grid-template-columns:repeat(16,1fr);gap:4px}.cell{font-size:12px;text-align:center;background:#202b33;border:2px solid #405963;border-radius:5px;padding:7px 0}.cell b{display:block;font-size:16px}.cell.on{background:#16644d}.cell.rejected{border-color:#ffbe64}.cell.unavailable{color:#829199;border-style:dashed}#signalTitle{margin-top:18px;font-size:16px}#filter{font-size:14px;padding:8px;margin-top:10px}
</style>
<div id="signalTitle">等待采样</div>
<div class="signalScroll"><div class="signals" id="signals"></div></div>
<select id="filter" aria-label="候选预测">
<option value="width4">候选：宽区域抑制</option>
<option value="curvature32_when_width4">候选：曲率32</option>
<option value="curvature64_when_width4">候选：曲率64</option>
<option value="prominence32_when_width4">候选：突出度32</option>
<option value="prominence64_when_width4">候选：突出度64</option>
<option value="width4to7_native1to3">候选：宽区域与原生键数</option>
</select>
<p style="font-size:14px">绿底：当前输出　橙框：候选会拦截　虚框：读取无效<br>候选仅预览，不改变设备。页面亮格不代表游戏延迟。</p>
'''
JS_PATCH = r'''
function renderSignal(s,running){
 const grid=$('signals');
 if(!grid.children.length){for(const i of [...Array(16).keys()].map(x=>2*x).concat([...Array(16).keys()].map(x=>2*x+1))){const c=document.createElement('div');c.className='cell';c.dataset.lane=i;const n=document.createElement('span');n.textContent=i+1;const b=document.createElement('b');b.textContent='—';c.append(n,b);grid.append(c)}}
 if(!s){$('signalTitle').textContent='等待采样';for(const c of grid.children){c.className='cell';c.lastChild.textContent='—'}return}
 const mask=s.masks?.[$('filter').value];let on=0,rejected=0;
 for(const c of grid.children){const i=Number(c.dataset.lane),valid=!s.copy_failed&&s.usable[i],active=!s.copy_failed&&s.output[i]!==0,deny=active&&mask&&!mask[i];on+=active;rejected+=Boolean(deny);c.className='cell'+(active?' on':'')+(deny?' rejected':'')+(!valid?' unavailable':'');c.lastChild.textContent=valid?s.counts[i]:'—'}
 $('signalTitle').textContent=(running?'采样中':'上一采样帧')+' · '+(s.copy_failed?'读取无效':on+'格输出 · '+(mask?rejected+'格候选拦截':'本帧不评估候选'));
}
'''


class Handler(sampler.Handler):
    def do_GET(self):
        if urlsplit(self.path).path == "/":
            html = Path(sampler.__file__).with_suffix(".html").read_text(encoding="utf-8")
            html = html.replace("触摸动态对照", "空间对照").replace("依次完成四组", "依次完成五组")
            html = html.replace("固定在滑条第17格，每组两次动作。高度从亚克力顶面估计；跟随页面提示。悬空组全程不能触板，意外碰到请作废。",
                                "奇数排按指定格轻触，每组两次。手掌组围绕第17格；悬空高度从板面估计。动作有偏差请作废。")
            options = "\n".join(f'<option value="{key}">{i} · {value[0]}</option>'
                                for i, (key, value) in enumerate(sampler.MODES.items(), 1))
            html = re.sub(r'(<select id="mode">).*?(</select>)', r'\1\n'+options+r'\n\2', html, flags=re.S)
            html = html.replace('<div id="error">', PAGE_PATCH+'<div id="error">')
            html = html.replace("const $=id=>", JS_PATCH+"\nconst $=id=>")
            html = html.replace("$('log').replaceChildren(", "renderSignal(['queued','preparing'].includes(state.phase)?null:state.signal,state.running);\n $('log').replaceChildren(")
            return self.send(200, html.encode("utf-8"), "text/html; charset=utf-8")
        return super().do_GET()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8774)
    parser.add_argument("--out", required=True)
    parser.add_argument("--backup", required=True)
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args()
    sampler.OUT = Path(args.out).resolve()
    sampler.OUT.mkdir(parents=True, exist_ok=True)
    sampler.BACKUP = Path(args.backup).resolve()
    backup = json.loads((sampler.BACKUP/"snapshot.json").read_text(encoding="utf-8"))
    if "BID=round89y" not in backup["version"] or backup["raw_status"] != "RAW=0":
        parser.error("verified round89y baseline required")
    sampler.phase_plan = phase_plan
    sampler.connect_checked = trace.connect_checked
    if args.mock:
        sampler.MOCK = True
        sampler.STATE["mock"] = True
        sampler.SCALE = .04
    else:
        trace.read_trace = read_trace
        sampler.capture = trace.capture
    sampler.ORIGIN = f"http://127.0.0.1:{args.port}"
    threading.Thread(target=sampler.worker, daemon=True).start()
    print("READY", sampler.ORIGIN, "MOCK" if args.mock else "round89y C8 SHADOW", flush=True)
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
