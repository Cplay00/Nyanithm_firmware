import argparse
import csv
import json
import statistics
import time
from pathlib import Path

from round89_live import connect, exact, split, stage_request, tail, version


def run(out, address, sensor):
    port, _ = connect()
    start = time.perf_counter()
    heartbeat = start
    current = None
    handled = set()
    fields = ["elapsed_s", "stage", "sync", "cp_pf", "diff", "baseline", "raw", "delta", "error"]
    try:
        print("VERSION", version(port), flush=True)
        port.write(b"\xb3")
        tail(port, 0.25)
        print(f"READY native debug {address:#x}/CS{sensor}", flush=True)
        with (out / "native.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            while time.perf_counter() - start < 1200:
                request_path = out / "stage.json"
                request = stage_request(request_path)
                name = request.get("stage")
                if name == "stop":
                    break
                if name and name not in handled:
                    if current:
                        raise RuntimeError("stage overlap")
                    handled.add(name)
                    current = {"name": name, "start": time.perf_counter(),
                               "duration": min(30, max(3, float(request.get("duration_s", 8))))}
                    rows = []
                    print("START", name, flush=True)
                if current:
                    split(port, 0xC7, [address, sensor])
                    head = exact(port, 1)
                    row = {"elapsed_s": time.perf_counter() - start, "stage": current["name"], "error": ""}
                    if head == b"\xc7":
                        data = exact(port, 10)
                        if data[:2] != bytes([address, sensor]):
                            raise RuntimeError(f"identity mismatch: {data.hex()}")
                        row.update(sync=data[2], cp_pf=data[3],
                                   diff=int.from_bytes(data[4:6], "little"),
                                   baseline=int.from_bytes(data[6:8], "little"),
                                   raw=int.from_bytes(data[8:10], "little"))
                        row["delta"] = row["raw"] - row["baseline"]
                    else:
                        row["error"] = (head + port.readline()).decode("ascii", "replace").strip()
                    writer.writerow(row)
                    rows.append(row)
                    if time.perf_counter() - current["start"] >= current["duration"]:
                        valid = [r for r in rows if not r["error"]]
                        summary = {"stage": current["name"], "n": len(valid),
                                   "errors": len(rows) - len(valid), "address": address, "sensor": sensor}
                        for field in ("diff", "raw", "baseline", "delta", "cp_pf"):
                            values = [r[field] for r in valid]
                            summary[field] = {"min": min(values), "median": statistics.median(values),
                                              "max": max(values)} if values else None
                        (out / f"{current['name']}.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
                        print("DONE", json.dumps(summary), flush=True)
                        stream.flush()
                        current = None
                if time.perf_counter() - heartbeat > 10:
                    port.write(b"\xc3")
                    heartbeat = time.perf_counter()
                if not current:
                    time.sleep(0.1)
    finally:
        try:
            port.write(b"\xb9")
            port.flush()
        finally:
            port.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--address", type=lambda value: int(value, 0), default=0x40)
    parser.add_argument("--sensor", type=int, default=7)
    args = parser.parse_args()
    output = Path(args.out).resolve()
    output.mkdir(parents=True, exist_ok=True)
    run(output, args.address, args.sensor)
