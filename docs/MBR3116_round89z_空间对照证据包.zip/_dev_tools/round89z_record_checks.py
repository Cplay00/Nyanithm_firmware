"""Save executed checks and an actual plateau counterexample from held contact."""
import json
from pathlib import Path
import subprocess
import sys
import round89z_spatial as spatial

root = Path(__file__).resolve().parents[1]
out = root/'_dev_tools/round89z_trace_20261002'
result = {}
for name in ('round89z_check_masks.py','round89z_check_quality.py'):
    completed = subprocess.run([sys.executable,str(root/'_dev_tools'/name)],capture_output=True,text=True,encoding='utf-8')
    result[name] = {'exit_code':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr}
    assert completed.returncode==0
groups = dict((j['mode'],(j,rows)) for j,rows in spatial.load(out))
assert len(groups)==5
job, rows = groups['four_contact']
inside = [r for r in rows if any(p['phase']=='hold' and p['start_s']+.5<=r['elapsed_s']<=p['end_s']-.5
                                for p in job['phase_plan']) and all(r['lane_usable'])]
expected = [12,14,16,18]
example = next(r for r in inside if all(r['counts'][i]==255 and r['slider'][i] for i in expected))
curvature = {str(i+1):2*example['counts'][i]-example['counts'][i-2]-example['counts'][i+2] for i in expected}
prominence = {str(i+1):example['counts'][i]-max(example['counts'][i-2],example['counts'][i+2]) for i in expected}
assert curvature['15']==curvature['17']==0
assert all(p==0 for p in prominence.values())
result['actual_four_contact'] = {'id':job['id'],'elapsed_s':example['elapsed_s'],'frame_id':example['frame_id'],
                               'counts':example['counts'],'slider':list(example['slider']),
                               'manual_curvature':curvature,'manual_prominence':prominence,
                               'trace_hex':example['trace_hex'],'all_32_qualified':True}
_, hover = groups['palm_hover5']
hover_example = next(r for r in hover if r['phase']=='hold' and all(r['lane_usable']) and any(r['slider'])
                     and spatial.features(r)['width120']==3)
assert all(all(not v or m for v,m in zip(hover_example['slider'],mask))
           for mask in spatial.masks(hover_example,True).values())
result['actual_palm_hover_survives_all_candidates'] = {'elapsed_s':hover_example['elapsed_s'],
       'frame_id':hover_example['frame_id'],'counts':hover_example['counts'],'slider':list(hover_example['slider']),
       'peak':max(hover_example['counts']),
       'trace_hex':hover_example['trace_hex'],'all_32_qualified':True}
report = json.loads((out/'spatial_analysis.json').read_text(encoding='utf-8'))
assert sum(g['host_frames'] for g in report['groups'])==7376
assert sum(g['qualified'] for g in report['groups'])==7227
assert sum(g['copy_failed'] for g in report['groups'])==3
assert sum(h['candidates']['width4to7_native1to3']['changed_on_frames'] for g in report['groups']
           if g['mode']=='palm_hover5' for h in g['holds'])==19
assert all(not h['physical_label_valid'] for g in report['groups'] if g['mode']=='palm_contact'
           for h in g['holds'] if h['repeat']==2)
result['totals_checked'] = True
(out/'executed_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PASS executed checks saved; real four-touch plateau and surviving palm hover; totals and exclusion checked')
