# round90f offline replay

Extract into a new directory and run there (Python standard library only):

```powershell
py -3 tools/analyze_mbr_raw_evidence.py evidence/manifest.json --out replay_raw.json
py -3 tools/decode_mpr121_snapshot.py docs/MBR3116_round90f_MPR源码写入意图.json --out replay_mpr.json
py -3 tools/test_touch_offline_research.py --manifest evidence/manifest.json --data-root evidence
```

Compare replay JSON with the saved docs JSON. No device, network, model fitting, or NVM generation.
Sparse MPR input is source intent, not hardware readback. One confirmed action per pose; sequential C7.
The historical proximity reference configuration differs from production beta10.
Source files document baseline 101f51d; the unchanged local beta10 UF2 is not duplicated in this archive.
helpers/ retains workspace-specific packaging provenance; portable replay uses tools/ above.
