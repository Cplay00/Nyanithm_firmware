"""Package and independently replay offline evidence. Never contact the device."""

import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "Nyanithm_firmware_hw_v1"
DOCS = REPO / "docs"
DATA = ROOT / "_dev_tools/round89q_no_autoreset_20261002"
ARCHIVE = DOCS / "MBR3116_round90f_离线证据.zip"
EXPECTED_UF2 = "9cc627e90abec0b45cd1695b477a5b04718baa74e76934eb6c29df191943128b"


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout + result.stderr


def main():
    run(["git", "diff", "--exit-code", "101f51d", "--", "src", "include", "lib", "CMakeLists.txt"], REPO)
    uf2 = (REPO / "build_round90e/Nyanithm.uf2").read_bytes()
    if digest(uf2) != EXPECTED_UF2:
        raise RuntimeError("local accepted beta10 artifact changed")
    fixture = json.loads((DOCS / "MBR3116_round90f_MPR源码写入意图.json").read_text(encoding="utf-8"))
    for name, expected in fixture["source_sha256"].items():
        if digest((REPO / name).read_bytes()) != expected:
            raise RuntimeError("source-intent binding no longer matches baseline")
    manifest = json.loads((DOCS / "MBR3116_round90f_输入清单.json").read_text(encoding="utf-8"))

    payload = {}
    for relative, expected in manifest["files"].items():
        content = (DATA / relative).read_bytes()
        if digest(content) != expected:
            raise RuntimeError("frozen historical evidence changed")
        payload["evidence/" + relative] = content
    payload["evidence/manifest.json"] = (DOCS / "MBR3116_round90f_输入清单.json").read_bytes()
    for name in ("decode_mpr121_snapshot.py", "analyze_mbr_raw_evidence.py", "test_touch_offline_research.py"):
        payload["tools/" + name] = (REPO / "tools" / name).read_bytes()
    for name in ("MBR3116_round90f_离线机理研究与实验收敛.md", "MBR3116_算法与驱动重构计划_20261003.md",
                 "MBR3116_round90f_MPR源码写入意图.json", "MBR3116_round90f_MPR字段解码.json", "MBR3116_round90f_RAW复核.json"):
        payload["docs/" + name] = (DOCS / name).read_bytes()
    sources = ("src/mpr121.cpp", "src/hw_devices.cpp", "src/app_link.cpp", "src/cy8cmbr3116.cpp", "src/i2c_port.cpp",
               "include/device/mpr121.h", "include/config/i2c_config.h", "include/share/nyanithm_shared.h")
    for name in sources:
        payload["baseline_source/" + name] = (REPO / name).read_bytes()
    payload["helpers/round90f_offline.py"] = (ROOT / "_dev_tools/round90f_offline.py").read_bytes()
    payload["helpers/round90f_package.py"] = Path(__file__).read_bytes()
    payload["docs/更新日志_固件.md"] = (REPO / "更新日志_固件.md").read_bytes()
    payload["README.md"] = ("# round90f offline replay\n\n"
        "Extract into a new directory and run there (Python standard library only):\n\n"
        "```powershell\n"
        "py -3 tools/analyze_mbr_raw_evidence.py evidence/manifest.json --out replay_raw.json\n"
        "py -3 tools/decode_mpr121_snapshot.py docs/MBR3116_round90f_MPR源码写入意图.json --out replay_mpr.json\n"
        "py -3 tools/test_touch_offline_research.py --manifest evidence/manifest.json --data-root evidence\n"
        "```\n\n"
        "Compare replay JSON with the saved docs JSON. No device, network, model fitting, or NVM generation.\n"
        "Sparse MPR input is source intent, not hardware readback. One confirmed action per pose; sequential C7.\n"
        "The historical proximity reference configuration differs from production beta10.\n"
        "Source files document baseline 101f51d; the unchanged local beta10 UF2 is not duplicated in this archive.\n"
        "helpers/ retains workspace-specific packaging provenance; portable replay uses tools/ above.\n").encode("utf-8")

    # Replay from a fresh, isolated directory, using only the files to be bundled.
    with tempfile.TemporaryDirectory(prefix="round90f_replay_", dir=ROOT / "_dev_tools") as temporary:
        replay_root = Path(temporary).resolve()
        if not replay_root.is_relative_to((ROOT / "_dev_tools").resolve()):
            raise RuntimeError("temporary replay path leaves intended directory")
        for name, content in payload.items():
            target = (replay_root / name).resolve()
            if not target.is_relative_to(replay_root):
                raise RuntimeError("bundle path leaves replay directory")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        commands = [
            [sys.executable, "tools/analyze_mbr_raw_evidence.py", "evidence/manifest.json", "--out", "replay_raw.json"],
            [sys.executable, "tools/decode_mpr121_snapshot.py", "docs/MBR3116_round90f_MPR源码写入意图.json", "--out", "replay_mpr.json"],
            [sys.executable, "tools/test_touch_offline_research.py", "--manifest", "evidence/manifest.json", "--data-root", "evidence"],
        ]
        outputs = [run(command, replay_root) for command in commands]
        for actual, expected in (("replay_raw.json", "docs/MBR3116_round90f_RAW复核.json"),
                                 ("replay_mpr.json", "docs/MBR3116_round90f_MPR字段解码.json")):
            if (replay_root / actual).read_bytes() != (replay_root / expected).read_bytes():
                raise RuntimeError("portable replay differs from recorded JSON")
        if "Ran 24 tests" not in outputs[2] or not outputs[2].rstrip().endswith("OK"):
            raise RuntimeError("test output did not confirm all 24 checks")
        payload["verification/offline_tests.txt"] = outputs[2].encode("utf-8")

    checks = {"date": "2026-10-03", "baseline_head": "101f51d", "device_access": False,
              "firmware_behavior_changed": False, "source_intent_binding_matches": True,
              "local_beta10_uf2_sha256": EXPECTED_UF2, "local_beta10_uf2_bytes": len(uf2),
              "input_files_verified": len(manifest["files"]), "portable_replay_matches_exact_json_bytes": True,
              "offline_tests_passed": 24, "python_version": sys.version.split()[0],
              "build_and_live_test_exemption": "Python tools and documents only; no firmware or protocol changes"}
    payload["verification/checks.json"] = (json.dumps(checks, indent=2) + "\n").encode("utf-8")
    bundle_manifest = {name: digest(content) for name, content in sorted(payload.items())}
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for name, content in sorted(payload.items()):
            bundle.writestr(name, content)
        bundle.writestr("bundle_manifest.json", json.dumps(bundle_manifest, indent=2) + "\n")
    with zipfile.ZipFile(ARCHIVE) as bundle:
        if bundle.testzip() is not None or any(digest(bundle.read(name)) != expected for name, expected in bundle_manifest.items()):
            raise RuntimeError("archive byte verification failed")
    checks["archive"] = {"name": ARCHIVE.name, "payload_files": len(payload), "total_entries": len(payload) + 1,
                         "size_bytes": ARCHIVE.stat().st_size, "sha256": digest(ARCHIVE.read_bytes())}
    (DOCS / "MBR3116_round90f_证据核对.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checks, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
