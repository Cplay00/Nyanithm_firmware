"""Reproduce round90f from frozen historical files. No device/network access."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "Nyanithm_firmware_hw_v1"
DOCS = REPO / "docs"
DATA = ROOT / "_dev_tools/round89q_no_autoreset_20261002"
sys.path.insert(0, str(REPO / "tools"))
import analyze_mbr_raw_evidence as mbr
import decode_mpr121_snapshot as mpr

MANIFEST = DOCS / "MBR3116_round90f_输入清单.json"
FIXTURE = DOCS / "MBR3116_round90f_MPR源码写入意图.json"


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prepare():
    jobs = [
        {"id": "1790876594174295200_finger_contact", "mode": "finger_contact"},
        {"id": "1790876627814037400_finger_hover3", "mode": "finger_hover3"},
        {"id": "1790875672052784000_palm_hover5", "mode": "palm_hover5"},
        {"id": "1790875704204811700_palm_contact", "mode": "palm_contact"},
    ]
    files = {}
    for job in jobs:
        job_id = job["id"]
        relative_paths = [job_id + suffix for suffix in (".json", ".csv")]
        relative_paths += [job_id + "_device/" + prefix + name for prefix in ("", "after_reboot/") for name in
                           ("controller_config.bin", "chip_40.bin", "chip_41.bin", "chip_42.bin")]
        relative_paths.append(job_id + "_device/after_reboot/snapshot.json")
        for relative in relative_paths:
            files[relative] = hashlib.sha256((DATA / relative).read_bytes()).hexdigest()
    first_meta = json.loads((DATA / (jobs[0]["id"] + ".json")).read_text(encoding="utf-8"))
    manifest = {
        "schema": mbr.SCHEMA, "reference_mode": mbr.REFERENCE_MODE,
        "usb_serial": first_meta["hardware"]["usb_serial"], "firmware": first_meta["firmware"],
        "hold_window_s": [6.0, 11.5], "selection_basis": "unchanged round89s fixed hold window; no rule fitting",
        "jobs": jobs, "files": dict(sorted(files.items())),
    }
    source_files = ("src/mpr121.cpp", "src/hw_devices.cpp", "include/device/mpr121.h")
    fixture = {
        "schema": mpr.SCHEMA, "origin": "source-intent", "source_head": "101f51d",
        "scope": "literal global/filter writes and ECR requested by calibrateBaseline; not a runtime snapshot",
        "source_sha256": {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in source_files},
        "registers": {"0x5C": 0x10, "0x5D": 0x28, "0x5E": 0xCC, "0x7B": 0,
                      "0x2B": 1, "0x2C": 1, "0x2D": 31, "0x2E": 0,
                      "0x2F": 1, "0x30": 1, "0x31": 127, "0x32": 4,
                      "0x33": 1, "0x34": 16, "0x35": 255},
        "unknowns": ["actual per-electrode CDC/CDT after AutoConfig", "live ECR after subsequent Stop/Run",
                     "physical VDD", "actual thresholds/debounce", "filtered/baseline/status readback"],
    }
    # Refuse to replace a previously frozen input list silently on a later run.
    for path, value in ((MANIFEST, manifest), (FIXTURE, fixture)):
        if path.exists() and json.loads(path.read_text(encoding="utf-8")) != value:
            raise RuntimeError(f"frozen round90f input changed: {path.name}")
        write(path, value)


def run():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    result = mbr.audit(manifest, DATA)
    write(DOCS / "MBR3116_round90f_RAW复核.json", result)
    write(DOCS / "MBR3116_round90f_MPR字段解码.json", mpr.decode(json.loads(FIXTURE.read_text(encoding="utf-8"))))
    print(json.dumps({
        "files_verified": result["input_files_verified"], "rows": result["csv_rows"],
        "error_rows_excluded": result["error_rows_excluded"],
        "hold_observations": result["hold_observations"],
        "unsaturated_ratio": result["unsaturated_phase_valid_diff_over_delta"],
        "jobs": [{"mode": job["mode"], "hold": job["hold_valid_observations"],
                  "clipped": job["hold_diff_255_observations"], "delta": job["hold"]["delta"]}
                 for job in result["jobs"]],
        "collisions": {key: {"n": value["distinct_opposite_label_keys"], "values": [p["values"] for p in value["examples"]]}
                       for key, value in result["exact_opposite_label_collisions"].items()},
    }, ensure_ascii=False, indent=2))


def add_log():
    path = REPO / "更新日志_固件.md"
    original = path.read_bytes()
    text = original.decode("utf-8-sig")
    entry = """### 20261003 round90f: Audit native observability and prepare offline research tools

- **原理**：按NXP修正MPR源码意图的SFI=6/名义6ms、CL装载、逐电极CDC/CDT和BVA掩码解释，登记Run写基线的原生时序问题；尚无MPR现场读回，不改已接受MPR行为。核查MBR的4位SYNC、ALP专属AVG_RAW、整数CP和REFRESH_CTRL边界，不虚构距离/扫描号。
- **离线证据**：44文件哈希/恢复核对，722条旧RAW记录、21错误排除；沿用旧保持窗175观察。DIFF饱和时RAW仍变，但单指接触/手掌悬空有三个RAW/BASE/DIFF/CP完全重合元组，否决单格幅值替换根治；不拟合新门限、不生成MBR表。下一次主实验收敛为MPR实际逐电极参数与一致信号对照。
- **交付/验证**：两个纯离线工具、24项编码与坏证据拒绝测试、可解压复跑证据包及详细报告/计划。来源/缺失值保留，逐字节复跑一致；本轮不访问设备，无C++/协议/面板或固件配置行为改变，豁免构建/迁移/Mock/新真机验收。既有beta10手感正常、隔空仍在；研究round90f没有beta11。见docs/MBR3116_round90f_离线机理研究与实验收敛.md。本地提交，不push。

"""
    if text.startswith(entry):
        return
    if "### 20261003 round90f:" in text:
        raise RuntimeError("different round90f log entry already exists")
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    path.write_bytes(bom + (entry + text).encode("utf-8"))


if __name__ == "__main__":
    if sys.argv[1:] == ["--prepare"]:
        prepare()
    elif sys.argv[1:] == ["--add-log"]:
        add_log()
    elif sys.argv[1:]:
        raise SystemExit("use --prepare, --add-log, or no arguments to reproduce results")
    else:
        run()
