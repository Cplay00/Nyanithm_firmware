"""Reuse the verified C8 capture flow for the deferred-retry candidate."""
import argparse
import re
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import round89x_trace_capture as trace

sampler = trace.sampler
trace.SIGNATURE = "NYANFW1;1.6.6-beta6;hw_v1;BID=round89y"
sampler.MODES = {
    "slow_contact": sampler.MODES["slow_contact"],
    "fast_contact": sampler.MODES["fast_contact"],
    "slide_contact": ("连续轻触滑动", "食指保持贴面，从第17格缓慢滑到第25格", "保持第25格轻触"),
}


class Handler(sampler.Handler):
    def do_GET(self):
        if urlsplit(self.path).path == "/":
            html = Path(sampler.__file__).with_suffix(".html").read_text(encoding="utf-8")
            html = html.replace("触摸动态对照", "读取稳定性对照").replace("依次完成四组", "依次完成三组")
            html = html.replace("固定在滑条第17格，每组两次动作。高度从亚克力顶面估计；跟随页面提示。悬空组全程不能触板，意外碰到请作废。",
                                "轻触和点按固定第17格；滑动从第17格到第25格。每组两次，跟随提示，动作有偏差请作废。")
            options = "\n".join(f'<option value="{key}">{i} · {value[0]}</option>'
                                for i, (key, value) in enumerate(sampler.MODES.items(), 1))
            html = re.sub(r'(<select id="mode">).*?(</select>)', r'\1\n'+options+r'\n\2', html, flags=re.S)
            return self.send(200, html.encode("utf-8"), "text/html; charset=utf-8")
        return super().do_GET()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8774)
    parser.add_argument("--out", required=True)
    parser.add_argument("--backup", required=True)
    args = parser.parse_args()
    sampler.OUT = Path(args.out).resolve()
    sampler.OUT.mkdir(parents=True, exist_ok=True)
    sampler.BACKUP = Path(args.backup).resolve()
    if not (sampler.BACKUP / "snapshot.json").is_file():
        parser.error("verified backup required")
    sampler.connect_checked = trace.connect_checked
    sampler.capture = trace.capture
    sampler.ORIGIN = f"http://127.0.0.1:{args.port}"
    threading.Thread(target=sampler.worker, daemon=True).start()
    print("READY", sampler.ORIGIN, "round89y C8 REAL", flush=True)
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()
