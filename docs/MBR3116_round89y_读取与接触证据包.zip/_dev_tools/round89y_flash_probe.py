import round89c_flash_probe as probe
from round89g_latency_probe import connect_target

probe.live.connect = connect_target
probe.OUT = probe.WORKSPACE / "_dev_tools/round89y_flash_20261002"
probe.UF2 = probe.WORKSPACE / "Nyanithm_firmware_hw_v1/build_round89y/Nyanithm.uf2"
probe.EXPECTED_SHA256 = "f9ea5d85ff7b4a0a702180a8c20f9c731ff203d63e25a507d5b04e7f01eab3b3"
probe.SIGNATURE = "NYANFW1;1.6.6-beta6;hw_v1;BID=round89y"
probe.BASELINE_BUILD_ID = "round89x"
probe.DEVICE_BACKUP = probe.WORKSPACE / "_dev_archive/round89y_flash_before_20261002"

if __name__ == "__main__":
    probe.main()
