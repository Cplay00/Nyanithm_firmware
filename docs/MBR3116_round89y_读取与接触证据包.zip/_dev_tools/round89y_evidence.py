import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "Nyanithm_firmware_hw_v1"
DOCS = REPO / "docs"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify():
    out = ROOT / "_dev_tools/round89y_trace_20261002"
    report = json.loads((out / "analysis.json").read_text(encoding="utf-8"))
    assert [j["mode"] for j in report["jobs"]] == ["slow_contact", "fast_contact", "slide_contact"]
    assert [j["summary"]["host_frames"] for j in report["jobs"]] == [1573, 1279, 1278]
    for entry in report["jobs"]:
        job = json.loads((out / (entry["id"] + ".json")).read_text(encoding="utf-8"))
        assert job["completed"] and job["user_confirmed"] is True and job["raw_restored"] and not job["mock"]
        assert all(c["io_failures_delta"] == c["button_invalid_frames"] == 0 for c in entry["summary"]["chips"])
    holds = report["jobs"][0]["stable_holds"]
    assert [h["observations"] for h in holds] == [99, 99]
    assert sum(h["final_off"]+h["native_off"]+h["latest_difference_invalid"] for h in holds) == 0
    before = json.loads((ROOT / "_dev_archive/round89y_flash_before_20261002/snapshot.json").read_text())
    after = json.loads((out / "after/snapshot.json").read_text())
    assert before["controller_config"] == after["controller_config"]
    assert all(before["chips"][k]["hex"] == after["chips"][k]["hex"] for k in before["chips"])
    assert after["raw_status"] == "RAW=0" and not any(after["initial_input"])
    artifact = (REPO / "build_round89y/Nyanithm.uf2").read_bytes()
    assert len(artifact) == 191488 and digest(artifact) == "f9ea5d85ff7b4a0a702180a8c20f9c731ff203d63e25a507d5b04e7f01eab3b3"
    tests = json.loads((ROOT / "_dev_tools/round89y_pipeline_tests/results.json").read_text())
    return {"gesture_rows": [1573, 1279, 1278], "holds_on": 198, "config_restored": True,
            "raw_final": 0, "uf2_sha256": digest(artifact), "pipeline_results_sha256": digest(json.dumps(tests).encode()),
            "game_hid_acceptance": "not completed; user cannot judge timing on the cue page"}


def main():
    checks = verify()
    files = set()
    for prefix in ("_dev_tools/round89y_quality_before_20261002", "_dev_tools/round89y_quality_after_20261002",
                   "_dev_tools/round89y_flash_20261002", "_dev_tools/round89y_trace_20261002",
                   "_dev_archive/round89y_flash_before_20261002", "_dev_tools/round89y_ui_mock_20261002"):
        files.update(p for p in (ROOT / prefix).rglob("*") if p.is_file())
    files.update(p for p in (ROOT / "_dev_tools").glob("round89y*") if p.is_file())
    for name in ("round89x_trace_capture.py", "round89x_dynamics_capture.py", "round89x_dynamics_capture.html",
                 "round89x_analyze_trace.py", "round89_live.py", "round89g_latency_probe.py", "round89c_flash_probe.py",
                 "round89h_raw_capture.py", "round89h_spatial_capture.py"):
        files.add(ROOT / "_dev_tools" / name)
    for name in ("results.json", "manifest.json", "production_pipeline.cpp"):
        p = ROOT / "_dev_tools/round89y_pipeline_tests" / name
        if p.exists():
            files.add(p)
    changed = subprocess.check_output(["git", "diff", "--name-only", "cf4b800"], cwd=REPO).decode().splitlines()
    files.update(REPO / name for name in changed if (REPO / name).is_file()
                 and not name.startswith("docs/MBR3116_round89y_"))
    for name in ("include/software/mbr_distance_gate.h", "include/software/touch_snapshot.h", "include/usb/tusb_config.h",
                 "src/i2c_port.cpp", "tools/test_touch_snapshot_readers.py", "tools/test_round50_migration.py",
                 "docs/MBR3116_round89y_延后重读与接触回归.md", "build_round89y/Nyanithm.uf2"):
        files.add(REPO / name)
    files.add(ROOT / "_dev_archive/round89y_before_20261002/Nyanithm_round89x.uf2")
    files.add(ROOT / "_dev_tools/official_mbr_sources/host_apis/Host APIs/CY8CMBR3xxx_APIs.c")
    patch = subprocess.check_output(["git", "diff", "--binary", "cf4b800", "--",
                                     "CMakeLists.txt", "include", "src", "tools", "更新日志_固件.md"], cwd=REPO)
    manifest = {"baseline": "cf4b800", "checks": checks, "files": [], "external_backup": {}}
    source_backup = ROOT / "_dev_archive/round89y_before_20261002/source_cf4b800.zip"
    manifest["external_backup"] = {"path": str(source_backup), "sha256": digest(source_backup.read_bytes()),
                                   "note": "Full prior Git archive kept locally; changed source and patch are in this package."}
    target = DOCS / "MBR3116_round89y_读取与接触证据包.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            data = path.read_bytes()
            key = path.relative_to(ROOT).as_posix()
            archive.writestr(key, data)
            manifest["files"].append({"path": key, "bytes": len(data), "sha256": digest(data)})
        archive.writestr("source_diff_cf4b800.patch", patch)
        manifest["files"].append({"path": "source_diff_cf4b800.patch", "bytes": len(patch), "sha256": digest(patch)})
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2)+"\n")
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for entry in manifest["files"]:
            assert digest(archive.read(entry["path"])) == entry["sha256"]
    manifest["package"] = {"path": target.name, "bytes": target.stat().st_size, "sha256": digest(target.read_bytes())}
    (DOCS / "MBR3116_round89y_证据核对.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "package": manifest["package"], "file_count": len(manifest["files"])}, indent=2))


if __name__ == "__main__":
    main()
