import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
import round89y_trace_capture as page

s = page.sampler
s.OUT = Path(__file__).resolve().parent / "round89y_ui_mock_20261002"
s.OUT.mkdir(exist_ok=True)
s.MOCK = True
s.STATE["mock"] = True
s.SCALE = .04
s.ORIGIN = "http://127.0.0.1:8775"
threading.Thread(target=s.worker, daemon=True).start()
print("READY MOCK ONLY", flush=True)
ThreadingHTTPServer(("127.0.0.1", 8775), page.Handler).serve_forever()
