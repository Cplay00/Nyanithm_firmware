"""Read completed C8 frames; no configuration or RAW-mode writes."""
import argparse
import json
import statistics
import time
from pathlib import Path

import round89_live as live
from round89g_latency_probe import connect_target, telemetry
from round89x_trace_capture import parse_trace


def capture(out, seconds):
    out.mkdir(parents=True, exist_ok=False)
    port, info = connect_target()
    result = {"serial": info.serial_number, "pose_controlled": False, "rows": []}
    try:
        result["version"] = live.version(port)
        if "BID=round89x" not in result["version"] and "BID=round89y" not in result["version"]:
            raise RuntimeError("unexpected firmware")
        port.write(b"\xc4")
        result["raw_status"] = live.tail(port)
        if result["raw_status"] != "RAW=0":
            raise RuntimeError("unexpected RAW mode")
        result["before"] = telemetry(port)
        origin = time.perf_counter()
        busy = 0
        while time.perf_counter() - origin < seconds:
            began = time.perf_counter()
            port.write(b"\xc8")
            first = live.exact(port, 1, 1)
            if first == b"\x00":
                busy += 1
                time.sleep(.002)
                continue
            if first != b"\xc8":
                raise RuntimeError("bad C8 prefix; stop transaction")
            data = first + live.exact(port, 239, 1)
            parse_trace(data)
            result["rows"].append({"start_s": began - origin,
                                   "end_s": time.perf_counter() - origin, "trace_hex": data.hex()})
            time.sleep(.001)
        result["after"] = telemetry(port)
        result["busy"] = busy
        result["completed"] = True
    finally:
        port.close()
        (out / "capture.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def analyze(result):
    raw = [parse_trace(bytes.fromhex(r["trace_hex"])) for r in result["rows"]]
    frames = []
    copies = 0
    for value in raw:
        if value["report_flags"] & 128:
            copies += 1
            continue
        if not frames or frames[-1]["frame_id"] != value["frame_id"]:
            frames.append(value)
    missing = sum(max(0, ((b["frame_id"] - a["frame_id"]) & 0x7fffffff) - 1)
                  for a, b in zip(frames, frames[1:]))
    report = {"version": result["version"], "host_replies": len(raw), "unique_frames": len(frames),
              "copy_failed": copies, "unobserved_frames": missing, "chips": []}
    for m in range(3):
        values = [f["chips"][m] for f in frames]
        deltas = {name: (values[-1][name] - values[0][name]) & 0xffffffff
                  for name in ("read_calls", "io_failures", "sync_mismatches")}
        runs = []
        current = []
        for f in frames:
            q = f["chips"][m]
            if q["flags"] & 1 and not q["flags"] & 2:
                if current and ((f["frame_id"] - current[-1]["frame_id"]) & 0x7fffffff) != 1:
                    runs.append(current)
                    current = []
                current.append(f)
            elif current:
                runs.append(current)
                current = []
        if current:
            runs.append(current)
        report["chips"].append({"address": hex(0x40 + m), "deltas": deltas,
                                "observed_invalid_frames": sum(not bool(q["flags"] & 2) for q in values),
                                "observed_runs": len(runs),
                                "max_consecutive_observed_invalid": max(map(len, runs), default=0),
                                "max_observed_invalid_span_ms": max(((r[-1]["published_ms"]-r[0]["published_ms"]) & 0xffffffff
                                                                     for r in runs), default=0),
                                "accepted_sync_values": sorted(set(q["sync"] for q in values if q["flags"] & 2))})
    elapsed = (result["after"]["uptime_ms"]-result["before"]["uptime_ms"]) & 0xffffffff
    count = (result["after"]["count"]-result["before"]["count"]) & 0xffffffff
    total = (result["after"]["sum_us"]-result["before"]["sum_us"]) & 0xffffffff
    report.update(mean_scan_us=total/max(1, count), host_completed_scan_hz=count*1000/max(1, elapsed),
                  reply_median_ms=statistics.median((r["end_s"]-r["start_s"])*1000 for r in result["rows"]),
                  semantics="Uncontrolled pose; host frames and reads are not independent native scans. Missing frames bound runs.")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    parser.add_argument("--seconds", type=float, default=8)
    args = parser.parse_args()
    out = Path(args.out)
    report = analyze(capture(out, args.seconds))
    (out / "analysis.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
