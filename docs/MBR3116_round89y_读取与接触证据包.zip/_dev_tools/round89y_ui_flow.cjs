const {chromium}=require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage(), errors=[];
 page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('http://127.0.0.1:8775/');
 for(const mode of ['slow_contact','fast_contact','slide_contact']){
  await page.waitForFunction(()=>!document.querySelector('#start').disabled);
  await page.selectOption('#mode',mode);
  await page.click('#start');
  await page.waitForFunction(()=>!document.querySelector('#valid').disabled);
  if(await page.isEnabled('#start'))throw Error('unconfirmed job must block start');
  const jobs=await page.evaluate(async()=> (await(await fetch('/status')).json()).jobs);
  if(jobs.at(-1).mode!==mode||!jobs.at(-1).mock||!jobs.at(-1).raw_restored)throw Error('bad mock restoration');
  await page.click('#valid');
  await page.waitForFunction(()=>document.querySelector('#log').textContent.includes('已确认'));
  console.log('PASS',mode,'start -> restored -> confirmation');
 }
 await page.waitForFunction(()=>!document.querySelector('#finish').disabled);
 await page.click('#finish');
 await page.waitForFunction(()=>document.querySelector('#message').textContent.includes('采样结束'));
 if(errors.length)throw Error(errors.join('\n'));
 console.log('PASS finish, no page errors, MOCK ONLY');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
