"""Controlled same-32-inch beta11 -> original beta10 comparison.

User must confirm hands clear. Keep current MPR/HW2 config; never load the old
MBR config. Beta10 has no MPR C6 interface: after-flash checks use B4 only.
"""
import argparse
from datetime import datetime, timezone
import json
import shutil
import time
import zipfile

import round90o_beta12_flash as base
import round90p_restore_beta11 as recovery
import round89_live as live

ROOT = base.ROOT
BEFORE = base.BEFORE
AFTER = 'NYANFW1;1.6.6-beta10;hw_v1;BID=round90e'
TARGET_SHA = '9cc627e90abec0b45cd1695b477a5b04718baa74e76934eb6c29df191943128b'
SOURCE_SHA = '0bec68a40905b9ff6bcdbd2908285079974057edf82c28c38e8ebdcff88005b1'
ORIGINAL = ROOT / '_dev_archive/round90i_same32_before_20261004'


def post_config(directory, expected):
    directory.mkdir()
    port, result = recovery.connect_checked(AFTER)
    entered = False
    try:
        port.write(b'\xb3')
        entered = True
        result['config_entry'] = live.tail(port, .3)
        cfg, result['config_trailer'] = live.config_read(port)
        (directory / 'controller_config.bin').write_bytes(cfg)
        result['controller_config_sha256'] = base.sha(cfg)
        result['controller_config_equal'] = cfg == expected
        result['mpr_c6_not_available_not_sent'] = True
        if cfg != expected:
            raise RuntimeError('original beta10 config readback changed')
        return result
    finally:
        try:
            if entered:
                port.write(b'\xb9')
                port.flush()
                result['exit_reboot_sent'] = True
        finally:
            port.close()
            result['serial_closed'] = not port.is_open
            base.save(directory / 'snapshot.json', result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hands-clear-confirmed', action='store_true', required=True)
    args = parser.parse_args()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = ROOT / '_dev_tools' / f'round90q_beta10_{stamp}'
    backup = ROOT / '_dev_archive' / f'round90q_before_beta10_{stamp}'
    out.mkdir()
    backup.mkdir()
    path = out / 'switch.json'
    report = {'completed': False, 'out': str(out), 'backup': str(backup),
              'time_utc': datetime.now(timezone.utc).isoformat(),
              'hands_clear_confirmed': args.hands_clear_confirmed,
              'target_user_selected': 'original 32-inch beta10 / round90e',
              'from_signature': BEFORE, 'to_signature': AFTER,
              'beta11_retest_user_result': '问题一致', 'host_config_save_commands': False,
              'old_mbr_or_27inch_config_not_loaded': True, 'beta13_deployed': False}
    base.save(path, report)
    print(f'evidence={out}', flush=True)
    try:
        cfg = (ROOT / '_dev_archive/round90o_beta12_before_20261004_050603/device_before/controller_config.bin').read_bytes()
        if base.sha(cfg) != base.CONFIG_SHA:
            raise RuntimeError('accepted current MPR config reference differs')
        target = (ORIGINAL / 'round90e_original.uf2').read_bytes()
        old = (ROOT / '_dev_archive/round90o_beta12_before_20261004_050603/Nyanithm_beta11_round90g.uf2').read_bytes()
        report['target_uf2'] = base.validate_uf2(target, TARGET_SHA, AFTER, 200192)
        report['recovery_uf2'] = base.validate_uf2(old, base.BETA11_SHA, BEFORE, 200704)
        (backup / 'beta10_original.uf2').write_bytes(target)
        (backup / 'beta11_before.uf2').write_bytes(old)
        source = ORIGINAL / 'source_original_beta10_round90e.zip'
        if base.sha(source.read_bytes()) != SOURCE_SHA:
            raise RuntimeError('original beta10 source archive hash differs')
        with zipfile.ZipFile(source) as z:
            if z.testzip() is not None:
                raise RuntimeError('original source archive CRC failure')
            headers = [n for n in z.namelist() if n.endswith('include/share/nyanithm_shared.h')]
            if len(headers) != 1 or b'"1.6.6-beta10"' not in z.read(headers[0]) or b'"round90e"' not in z.read(headers[0]):
                raise RuntimeError('original source version/build identity differs')
        shutil.copyfile(source, backup / 'source_original_beta10.zip')
        report['source_archive_sha256'] = SOURCE_SHA
        report['source_archive_crc_and_macros_verified'] = True
        if base.rp2040_drives():
            raise RuntimeError('pre-existing BOOTSEL target ambiguity')
        report['before'] = base.snapshot(backup / 'device_before', BEFORE, cfg)
        report['backup_files_sha256'] = {str(p.relative_to(backup)): base.sha(p.read_bytes())
                                         for p in backup.rglob('*') if p.is_file()}
        base.save(path, report)
        base.wait_device()
        if base.rp2040_drives():
            raise RuntimeError('BOOTSEL drive appeared before targeted transition')
        port, report['pre_bootsel_identity'] = recovery.connect_checked(BEFORE)
        try:
            report['bootsel_command_attempted'] = True
            base.save(path, report)
            port.write(b'\xbb\xa5')
            port.flush()
            report['bootsel_sent'] = True
            base.save(path, report)
        finally:
            port.close()
        deadline = time.monotonic() + 20
        drives = []
        while time.monotonic() < deadline:
            drives = base.rp2040_drives()
            if drives:
                break
            time.sleep(.25)
        if len(drives) != 1:
            raise RuntimeError(f'expected exactly one new RP2040 drive: {drives}')
        report['drive'] = str(drives[0])
        frozen = backup / 'beta10_original.uf2'
        base.validate_uf2(frozen.read_bytes(), TARGET_SHA, AFTER, 200192)
        report['uf2_copy_attempted'] = True
        base.save(path, report)
        shutil.copyfile(frozen, drives[0] / 'Nyanithm.uf2')
        report['uf2_copied'] = True
        base.save(path, report)
        base.wait_device()
        report['after'] = post_config(out / 'device_after', cfg)
        base.save(path, report)
        base.wait_device()
        port, report['final_normal'] = recovery.connect_checked(AFTER)
        try:
            frames = []
            for _ in range(30):
                port.write(b'\xb1')
                frames.append(list(live.exact(port, 33)))
                time.sleep(.01)
            report['final_normal']['idle_frames'] = frames
            report['final_normal']['all_slider_zero'] = all(not any(f[:32]) for f in frames)
        finally:
            port.close()
            report['final_normal']['serial_closed'] = not port.is_open
        if not report['final_normal']['all_slider_zero']:
            raise RuntimeError('beta10 idle input not zero')
        report['completed'] = True
        report['action_retest'] = 'pending; serial sampler stopped'
        print('original beta10 running; current32 MPR config equal; RAW0 / 30 idle frames verified; serial CLOSED', flush=True)
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        base.save(path, report)


if __name__ == '__main__':
    main()
