"""Guarded recovery to accepted beta11 after the user's beta12 test-page rejection.

Run only after the user confirms hands clear and closes active device users.
Reuses validated native command and UF2 helpers; no persistent config writes.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import time

import round90o_beta12_flash as previous
import round89_live as live

ROOT = previous.ROOT
OLD = previous.AFTER  # currently deployed beta12
RESTORED = previous.BEFORE  # accepted beta11
SAVED_BACKUP = ROOT / '_dev_archive/round90o_beta12_before_20261004_050603'


def connect_checked(signature, allow_raw_session=False):
    candidates = [p for p in previous.serial.tools.list_ports.comports()
                  if p.vid == 0xCAFE and p.pid == 0x4009]
    if len(candidates) != 1 or candidates[0].serial_number != previous.SERIAL:
        raise RuntimeError('ambiguous or wrong USB target; no commands sent')
    port, info = live.connect()
    try:
        if info.serial_number != previous.SERIAL:
            raise RuntimeError('USB identity changed while connecting')
        version = live.version(port)
        if signature not in version:
            raise RuntimeError(f'wrong firmware for recovery stage: {version}')
        port.write(b'\xbc')
        probe = live.exact(port, 6)
        if probe != previous.PROBE:
            raise RuntimeError(f'wrong MPR hardware/layout: {probe.hex()}')
        port.write(b'\xc4')
        raw = live.tail(port)
        allowed = ('RAW=0', 'RAW=1', 'RAW=2') if allow_raw_session else ('RAW=0',)
        if raw not in allowed:
            raise RuntimeError(f'unexpected RAW status: {raw!r}')
        return port, {'version': version, 'port': info.device, 'usb_serial': info.serial_number,
                      'probe': probe.hex(), 'raw_status': raw}
    except BaseException:
        port.close()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hands-clear-confirmed', action='store_true', required=True)
    args = parser.parse_args()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = ROOT / '_dev_tools' / f'round90p_restore_{stamp}'
    backup = ROOT / '_dev_archive' / f'round90p_before_restore_{stamp}'
    out.mkdir()
    backup.mkdir()
    path = out / 'restore.json'
    report = {'completed': False, 'time_utc': datetime.now(timezone.utc).isoformat(),
              'hands_clear_confirmed': args.hands_clear_confirmed, 'out': str(out),
              'backup': str(backup), 'from_signature': OLD, 'to_signature': RESTORED,
              'beta12_user_rejected': True, 'reported_observation_surface': 'test-page key/pressure display',
              'hid_gameplay_regression_proven': False, 'beta13_deployed': False,
              'host_persistent_config_write_commands': False}
    previous.save(path, report)
    print(f'evidence={out}', flush=True)
    original_connect = previous.connect_checked
    try:
        manifest = json.loads((SAVED_BACKUP / 'manifest.json').read_text())
        if not all(previous.sha((SAVED_BACKUP / name).read_bytes()) == value
                   for name, value in manifest['files'].items()):
            raise RuntimeError('preserved recovery backup hash mismatch')
        expected = (SAVED_BACKUP / 'device_before/controller_config.bin').read_bytes()
        if previous.sha(expected) != previous.CONFIG_SHA:
            raise RuntimeError('preserved accepted controller configuration differs')
        files = {
            'beta11_recovery.uf2': SAVED_BACKUP / 'Nyanithm_beta11_round90g.uf2',
            'beta12_rejected.uf2': SAVED_BACKUP / 'Nyanithm_beta12_round90m.uf2',
        }
        for name, source in files.items():
            shutil.copyfile(source, backup / name)
        report['recovery_uf2'] = previous.validate_uf2((backup / 'beta11_recovery.uf2').read_bytes(),
                                                     previous.BETA11_SHA, RESTORED, 200704)
        report['rejected_uf2'] = previous.validate_uf2((backup / 'beta12_rejected.uf2').read_bytes(),
                                                     previous.BETA12_SHA, OLD, 199680)
        if previous.rp2040_drives():
            raise RuntimeError('pre-existing BOOTSEL target ambiguity')
        # Preserve an existing volatile panel RAW session in the rejection record.
        # Configuration exit reboots normally; post-recovery must be RAW0.
        previous.connect_checked = lambda signature: connect_checked(signature, allow_raw_session=signature == OLD)
        report['before'] = previous.snapshot(backup / 'device_before', OLD, expected)
        report['backup_files_sha256'] = {str(p.relative_to(backup)): previous.sha(p.read_bytes())
                                         for p in backup.rglob('*') if p.is_file()}
        previous.save(path, report)
        previous.wait_device()
        if previous.rp2040_drives():
            raise RuntimeError('BOOTSEL target ambiguity before transition')
        port, report['pre_bootsel_identity'] = connect_checked(OLD)
        try:
            report['bootsel_command_attempted'] = True
            previous.save(path, report)
            port.write(b'\xbb\xa5')
            port.flush()
            report['bootsel_sent'] = True
            previous.save(path, report)
        finally:
            port.close()
        deadline = time.monotonic() + 20
        drives = []
        while time.monotonic() < deadline:
            drives = previous.rp2040_drives()
            if drives:
                break
            time.sleep(.25)
        if len(drives) != 1:
            raise RuntimeError(f'expected one newly appeared recovery drive: {drives}')
        report['bootsel_drive'] = str(drives[0])
        uf2 = backup / 'beta11_recovery.uf2'
        previous.validate_uf2(uf2.read_bytes(), previous.BETA11_SHA, RESTORED, 200704)
        report['uf2_copy_attempted'] = True
        previous.save(path, report)
        shutil.copyfile(uf2, drives[0] / 'Nyanithm.uf2')
        report['uf2_copied'] = True
        previous.save(path, report)
        previous.wait_device()
        report['after'] = previous.snapshot(out / 'device_after', RESTORED, expected)
        report['static_and_gain_comparison'] = previous.compare_static(backup / 'device_before', out / 'device_after')
        if any(v['static_control_changes'] for v in report['static_and_gain_comparison'].values()):
            raise RuntimeError('unexpected static parameter drift after recovery')
        previous.save(path, report)
        previous.wait_device()
        port, report['final_normal'] = connect_checked(RESTORED)
        try:
            frames = []
            for _ in range(30):
                port.write(b'\xb1')
                frames.append(list(live.exact(port, 33)))
                time.sleep(.01)
            report['final_normal']['idle_frames'] = frames
            report['final_normal']['all_slider_zero'] = all(not any(f[:32]) for f in frames)
        finally:
            port.close()
            report['final_normal']['serial_closed'] = not port.is_open
        if not report['final_normal']['all_slider_zero']:
            raise RuntimeError('restored idle input is not all zero')
        report['completed'] = True
        report['gameplay_retest'] = 'pending; serial sampler stopped'
        print('accepted beta11 restored; config/static controls/RAW0/idle verified; serial CLOSED', flush=True)
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        previous.connect_checked = original_connect
        previous.save(path, report)


if __name__ == '__main__':
    main()
