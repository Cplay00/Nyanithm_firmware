"""Deploy the preserved, baseline-only beta12 to the confirmed 32-inch MPR unit.

No controller-config save or MPR register-value write commands. C6 reads two
separate native windows; only static controls are compared across reboots.
Every run has a unique evidence directory; a started flash cannot be retried
by this script. Existing source/UF2 artifacts are recovery builds, not a dump
of physical device Flash.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
import time

import serial.tools.list_ports
import round89_live as live
from round89c_flash_probe import rp2040_drives

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'Nyanithm_firmware_hw_v1'
sys.path.insert(0, str(REPO / 'tools'))
from decode_mpr121_snapshot import decode

SERIAL = '5303284739002C9C'
BEFORE = 'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g'
AFTER = 'NYANFW1;1.6.6-beta12;hw_v1;BID=round90m'
CONFIG_SHA = 'd2b2cbe5ecb3f6dc625ed1c17e0e1672ebf688a2e5d5be7db2d08209c1f05596'
BETA11_SHA = '4412c8af403cba32125cc7135628b6c193d278cbfeeac944022ccfcad35f34d1'
BETA12_SHA = 'd9e760c66dd45645a32df2133d7dffbcd8b067b0f2f9e2ac365c57ed3b369e9c'
PROBE = bytes.fromhex('bc0700050502')
STATIC_REGS = list(range(0x2B, 0x5F)) + list(range(0x73, 0x80))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def validate_uf2(data, expected_sha, signature, expected_size):
    if sha(data) != expected_sha or len(data) != expected_size or len(data) % 512:
        raise RuntimeError('UF2 hash/size mismatch')
    addresses, payloads = set(), []
    for offset in range(0, len(data), 512):
        m0, m1, flags, address, size, block, count, family = struct.unpack_from('<8I', data, offset)
        if ((m0, m1, flags, family) != (0x0A324655, 0x9E5D5157, 0x2000, 0xE48BFF56)
                or size != 256 or block != offset // 512 or count != len(data) // 512
                or address in addresses or address % 256
                or address < 0x10000000 or address + size > 0x101FF000
                or struct.unpack_from('<I', data, offset + 508)[0] != 0x0AB16F30):
            raise RuntimeError('invalid firmware-only RP2040 UF2')
        addresses.add(address)
        payloads.append(data[offset + 32:offset + 288])
    if signature.encode() not in b''.join(payloads):
        raise RuntimeError('expected build signature absent from UF2')
    return {'sha256': sha(data), 'bytes': len(data), 'blocks': len(addresses),
            'address_range': [hex(min(addresses)), hex(max(addresses) + 256)],
            'controller_config_sector_excluded': True}


def connect_checked(signature):
    candidates = [p for p in serial.tools.list_ports.comports()
                  if p.vid == 0xCAFE and p.pid == 0x4009]
    if len(candidates) != 1 or candidates[0].serial_number != SERIAL:
        raise RuntimeError('ambiguous or wrong USB device; no commands sent')
    port, info = live.connect()
    try:
        if info.serial_number != SERIAL:
            raise RuntimeError('USB identity changed during connection')
        version = live.version(port)
        if signature not in version:
            raise RuntimeError(f'firmware identity mismatch: {version}')
        port.write(b'\xbc')
        probe = live.exact(port, 6)
        if probe != PROBE:
            raise RuntimeError(f'MPR/HW2 hardware identity mismatch: {probe.hex()}')
        port.write(b'\xc4')
        raw = live.tail(port)
        if raw != 'RAW=0':
            raise RuntimeError(f'expected ordinary input mode: {raw!r}')
        return port, {'port': info.device, 'usb_serial': info.serial_number,
                      'version': version, 'probe': probe.hex(), 'raw_status': raw}
    except BaseException:
        port.close()
        raise


def wait_device():
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        matches = [p for p in serial.tools.list_ports.comports()
                   if p.vid == 0xCAFE and p.pid == 0x4009 and p.serial_number == SERIAL]
        if len(matches) == 1:
            time.sleep(1)
            return
        time.sleep(.25)
    raise RuntimeError('confirmed device did not re-enumerate')


def snapshot(directory, signature, expected):
    directory.mkdir()
    result = {'signal_windows_not_simultaneous_across_chips': True,
              'signal43_and_control85_are_separate_transactions': True}
    port, identity = connect_checked(signature)
    result.update(identity)
    entered = False
    try:
        port.write(b'\xb3')
        entered = True
        result['config_entry'] = live.tail(port, .3)
        cfg, result['config_trailer'] = live.config_read(port)
        (directory / 'controller_config.bin').write_bytes(cfg)
        result['controller_config_sha256'] = sha(cfg)
        result['controller_config_equal_reference'] = cfg == expected
        if cfg != expected:
            raise RuntimeError('live controller config drift; preserved actual bytes, no flash')
        result['chips'] = {}
        for address in (0x5A, 0x5B, 0x5C):
            live.split(port, 0xC6, [address])
            data = live.exact(port, 128)
            (directory / f'mpr_{address:02x}.bin').write_bytes(data)
            document = {'schema': 'mpr121-register-snapshot-v1', 'origin': 'hardware-readback',
                        'registers': {f'0x{i:02X}': b for i, b in enumerate(data)}}
            decoded = decode(document)
            save(directory / f'mpr_{address:02x}_decoded.json', decoded)
            result['chips'][hex(address)] = {
                'sha256': sha(data), 'touch_status': int.from_bytes(data[:2], 'little'),
                'oor_status': int.from_bytes(data[2:4], 'little'),
                'config1': data[0x5C], 'config2': data[0x5D], 'ecr': data[0x5E],
                'debounce': data[0x5B], 'touch_thresholds': list(data[0x41:0x59:2]),
                'release_thresholds': list(data[0x42:0x59:2]),
                'cdc': list(data[0x5F:0x6C]), 'cdt': list(data[0x6C:0x73]),
            }
            if (data[0x5B:0x5F] != bytes([0x11, 0x10, 0x28, 0xCC])
                    or data[0x41:0x59:2] != bytes([13] * 12)
                    or data[0x42:0x59:2] != bytes([12] * 12)):
                raise RuntimeError(f'unexpected actual MPR static parameters at {address:#x}')
        return result
    finally:
        try:
            if entered:
                port.write(b'\xb9')
                port.flush()
                result['exit_reboot_sent'] = True
        finally:
            port.close()
            result['serial_closed'] = not port.is_open
            save(directory / 'snapshot.json', result)


def compare_static(before_dir, after_dir):
    result = {}
    for address in (0x5A, 0x5B, 0x5C):
        before = (before_dir / f'mpr_{address:02x}.bin').read_bytes()
        after = (after_dir / f'mpr_{address:02x}.bin').read_bytes()
        delta = lambda regs: [{'register': f'0x{i:02X}', 'before': before[i], 'after': after[i]}
                              for i in regs if before[i] != after[i]]
        result[hex(address)] = {
            'static_control_changes': delta(STATIC_REGS),
            'startup_retunable_cdc_cdt_changes': delta(range(0x5F, 0x73)),
            'dynamic_signal_window_excluded': '0x00..0x2A',
        }
    return result


def main():
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = ROOT / '_dev_tools' / f'round90o_beta12_live_{stamp}'
    backup = ROOT / '_dev_archive' / f'round90o_beta12_before_{stamp}'
    out.mkdir()
    backup.mkdir()
    report_path = out / 'deployment.json'
    report = {'completed': False, 'time_utc': datetime.now(timezone.utc).isoformat(),
              'out': str(out), 'backup': str(backup), 'expected_usb_serial': SERIAL,
              'deploy_signature': AFTER, 'beta13_deployed': False,
              'no_controller_config_save_commands': True, 'no_chip_register_value_write_commands': True,
              'recovery_uf2_is_matching_local_build_not_physical_flash_dump': True}
    save(report_path, report)
    print(f'evidence={out}', flush=True)
    try:
        expected = (ROOT / '_dev_tools/round90i_same32_20261004/mpr_controller_config.bin').read_bytes()
        if len(expected) != 128 or expected[:2] != b'\x88\x02' or live.xor(expected) or sha(expected) != CONFIG_SHA:
            raise RuntimeError('accepted controller config reference invalid')
        old = (REPO / 'build_round90g/Nyanithm.uf2').read_bytes()
        new = (REPO / 'build_round90m/Nyanithm.uf2').read_bytes()
        report['recovery_uf2_validation'] = validate_uf2(old, BETA11_SHA, BEFORE, 200704)
        report['deploy_uf2_validation'] = validate_uf2(new, BETA12_SHA, AFTER, 199680)
        (backup / 'Nyanithm_beta11_round90g.uf2').write_bytes(old)
        (backup / 'Nyanithm_beta12_round90m.uf2').write_bytes(new)
        sources = {
            'source_beta11_round90l.zip': ROOT / '_dev_archive/round90m_before_20261004_042009/source_HEAD.zip',
            'source_beta12_round90m.zip': ROOT / '_dev_archive/round90n_before_20261004_043117/source_round90m.zip',
        }
        for name, source in sources.items():
            shutil.copyfile(source, backup / name)
            if sha(source.read_bytes()) != sha((backup / name).read_bytes()):
                raise RuntimeError('source recovery copy differs')
        report['source_backup_commits'] = {'beta11_base': 'f0fa0cb', 'beta12': '9649267'}
        save(report_path, report)
        if rp2040_drives():
            raise RuntimeError('pre-existing BOOTSEL drive; no device commands sent')
        report['before'] = snapshot(backup / 'device_before', BEFORE, expected)
        manifest = {str(p.relative_to(backup)): sha(p.read_bytes())
                    for p in sorted(backup.rglob('*')) if p.is_file()}
        save(backup / 'manifest.json', {'files': manifest, 'source_commits': report['source_backup_commits']})
        report['backup_manifest_verified'] = all(sha((backup / name).read_bytes()) == digest
                                                 for name, digest in manifest.items())
        if not report['backup_manifest_verified']:
            raise RuntimeError('backup integrity check failed')
        save(report_path, report)
        print('before identity/config/native snapshot and recovery backups verified', flush=True)
        wait_device()
        if rp2040_drives():
            raise RuntimeError('BOOTSEL drive appeared before targeted transition')
        port, identity = connect_checked(BEFORE)
        report['pre_bootsel_identity'] = identity
        try:
            report['bootsel_command_attempted'] = True
            report['software_bootsel_erases_first_flash_sector'] = True
            save(report_path, report)
            port.write(b'\xbb\xa5')
            port.flush()
            report['bootsel_sent'] = True
            save(report_path, report)
        finally:
            port.close()
        deadline = time.monotonic() + 20
        drives = []
        while time.monotonic() < deadline:
            drives = rp2040_drives()
            if drives:
                break
            time.sleep(.25)
        if len(drives) != 1:
            raise RuntimeError(f'expected exactly one new RP2040 BOOTSEL drive: {drives}')
        report['bootsel_drive'] = str(drives[0])
        frozen = backup / 'Nyanithm_beta12_round90m.uf2'
        validate_uf2(frozen.read_bytes(), BETA12_SHA, AFTER, 199680)
        report['uf2_copy_attempted'] = True
        save(report_path, report)
        shutil.copyfile(frozen, drives[0] / 'Nyanithm.uf2')
        report['uf2_copied'] = True
        save(report_path, report)
        print('preserved beta12 copied; waiting for native reboot', flush=True)
        wait_device()
        report['after'] = snapshot(out / 'device_after', AFTER, expected)
        report['native_parameter_comparison'] = compare_static(backup / 'device_before', out / 'device_after')
        if any(value['static_control_changes'] for value in report['native_parameter_comparison'].values()):
            raise RuntimeError('static MPR control register drift after deployment')
        save(report_path, report)
        wait_device()
        port, identity = connect_checked(AFTER)
        report['final_normal'] = identity
        try:
            frames = []
            for _ in range(30):
                port.write(b'\xb1')
                frames.append(list(live.exact(port, 33)))
                time.sleep(.01)
            report['final_normal']['idle_frames'] = frames
            report['final_normal']['all_slider_zero'] = all(not any(f[:32]) for f in frames)
            report['final_normal']['binary_slider_values_only'] = all(v in (0, 128) for f in frames for v in f[:32])
        finally:
            port.close()
            report['final_normal']['serial_closed'] = not port.is_open
        if not report['final_normal']['all_slider_zero'] or not report['final_normal']['serial_closed']:
            raise RuntimeError('post-reboot idle input or serial release check failed')
        report['completed'] = True
        report['gameplay_acceptance'] = 'pending; no serial sampler remains running'
        report['after_readback_precedes_final_normal_reboot'] = True
        print('beta12 identity/config/static controls/30 idle frames verified; serial CLOSED', flush=True)
    except BaseException as error:
        report['error'] = repr(error)
        print(f'FAILED; inspect persisted evidence before any retry: {error!r}', flush=True)
        raise
    finally:
        save(report_path, report)


if __name__ == '__main__':
    main()
