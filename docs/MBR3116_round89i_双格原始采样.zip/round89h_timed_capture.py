import argparse
import csv
import json
import queue
import statistics
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import round89_live as live
from round89h_raw_capture import connect_checked

MODES = {
    "finger_contact": "食指轻触同一点",
    "finger_hover5": "食指悬空5 mm",
    "finger_hover3": "食指悬空3 mm",
    "palm_hover5": "手掌悬空5 mm",
    "palm_hover3": "手掌悬空3 mm",
    "palm_contact": "手掌轻贴表面",
}
FIELDS = ["elapsed_s", "phase", "phase_valid", "sync", "cp_pf", "diff", "baseline", "raw", "delta", "error"]
OUT = Path(__file__).resolve().parent / "round89h_timed_20261001"
ORIGIN = "http://127.0.0.1:8766"
TASKS = queue.Queue()
LOCK = threading.Lock()
STATE = {"running": False, "phase": "idle", "message": "请先将整只手移开至少30 cm", "jobs": [], "end_ms": 0}


def update(**values):
    with LOCK:
        STATE.update(values)


def read_native(port, address=0x40, sensor=7):
    live.split(port, 0xC7, [address, sensor])
    head = live.exact(port, 1)
    if head != b"\xc7":
        return {"error": (head + port.readline()).decode("ascii", "replace").strip()}
    data = live.exact(port, 10)
    if data[:2] != bytes([address, sensor]):
        raise RuntimeError(f"debug identity mismatch: {data.hex()}")
    result = {"sync": data[2], "cp_pf": data[3], "diff": int.from_bytes(data[4:6], "little"),
              "baseline": int.from_bytes(data[6:8], "little"), "raw": int.from_bytes(data[8:10], "little"),
              "error": ""}
    result["delta"] = result["raw"] - result["baseline"]
    return result


def save_job(job):
    path = OUT / (job["id"] + ".json")
    temporary = path.with_suffix(".pending")
    temporary.write_text(json.dumps(job, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def capture_job(port, job, firmware, reader=None, fields=None):
    reader = reader or read_native
    fields = fields or FIELDS
    job["firmware"] = firmware
    job["phase_plan"] = [{"phase": "baseline", "start_s": 0, "end_s": 4},
                         {"phase": "hold", "start_s": 4, "end_s": 12},
                         {"phase": "release", "start_s": 12, "end_s": 22}]
    job["user_confirmed"] = None
    start = time.perf_counter()
    epoch_ms = time.time() * 1000
    rows = []
    path = OUT / (job["id"] + ".csv")
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        current = None
        while time.perf_counter() - start < 22:
            began = time.perf_counter() - start
            phase = next(p for p in job["phase_plan"] if p["start_s"] <= began < p["end_s"])
            if phase["phase"] != current:
                current = phase["phase"]
                message = {"baseline": "继续保持手远离至少30 cm", "hold": MODES[job["mode"]] + "，保持不动",
                           "release": "立即将整只手移开至少30 cm，保持远离"}[current]
                update(phase=current, message=message, end_ms=epoch_ms + phase["end_s"] * 1000)
            value = reader(port)
            ended = time.perf_counter() - start
            row = dict(elapsed_s=(began + ended) / 2, phase=phase["phase"],
                       phase_valid=int(ended <= phase["end_s"] and began >= phase["start_s"] + .25), **value)
            writer.writerow(row)
            stream.flush()
            rows.append(row)
    job["summary"] = {}
    for phase in ("baseline", "hold", "release"):
        selected = [r for r in rows if r["phase"] == phase]
        valid = [r for r in selected if not r["error"] and r["phase_valid"]]
        summary = {"rows": len(selected), "valid": len(valid), "errors": sum(bool(r["error"]) for r in selected)}
        for field in ("diff", "raw", "baseline", "delta"):
            values = [r[field] for r in valid if field in r]
            summary[field] = {"min": min(values), "median": statistics.median(values), "max": max(values)} if values else None
        job["summary"][phase] = summary
    job["completed"] = True
    save_job(job)
    with LOCK:
        STATE["jobs"].append(job)
    update(running=False, phase="done", message="采完了，请保持手远离，并确认这一组动作", end_ms=0)
    print("DONE", json.dumps({k: job[k] for k in ("id", "mode", "summary")}, ensure_ascii=False), flush=True)


def worker():
    port = None
    firmware = None
    heartbeat = 0
    while True:
        try:
            task = TASKS.get(timeout=.2)
        except queue.Empty:
            if port is not None and time.perf_counter() - heartbeat > 10:
                try:
                    port.write(b"\xc3")
                    heartbeat = time.perf_counter()
                except Exception as error:
                    port.close()
                    port = None
                    update(phase="error", message=str(error))
            continue
        try:
            if task == "finish":
                if port:
                    port.write(b"\xb9")
                    port.flush()
                    port.close()
                    port = None
                update(running=False, phase="closed", message="诊断已退出，设备恢复普通模式", end_ms=0)
                continue
            if port is None:
                update(phase="preparing", message="设备准备中，请保持手远离", end_ms=0)
                port, _ = connect_checked()
                firmware = live.version(port)
                port.write(b"\xb3")
                live.tail(port, .25)
                read_native(port)
            capture_job(port, task, firmware)
            heartbeat = time.perf_counter()
        except Exception as error:
            print("ERROR", repr(error), flush=True)
            if isinstance(task, dict):
                task["error"] = repr(error)
                task["completed"] = False
                save_job(task)
            if port is not None:
                try:
                    port.write(b"\xb9")
                    port.flush()
                except Exception:
                    pass
                port.close()
                port = None
            update(running=False, phase="error", message="采样失败，请保持手远离：" + str(error), end_ms=0)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def send(self, status, value, content_type="application/json; charset=utf-8"):
        data = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/":
            self.send(200, Path(__file__).with_suffix(".html").read_bytes(), "text/html; charset=utf-8")
        elif self.path == "/status":
            with LOCK:
                snapshot = dict(STATE)
                snapshot["jobs"] = list(STATE["jobs"])
            snapshot["now_ms"] = time.time() * 1000
            self.send(200, snapshot)
        elif self.path == "/favicon.ico":
            self.send(204, b"")
        else:
            self.send(404, {"error": "not found"})

    def do_POST(self):
        if self.headers.get("Origin") != ORIGIN:
            return self.send(403, {"error": "origin rejected"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 2048:
                raise ValueError("invalid request size")
            payload = json.loads(self.rfile.read(length))
            if self.path == "/start":
                mode = payload.get("mode")
                if mode not in MODES:
                    raise ValueError("invalid mode")
                with LOCK:
                    if STATE["running"]:
                        return self.send(409, {"error": "已有采样正在进行"})
                    STATE["running"] = True
                    STATE["phase"] = "queued"
                    STATE["message"] = "请保持手远离"
                    identifier = f"{time.time_ns()}_{mode}"
                TASKS.put({"id": identifier, "mode": mode})
                self.send(200, {"id": identifier})
            elif self.path == "/label":
                with LOCK:
                    job = next((j for j in STATE["jobs"] if j["id"] == payload.get("id")), None)
                    if job is None or not isinstance(payload.get("valid"), bool):
                        raise ValueError("invalid label")
                    job["user_confirmed"] = payload["valid"]
                    save_job(job)
                self.send(200, {"saved": True})
            elif self.path == "/finish":
                with LOCK:
                    if STATE["running"]:
                        return self.send(409, {"error": "请等当前采样结束"})
                    STATE["running"] = True
                TASKS.put("finish")
                self.send(200, {"closing": True})
            else:
                self.send(404, {"error": "not found"})
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            self.send(400, {"error": str(error)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    if not args.serve:
        parser.error("use --serve")
    OUT.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=worker, daemon=True).start()
    print("READY http://127.0.0.1:8766", flush=True)
    ThreadingHTTPServer(("127.0.0.1", 8766), Handler).serve_forever()
