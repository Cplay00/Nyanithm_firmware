import round89i_pair_capture as pair


class Port:
    def __init__(self, content):
        self.content = bytearray(content)
        self.writes = []

    def read(self, count):
        value = bytes(self.content[:count])
        del self.content[:count]
        return value

    def readline(self):
        return self.read(self.content.index(10) + 1)

    def write(self, value):
        self.writes.append(value)

    def flush(self):
        pass


def frame(address, sensor, baseline, raw, diff):
    return bytes([0xC7, address, sensor, 1, 30]) + diff.to_bytes(2, "little") + baseline.to_bytes(2, "little") + raw.to_bytes(2, "little")


center = frame(0x40, 7, 2800, 3000, 255)
ref = frame(0x42, 0, 3000, 3020, 0)
port = Port(center + ref)
result = pair.read_pair(port)
assert result["delta"] == 200 and result["ref_delta"] == 20 and result["ref_diff"] == 0
assert result["delta_ratio"] == .1 and not port.content
assert port.writes == [b"\xc7", bytes([0x40, 7]), b"\xc7", bytes([0x42, 0])]
port = Port(center + b"3116 debug fail\r\n")
assert pair.read_pair(port)["error"].startswith("reference:") and not port.content
try:
    pair.read_pair(Port(center + frame(0x41, 0, 3000, 3020, 0)))
    raise AssertionError("reference identity mismatch accepted")
except RuntimeError:
    pass
port = Port(frame(0x40, 7, 2800, 2800, 0) + ref)
assert pair.read_pair(port)["delta_ratio"] == ""
print("PASS paired debug identities, subthreshold reference, failures, zero-denominator exclusion")
