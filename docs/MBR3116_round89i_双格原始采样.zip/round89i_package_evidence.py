import csv
import hashlib
import json
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / "_dev_tools"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
DATA = TOOLS / "round89i_pair_20261001"
analysis = json.loads((DATA / "analysis.json").read_text(encoding="utf-8"))
labels = {"finger_contact": ("Finger contact", "#236aa4", "o"),
          "finger_hover3": ("Finger hover ~3 mm", "#e28732", "x"),
          "palm_hover5": ("Palm hover ~5 mm", "#bf6927", "+"),
          "palm_contact": ("Palm contact", "#21866b", "o")}
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5))
for path in sorted(DATA.glob("*.csv")):
    job = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
    if job.get("user_confirmed") is not True:
        continue
    held = [r for r in csv.DictReader(path.open(encoding="utf-8", newline=""))
            if r["phase"] == "hold" and r["phase_valid"] == "1" and not r["error"]
            and 6 <= float(r["elapsed_s"]) <= 11.5]
    name, color, marker = labels[job["mode"]]
    for axis in axes:
        axis.scatter([int(r["delta"]) for r in held], [int(r["ref_delta"]) for r in held],
                     label=name, color=color, marker=marker, s=28, alpha=.7)
axes[0].set_title("Confirmed poses: paired native counts")
axes[0].legend(fontsize=9, frameon=False)
axes[1].set_xlim(80, 260)
axes[1].set_ylim(0, 30)
axes[1].set_title("Finger samples: small reference margin")
axes[1].plot([202, 202], [13, 20], color="#555555", linewidth=1.2)
axes[1].annotate("7-count nearest separation", xy=(202, 16.5), xytext=(112, 27),
                 fontsize=9, arrowprops={"arrowstyle": "->", "color": "#555555"})
for axis in axes:
    axis.set_xlabel("Lane 17 RAW - BASELINE")
    axis.set_ylabel("Lane 18 RAW - BASELINE")
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(alpha=.15)
fig.text(.5, .015, "Same 6.0-11.5 s windows; sequential debug reads; manual heights; no decision boundary fitted", ha="center", fontsize=9)
fig.tight_layout(rect=(0, .045, 1, 1))
plot = DOCS / "MBR3116_round89i_双格RAW.png"
fig.savefig(plot, dpi=160)
plt.close(fig)
paths = [p for p in DATA.iterdir() if p.is_file() and p.suffix in (".json", ".csv")]
paths += [p for p in (TOOLS / "round89i_after_pair_20261001").iterdir() if p.is_file()]
for name in ("round89i_pair_capture.py", "round89i_analyze_pair.py", "test_round89i_pair_capture.py",
             "round89h_timed_capture.py", "round89h_timed_capture.html", "test_round89h_timed_ui.js",
             "round89h_raw_capture.py", "round89_live.py", "round89_live_debug.py", "round89g_latency_probe.py",
             "round89h_analyze_timed.py", "round89i_package_evidence.py"):
    paths.append(TOOLS / name)
manifest = {p.relative_to(TOOLS).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
archive = DOCS / "MBR3116_round89i_双格原始采样.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(paths):
        output.write(path, path.relative_to(TOOLS).as_posix())
    output.writestr("manifest_sha256.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
after = json.loads((TOOLS / "round89i_after_pair_20261001/snapshot.json").read_text(encoding="utf-8"))
report = {"date": "2026-10-01", "firmware": after["version"], "analysis": analysis,
          "user_clarification": "Only the first palm-hover group had deviation and is discarded; later palm-hover and palm-contact groups are valid",
          "height_control": "User has a ruler; heights remain manually estimated",
          "restoration": {"comparison": json.loads((TOOLS / "round89i_after_pair_20261001/comparison.json").read_text()),
                          "raw_status": after["raw_status"], "slider_far": after["initial_input"][:32],
                          "serial_closed": True, "capture_server_stopped": True, "nvm_writes": False},
          "archive": {"filename": archive.name, "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "manifest": manifest},
          "plot_sha256": hashlib.sha256(plot.read_bytes()).hexdigest(),
          "prox_experiment_specification": json.loads((DOCS / "MBR3116_round89i_Proximity实验规格.json").read_text(encoding="utf-8")),
          "validation": "PASS paired identities, error framing, subthreshold counts, zero denominator, countdown UI mock; no firmware code changes",
          "limits": ["Four confirmed poses at one location and one boot are not a validated full-board classifier",
                     "Joint RAW samples do not coincide in time; each debug window separately passed native identity/SYNC checks",
                     "No exact joint-count collisions in 163 valid frames does not prove separability under noise or new gestures",
                     "C7 diagnostic waiting cannot be inserted into gameplay scan; same-chip multi-sensor RAW access still requires native scheduling"]}
(DOCS / "MBR3116_round89i_双格证据.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACKAGED", len(paths), "files", archive.stat().st_size, "bytes; plot", plot.stat().st_size, "bytes")
