import argparse
import threading
from pathlib import Path

import round89h_timed_capture as ui

read_debug = ui.read_native


def read_pair(port):
    center = read_debug(port, 0x40, 7)
    if center["error"]:
        return {"error": "center: " + center["error"]}
    reference = read_debug(port, 0x42, 0)
    if reference["error"]:
        return {"error": "reference: " + reference["error"]}
    value = dict(center)
    value.update({"ref_" + key: val for key, val in reference.items() if key != "error"})
    value["delta_ratio"] = reference["delta"] / center["delta"] if center["delta"] > 0 else ""
    return value


ui.OUT = Path(__file__).resolve().parent / "round89i_pair_20261001"
ui.ORIGIN = "http://127.0.0.1:8768"
ui.FIELDS += ["ref_sync", "ref_cp_pf", "ref_diff", "ref_baseline", "ref_raw", "ref_delta", "delta_ratio"]
ui.read_native = read_pair


class Handler(ui.Handler):
    def do_GET(self):
        if self.path == "/":
            page = Path(__file__).with_name("round89h_timed_capture.html").read_text(encoding="utf-8")
            page = page.replace("<h1>触摸对照采样</h1>", "<h1>相邻格原始信号采样</h1>")
            self.send(200, page.encode("utf-8"), "text/html; charset=utf-8")
        else:
            super().do_GET()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    if not args.serve:
        parser.error("use --serve")
    ui.OUT.mkdir(exist_ok=True)
    threading.Thread(target=ui.worker, daemon=True).start()
    print("READY http://127.0.0.1:8768", flush=True)
    ui.ThreadingHTTPServer(("127.0.0.1", 8768), Handler).serve_forever()
