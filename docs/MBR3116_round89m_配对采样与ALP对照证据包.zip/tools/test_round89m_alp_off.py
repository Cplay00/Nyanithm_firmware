import unittest
from unittest.mock import patch

import round89m_alp_off_capture as experiment
import test_round89k_prox_capture as capture_tests

capture = experiment.capture


def bitwise_crc(data):
    value = 0xFFFF
    for byte in data[:126]:
        value ^= byte << 8
        for _ in range(8):
            value = ((value << 1) ^ (0x1021 if value & 0x8000 else 0)) & 0xFFFF
    return value


class AlpTests(unittest.TestCase):
    def test_only_documented_fields_and_crc_change(self):
        original = capture.ORIGINALS[0x42]
        desired = experiment.make_patch(original)
        alp_on = capture.probe.make_patch(original)
        self.assertEqual(desired[0x27], original[0x27] & 0x7F)
        self.assertEqual(desired[0x26], 1)
        self.assertEqual(desired[0x2E], 4)
        self.assertEqual(bitwise_crc(desired), int.from_bytes(desired[-2:], "little"))
        self.assertEqual([i for i in range(126) if desired[i] != alp_on[i]], [0x27])
        self.assertEqual([i for i in range(126) if desired[i] != original[i]], [0x26, 0x27, 0x2E])

    def test_wake_bits_and_reserved_bits_preserved(self):
        original = bytearray(capture.ORIGINALS[0x42])
        original[0x27] = 0x83
        original[-2:] = bitwise_crc(original).to_bytes(2, "little")
        self.assertEqual(experiment.make_patch(original)[0x27], 3)

    def test_unknown_baseline_rejected(self):
        original = bytearray(capture.ORIGINALS[0x42])
        original[0x27] &= 0x7F
        original[-2:] = bitwise_crc(original).to_bytes(2, "little")
        with self.assertRaisesRegex(RuntimeError, "ALP ON"):
            experiment.make_patch(original)
        original[-1] ^= 1
        with self.assertRaisesRegex(RuntimeError, "CRC"):
            experiment.make_patch(original)

    def test_reuses_restore_path_for_success_and_failures(self):
        desired = experiment.make_patch(capture.ORIGINALS[0x42])
        for failure in (None, "capture", "restore", "reboot", "precheck", "exit", "invalid_data"):
            with self.subTest(failure=failure), patch.object(capture, "DESIRED", desired):
                capture_tests.CaptureTests().exercise(failure)

    def test_configuration_separates_data_and_origin(self):
        with patch.object(capture, "DESIRED"), patch.object(capture, "REFERENCE_MODE"), \
             patch.object(capture, "PAGE_TITLE"), patch.object(capture, "DEFAULT_MODE"), \
             patch.object(capture.ui, "OUT"), patch.object(capture.ui, "ORIGIN"):
            experiment.configure()
            self.assertEqual(capture.ui.OUT, experiment.OUT)
            self.assertEqual(capture.ui.ORIGIN, "http://127.0.0.1:8770")
            self.assertIn("ALP OFF", capture.REFERENCE_MODE)
            self.assertEqual(capture.DEFAULT_MODE, "finger_contact")


if __name__ == "__main__":
    unittest.main()
