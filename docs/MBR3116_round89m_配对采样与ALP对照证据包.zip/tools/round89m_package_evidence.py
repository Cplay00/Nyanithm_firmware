import hashlib
import json
import zipfile
from pathlib import Path

import round89i_analyze_pair as paired
import round89m_alp_off_capture as experiment

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "_dev_tools/round89k_prox_20261001"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
paired.ROOT = DATA
analysis = paired.analyze()
accepted = [j for j in analysis["jobs"] if j["completed"] and j["user_confirmed"] is True]
if {j["mode"] for j in accepted} != {"finger_contact", "finger_hover3"} or len(accepted) != 2:
    raise RuntimeError("unexpected accepted sample set")
originals = experiment.capture.ORIGINALS
cfg = experiment.capture.CFG
restoration, files = {}, {}
for job in accepted:
    raw = json.loads((DATA / (job["id"] + ".json")).read_text(encoding="utf-8"))
    if not all(raw["hardware"].get(key) for key in ("candidate_applied", "restore_verified", "restore_after_reboot")):
        raise RuntimeError("unverified restoration")
    folder = DATA / (job["id"] + "_device")
    after = folder / "after_reboot"
    equal = all((after / f"chip_{a:02x}.bin").read_bytes() == table for a, table in originals.items())
    equal = equal and (after / "controller_config.bin").read_bytes() == cfg
    snapshot = json.loads((after / "snapshot.json").read_text(encoding="utf-8"))
    if not equal or snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
        raise RuntimeError("restoration data mismatch")
    restoration[job["id"]] = {"all_four_blocks_equal": equal, "raw": snapshot["raw_status"], "slider_all_zero": True}
    for suffix in (".json", ".csv"):
        path = DATA / (job["id"] + suffix)
        files["samples/" + path.name] = path
    for path in folder.rglob("*"):
        if path.is_file():
            files["samples/" + path.relative_to(DATA).as_posix()] = path

original = originals[0x42]
alp_on = experiment.capture.probe.make_patch(original)
alp_off = experiment.make_patch(original)
spec = {
    "date": "2026-10-02", "address": "0x42", "sensor": "CS0/PS0/lane18",
    "source": "TRM 001-91082 Rev E 1.5.30/31/35 and AN90071 6.3.1/6.3.2",
    "baseline_sha256": hashlib.sha256(original).hexdigest(),
    "comparison": "Same temporary 12-bit Proximity as round89k; only ALP_FILTER_EN changes from ON to OFF, with CRC update",
    "differences_from_alp_on": [{"offset": hex(i), "before": alp_on[i], "after": alp_off[i]} for i in range(128) if alp_on[i] != alp_off[i]],
    "differences_from_original": [{"offset": hex(i), "before": original[i], "after": alp_off[i]} for i in range(128) if original[i] != alp_off[i]],
    "candidate_sha256": hashlib.sha256(alp_off).hexdigest(),
    "restoration": "Restore original after every job and compare controller plus all three tables again after reboot before allowing human confirmation",
    "hardware_applied": False, "pose_samples_pending": True,
}
spec_path = DOCS / "MBR3116_round89m_ALP对照规格.json"
spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
evidence = {
    "date": "2026-10-02", "semantics": "Sequential native C7, 12-bit Proximity ALP ON reference and button center; fixed hold 6.0-11.5 s, invalid pairs excluded, no zero fill",
    "accepted_samples": accepted, "restoration": restoration,
    "center_raw_delta_observed_gap": next(j for j in accepted if j["mode"] == "finger_contact")["windows"]["hold"]["delta"]["min"] - next(j for j in accepted if j["mode"] == "finger_hover3")["windows"]["hold"]["delta"]["max"],
    "conclusion": "Both accepted poses have constant zero Proximity reference delta and diff; current experiment adds no reference discrimination. Center-only gap is limited to these two hand-estimated poses and is not a global distance threshold.",
    "limitations": ["Separate post-reset runs, manually estimated height, one finger and one position", "Sequential windows and repeated SYNC values do not establish independent simultaneous physical samples", "Earlier confirmed palm-hover saturation and finger-overlap examples prohibit global classification from this pair", "ALP filtering is a hypothesis for weak-reference suppression, not an established cause"],
    "tests": {"capture": "12/12", "alp_fields_and_reused_failures": "5/5 with 7 transaction subcases", "browser_mock": "PASS: intercepted hardware endpoints; desktop 1100x850 and mobile 390x844; countdown, restore, confirmation, discard, abort, blocking, finish and console", "independent_readonly_review": "22/22 register and transaction cases plus 3/3 page/service cases; no file writes or serial access"},
    "cpp_or_production_panel_changes": False,
}
for name in ("round89m_alp_off_capture.py", "test_round89m_alp_off.py", "round89m_package_evidence.py",
             "round89k_prox_capture.py", "round89j_prox_idle.py", "round89h_timed_capture.py", "round89h_timed_capture.html",
             "round89h_raw_capture.py", "round89g_latency_probe.py", "round89_live.py", "round89_live_debug.py",
             "round89i_analyze_pair.py", "round89h_analyze_timed.py", "test_round89k_prox_capture.py", "test_round89h_timed_ui.js"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
files["specification.json"] = spec_path
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89m_配对采样与ALP对照证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != digest for name, digest in manifest.items()):
        raise RuntimeError("archive mismatch")
evidence["archive"] = {"name": archive.name, "files": len(manifest), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "size": archive.stat().st_size}
(DOCS / "MBR3116_round89m_配对采样分析.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "accepted pairs", [j["windows"]["hold"]["valid"] for j in accepted])
print("PATCH", spec["differences_from_original"])
