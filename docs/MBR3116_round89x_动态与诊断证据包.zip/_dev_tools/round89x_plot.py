import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from round89x_analyze_trace import decode, ROOT

plt.rcParams.update({"font.sans-serif": ["Microsoft YaHei"], "axes.unicode_minus": False, "font.size": 10})
docs = ROOT/"Nyanithm_firmware_hw_v1/docs"
trace = ROOT/"_dev_tools/round89x_trace_20261002"
jobs = []
for path in sorted(trace.glob("*.json")):
    if path.name.endswith(".trace.json") or path.name == "analysis.json":
        continue
    job = json.loads(path.read_text(encoding="utf-8"))
    if job.get("completed") and job.get("user_confirmed") is True and job.get("raw_restored"):
        jobs.append(job)
if jobs:
    fig, axes = plt.subplots(len(jobs), 1, figsize=(12, 3.2*len(jobs)), constrained_layout=True)
    if len(jobs) == 1:
        axes = [axes]
    labels = {"slow_contact":"慢轻触", "fast_finger_hover":"快速食指悬空", "fast_palm_hover":"快速手掌悬空"}
    for ax, job in zip(axes, jobs):
        rows = [decode(r) for r in json.loads((trace/(job["id"]+".trace.json")).read_text(encoding="utf-8"))]
        valid = [r for r in rows if r["lane_usable"][16]]
        invalid = [r for r in rows if not r["lane_usable"][16] and not r["report_flags"] & 128]
        ax.scatter([r["elapsed_s"] for r in valid], [r["counts"][16] for r in valid], s=5, label="第17格有效差值", color="#207c88")
        ax.scatter([r["elapsed_s"] for r in invalid], [r["counts"][16] for r in invalid], s=12, marker="x", label="读取无效或超龄", color="#a5a5a5")
        ax.plot([r["elapsed_s"] for r in rows], [float('nan') if r["report_flags"] & 128 else 260 if r["slider"][16] else -15 for r in rows], lw=.8, color="#bd6b20", label="最终输出 ON=260 / OFF=-15")
        for phase in job["phase_plan"]:
            if phase["phase"] in ("action", "hold"):
                ax.axvspan(phase["start_s"], phase["end_s"], color="#e9cc86" if phase["phase"] == "action" else "#d7e5c7", alpha=.24)
        ax.set(title=labels[job["mode"]], ylim=(-25,280), ylabel="DIFF", xlabel="主机观察时间（秒）")
        ax.grid(alpha=.2); ax.legend(loc="upper right", ncol=3, fontsize=8)
    fig.suptitle("C8同帧对照：排除无效读取后检查悬空信号\n阴影是动作/保持提示，不是测得的接触时间；样本为主机观察")
    fig.savefig(docs/"MBR3116_round89x_同帧对照.png", dpi=170)
    plt.close(fig)

out = ROOT/"_dev_tools/round89x_dynamics_20261002"
report = json.loads((out/"analysis.json").read_text(encoding="utf-8"))
fig, axes = plt.subplots(2,2,figsize=(12,7), constrained_layout=True)
labels = {"slow_contact":"慢轻触", "fast_finger_hover":"快速食指悬空", "fast_contact":"快速真实点按", "fast_palm_hover":"快速手掌悬空"}
for ax, job in zip(axes.flat, report["jobs"]):
    rows = list(csv.DictReader((out/(job["id"]+".csv")).open(encoding="utf-8")))
    ax.plot([float(r["elapsed_s"]) for r in rows], [bytes.fromhex(r["pressures"])[16] for r in rows], lw=1, label="第17格 B1 差值")
    ax.plot([float(r["elapsed_s"]) for r in rows], [260 if bytes.fromhex(r["final"])[16] else -15 for r in rows], lw=.7, label="稍后C0最终输出")
    ax.set(title=labels[job["mode"]], ylim=(-25,280), ylabel="DIFF", xlabel="主机观察时间（秒）")
    ax.grid(alpha=.2); ax.legend(fontsize=8)
fig.suptitle("原round89g动态四组：B1与C0为不同事务，差值可能保留旧值\n不能当成新扫描计数、物理上升率或输入延迟")
fig.savefig(docs/"MBR3116_round89x_初始动态对照.png", dpi=170)
plt.close(fig)
