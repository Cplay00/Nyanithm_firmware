import argparse
import bisect
import csv
import json
from pathlib import Path


def vector(row, name):
    data = bytes.fromhex(row[name])
    if len(data) != (6 if name == "hardware" else 32):
        raise ValueError("wrong vector length")
    return data


def bounds(values):
    return {"min": min(values), "max": max(values)} if values else None


def summarize(rows):
    if not rows:
        return None
    vectors = [vector(r, "pressures") for r in rows]
    finals = [vector(r, "final") for r in rows]
    hardware = [vector(r, "hardware") for r in rows]
    times = [(float(r["b1_start_s"]) + float(r["b1_end_s"])) / 2 for r in rows]
    failures = [int(r["gate_failures"]) for r in rows]
    quiet_rises, all_rises = [], []
    for i, t in enumerate(times):
        j = bisect.bisect_left(times, t - .1, 0, i)
        if j >= i or not .08 <= t - times[j] <= .12:
            continue
        rise = (vectors[i][16] - vectors[j][16]) * .1 / (t - times[j])
        all_rises.append(rise)
        if failures[i] == failures[j]:
            quiet_rises.append(rise)
    return {
        "host_observations": len(rows),
        "center_diff": bounds([v[16] for v in vectors]),
        "center_hardware_on_observations": sum(bool(h[0] & 0x80) for h in hardware),
        "center_final_on_observations": sum(bool(f[16]) for f in finals),
        "any_final_on_observations": sum(any(f) for f in finals),
        "final_lanes": [i + 1 for i in range(32) if any(f[i] for f in finals)],
        "above120_lane_count": bounds([sum(x > 120 for x in v) for v in vectors]),
        "distinct_pressure_vectors": len(set(vectors)),
        "consecutive_pressure_changes": sum(a != b for a, b in zip(vectors, vectors[1:])),
        "gate_failure_increase": (failures[-1] - failures[0]) & 0xFFFFFFFF,
        "request_ms": bounds([float(r["request_ms"]) for r in rows]),
        "observed_positive_rise_per_100ms": max(0, max(all_rises)) if all_rises else None,
        "failure_quiet_positive_rise_per_100ms": max(0, max(quiet_rises)) if quiet_rises else None,
        "failure_quiet_comparisons": len(quiet_rises),
        "host_window_comparisons": len(all_rises),
    }


def analyze(root):
    jobs, excluded = [], []
    for path in sorted(root.glob("*.json")):
        job = json.loads(path.read_text(encoding="utf-8"))
        if "mode" not in job:
            continue
        if not (job.get("completed") and job.get("user_confirmed") is True
                and job.get("raw_restored") and not job.get("mock")):
            excluded.append({"id": job["id"], "mode": job["mode"],
                             "completed": job.get("completed"), "confirmed": job.get("user_confirmed"),
                             "restored": job.get("raw_restored"), "mock": job.get("mock")})
            continue
        rows = list(csv.DictReader(path.with_suffix(".csv").open(encoding="utf-8", newline="")))
        if any(r["error"] for r in rows):
            raise ValueError("completed job contains failed transport")
        phases = []
        for phase in job["phase_plan"]:
            selected = [r for r in rows if r["cue_id"] == phase["cue_id"]]
            phases.append({"phase": phase["phase"], "repeat": phase["repeat"],
                           "prompt_start_s": phase["start_s"], "prompt_end_s": phase["end_s"],
                           "summary": summarize(selected)})
        jobs.append({"id": job["id"], "mode": job["mode"], "firmware": job["firmware"],
                     "summary": summarize(rows), "phases": phases})
    return {
        "semantics": [
            "Host observations, not independent scans or physical touch counts.",
            "Approximate 100ms B1 host-window change, not physical dC/dt or input latency.",
            "Failure-quiet global counter does not prove each pressure lane is fresh.",
            "Fast-contact action includes approach, contact and lifted hover; do not label every row contact.",
            "Cue boundaries do not measure physical contact times.",
            "Only completed, explicitly confirmed, restored real-device jobs are included.",
        ],
        "jobs": jobs, "excluded": excluded,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--save", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    report = analyze(root)
    if args.save:
        (root / "analysis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                                          encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
