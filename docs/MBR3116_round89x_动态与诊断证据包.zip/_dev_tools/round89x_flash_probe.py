import round89c_flash_probe as probe
from round89g_latency_probe import connect_target

probe.live.connect = connect_target
probe.OUT = probe.WORKSPACE / "_dev_tools/round89x_flash_20261002"
probe.UF2 = probe.WORKSPACE / "Nyanithm_firmware_hw_v1/build_round89x/Nyanithm.uf2"
probe.EXPECTED_SHA256 = "8e23b5d1a568bfb15ac34cb1da0f285f06495a5612c5a93e5de1a82c3238a301"
probe.SIGNATURE = "NYANFW1;1.6.6-beta5;hw_v1;BID=round89x"
probe.BASELINE_BUILD_ID = "round89g"
probe.DEVICE_BACKUP = probe.WORKSPACE / "_dev_archive/round89x_flash_before_20261002"

if __name__ == "__main__":
    probe.main()
