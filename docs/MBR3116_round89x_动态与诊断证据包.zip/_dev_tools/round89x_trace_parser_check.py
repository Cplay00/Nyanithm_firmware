import struct
from round89x_trace_capture import parse_trace

data = bytearray(240)
data[:4] = bytes([0xc8, 1, 3, 1])
struct.pack_into("<II", data, 4, 41, 100)
struct.pack_into("<H", data, 12, 256)
struct.pack_into("<9IHBB", data, 120, 20, 0, 1, 94, 95, 94, 95, 96, 97, 0xfffe, 0x3f, 7)
v = parse_trace(data)
assert v["frame_id"] == 41 and v["counts"][0] == 256 and v["chips"][0]["usable"]
data[158] &= ~2
v = parse_trace(data)
assert not v["chips"][0]["usable"] and v["chips"][0]["good_start_ms"] == 94
data[158] |= 2
struct.pack_into("<I", data, 8, 110)
assert not parse_trace(data)["chips"][0]["usable"]
struct.pack_into("<I", data, 8, 109)
assert parse_trace(data)["chips"][0]["usable"]
data[3] = 0
assert not parse_trace(data)["chips"][0]["usable"]
data[3] = 0x81
assert not parse_trace(data)["chips"][0]["usable"]
for corrupt in (bytes(239), b"\xc8\x02"+bytes(238), b"\xc8\x01\x09"+bytes(237)):
    try:
        parse_trace(corrupt)
    except ValueError:
        pass
    else:
        raise AssertionError("corrupt trace accepted")
print("PASS C8 parsing: exact length/version, full 16-bit counts, retained time, VALID, inclusive age, source and copy failure")
from round89x_analyze_trace import decode
failed = bytearray(240)
failed[:4] = b"\xc8\x01\x00\x80"
row = decode({"trace_hex": failed.hex(), "elapsed_s": 0})
assert not any(row["lane_usable"])
print("PASS explicit C8 copy failure is excluded from all lane measurements")
