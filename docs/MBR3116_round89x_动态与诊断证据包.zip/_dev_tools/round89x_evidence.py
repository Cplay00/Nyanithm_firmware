"""Local evidence packaging; preserve rejected/aborted groups, no remote upload."""
import csv
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FW = ROOT/"Nyanithm_firmware_hw_v1"
DOCS = FW/"docs"
groups = ["round89x_dynamics_20261002", "round89x_hysteresis_20261002", "round89x_flash_20261002",
          "round89x_trace_preflight_20261002", "round89x_trace_20261002", "round89x_pipeline_tests"]
scripts = ["round89x_dynamics_capture.py", "round89x_dynamics_capture.html", "round89x_analyze_dynamics.py",
           "round89x_hysteresis_capture.py", "round89x_trace_capture.py", "round89x_analyze_trace.py",
           "round89x_trace_parser_check.py", "round89x_trace_ui_check.cjs", "round89x_flash_probe.py", "round89x_trace_findings.py",
           "round89x_plot.py", "round89x_evidence.py", "round89_live.py", "round89_live_debug.py",
           "round89u_native_filter_capture.py", "round89h_raw_capture.py", "round89h_spatial_capture.py",
           "round89g_latency_probe.py", "round89c_flash_probe.py"]
files = [ROOT/"_dev_tools"/s for s in scripts]
files.extend(ROOT/"_dev_tools"/s for s in ("round89x_dynamics_desktop.png", "round89x_dynamics_mobile.png",
                                         "round89x_trace_1280.png", "round89x_trace_390.png"))
for group in groups:
    files.extend(p for p in (ROOT/"_dev_tools"/group).rglob("*") if p.is_file())
for folder in ("round89x_dynamics_before_20261002_165335", "round89x_before_20261002", "round89x_flash_before_20261002"):
    files.extend(p for p in (ROOT/"_dev_archive"/folder).rglob("*") if p.is_file())
source_paths = ["CMakeLists.txt", "include/device/cy8cmbr3116.h", "include/device/hw_devices.h",
               "include/share/nyanithm_shared.h", "src/chuni_io.cpp", "src/cy8cmbr3116.cpp", "src/hw_devices.cpp",
               "tools/test_mbr3116_difference_counts.py", "tools/test_mbr_distance_pipeline.py", "tools/test_touch_snapshot_readers.py"]
files.extend(FW/p for p in source_paths)
files.append(FW/"build_round89x/Nyanithm.uf2")
files.extend(DOCS/s for s in ("MBR3116_round89x_动态实测与同帧诊断.md", "MBR3116_round89x_初始动态对照.png"))
files.append(DOCS/"MBR3116_round89x_同帧对照.png")
files.append(FW/"更新日志_固件.md")
files = sorted(set(files))
manifest = {str(p.relative_to(ROOT)).replace("\\", "/"): {"size": p.stat().st_size,
                    "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}

dpath = ROOT/"_dev_tools/round89x_hysteresis_20261002/1790932737589688100_d_palm_hover5.csv"
allrows = list(csv.DictReader(dpath.open(encoding="utf-8")))
window = [r for r in allrows if 6 <= float(r["elapsed_s"]) < 11.5 and not r.get("error")]
key = "pressures" if "pressures" in window[0] else "pressure32"
d_result = {"host_observations": len(window),
            "center_diff": [min(bytes.fromhex(r[key])[16] for r in window), max(bytes.fromhex(r[key])[16] for r in window)],
            "center_final_on": sum(bool(bytes.fromhex(r["final"])[16]) for r in window),
            "any_final_on": sum(any(bytes.fromhex(r["final"])) for r in window),
            "final_lanes": [i+1 for i in range(32) if any(bytes.fromhex(r["final"])[i] for r in window)]}
result = {"d_fixed_window": d_result, "firmware": "1.6.6-beta5/BID round89x",
          "trace_findings": json.loads((ROOT/"_dev_tools/round89x_trace_20261002/findings.json").read_text(encoding="utf-8")),
          "tests": {"migration": "138/138 pre and post", "production_driver": "19/19", "production_readers": "28/28",
                    "production_pipeline": "34/34, 66711 assertions", "trace_parser": "PASS", "readonly_review": "no blocking finding",
                    "ui": "1280x900 and 390x844 PASS; prior mock confirmation/abort/restore PASS"},
          "manifest": manifest}
(DOCS/"MBR3116_round89x_证据核对.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
target = DOCS/"MBR3116_round89x_动态与诊断证据包.zip"
with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for path in files:
        archive.write(path, str(path.relative_to(ROOT)))
    archive.writestr("MANIFEST_SHA256.json", json.dumps(result, ensure_ascii=False, indent=2)+"\n")
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
print(json.dumps(d_result, ensure_ascii=False))
print("PACK", target.stat().st_size, "files", len(files), "SHA256", hashlib.sha256(target.read_bytes()).hexdigest())
