import argparse
import json
import time
from pathlib import Path

import round89u_native_filter_capture as base
from round89x_dynamics_capture import read_full

ROOT = Path(__file__).resolve().parents[1]
BACKUP = ROOT / "_dev_archive/round89x_dynamics_before_20261002_165335"
OUT = ROOT / "_dev_tools/round89x_hysteresis_20261002"
base.OUT = OUT
base.BACKUP = BACKUP
base.ORIGINALS = {a: (BACKUP / f"chip_{a:02x}.bin").read_bytes() for a in (0x40, 0x41, 0x42)}
base.capture.ORIGINALS = base.ORIGINALS
base.capture.CFG = (BACKUP / "controller_config.bin").read_bytes()
base.ui.OUT = OUT
base.ui.ORIGIN = "http://127.0.0.1:8773"
base.ui.MODES = {"d_palm_hover5": "手掌悬空约5 mm（始终不接触）"}
base.ui.FIELDS = [
    "elapsed_s", "phase", "phase_valid", "diff", "pressures", "hardware", "verified",
    "final", "air", "gate_failures", "uptime_ms", "telemetry_hex", "request_ms",
    "b1_start_s", "b1_end_s", "c0_start_s", "c0_end_s", "c1_start_s", "c1_end_s", "error",
]


def read_all(port):
    if base.capture.STOP.is_set():
        raise RuntimeError("capture cancelled")
    started = time.perf_counter()
    value = read_full(port, started)
    value["diff"] = bytes.fromhex(value["pressures"])[16]
    time.sleep(max(0, .02 - (time.perf_counter() - started)))
    return value


base.read_center = read_all
base.PAGE = base.PAGE.replace(
    '<select id="setting">' + "".join(f'<option value="{k}">{v[0]}</option>' for k, v in base.SETTINGS.items()) + "</select>",
    '<select id="setting"><option value="d">D · 手动阈值，迟滞31</option></select>',
)
base.PAGE = base.PAGE.replace(
    '<select id="gesture">' + "".join(f'<option value="{k}">{v}</option>' for k, v in base.GESTURES.items()) + "</select>",
    '<select id="gesture"><option value="palm_hover5">手掌悬空约5 mm，全程不触板</option></select>',
)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    candidate = base.patch(base.ORIGINALS[0x40], "d")
    manifest = {
        "source_backup": str(BACKUP),
        "candidate_hex": candidate.hex(),
        "changed_offsets": [i for i in range(128) if candidate[i] != base.ORIGINALS[0x40][i]],
        "documented_fields": "0x4F ATH off; 0x1D HYS31 override; official CRC",
        "scope": "temporary 0x40 only; original restored and all three chips/config compared after reboot",
        "capture": "full B1 DIFF32; C0/C1 sequential, transaction offsets are relative to this row",
    }
    (OUT / "candidate.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.serve:
        base.capture.serve(8773)
    else:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
