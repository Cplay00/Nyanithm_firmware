import json
from pathlib import Path
from round89x_analyze_trace import decode, ROOT

out = ROOT/"_dev_tools/round89x_trace_20261002"
analysis = json.loads((out/"analysis.json").read_text(encoding="utf-8"))
result = {"semantics": "Confirmed host observations; not physical scans or touch counts.", "slow_hold": []}
contact_examples = []
hover_examples = []
for job in analysis["jobs"]:
    rows = [decode(r) for r in json.loads((out/(job["id"]+".trace.json")).read_text(encoding="utf-8"))]
    if job["mode"] == "slow_contact":
        for repeat in (1,2):
            hold = [r for r in rows if r["phase"] == "hold" and r["repeat"] == repeat and not r["report_flags"] & 128]
            offs = [r for r in hold if not r["slider"][16]]
            result["slow_hold"].append({"repeat": repeat, "reported_frames": len(hold), "final_off": len(offs),
                "off_with_failed_latest_read": sum(not r["chips"][0]["flags"] & 2 for r in offs),
                "off_with_native_on_and_retained_count255": sum(bool(r["counts"][16] == 255 and r["hardware"][0] & 128) for r in offs)})
        plan = json.loads((out/(job["id"]+".json")).read_text(encoding="utf-8"))["phase_plan"]
        contact_examples.extend(r for r in rows if all(r["lane_usable"]) and r["phase"] == "hold"
             and r["slider"][16] and r["hardware"][0] & 128
             and any(p["phase"] == "hold" and p["start_s"]+.5 <= r["elapsed_s"] <= p["end_s"]-.5 for p in plan))
    elif job["mode"] == "fast_finger_hover":
        hover_examples.extend(r for r in rows if all(r["lane_usable"]) and r["phase"] == "action"
                              and r["slider"][16] and r["hardware"][0] & 128)
common = next(((a,b) for a in contact_examples for b in hover_examples if a["counts"] == b["counts"]), None)
assert common is not None, "expected qualified full-vector contact/hover counterexample"
assert all(x["off_with_native_on_and_retained_count255"] <= x["final_off"] for x in result["slow_hold"])
result["stable_hold_hover_same_vector"] = [{"frame_id": r["frame_id"], "elapsed_s": r["elapsed_s"],
    "counts": r["counts"], "hardware": r["hardware"].hex(), "verified": r["verified"].hex(),
    "slider": r["slider"].hex(), "chip_good_ages_ms": [c["good_age_ms"] for c in r["chips"]]} for r in common]
(out/"findings.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps(result, indent=2))
