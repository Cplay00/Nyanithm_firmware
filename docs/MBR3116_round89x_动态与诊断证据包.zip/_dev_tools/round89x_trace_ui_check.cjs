const { chromium } = require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
const browser=await chromium.launch({channel:'msedge',headless:true});
for(const size of [{width:1280,height:900},{width:390,height:844}]){
 const page=await browser.newPage({viewport:size}), errors=[];
 page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('http://127.0.0.1:8774/?v=trace89x');
 await page.waitForFunction(()=>document.getElementById('message').textContent.includes('手远离'));
 const info=await page.evaluate(()=>({title:document.title,options:[...document.getElementById('mode').options].map(o=>o.value),start:!document.getElementById('start').disabled,fits:document.documentElement.scrollWidth<=innerWidth}));
 if(info.title!=='同帧信号对照'||info.options.length!==3||!info.start||!info.fits||errors.length)throw Error(JSON.stringify({info,errors}));
 await page.screenshot({path:`D:/Opencode,OCCM/Items/Nyanithm_Firmware/_dev_tools/round89x_trace_${size.width}.png`,fullPage:true});
 console.log('PASS',size.width,info);
 await page.close();
}
await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
