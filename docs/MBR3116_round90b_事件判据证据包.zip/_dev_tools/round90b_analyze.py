"""Audit frozen evidence and compare causal features. No device access or fitting."""
import argparse
import hashlib
import json
import re
import statistics
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'Nyanithm_firmware_hw_v1/src/hw_devices.cpp').read_text(encoding='utf-8')

def mapping(name):
    body = re.search(r'static const uint8_t ' + name + r'\[32\] = \{(.*?)\};', SOURCE, re.S)
    values = [int(x) for x in re.findall(r'\d+', body[1])]
    assert len(values) == 32
    return values

LM, LE = mapping('V1_LANE_M'), mapping('V1_LANE_E')
MASK = 0xffffffff

def age(now, then): return (now - then) & MASK

def qualified(t, lane, button=True):
    chip = t['chips'][LM[lane]]
    required = 0x0e | (0x10 if button else 0)
    return bool(t['report_flags'] == 1 and t['chip_count'] == 3 and
                (chip['flags'] & required) == required and
                (chip['range_mask'] & (1 << LE[lane])) and t['counts'][lane] <= 255 and
                age(t['published_ms'], chip['good_start_ms']) <= 15 and
                age(t['published_ms'], chip['attempt_start_ms']) <= 15 and
                (not button or age(t['published_ms'], chip['button_start_ms']) <= 15))

def snapshot(t): return [t['counts'], t['hardware'], t['verified'], t['slider']]

def analyze_job(path):
    job = json.loads(path.read_text(encoding='utf-8'))
    assert job['completed'] and job['user_confirmed'] and job['raw_restored'] and not job['mock'], path
    assert job['usb_serial'] == '5303284739002C9C' and 'BID=round90b' in job['firmware']
    result = []
    for capture in job['captures']:
        rows, frozen = capture['rows'], capture['frozen']
        assert frozen['state'] == 3 and frozen['pending'] == 0 and frozen['reason'] == 1
        assert len(rows) == frozen['queued'] == 96
        assert frozen['stored'] - frozen['overwritten'] == 96
        frames = [r['trace'] for r in rows]
        for i, (row, t) in enumerate(zip(rows, frames)):
            data = bytes.fromhex(row['hex'])
            assert len(data) == 248 and data[:4] == b'\xcb\x01\x00\x00'
            assert struct.unpack_from('<I', data, 4)[0] == frozen['session']
            assert data[8:10] == b'\xc8\x01'
            assert struct.unpack_from('<II', data, 12) == (t['frame_id'], t['published_ms'])
            assert list(struct.unpack_from('<32H', data, 20)) == t['counts']
            assert list(data[84:116]) == t['slider']
            assert list(struct.unpack_from('<3H', data, 116)) == t['hardware']
            assert list(struct.unpack_from('<3H', data, 122)) == t['verified']
            for m in range(3):
                names = ('read_calls io_failures sync_mismatches attempt_start_ms attempt_end_ms good_start_ms good_end_ms button_start_ms button_end_ms range_mask flags sync').split()
                assert list(struct.unpack_from('<9IHBB', data, 128+40*m)) == [t['chips'][m][n] for n in names]
            if i: assert ((t['frame_id']-frames[i-1]['frame_id']) & 0x7fffffff) == 1
        trigger = next(i for i,t in enumerate(frames) if t['frame_id'] == frozen['trigger_frame'])
        assert frames[trigger]['published_ms'] == frozen['trigger_ms']
        pre = age(frozen['trigger_ms'], frames[0]['published_ms'])
        post = age(frames[-1]['published_ms'], frozen['trigger_ms'])
        assert pre >= 180 and post >= 160
        onsets = [i for i in range(1,len(frames)) if not frames[i-1]['slider'][16] and frames[i]['slider'][16]]
        onset = onsets[0] if onsets else None
        entry = {'file': path.name, 'mode': job['mode'], 'repeat': capture['repeat'], 'session': frozen['session'],
                 'frames': len(frames), 'pre_ms': pre, 'post_ms': post, 'span_ms': pre+post,
                 'all_lanes_qualified': sum(all(qualified(t,l) for l in range(32)) for t in frames),
                 'target_qualified': sum(qualified(t,16) for t in frames),
                 'target_on_frames': sum(bool(t['slider'][16]) for t in frames),
                 'target_peak': max(t['counts'][16] for t in frames),
                 'target_onset_index': onset, 'feature_reason': None, 'features': {}}
        if onset is None:
            entry['feature_reason'] = 'no target OFF-to-ON in recorded window'
        elif not qualified(frames[onset-1],16) or not qualified(frames[onset],16):
            entry['feature_reason'] = 'target onset adjacent to unqualified read; no causal slope fit'
        else:
            now = frames[onset]
            entry['onset_ms'] = now['published_ms']
            entry['onset_counts'] = now['counts']
            entry['onset_snapshot'] = snapshot(now)
            past = [t for t in frames[:onset+1] if age(now['published_ms'],t['published_ms']) <= 100 and qualified(t,16)]
            f = entry['features']
            f['count_at_onset'] = now['counts'][16]
            for interval in (15,30,60):
                older = [t for t in past if interval <= age(now['published_ms'],t['published_ms']) <= interval+10]
                if older:
                    old = older[-1]
                    f[f'delta_{interval}ms'] = now['counts'][16] - old['counts'][16]
                    actual = age(now['published_ms'],old['published_ms'])
                    f[f'delta_{interval}ms_actual_dt'] = actual
                    f[f'delta_{interval}ms_per_ms'] = f[f'delta_{interval}ms'] / actual
            unique = []
            for t in past:
                c = t['chips'][LM[16]]
                identity = tuple(c[k] for k in ('read_calls','good_start_ms','good_end_ms','sync'))
                if not unique or unique[-1][0] != identity: unique.append((identity,t))
            slopes = []
            for (_,a),(_,b) in zip(unique,unique[1:]):
                ca, cb = a['chips'][LM[16]], b['chips'][LM[16]]
                dt = age(cb['good_start_ms'],ca['good_start_ms'])
                if 0 < dt <= 20: slopes.append((b['counts'][16]-a['counts'][16])/dt)
            if slopes: f['max_step_count_per_ms'] = max(slopes)
            f['unique_qualified_reads_in_past100ms'] = len(unique)
            if all(qualified(now,l) for l in range(32)):
                f['curvature_same_row'] = 2*now['counts'][16]-now['counts'][14]-now['counts'][18]
                f['lanes_above128'] = sum(c >= 128 for c in now['counts'])
                f['lanes_saturated255'] = sum(c == 255 for c in now['counts'])
            if onset >= 2 and all(all(qualified(t,l) for l in range(32)) for t in frames[onset-2:onset+1]):
                entry['three_frame_values'] = [snapshot(t) for t in frames[onset-2:onset+1]]
                entry['three_frame_relative_ms'] = [-age(now['published_ms'],t['published_ms']) for t in frames[onset-2:onset+1]]
        result.append(entry)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--events', type=Path, required=True)
    parser.add_argument('--sanity', type=Path, required=True)
    args = parser.parse_args()
    paths = lambda folder: [p for p in sorted(folder.glob('*.json')) if 'captures' in json.loads(p.read_text(encoding='utf-8')) and 'mode' in json.loads(p.read_text(encoding='utf-8'))]
    trials = [t for p in paths(args.events) for t in analyze_job(p)]
    holdout = [t for p in paths(args.sanity) for t in analyze_job(p)]
    contacts = [t for t in trials if 'hover' not in t['mode']]
    hovers = [t for t in trials if 'hover' in t['mode']]
    comparison = {}
    for name in sorted(set(k for t in trials for k in t['features'])):
        a, b = [t['features'][name] for t in contacts if name in t['features']], [t['features'][name] for t in hovers if name in t['features']]
        if a and b:
            comparison[name] = {'contact_range':[min(a),max(a)], 'hover_range':[min(b),max(b)],
                                'intervals_overlap':max(min(a),min(b)) <= min(max(a),max(b)),
                                'contact_n':len(a),'hover_n':len(b)}
    matches = []
    for a in contacts:
        for b in hovers:
            if a.get('onset_snapshot') is not None and a.get('onset_snapshot') == b.get('onset_snapshot'):
                matches.append({'contact':a['session'],'hover':b['session'],'kind':'same instantaneous signal/native/verified/final'})
            if a.get('three_frame_values') is not None and a.get('three_frame_values') == b.get('three_frame_values'):
                matches.append({'contact':a['session'],'hover':b['session'],'kind':'same three-frame values; compare time intervals separately',
                                'contact_ms':a['three_frame_relative_ms'],'hover_ms':b['three_frame_relative_ms']})
    report = {'semantics':'Only past/current observations at target first final ON. Gesture labels do not mark exact physical contact. Step slopes describe host read times, not native sensing or mechanical impact. No classifier fitted; small-sample gaps are hypotheses.',
              'trials':trials,'holdout':holdout,'feature_ranges':comparison,'matches':matches,
              'source_sha256':hashlib.sha256(SOURCE.encode()).hexdigest()}
    (args.events / 'analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'trials':len(trials),'holdout':len(holdout),'qualified_feature_trials':sum(bool(t['features']) for t in trials),'feature_ranges':comparison,'matches':matches},ensure_ascii=False,indent=2))

if __name__ == '__main__': main()
