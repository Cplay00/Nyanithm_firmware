"""Session checked, frozen Core0 event history. No configuration writes."""
import json
import struct
import time

import round89_live as live
from round89g_latency_probe import connect_target
from round89x_trace_capture import parse_trace

SIGNATURE = 'NYANFW1;1.6.6-beta8;hw_v1;BID=round90b'
NAMES = ('tag version state pending session trigger_frame trigger_ms started_ms ended_ms '
         'stored overwritten hook_count hook_sum_us hook_max_us capacity queued pre_ms post_ms '
         'reason reserved0 reserved1 reserved2').split()

def checked():
    port, info = connect_target()
    try:
        if SIGNATURE not in live.version(port):
            raise RuntimeError('requires round90b')
        port.write(b'\xc4')
        if live.tail(port) != 'RAW=0':
            raise RuntimeError('requires normal binary output')
        return port, info
    except Exception:
        port.close()
        raise

def receive(port, tag, size):
    try:
        first = live.exact(port, 1, 1)
    except Exception:
        port._history_protocol_broken = True
        raise
    if first == b'\x00':
        raise RuntimeError('BUSY; no partial reply')
    if first != bytes([tag]):
        port._history_protocol_broken = True
        raise RuntimeError('unexpected reply; do not send another command')
    try:
        return first + live.exact(port, size - 1, 1)
    except Exception:
        port._history_protocol_broken = True
        raise

def status(port):
    port.write(b'\xcc')
    data = receive(port, 0xcc, 56)
    value = dict(zip(NAMES, struct.unpack('<4B10I4H4B', data)))
    if value['version'] != 1 or value['capacity'] != 96 or value['state'] > 5:
        raise RuntimeError('invalid history status')
    return value

def request(port, cmd):
    port.write(bytes([cmd]))
    reply = receive(port, cmd, 2)
    if reply[1] != 1:
        raise RuntimeError('history control pending')

def arm(port):
    old = status(port)['session']
    request(port, 0xc9)
    deadline = time.monotonic() + 1
    while time.monotonic() < deadline:
        value = status(port)
        if not value['pending'] and value['session'] != old:
            if value['state'] != 1:
                raise RuntimeError('history did not arm: ' + json.dumps(value))
            return value
        time.sleep(.005)
    raise RuntimeError('Core0 arm acknowledgement timeout')

def freeze(port):
    if status(port)['state'] != 3:
        request(port, 0xca)
    deadline = time.monotonic() + 1
    while time.monotonic() < deadline:
        value = status(port)
        if not value['pending'] and value['state'] == 3:
            return value
        time.sleep(.005)
    raise RuntimeError('Core0 freeze acknowledgement timeout')

def drain(port, frozen):
    if frozen['state'] != 3 or frozen['pending']:
        raise RuntimeError('not frozen')
    rows = []
    for _ in range(frozen['queued']):
        port.write(b'\xcb')
        data = receive(port, 0xcb, 248)
        if data[1:4] != b'\x01\x00\x00' or struct.unpack_from('<I', data, 4)[0] != frozen['session']:
            raise RuntimeError('history session changed')
        trace = parse_trace(data[8:])
        trace['slider'] = list(trace['slider'])
        trace['hardware'] = list(struct.unpack('<3H', trace['hardware']))
        trace['verified'] = list(struct.unpack('<3H', trace['verified']))
        rows.append({'hex': data.hex(), 'trace': trace})
    final = status(port)
    if final['session'] != frozen['session'] or final['queued']:
        raise RuntimeError('history drain incomplete')
    for a, b in zip(rows, rows[1:]):
        if (b['trace']['frame_id'] - a['trace']['frame_id']) & 0x7fffffff != 1:
            raise RuntimeError('missing completed Core0 frame')
    return rows
