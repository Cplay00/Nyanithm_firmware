const {chromium}=require('C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true}), results=[];
 for(const size of [{width:1280,height:900},{width:390,height:844}]){
  const page=await browser.newPage({viewport:size}), errors=[];
  page.on('pageerror',e=>errors.push(String(e)));
  page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
  await page.goto('http://127.0.0.1:8775/?v=history90b_stress');
  await page.waitForFunction(()=>!document.getElementById('start').disabled);
  const info=await page.evaluate(()=>({title:document.title,options:[...document.getElementById('mode').options].map(x=>x.value),text:document.body.innerText,fits:document.documentElement.scrollWidth<=innerWidth}));
  if(info.title!=='触发判据复核'||info.options.join()!=='very_slow_contact,near_finger_hover'||!info.text.includes('每组两次')||!info.fits)throw Error(JSON.stringify(info));
  for(const mode of info.options){
   await page.selectOption('#mode',mode);
   await page.locator('#start').click();
   await page.waitForFunction(()=>!document.getElementById('valid').disabled);
   const button=await page.locator('#valid').innerText();
   if(!button.includes(mode.includes('hover')?'全程未触板':'确实触板'))throw Error('wrong confirmation');
   await page.locator('#valid').click();
   await page.waitForFunction(()=>!document.getElementById('start').disabled);
  }
  const state=await page.evaluate(async()=>await (await fetch('/status')).json());
  const last=state.jobs.slice(-2);
  if(last.some(j=>j.captures.length!==2||!j.completed||!j.user_confirmed||!j.raw_restored||!j.hypothesis_sha256))throw Error('wrong repeats or frozen hypothesis');
  await page.locator('#start').click();
  await page.waitForFunction(()=>!document.getElementById('abort').disabled);
  await page.locator('#abort').click();
  await page.waitForFunction(()=>!document.getElementById('start').disabled);
  if(!(await page.locator('#message').innerText()).includes('用户中止'))throw Error('abort not shown');
  await page.screenshot({path:`D:/Opencode,OCCM/Items/Nyanithm_Firmware/_dev_tools/round90b_stress_${size.width}.png`,fullPage:true});
  if(errors.length)throw Error(JSON.stringify(errors));
  results.push({size,title:info.title,options:info.options,fits:info.fits,errors,confirmed_modes:last.map(j=>j.mode)}); await page.close();
 }
 fs.writeFileSync('D:/Opencode,OCCM/Items/Nyanithm_Firmware/_dev_tools/round90b_stress_ui.json',JSON.stringify(results,null,2));
 await browser.close(); console.log('PASS stress page desktop/mobile, two modes/two repeats, correct confirmation, start/confirm/abort, no console errors');
})().catch(e=>{console.error(e);process.exit(1)});
