import ast
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'Nyanithm_firmware_hw_v1'
output = REPO / 'docs/MBR3116_round90b_事件判据证据包.zip'
assert not output.exists(), 'Do not overwrite an evidence package'
selected = set()
def add(path):
    assert path.is_file(), path
    selected.add(path)
for directory in ('round90b_events_20261002','round90b_sanity_20261002','round90b_stress_20261002',
                  'round90b_final_snapshot_20261002','round90b_final_snapshot_20261002_retry'):
    for path in (ROOT / '_dev_tools' / directory).iterdir():
        if path.is_file(): add(path)
for name in ('round90b_candidate_20261002.json','round90b_event_summary.json','round90b_analyze.py',
             'round90b_freeze_candidate.py','round90b_candidate_check.py','round90b_finish.py',
             'round90b_restore_check.py','round90b_pack.py','round90b_sampler_contract.py',
             'round90b_stress_ui.cjs','round90b_stress_ui.json','round90b_stress_390.png','round90b_stress_1280.png',
             'round90b_final_snapshot_console.txt','round90b_final_snapshot_retry_console.txt',
             'round90b_build.txt','round90b_history_tests.txt','round90b_migration_before.txt',
             'round90b_migration_after.txt','round90b_readers.txt','round90b_driver.txt','round90b_pipeline.txt'):
    add(ROOT / '_dev_tools' / name)
pending = ['round90a_capture','round90a_history']
visited = set()
while pending:
    module = pending.pop()
    if module in visited: continue
    visited.add(module)
    path = ROOT / '_dev_tools' / (module+'.py')
    add(path)
    if path.with_suffix('.html').is_file(): add(path.with_suffix('.html'))
    for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
        names = [x.name for x in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) else []
        pending.extend(name for name in names if name and name.startswith('round') and (ROOT/'_dev_tools'/f'{name}.py').is_file())
for name in ('src/hw_devices.cpp','src/mbr_history.cpp','src/chuni_io.cpp','src/usb_device.cpp',
             'include/software/mbr_history.h','include/share/nyanithm_shared.h',
             'tools/test_mbr_history.py','tools/test_round50_migration.py','build_round90b/Nyanithm.uf2'):
    add(REPO / name)
for name in ('controller_config.bin','chip_40.bin','chip_41.bin','chip_42.bin','snapshot.json'):
    add(ROOT / '_dev_archive/round90b_flash_before_20261002' / name)
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha((REPO/'build_round90b/Nyanithm.uf2').read_bytes())=='2c59f8be0289a2bacbca40a7fadc59d83e32d48f76a278c9e7a0667dd2335d18'
manifest = {'firmware_commit':'2c6afb06b153a8d8d74f073cfeace85d02ecb1be', 'schema':1,
            'scope':'14 confirmed trials;2 aborted jobs retained/excluded;frozen temporal candidate failed;no deployed gate.',
            'files':[{'path':p.relative_to(ROOT).as_posix(),'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(selected)]}
with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for file in manifest['files']: archive.write(ROOT/file['path'],file['path'])
    archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    archive.writestr('REPLAY.txt','Extract preserving paths. Python3 with standard library is enough for offline audits:\npy -3 _dev_tools/round90b_finish.py\npy -3 _dev_tools/round90b_candidate_check.py --plan _dev_tools/round90b_candidate_20261002.json --events _dev_tools/round90b_stress_20261002 --out replay_stress.json --stress\nDevice capture needs pyserial and the strict matching firmware/USB device. Do not flash or run sampling to replay.\n')
with zipfile.ZipFile(output) as archive:
    for file in manifest['files']:
        data = archive.read(file['path'])
        assert len(data)==file['size'] and sha(data)==file['sha256'], file['path']
result = {'path':str(output.relative_to(ROOT)), 'files':len(manifest['files']),
          'size':output.stat().st_size, 'sha256':sha(output.read_bytes()), 'all_entry_hashes_verified':True}
(REPO/'docs/MBR3116_round90b_事件判据证据包.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
