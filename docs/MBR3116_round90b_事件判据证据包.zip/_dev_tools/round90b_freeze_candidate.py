import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90b_candidate_20261002.json'
assert not OUT.exists(), 'Frozen hypothesis must not be overwritten'
training = ROOT / '_dev_tools/round90b_events_20261002'
report = json.loads((training / 'analysis.json').read_text(encoding='utf-8'))
assert len(report['trials']) == 9 and all(t['feature_reason'] is None for t in report['trials'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = sorted({t['file'] for t in report['trials']})
plan = {
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'firmware_commit': subprocess.check_output(['git', '-C', str(ROOT / 'Nyanithm_firmware_hw_v1'), 'rev-parse', 'HEAD'], text=True).strip(),
    'analysis_sha256': sha(ROOT / '_dev_tools/round90b_analyze.py'),
    'training': {name: sha(training / name) for name in files},
    'feature': 'delta_15ms_per_ms',
    'threshold_numerator': 3,
    'threshold_denominator': 2,
    'definition': 'At lane17 first final OFF-to-ON, current minus newest qualified past value aged 15..25 published-ms, divided by actual published interval. Requires qualified onset, previous frame and past endpoint. No future frame.',
    'quality': 'PROFILE,3 chips,VALID,HASGOOD,COHERENT,BUTTON,positive range bit,count<=255,good/attempt/button start age<=15ms. Missing evidence is inconclusive and cannot justify rejection.',
    'meaning': 'Offline onset predicate only. Contact gestures should pass without changing their current ON time; hover should fail. No implemented HID gate, no exact surface contact timestamp, no full hold/release model.',
    'selection': '1.5 count/ms chosen once in training gap (hover maximum1.1333/contact minimum2.125); no subsequent threshold fitting. Preflight fast tap is a separate holdout.',
    'stress_modes': {
        'very_slow_contact': {'expected_pass': True, 'repeats': 2, 'instruction': 'About4s descent,1s actual gentle surface contact,then lift'},
        'near_finger_hover': {'expected_pass': False, 'repeats': 2, 'instruction': 'Fast descent to estimated1..2mm,then lift; never touch'},
    },
    'stop_rule': 'Any qualified contact onset below1.5 or hover onset>=1.5 falsifies this zero-delay onset predicate. Do not tune threshold using stress set. Passing four stress gestures alone does not prove safe for chords/slides or arbitrary approach speeds.',
}
OUT.write_text(json.dumps(plan, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'frozen': str(OUT), 'sha256': sha(OUT), 'threshold': '3/2 count/ms', 'training_trials': 9}, ensure_ascii=False))
