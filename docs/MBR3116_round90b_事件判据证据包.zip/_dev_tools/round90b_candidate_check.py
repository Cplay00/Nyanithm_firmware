import argparse
import hashlib
import json
from pathlib import Path
import round90b_analyze as audit

def jobs(folder):
    for path in sorted(folder.glob('*.json')):
        obj = json.loads(path.read_text(encoding='utf-8'))
        if 'captures' in obj and 'mode' in obj:
            yield path

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--plan', required=True, type=Path)
    p.add_argument('--events', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--stress', action='store_true')
    args = p.parse_args()
    plan = json.loads(args.plan.read_text(encoding='utf-8'))
    sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    assert sha(Path(audit.__file__)) == plan['analysis_sha256'], 'Frozen method changed'
    result, excluded = [], []
    for path in jobs(args.events):
        job = json.loads(path.read_text(encoding='utf-8'))
        if not job['completed'] or job['user_confirmed'] is not True:
            excluded.append({'file': path.name, 'completed':job['completed'], 'user_confirmed':job['user_confirmed'], 'error':job.get('error'), 'captures':len(job['captures'])})
            continue
        if args.stress:
            assert job['hypothesis_sha256'] == sha(args.plan)
            assert job['mode'] in plan['stress_modes']
        for trial in audit.analyze_job(path):
            f = trial['features']
            actual = f.get('delta_15ms_actual_dt')
            delta = f.get('delta_15ms')
            passes = None if actual is None else delta*plan['threshold_denominator'] >= actual*plan['threshold_numerator']
            expected = plan['stress_modes'][job['mode']]['expected_pass'] if args.stress else 'hover' not in job['mode']
            result.append(dict(trial, candidate_pass=passes, expected_pass=expected,
                               matches_expected=None if passes is None else passes==expected))
    report = {
        'plan_sha256': sha(args.plan), 'offline_only': True,
        'interpretation': 'Evaluates original first final ON, not exact physical touch. No quality/window failure is counted as successful suppression.',
        'trials': result,
        'excluded_jobs': excluded,
        'qualified': sum(t['candidate_pass'] is not None for t in result),
        'inconclusive': sum(t['candidate_pass'] is None for t in result),
        'counterexamples': [{'file':t['file'], 'repeat':t['repeat'], 'mode':t['mode'], 'feature':t['features'].get('delta_15ms_per_ms')} for t in result if t['matches_expected'] is False],
    }
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='trials'}, ensure_ascii=False, indent=2))

if __name__=='__main__': main()
