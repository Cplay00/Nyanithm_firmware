import json
import argparse
import time
from pathlib import Path
import round90a_history as history

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--out', default='_dev_tools/round90b_final_snapshot_20261002')
args = parser.parse_args()
out = ROOT / args.out
assert not out.exists(), 'Do not overwrite a previous device snapshot'
out.mkdir()
port, info = history.checked()
try:
    before = history.freeze(port)
    assert before['state'] in (0,3) and before['pending']==0
    (out/'history_before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
finally:
    port.close()
history.live.snapshot(out)
baseline = ROOT / '_dev_archive/round90b_flash_before_20261002'
snapshot = json.loads((out / 'snapshot.json').read_text(encoding='utf-8'))
assert snapshot['usb_serial']=='5303284739002C9C'
assert history.SIGNATURE in snapshot['version']
equal = {name: (out/name).read_bytes()==(baseline/name).read_bytes()
         for name in ('controller_config.bin','chip_40.bin','chip_41.bin','chip_42.bin')}
deadline = time.monotonic()+15
reconnect_errors = []
while True:
    try:
        port, info = history.checked()
        break
    except Exception as error:
        if isinstance(error, RuntimeError) and not str(error).startswith('target enumeration:'):
            raise
        reconnect_errors.append(repr(error))
        if time.monotonic()>=deadline: raise
        time.sleep(.15)
try:
    after = history.status(port)
    port.write(b'\xb8')
    state = history.live.tail(port)
    port.write(b'\xb1')
    inputs = list(history.live.exact(port, 33))
finally:
    port.close()
result = {'usb_serial':snapshot['usb_serial'], 'version':snapshot['version'],
          'files_equal_to_flash_backup':equal, 'raw_status':snapshot['raw_status'],
          'history_before':before, 'history_after':after, 'device_status':state,
          'profile':snapshot['profile'], 'current_inputs':inputs,
          'reconnect_errors':reconnect_errors,
          'operations':'No config/NVRAM writes. Config mode only for controller and chip readback, then EXIT performs a normal reboot; bounded strict identity reconnection.'}
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert all(equal.values()) and snapshot['raw_status']=='RAW=0'
assert after['state']==0 and after['pending']==0
print(json.dumps({'files_equal':equal,'raw':snapshot['raw_status'],'history_state':after['state'],
                  'version':snapshot['version'],'device_status':state},indent=2))
