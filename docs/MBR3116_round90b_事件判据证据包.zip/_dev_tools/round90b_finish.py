import datetime
import hashlib
import json
from pathlib import Path
import round90b_analyze as audit

ROOT = Path(__file__).resolve().parents[1]
plan_path = ROOT / '_dev_tools/round90b_candidate_20261002.json'
plan = json.loads(plan_path.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(audit.__file__)) == plan['analysis_sha256']
sets = {}
excluded = []
input_hashes = {}
stress_first_cue = []
for label, directory in [('exploration', 'round90b_events_20261002'), ('preflight', 'round90b_sanity_20261002'), ('stress', 'round90b_stress_20261002')]:
    trials = []
    for path in sorted((ROOT / '_dev_tools' / directory).glob('*.json')):
        job = json.loads(path.read_text(encoding='utf-8'))
        if 'captures' not in job or 'mode' not in job: continue
        input_hashes[str(path.relative_to(ROOT))] = sha(path)
        if not job['completed'] or job['user_confirmed'] is not True:
            excluded.append({'file':path.name, 'error':job.get('error'), 'captures':len(job['captures'])})
            continue
        if label == 'stress':
            assert job['hypothesis_sha256'] == sha(plan_path)
            assert len(job['captures']) == plan['stress_modes'][job['mode']]['repeats']
            stress_first_cue.extend(e['host_epoch_ms'] for e in job['cue_events'] if e['phase']=='prepare')
        trials.extend(audit.analyze_job(path))
    sets[label] = trials
assert [len(sets[k]) for k in ('exploration','preflight','stress')] == [9,1,4]
for filename, value in plan['training'].items():
    assert sha(ROOT / '_dev_tools/round90b_events_20261002' / filename)==value
trials = sum(sets.values(), [])
contacts = [t for t in trials if 'hover' not in t['mode'] and t['feature_reason'] is None]
hovers = [t for t in trials if 'hover' in t['mode'] and t['feature_reason'] is None]
bounds = {}
for name in ('count_at_onset','delta_15ms','delta_15ms_per_ms','delta_30ms_per_ms','delta_60ms_per_ms','max_step_count_per_ms'):
    contact_min = min(t['features'][name] for t in contacts)
    hover_max = max(t['features'][name] for t in hovers)
    bounds[name] = {'contact_min':contact_min, 'hover_max':hover_max,
                   'any_minimum_threshold_can_preserve_all_observed_onsets_and_reject_all_observed_hover_onsets': hover_max < contact_min}
created_ms = datetime.datetime.fromisoformat(plan['created_utc']).timestamp()*1000
assert created_ms < min(stress_first_cue)
report = {
    'firmware_commit':plan['firmware_commit'], 'candidate_sha256':sha(plan_path),
    'freeze_precedes_first_stress_prepare_ms':min(stress_first_cue)-created_ms,
    'scopes':{k:{'trials':len(v), 'frames':sum(t['frames'] for t in v),
                'qualified_onsets':sum(t['feature_reason'] is None for t in v),
                'all_lanes_qualified_frames':sum(t['all_lanes_qualified'] for t in v)} for k,v in sets.items()},
    'near_hover_interpretation':'No final ON in the160ms post-native window; not a complete gesture result or demonstrated suppression.',
    'excluded_jobs':excluded, 'monotone_minimum_threshold_bounds':bounds,
    'bound_semantics':'These finite-sample inequalities exclude a minimum threshold on each listed scalar while preserving the original first final ON. They do not exclude arbitrary multifeature histories or prove physical-contact misses.',
    'inputs_sha256':input_hashes,
}
out = ROOT / '_dev_tools/round90b_event_summary.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='inputs_sha256'},ensure_ascii=False,indent=2))
