import tempfile
from pathlib import Path
import json
import round90a_capture as sample

class FakePort:
    def write(self, _): pass

with tempfile.TemporaryDirectory() as folder:
    sample.ui.OUT = Path(folder)
    sample.ui.MOCK = False
    sample.pause = lambda _: None
    sample.history.live.exact = lambda *_: bytes(33)
    sample.history.arm = lambda _: {'session': 1}
    sample.history.status = lambda _: {'state': 1}
    sample.history.freeze = lambda _: {'session': 1, 'state': 3, 'reason': 2, 'queued': 0}
    sample.history.drain = lambda *_: []
    job = {'id': 'manual_tail', 'mode': 'fast_contact'}
    try:
        sample.capture(FakePort(), job)
        raise AssertionError('manual tail must not succeed')
    except RuntimeError as error:
        assert '未采到触发边沿' in str(error)
    assert not job['completed'] and len(job['captures']) == 1
    full = json.loads((sample.ui.OUT / 'manual_tail.json').read_text(encoding='utf-8'))
    assert not full['captures'][0]['automatic_edge']
    full['captures'][0]['rows'] = [{'hex': 'sentinel original packet'}]
    sample.save_job(full)
    summary = dict(full, user_confirmed=True, captures=[{k:v for k,v in full['captures'][0].items() if k!='rows'}])
    sample.save_job(summary)
    saved = json.loads((sample.ui.OUT / 'manual_tail.json').read_text(encoding='utf-8'))
    assert saved['captures'][0]['rows'] == full['captures'][0]['rows']
    sample.history.freeze = lambda _: {'session': 2, 'state': 3, 'reason': 1, 'queued': 3, 'trigger_frame': 2, 'trigger_ms': 1005, 'pre_ms': 180, 'post_ms': 160}
    sample.history.drain = lambda *_: [{'trace': {'frame_id': i, 'published_ms': 995 + i*5}} for i in (1, 2, 3)]
    job = {'id': 'short_window', 'mode': 'fast_contact'}
    try:
        sample.capture(FakePort(), job)
        raise AssertionError('short window must not succeed')
    except RuntimeError as error:
        assert '窗口不足' in str(error)
    assert not job['completed'] and len(job['captures']) == 1 and not job['captures'][0]['window_valid']
    print('PASS missing-edge and insufficient window stop after first trial; confirmation retains original packet')
