import argparse
import hashlib
import json
import threading
import time
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import round89x_dynamics_capture as ui
import round90a_history as history

ui.MODES = {
    'slow_contact': ('慢轻触', '食指用约1秒缓慢降到表面，刚好轻触，随即抬回', ''),
    'fast_contact': ('快速真实点按', '食指立即轻点一次，确实触板，随即抬回', ''),
    'fast_finger_hover': ('快速食指悬空', '食指快速下探到约3–5 mm，随即抬回；全程不触板', ''),
}
REPEATS = (1, 2, 3)
SANITY = False
STRESS = False
ACTION_SECONDS = 3
HYPOTHESIS_SHA256 = None

def save_job(job):
    path = ui.OUT / (job['id'] + '.json')
    value = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    if 'captures' in job and 'captures' in value:
        old = {c['repeat']: c for c in value['captures']}
        job = dict(job)
        job['captures'] = [dict(old.get(c['repeat'], {}), **c) for c in job['captures']]
    value.update(job)
    temporary = path.with_suffix('.pending')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)

def cue(job, phase, repeat, duration, message):
    event = {'phase': phase, 'repeat': repeat, 'host_epoch_ms': time.time()*1000, 'duration_s': duration}
    job['cue_events'].append(event)
    ui.update(phase=phase, cue_id=f'{repeat}_{phase}', message=f'第{repeat}次：{message}',
              end_ms=time.time()*1000 + duration*1000)

def pause(duration):
    deadline = time.monotonic() + duration*ui.SCALE
    while time.monotonic() < deadline:
        if ui.ABORT.wait(min(.05, max(0, deadline-time.monotonic()))):
            raise RuntimeError('用户中止')

def capture(port, job):
    job.update(completed=False, user_confirmed=None, cue_events=[], captures=[],
               semantics='Core0 completed frames, not independent native scans. Chip reads are sequential. '
               'Gesture confirmation does not label the exact surface-contact instant; pre-contact approach may already trigger. '
               'Check invalid reads, age, warmup edges, actual window coverage and cue interval before any causal classifier.')
    for repeat in REPEATS:
        cue(job, 'prepare', repeat, 3, '指尖停在第17格上方约3 cm，其余手指远离')
        pause(3)
        if ui.MOCK:
            armed = {'session': repeat}
        else:
            port.write(b'\xb1')
            inputs = history.live.exact(port, 33)
            if any(inputs[:32]):
                raise RuntimeError('就位时已有触发；手抬高后重新开始本组')
            armed = history.arm(port)
        cue(job, 'baseline', repeat, 1, '保持原位，等提示')
        pause(1)
        # Freeze/edge before the action cue cannot be attributed to this gesture.
        if not ui.MOCK and history.status(port)['state'] != 1:
            raise RuntimeError('动作前已出现状态变化；本组作废并重新就位')
        cue(job, 'action', repeat, ACTION_SECONDS, ui.MODES[job['mode']][1])
        pause(ACTION_SECONDS)
        if ui.MOCK:
            frozen, rows = {'session': repeat, 'state': 3, 'reason': 1, 'queued': 96}, []
        else:
            frozen = history.freeze(port)
            rows = history.drain(port, frozen)
        cue(job, 'release', repeat, 2, '整只手远离30 cm')
        pause(2)
        result = {'repeat': repeat, 'armed': armed, 'frozen': frozen, 'rows': rows,
                  'automatic_edge': frozen['reason'] == 1,
                  'span_ms': ((rows[-1]['trace']['published_ms'] - rows[0]['trace']['published_ms']) & 0xffffffff) if rows else None}
        if not ui.MOCK and result['automatic_edge']:
            trigger = [r for r in rows if r['trace']['frame_id'] == frozen['trigger_frame']]
            result['window_valid'] = len(trigger) == 1 and trigger[0]['trace']['published_ms'] == frozen['trigger_ms']
            if result['window_valid']:
                result['pre_ms'] = (frozen['trigger_ms'] - rows[0]['trace']['published_ms']) & 0xffffffff
                result['post_ms'] = (rows[-1]['trace']['published_ms'] - frozen['trigger_ms']) & 0xffffffff
                result['window_valid'] = result['pre_ms'] >= frozen['pre_ms'] and result['post_ms'] >= frozen['post_ms']
        else:
            result['window_valid'] = ui.MOCK
        job['captures'].append(result)
        save_job(job)
        if not result['automatic_edge']:
            raise RuntimeError('未采到触发边沿，本组已停止；记录已保存，请等待核查')
        if not result['window_valid']:
            raise RuntimeError('触发前后窗口不足，本组已停止；记录已保存，请等待核查')
    job['completed'] = True

def worker():
    while True:
        job = ui.TASKS.get()
        if job == 'finish':
            ui.update(phase='closed', message='采样已结束，记录已停止', end_ms=0)
            continue
        port = None
        restored = ui.MOCK
        try:
            if not ui.MOCK:
                port, info = history.checked()
                job['usb_serial'] = info.serial_number
                job['firmware'] = history.live.version(port)
            if STRESS:
                job['hypothesis_sha256'] = HYPOTHESIS_SHA256
            capture(port, job)
        except Exception as error:
            job.update(error=str(error), error_type=type(error).__name__, completed=False)
        finally:
            if port:
                try:
                    if getattr(port, '_history_protocol_broken', False):
                        raise RuntimeError('串口帧异常；关闭连接以停止记录，需重新核查')
                    job['final_history'] = history.freeze(port)
                    port.write(b'\xc4')
                    restored = history.live.tail(port) == 'RAW=0'
                    if not restored: raise RuntimeError('普通模式回读失败')
                except Exception as error:
                    job['restore_error'] = repr(error)
                finally:
                    port.close()
            job.update(raw_restored=restored, mock=ui.MOCK, backup=str(ui.BACKUP))
            save_job(job)
            summary = {k: v for k, v in job.items() if k != 'captures'}
            summary['captures'] = [{k: v for k, v in c.items() if k != 'rows'} for c in job.get('captures', [])]
            with ui.LOCK:
                ui.STATE['jobs'].append(summary)
            ui.update(running=False, blocked=not restored, raw_restored=restored,
                      phase='done' if job['completed'] and restored else 'error', cue_id='', end_ms=0,
                      message='记录已停止，普通模式已确认；请确认动作' if job['completed'] and restored else
                              '采样停止：' + job.get('restore_error', job.get('error', '已中止')))
            print('DONE', job['id'], job['completed'], restored, flush=True)

class Handler(ui.Handler):
    def do_GET(self):
        if urlsplit(self.path).path == '/':
            html = Path(ui.__file__).with_suffix('.html').read_text(encoding='utf-8')
            html = html.replace('触摸动态对照', '固件事件记录')
            html = html.replace('固定在滑条第17格，每组两次动作。高度从亚克力顶面估计；跟随页面提示。悬空组全程不能触板，意外碰到请作废。',
                                '固定第17格，每组三次。跟随提示；悬空组全程不触板，有偏差请作废。')
            html = html.replace('依次完成四组', '依次完成三组').replace('每组约半分钟', '每组约半分钟')
            opening, ending = html.index('<option'), html.index('</select>')
            options = '\n'.join(f'<option value="{key}">{i} · {value[0]}</option>' for i, (key, value) in enumerate(ui.MODES.items(), 1))
            html = html[:opening] + options + '\n' + html[ending:]
            if SANITY:
                html = html.replace('每组三次', '本组一次').replace('依次完成三组', '先确认一次点按记录')
            if STRESS:
                html = html.replace('固件事件记录', '触发判据复核')
                html = html.replace('每组三次', '每组两次').replace('依次完成三组', '依次完成两组')
                html = html.replace('每组约半分钟', '每组约半分钟；输出保持原样')
            return self.send(200, html.encode(), 'text/html; charset=utf-8')
        super().do_GET()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8774)
    parser.add_argument('--out', required=True)
    parser.add_argument('--backup', required=True)
    parser.add_argument('--mock', action='store_true')
    parser.add_argument('--test-scale', type=float, default=1)
    parser.add_argument('--sanity', action='store_true')
    parser.add_argument('--stress', action='store_true')
    parser.add_argument('--hypothesis')
    args = parser.parse_args()
    if args.sanity and args.stress: parser.error('choose sanity or stress')
    if args.test_scale != 1 and not args.mock: parser.error('short timing is mock only')
    ui.OUT = Path(args.out).resolve(); ui.OUT.mkdir(parents=True, exist_ok=True)
    ui.BACKUP = Path(args.backup).resolve()
    if not args.mock and not (ui.BACKUP / 'snapshot.json').is_file(): parser.error('backup required')
    ui.MOCK, ui.SCALE = args.mock, args.test_scale
    SANITY = args.sanity
    STRESS = args.stress
    if STRESS:
        if not args.hypothesis: parser.error('frozen hypothesis required')
        frozen_path = Path(args.hypothesis)
        frozen = json.loads(frozen_path.read_text(encoding='utf-8'))
        if set(frozen['stress_modes']) != {'very_slow_contact', 'near_finger_hover'}:
            parser.error('wrong stress hypothesis')
        HYPOTHESIS_SHA256 = hashlib.sha256(frozen_path.read_bytes()).hexdigest()
    if SANITY:
        REPEATS = (1,)
        ui.MODES = {'fast_contact': ui.MODES['fast_contact']}
    if STRESS:
        REPEATS = (1, 2)
        ACTION_SECONDS = 6
        ui.MODES = {
            'very_slow_contact': ('非常慢的轻触', '用约4秒缓慢降到表面，轻贴1秒后抬回；确实触板', ''),
            'near_finger_hover': ('贴近板面的快速悬空', '快速下探到约1–2 mm，随即抬回；全程不触板，意外碰到请作废', ''),
        }
    ui.ORIGIN = f'http://127.0.0.1:{args.port}'
    ui.save_job = save_job
    ui.update(mock=args.mock)
    threading.Thread(target=worker, daemon=True).start()
    print('READY', ui.ORIGIN, 'MOCK' if args.mock else 'REAL', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
