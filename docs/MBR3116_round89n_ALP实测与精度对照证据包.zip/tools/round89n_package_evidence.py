import hashlib
import json
import zipfile
from pathlib import Path

import round89i_analyze_pair as paired
import round89n_prox16_capture as experiment

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
files, groups, restoration = {}, {}, {}
for name, folder in (("alp_on_12", "round89k_prox_20261001"), ("alp_off_12", "round89m_alp_off_20261002")):
    directory = ROOT / "_dev_tools" / folder
    paired.ROOT = directory
    result = paired.analyze()
    accepted = [j for j in result["jobs"] if j["completed"] and j["user_confirmed"] is True]
    if len(accepted) != 2 or {j["mode"] for j in accepted} != {"finger_contact", "finger_hover3"}:
        raise RuntimeError("unexpected accepted sample set: " + name)
    groups[name] = {"accepted_samples": accepted, "joint_collisions": result["joint_delta_collisions"],
                    "capped_collisions": result["capped_center_plus_reference_collisions"], "closest": result["closest_finger_pair"]}
    for job in accepted:
        raw = json.loads((directory / (job["id"] + ".json")).read_text(encoding="utf-8"))
        if not all(raw["hardware"].get(k) for k in ("candidate_applied", "restore_verified", "restore_after_reboot")):
            raise RuntimeError("restoration not verified")
        device = directory / (job["id"] + "_device")
        after = device / "after_reboot"
        equal = all((after / f"chip_{a:02x}.bin").read_bytes() == t for a, t in experiment.capture.ORIGINALS.items())
        equal = equal and (after / "controller_config.bin").read_bytes() == experiment.capture.CFG
        snapshot = json.loads((after / "snapshot.json").read_text(encoding="utf-8"))
        if not equal or snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
            raise RuntimeError("restoration snapshot mismatch")
        restoration[job["id"]] = {"all_four_blocks_equal": True, "raw": snapshot["raw_status"], "slider_all_zero": True}
        for suffix in (".csv", ".json"):
            path = directory / (job["id"] + suffix)
            files[name + "/" + path.name] = path
        for path in device.rglob("*"):
            if path.is_file():
                files[name + "/" + path.relative_to(directory).as_posix()] = path

original = experiment.capture.ORIGINALS[0x42]
twelve = experiment.alp.make_patch(original)
sixteen = experiment.make_patch(original)
spec = {
    "date": "2026-10-02", "address": "0x42", "sensor": "CS0/PS0/lane18",
    "source": "TRM 001-91082 Rev E 1.5.35 and official KBA229990",
    "baseline_sha256": hashlib.sha256(original).hexdigest(),
    "comparison": "Proximity ALP OFF retained; change only output resolution 12 to 16 bits, with native CRC update",
    "differences_from_alp_off_12": [{"offset": hex(i), "before": twelve[i], "after": sixteen[i]} for i in range(128) if twelve[i] != sixteen[i]],
    "differences_from_original": [{"offset": hex(i), "before": original[i], "after": sixteen[i]} for i in range(128) if original[i] != sixteen[i]],
    "candidate_sha256": hashlib.sha256(sixteen).hexdigest(),
    "candidate_crc_value": "0x" + format(int.from_bytes(sixteen[-2:], "little"), "04X"),
    "candidate_crc_little_endian_bytes": sixteen[-2:].hex(),
    "limits": "Full output precision, not an independent distance measurement; noise scales too. No scan speed or hover suppression improvement established.",
    "restoration": "Restore original after every job; compare controller and all three tables after reboot before confirmation",
    "hardware_applied": False, "pose_samples_pending": True,
}
spec_path = DOCS / "MBR3116_round89n_16位对照规格.json"
spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
evidence = {
    "date": "2026-10-02", "groups": groups, "restoration": restoration,
    "semantics": "Sequential native C7; only completed human-confirmed jobs accepted. Fixed hold 6-11.5 seconds; invalid pairs excluded without zero fill.",
    "conclusion": "Disabling ALP yielded small reference changes but contact and hover still overlap. Joint raw-baseline features (94,2), and capped center diff plus reference delta (176,2), both collide. Do not deploy a classifier from this pair.",
    "limitations": ["Hand-estimated height, one finger and position; separate post-reset runs", "Rows are not independent touch trials and C7 windows are sequential", "Weak reference changes comparable to short far-window variation; formal SNR and 3000-sample noise tuning not established", "16-bit experiment must demonstrate margin after normalization, not just larger displayed counts"],
    "tests": {"full_resolution_fields_and_native_parser": "5/5 with 7 restore transaction subcases", "browser_mock": "PASS: hardware endpoints intercepted; desktop 1100x850 and mobile 390x844; countdown, restore, confirm, discard, abort, block, finish, console", "independent_readonly_review": "21/21 pure memory cases covering fields, unsigned parser, metadata isolation and 10 transaction paths; no file writes or serial access"},
    "cpp_or_production_panel_changes": False,
}
for name in ("round89n_prox16_capture.py", "test_round89n_prox16.py", "round89n_package_evidence.py",
             "round89m_alp_off_capture.py", "test_round89m_alp_off.py", "round89k_prox_capture.py", "test_round89k_prox_capture.py",
             "round89j_prox_idle.py", "round89h_timed_capture.py", "round89h_timed_capture.html", "round89h_raw_capture.py",
             "round89g_latency_probe.py", "round89_live.py", "round89_live_debug.py", "round89i_analyze_pair.py",
             "round89h_analyze_timed.py", "test_round89h_timed_ui.js"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
files["specification.json"] = spec_path
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89n_ALP实测与精度对照证据包.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as bundle:
    if any(hashlib.sha256(bundle.read(name)).hexdigest() != digest for name, digest in manifest.items()):
        raise RuntimeError("archive mismatch")
evidence["archive"] = {"name": archive.name, "files": len(manifest), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "size": archive.stat().st_size}
(DOCS / "MBR3116_round89n_ALP实测分析.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PACK VERIFIED", len(manifest), archive.stat().st_size, "ALP OFF pairs", [j["windows"]["hold"]["valid"] for j in groups["alp_off_12"]["accepted_samples"]])
print("PATCH", spec["differences_from_original"])
