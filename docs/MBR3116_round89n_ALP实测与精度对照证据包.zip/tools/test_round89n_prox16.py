import unittest
from unittest.mock import patch

import round89n_prox16_capture as experiment
import test_round89k_prox_capture as capture_tests
import test_round89m_alp_off as alp_tests

capture = experiment.capture


class FullResolutionTests(unittest.TestCase):
    def test_only_resolution_changes_from_alp_off_twelve(self):
        original = capture.ORIGINALS[0x42]
        desired = experiment.make_patch(original)
        twelve = experiment.alp.make_patch(original)
        self.assertEqual([i for i in range(126) if desired[i] != twelve[i]], [0x2E])
        self.assertEqual(desired[0x2E], 0)
        self.assertEqual(desired[0x26], 1)
        self.assertEqual(desired[0x27], 0)
        self.assertEqual([i for i in range(126) if desired[i] != original[i]], [0x26, 0x27])
        self.assertEqual(alp_tests.bitwise_crc(desired), int.from_bytes(desired[-2:], "little"))

    def test_unexpected_original_mode_rejected(self):
        original = bytearray(capture.ORIGINALS[0x42])
        original[0x2E] = 4
        original[-2:] = alp_tests.bitwise_crc(original).to_bytes(2, "little")
        with self.assertRaisesRegex(RuntimeError, "unexpected mode"):
            experiment.make_patch(original)

    def test_unsigned_sixteen_bit_counts_preserved(self):
        def frame(address, sensor, diff, baseline, raw):
            return bytes([address, sensor, 3, 25]) + diff.to_bytes(2, "little") + baseline.to_bytes(2, "little") + raw.to_bytes(2, "little")

        packets = [b"\xc7", frame(0x40, 7, 255, 2820, 3000), b"\xc7", frame(0x42, 0, 500, 65000, 65500)]
        with patch.object(capture.ui.live, "split"), patch.object(capture.ui.live, "exact", side_effect=packets):
            row = capture.read_pair(None)
        self.assertEqual(row["ref_baseline"], 65000)
        self.assertEqual(row["ref_raw"], 65500)
        self.assertEqual(row["ref_diff"], 500)
        self.assertEqual(row["ref_delta"], 500)
        self.assertEqual(row["delta_ratio"], 500 / 180)

    def test_reuses_verified_restore_transaction(self):
        desired = experiment.make_patch(capture.ORIGINALS[0x42])
        for failure in (None, "capture", "restore", "reboot", "precheck", "exit", "invalid_data"):
            with self.subTest(failure=failure), patch.object(capture, "DESIRED", desired):
                capture_tests.CaptureTests().exercise(failure)

    def test_isolated_service_configuration(self):
        with patch.object(capture, "DESIRED"), patch.object(capture, "REFERENCE_MODE"), \
             patch.object(capture, "PAGE_TITLE"), patch.object(capture, "DEFAULT_MODE"), \
             patch.object(capture.ui, "OUT"), patch.object(capture.ui, "ORIGIN"):
            experiment.configure()
            self.assertEqual(capture.ui.OUT, experiment.OUT)
            self.assertEqual(capture.ui.ORIGIN, "http://127.0.0.1:8771")
            self.assertIn("16-bit ALP OFF", capture.REFERENCE_MODE)
            self.assertEqual(capture.DEFAULT_MODE, "finger_contact")


if __name__ == "__main__":
    unittest.main()
