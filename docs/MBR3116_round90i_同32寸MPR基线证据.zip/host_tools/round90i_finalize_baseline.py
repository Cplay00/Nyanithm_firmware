"""Package the completed same-32 baseline. Local files only; no serial/network."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90i_same32_20261004'
BACKUP = ROOT / '_dev_archive/round90i_same32_before_20261004'
DOCS = ROOT / 'Nyanithm_firmware_hw_v1/docs'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    packet = DOCS / 'MBR3116_round90i_同32寸MPR基线证据.zip'
    if packet.exists():
        raise RuntimeError('baseline already frozen; do not overwrite it with later gestures')
    manifest = json.loads((BACKUP / 'backup_complete.json').read_text(encoding='utf-8'))
    for name, digest in manifest['files'].items():
        assert sha((BACKUP / name).read_bytes()) == digest, name
    original_source = ROOT / '_dev_archive/round90g_before_20261003/source.zip'
    with zipfile.ZipFile(original_source) as archive:
        headers = b'\n'.join(archive.read(name) for name in archive.namelist() if name.endswith('.h'))
        assert b'1.6.6-beta10' in headers and b'round90e' in headers
    source_copy = BACKUP / 'source_original_beta10_round90e.zip'
    if source_copy.exists():
        assert source_copy.read_bytes() == original_source.read_bytes()
    else:
        shutil.copyfile(original_source, source_copy)
    save(BACKUP / 'original_source_provenance.json', {
        'source_original_beta10': source_copy.name, 'sha256': sha(source_copy.read_bytes()),
        'copied_from': str(original_source), 'version_and_bid_macros_checked': True,
        'source_6010130_zip': 'current beta11 source; not deployed original beta10 source',
        'original_uf2': 'round90e_original.uf2', 'hardware_flash_dump': False})
    mock = OUT / 'page_mock'
    jobs = [json.loads(path.read_text(encoding='utf-8')) for path in mock.glob('*.json')
            if path.name != 'session_closed.json']
    assert len(jobs) == 1 and jobs[0]['completed'] and jobs[0]['user_confirmed'] is True
    mock_csv = mock / (jobs[0]['id'] + '.csv')
    with mock_csv.open(encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    assert rows and all(len(json.loads(row['channels_json'])) == 36 for row in rows)
    assert all(all(len(row[f'registers_{a}']) == 256 for a in ('5a', '5b', '5c')) for row in rows)
    qa = {'mock': True, 'confirmed_completed_jobs': 1, 'full_three_chip_cycles': len(rows),
          'all_36_channels_preserved': True, 'browser': 'Codex in-app browser via cua_repl',
          'mock_url': 'http://127.0.0.1:8881/', 'real_url': 'http://127.0.0.1:8882/',
          'verified_flow': 'load -> start -> countdown -> confirm -> automatic next action -> finish',
          'console_errors_or_warnings': [], 'page_identity_not_blank': True,
          'exit_truthfulness_fix_offline_cases': 5,
          'old_no_port_finish_claim_corrected_in_source': True,
          'untested': ['mobile viewport', 'real user gestures', 'actual HID game acceptance']}
    save(OUT / 'page_qa.json', qa)
    idle = json.loads((OUT / 'idle/capture.json').read_text(encoding='utf-8'))
    assert idle['complete'] and idle['controller_equal_after'] and len(idle['samples']) == 36
    assert all(sample['response_bytes'] == 128 and
               bytes.fromhex(sample['hex'])[:4] == bytes(4) for sample in idle['samples'])
    config = json.loads((OUT / 'configure_retry.json').read_text(encoding='utf-8'))
    assert config['completed'] and config['saved_readback_equal'] and config['after_reboot']['controller_config_equal']
    normal = json.loads((OUT / 'normal_idle.json').read_text(encoding='utf-8'))
    assert len(normal['frames']) == 100 and normal['touch_active_frames'] == 0
    files = {}
    for name in ('identity.json', 'candidate.json', 'mpr_controller_config.bin', 'flash.json',
                 'configure.json', 'configure_retry.json', 'normal_idle.json', 'offline_checks.json',
                 'page_qa.json', 'page_ready.png', 'idle/capture.json', 'idle/summary.json'):
        files['baseline/' + name] = OUT / name
    for name in ('controller_config.bin', 'backup_complete.json', 'snapshot.json', 'original_source_provenance.json'):
        files['backup/' + name] = BACKUP / name
    for name in ('round90i_same32_setup.py', 'round90i_same32_page.py', 'round90i_same32_page.html',
                 'round90i_finalize_baseline.py', 'round89_live.py', 'round89c_flash_probe.py',
                 'round89h_timed_capture.py'):
        files['host_tools/' + name] = ROOT / '_dev_tools' / name
    files['mock/' + mock_csv.name] = mock_csv
    files['mock/' + jobs[0]['id'] + '.json'] = mock / (jobs[0]['id'] + '.json')
    metadata = {'scope': 'same-32 setup and idle baseline; excludes future physical gestures',
                'usb_serial': '5303284739002C9C', 'new_firmware_code': False,
                'touch_algorithm_changed': False, 'new_mbr_tables_written': False,
                'configuration_sha256': sha((OUT / 'mpr_controller_config.bin').read_bytes()),
                'manifest': {name: sha(path.read_bytes()) for name, path in files.items()}}
    with zipfile.ZipFile(packet, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in files.items():
            archive.write(path, name)
        archive.writestr('manifest.json', json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(packet) as archive:
        assert archive.testzip() is None
        for name, digest in metadata['manifest'].items():
            assert sha(archive.read(name)) == digest, name
    check = {'packet': packet.name, 'sha256': sha(packet.read_bytes()), 'bytes': packet.stat().st_size,
             'members_verified': len(files), 'idle_snapshots': 36, 'normal_cdc_frames': 100,
             'configuration_saved_and_reboot_equal': True, 'mock_cycles': len(rows),
             'new_touch_or_firmware_code': False, 'real_user_gestures': 'pending',
             'hid_game_acceptance': 'pending'}
    save(DOCS / 'MBR3116_round90i_基线核查.json', check)
    print(json.dumps(check, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
