import tempfile
import queue
import unittest
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import round89k_prox_capture as capture


class Port:
    def __init__(self):
        self.writes = []
        self.closed = False
        self.fail_exit = False

    def write(self, data):
        self.writes.append(data)
        if self.fail_exit and data == b"\xb9":
            raise OSError("exit write failed")

    def flush(self):
        pass

    def close(self):
        self.closed = True


class CaptureTests(unittest.TestCase):
    def exercise(self, failure=None):
        port = Port()
        port.fail_exit = failure == "exit"
        job = {"id": "test", "mode": "finger_contact"}
        writes = []

        def read_chip(p, address):
            if failure == "precheck":
                return b"unexpected configuration"
            if writes and len(writes) == 1 and address == capture.probe.ADDRESS:
                return capture.DESIRED
            return capture.ORIGINALS[address]

        def program(p, table):
            writes.append(table)
            return ["done"]

        def collect(p, j, firmware, **kwargs):
            self.assertFalse(kwargs["publish"])
            self.assertNotIn(j, capture.ui.STATE["jobs"])
            if failure == "capture":
                raise RuntimeError("capture failed")
            j.update(completed=True, user_confirmed=None,
                     summary={phase: {"rows": 25, "valid": 20} for phase in ("baseline", "hold", "release")})
            if failure == "invalid_data":
                j["summary"]["hold"]["valid"] = 1

        def restore(p, originals, cfg, report):
            self.assertEqual(originals, capture.ORIGINALS)
            self.assertEqual(cfg, capture.CFG)
            self.assertNotIn(job, capture.ui.STATE["jobs"])
            if failure == "restore":
                raise RuntimeError("restore failed")
            writes.append(originals[capture.probe.ADDRESS])
            report["restore_verified"] = True

        def snapshot(folder):
            self.assertIn(b"\xb9", port.writes)
            if failure == "reboot":
                raise RuntimeError("re-enumeration failed")
            for a, table in capture.ORIGINALS.items():
                (folder / f"chip_{a:02x}.bin").write_bytes(table)
            (folder / "controller_config.bin").write_bytes(capture.CFG)

        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            stack.enter_context(patch.object(capture.ui, "OUT", Path(directory)))
            stack.enter_context(patch.object(capture.ui, "STATE", {"running": True, "jobs": []}))
            stack.enter_context(patch.object(capture.probe, "connect_reboot_ready", return_value=(port, SimpleNamespace(serial_number="test"))))
            stack.enter_context(patch.object(capture.ui.live, "connect"))
            stack.enter_context(patch.object(capture.ui.live, "version", return_value="BID=round89g"))
            stack.enter_context(patch.object(capture.ui.live, "tail", return_value=""))
            stack.enter_context(patch.object(capture.ui.live, "config_read", return_value=(capture.CFG, "")))
            stack.enter_context(patch.object(capture.probe, "read_chip", side_effect=read_chip))
            stack.enter_context(patch.object(capture.probe, "program", side_effect=program))
            stack.enter_context(patch.object(capture.probe, "samples", return_value=[{"error": "", "raw": 2900, "baseline": 2900}] * 20))
            stack.enter_context(patch.object(capture.ui, "capture_job", side_effect=collect))
            stack.enter_context(patch.object(capture.probe, "restore", side_effect=restore))
            stack.enter_context(patch.object(capture.ui.live, "snapshot", side_effect=snapshot))
            if failure:
                with self.assertRaises(RuntimeError):
                    capture.run_job(job)
                self.assertNotIn(job, capture.ui.STATE["jobs"])
                self.assertEqual(bool(capture.ui.STATE.get("blocked")), failure in ("restore", "reboot", "precheck", "exit"))
            else:
                capture.run_job(job)
                self.assertIn(job, capture.ui.STATE["jobs"])
                self.assertTrue(job["completed"])
                self.assertTrue(job["hardware"]["restore_after_reboot"])
        self.assertTrue(port.closed)
        if failure == "precheck":
            self.assertEqual(writes, [])
        elif failure == "restore":
            self.assertNotIn(b"\xb9", port.writes)
        else:
            self.assertEqual(writes, [capture.DESIRED, capture.ORIGINALS[capture.probe.ADDRESS]])

    def test_success_publishes_only_after_restore(self):
        self.exercise()

    def test_capture_failure_still_restores_and_closes(self):
        self.exercise("capture")

    def test_restore_failure_blocks_next_job(self):
        self.exercise("restore")

    def test_reboot_verification_failure_blocks_next_job(self):
        self.exercise("reboot")

    def test_unknown_baseline_blocks_without_programming(self):
        self.exercise("precheck")

    def test_too_few_valid_pairs_restores_without_publishing(self):
        self.exercise("invalid_data")

    def test_exit_error_closes_and_blocks_without_claiming_success(self):
        self.exercise("exit")

    def test_queued_finish_is_rejected_after_blocking(self):
        with patch.object(capture.ui, "STATE", {"blocked": True, "jobs": []}), \
             patch.object(capture.STOP, "is_set", side_effect=[False, False, True]), \
             patch.object(capture.ui.TASKS, "get", side_effect=["finish", queue.Empty]), \
             patch.object(capture, "run_job") as run:
            capture.worker()
            self.assertEqual(capture.ui.STATE["phase"], "error")
            run.assert_not_called()

    def test_pair_keeps_wide_reference_and_excludes_error(self):
        center = {"error": "", "delta": 100, "diff": 255}
        reference = {"error": "", "delta": 300, "diff": 300}
        with patch.object(capture, "NATIVE", side_effect=[center, reference]):
            row = capture.read_pair(None)
        self.assertEqual(row["ref_diff"], 300)
        self.assertEqual(row["delta_ratio"], 3)
        with patch.object(capture, "NATIVE", side_effect=[center, {"error": "fail"}]):
            self.assertEqual(capture.read_pair(None), {"error": "reference: fail"})


if __name__ == "__main__":
    unittest.main()
