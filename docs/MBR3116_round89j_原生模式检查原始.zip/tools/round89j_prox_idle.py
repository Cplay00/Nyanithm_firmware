import argparse
import hashlib
import json
import shutil
import time
from pathlib import Path

import serial

import round89_live as live
from round89h_raw_capture import connect_checked
from round89h_timed_capture import read_native

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "_dev_tools/round89i_after_pair_20261001"
OUT = ROOT / "_dev_tools/round89j_prox_idle_20261001"
ARCHIVE = ROOT / "_dev_archive/round89j_device_before_20261001"
ADDRESS = 0x42


def crc(table):
    seed = 0xFFFF
    for value in table[:126]:
        for nibble in (value >> 4, value & 15):
            seed = ((0x1021 * (nibble ^ (seed >> 12))) ^ (seed << 4)) & 0xFFFF
    return seed


def make_patch(original):
    if len(original) != 128 or crc(original) != int.from_bytes(original[126:128], "little"):
        raise RuntimeError("invalid original table CRC")
    if original[0x26] != 0 or original[0x2E] != 0 or not (int.from_bytes(original[:2], "little") & 1):
        raise RuntimeError("unexpected mode, resolution, or sensor enable")
    if not 62 <= int.from_bytes(original[0x2A:0x2C], "little") <= 65000:
        raise RuntimeError("invalid native proximity touch threshold")
    if not 31 <= original[0x0C] <= 200 or original[0x0C] >= int.from_bytes(original[0x2A:0x2C], "little"):
        raise RuntimeError("invalid native proximity base threshold")
    patched = bytearray(original)
    patched[0x26] |= 1
    patched[0x2E] = (patched[0x2E] & 0xF8) | 4
    patched[126:128] = crc(patched).to_bytes(2, "little")
    if any(original[i] != patched[i] for i in range(128) if i not in (0x26, 0x2E, 0x7E, 0x7F)):
        raise RuntimeError("unexpected patch fields")
    return bytes(patched)


def read_chip(port, address):
    live.split(port, 0xC6, [address])
    return live.exact(port, 128, 5)


def program(port, table):
    if len(table) != 128 or crc(table) != int.from_bytes(table[126:128], "little"):
        raise RuntimeError("invalid programming table")
    live.tail(port, .05)
    live.split(port, 0xBA, bytes([ADDRESS]) + table)
    data = bytearray()
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        data.extend(port.read(port.in_waiting or 1))
        if not data.endswith(b"\n"):
            continue
        lines = data.decode("ascii", "replace").splitlines()
        if any("failed" in line or "aborted" in line or "unknown command" in line for line in lines):
            raise RuntimeError(f"program rejected: {lines}")
        if "done" in lines:
            if "programing 3116 chip" not in lines:
                raise RuntimeError(f"unexpected program response: {lines}")
            return lines
    raise RuntimeError(f"program response timeout: {data!r}")


def samples(port, count=20):
    rows = []
    for _ in range(count):
        start = time.perf_counter()
        row = read_native(port, ADDRESS, 0)
        row["host_ms"] = (time.perf_counter() - start) * 1000
        rows.append(row)
    return rows


def restore(port, originals, expected_cfg, report):
    report["restore_attempts"] = []
    for attempt in range(2):
        result = {"attempt": attempt + 1}
        try:
            port.write(b"\xc3")
            result["reply"] = program(port, originals[ADDRESS])
            restored = {address: read_chip(port, address) for address in originals}
            cfg, _ = live.config_read(port)
            result["chip_equal"] = {hex(a): restored[a] == originals[a] for a in originals}
            result["controller_equal"] = cfg == expected_cfg
            report["restore_verified"] = restored == originals and cfg == expected_cfg
            if not report["restore_verified"]:
                raise RuntimeError("restoration readback mismatch")
        except Exception as error:
            result["error"] = repr(error)
        report["restore_attempts"].append(result)
        if report["restore_verified"]:
            return
    raise RuntimeError("could not verify original configuration restoration")


def validate_samples(rows):
    good = [row for row in rows if not row["error"]]
    if not rows or len(good) < len(rows) * .9 or any(row["raw"] == 0 or row["baseline"] == 0 for row in good):
        raise RuntimeError("native idle samples missing or invalid")


def connect_reboot_ready():
    deadline = time.monotonic() + 15
    while True:
        try:
            return connect_checked()
        except (serial.SerialException, OSError):
            if time.monotonic() >= deadline:
                raise
            time.sleep(.2)


def final_verify(report, originals, expected_cfg):
    live.connect = connect_reboot_ready
    final = OUT / "after_reboot"
    final.mkdir(exist_ok=True)
    try:
        live.snapshot(final)
        report["after_reboot_equal"] = all((final / f"chip_{a:02x}.bin").read_bytes() == originals[a] for a in originals)
        report["controller_after_reboot_equal"] = (final / "controller_config.bin").read_bytes() == expected_cfg
        report["restoration_completed"] = report["after_reboot_equal"] and report["controller_after_reboot_equal"] and report["restore_verified"]
        report["completed"] = report["restoration_completed"] and report["candidate_applied"] and "error" not in report
    except Exception as error:
        report.setdefault("post_reboot_errors", []).append(repr(error))
        report["completed"] = False
        raise
    finally:
        (OUT / "probe.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if not report["restoration_completed"]:
        raise RuntimeError("reboot restoration mismatch")
    if not report["completed"]:
        raise RuntimeError("experiment failed; original configuration verified after reboot: " + report.get("error", "unknown error"))
    print("COMPLETE restored after reboot; device remains round89g", flush=True)


def main():
    OUT.mkdir(exist_ok=False)
    ARCHIVE.mkdir(exist_ok=False)
    originals = {address: (BASE / f"chip_{address:02x}.bin").read_bytes() for address in (0x40, 0x41, 0x42)}
    expected_cfg = (BASE / "controller_config.bin").read_bytes()
    desired = make_patch(originals[ADDRESS])
    spec = json.loads((ROOT / "Nyanithm_firmware_hw_v1/docs/MBR3116_round89i_Proximity实验规格.json").read_text(encoding="utf-8"))
    if hashlib.sha256(originals[ADDRESS]).hexdigest() != spec["baseline_sha256"]:
        raise RuntimeError("baseline specification mismatch")
    differences = [{"offset": hex(i), "original": originals[ADDRESS][i], "planned": desired[i]}
                   for i in range(128) if originals[ADDRESS][i] != desired[i]]
    if differences != spec["predicted_changed_bytes"]:
        raise RuntimeError("patch specification mismatch")
    for path in BASE.iterdir():
        if path.is_file():
            shutil.copy2(path, ARCHIVE / path.name)
    shutil.copy2(ROOT / "Nyanithm_firmware_hw_v1/build_round89g/Nyanithm.uf2", ARCHIVE / "Nyanithm_round89g.uf2")
    report = {"address": hex(ADDRESS), "candidate_applied": False, "restore_verified": False,
              "completed": False, "source": "TRM 1.5.30/35; official Host API CRC", "hands": "last user instruction: remain far; no new action required"}
    port, info = connect_checked()
    entered, attempted = False, False
    try:
        report["version"] = live.version(port)
        report["usb_serial"] = info.serial_number
        port.write(b"\xb3")
        entered = True
        live.tail(port, .25)
        controller, _ = live.config_read(port)
        before = {address: read_chip(port, address) for address in originals}
        if controller != expected_cfg or before != originals:
            raise RuntimeError("live configuration differs from verified baseline")
        print("PRECHECK original config and all three chip tables verified", flush=True)
        report["button_idle"] = samples(port)
        validate_samples(report["button_idle"])
        attempted = True
        report["apply_reply"] = program(port, desired)
        after = {address: read_chip(port, address) for address in originals}
        if after[ADDRESS] != desired or any(after[a] != originals[a] for a in originals if a != ADDRESS):
            raise RuntimeError("candidate readback mismatch")
        report["candidate_applied"] = True
        report["candidate_hex"] = after[ADDRESS].hex()
        print("APPLIED CS0 Proximity, 12-bit; other chip tables unchanged", flush=True)
        report["warmup"] = samples(port, 12)
        report["prox12_idle"] = samples(port, 40)
        validate_samples(report["prox12_idle"])
    except Exception as error:
        report["error"] = repr(error)
    finally:
        try:
            if attempted:
                restore(port, originals, expected_cfg, report)
                print("RESTORED original controller and all chip tables", flush=True)
        finally:
            try:
                report["exit_sent"] = False
                if entered and (not attempted or report["restore_verified"]):
                    port.write(b"\xb9")
                    port.flush()
                    report["exit_sent"] = True
            finally:
                port.close()
                (OUT / "probe.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if not attempted:
        raise RuntimeError("experiment aborted before programming: " + report.get("error", "unknown error"))
    final_verify(report, originals, expected_cfg)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    if args.verify_only:
        report = json.loads((OUT / "probe.json").read_text(encoding="utf-8"))
        if not report["restore_verified"] or not report["exit_sent"]:
            raise RuntimeError("verify-only requires completed pre-reboot restoration")
        originals = {a: (ARCHIVE / f"chip_{a:02x}.bin").read_bytes() for a in (0x40, 0x41, 0x42)}
        final_verify(report, originals, (ARCHIVE / "controller_config.bin").read_bytes())
    else:
        main()
