import hashlib
import json
import statistics
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "_dev_tools/round89j_prox_idle_20261001"
DOCS = ROOT / "Nyanithm_firmware_hw_v1/docs"
report = json.loads((SOURCE / "probe.json").read_text(encoding="utf-8"))
report["initial_reboot_verification"] = "First full execution opened the stale COM6 enumeration immediately after B9 and got FileNotFoundError(2); no second mode programming was done. A later --verify-only completed the reboot verification."
(SOURCE / "probe.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
summary = {}
for name in ("button_idle", "warmup", "prox12_idle"):
    rows = report[name]
    good = [row for row in rows if not row["error"]]
    summary[name] = {"rows": len(rows), "valid": len(good), "errors": len(rows) - len(good)}
    summary[name]["ranges"] = {key: {"min": min(r[key] for r in good), "median": statistics.median(r[key] for r in good), "max": max(r[key] for r in good)}
                              for key in ("raw", "baseline", "delta", "diff", "host_ms")}
snapshot = json.loads((SOURCE / "after_reboot/snapshot.json").read_text(encoding="utf-8"))
if not report["completed"] or snapshot["raw_status"] != "RAW=0" or any(snapshot["initial_input"][:32]):
    raise RuntimeError("restoration or normal slider state not verified")
uf2 = ROOT / "_dev_archive/round89j_device_before_20261001/Nyanithm_round89g.uf2"
uf2_hash = hashlib.sha256(uf2.read_bytes()).hexdigest()
if uf2_hash != "aa4a65dbbf98ccb809142bb765d8ace786a489baa742edc8aa32dc25daefc941":
    raise RuntimeError("unexpected firmware backup hash")
evidence = {"date": "2026-10-01", "experiment": "Native Proximity 12-bit idle interface check",
            "target": {"address": "0x42", "sensor": "CS0/PS0", "lane": 18}, "summary": summary,
            "candidate_applied": report["candidate_applied"], "restoration_completed": report["restoration_completed"],
            "after_reboot_controller_and_three_tables_equal": True, "raw_mode": snapshot["raw_status"],
            "preserved_native_proximity_filter": {"PROX_CFG": "0x80", "PROX_CFG2": 5, "ALP_enabled_on_mode_activation": True},
            "final_slider": snapshot["initial_input"][:32], "version": snapshot["version"],
            "uf2_backup_sha256": uf2_hash, "independent_readonly_review": "round89c_readonly_review: documented fields/CRC/protocol and failure restoration reviewed; pure-memory worker 3/3 passed; did not access hardware",
            "host_tests": {"idle_probe": "7/7", "per_job_capture": "9/9", "common_capture": "PASS", "browser_mock": "PASS: requests intercepted; countdown/restoring/blocking/labels/mobile/finish"},
            "no_cpp_or_production_panel_change": True,
            "limitations": ["Manual previous far-hand instruction, no new pose confirmation; not a distance sample", "40 valid C7 rows do not prove SNR or unique physical scans", "Warmup 6/12 native errors are preserved, not replaced with zeros", "Native mode acceptance does not establish contact/hover separation", "No production 32-lane reference gating or HID latency validation"]}
files = {}
for directory, prefix in ((SOURCE, "idle"), (ROOT / "_dev_archive/round89j_device_before_20261001", "before")):
    for path in directory.rglob("*"):
        if path.is_file() and path.suffix != ".uf2":
            files[f"{prefix}/{path.relative_to(directory).as_posix()}"] = path
for name in ("round89j_prox_idle.py", "test_round89j_prox_idle.py", "round89k_prox_capture.py", "test_round89k_prox_capture.py",
             "round89h_timed_capture.py", "round89h_timed_capture.html", "round89h_raw_capture.py", "round89g_latency_probe.py",
             "round89_live.py", "round89_live_debug.py", "test_round89h_timed_capture.py", "test_round89h_timed_ui.js", "round89j_package_evidence.py"):
    files["tools/" + name] = ROOT / "_dev_tools" / name
files["spec/MBR3116_round89i_Proximity实验规格.json"] = DOCS / "MBR3116_round89i_Proximity实验规格.json"
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
archive = DOCS / "MBR3116_round89j_原生模式检查原始.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, path in files.items():
        bundle.write(path, name)
    bundle.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
with zipfile.ZipFile(archive) as bundle:
    for name, digest in manifest.items():
        if hashlib.sha256(bundle.read(name)).hexdigest() != digest:
            raise RuntimeError("archive hash mismatch: " + name)
evidence["archive"] = {"name": archive.name, "files": len(manifest), "size": archive.stat().st_size,
                        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}
(DOCS / "MBR3116_round89j_原生模式检查证据.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(evidence, ensure_ascii=False, indent=2))
