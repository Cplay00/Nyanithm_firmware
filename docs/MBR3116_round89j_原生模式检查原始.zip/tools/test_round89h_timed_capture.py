import tempfile
import json
from pathlib import Path
from types import SimpleNamespace

import round89h_timed_capture as capture


class Port:
    def __init__(self, data):
        self.data = bytearray(data)
        self.writes = []

    def read(self, count):
        result = bytes(self.data[:count])
        del self.data[:count]
        return result

    def readline(self):
        return self.read(self.data.index(10) + 1)

    def write(self, data):
        self.writes.append(data)

    def flush(self):
        pass


data = bytes([0xC7, 0x40, 7, 8, 30]) + b"\xff\x00" + (2814).to_bytes(2, "little") + (3114).to_bytes(2, "little")
port = Port(data)
assert capture.read_native(port)["delta"] == 300
assert port.writes == [b"\xc7", bytes([0x40, 7])]
port = Port(b"3116 debug fail\r\n")
assert capture.read_native(port) == {"error": "3116 debug fail"} and not port.data
try:
    capture.read_native(Port(data[:1] + bytes([0x41]) + data[2:]))
    raise AssertionError("identity accepted")
except RuntimeError:
    pass

clock = 100


def now():
    global clock
    clock += .11
    return clock


capture.time = SimpleNamespace(perf_counter=now, time=lambda: 500)
sequence = 0


def fake_read(_):
    global sequence
    sequence += 1
    if sequence % 9 == 0:
        return {"error": "3116 debug fail"}
    return {"sync": sequence % 256, "cp_pf": 30, "diff": 255, "baseline": 2800, "raw": 3000,
            "delta": 200, "error": ""}


capture.read_native = fake_read
with tempfile.TemporaryDirectory() as directory:
    capture.OUT = Path(directory)
    job = {"id": "test", "mode": "finger_contact"}
    capture.capture_job(None, job, "test firmware")
    saved = json.loads((capture.OUT / "test.json").read_text())
    assert saved["completed"] and saved["user_confirmed"] is None
    for phase in ("baseline", "hold", "release"):
        summary = saved["summary"][phase]
        assert summary["valid"] > 0 and summary["errors"] > 0
        assert summary["delta"] == {"min": 200, "median": 200, "max": 200}
    assert capture.STATE["phase"] == "done" and not capture.STATE["running"]
    assert saved["phase_plan"][1] == {"phase": "hold", "start_s": 4, "end_s": 12}
print("PASS native frame, full error line, identity, timed phases, invalid-row exclusion, user labels")
