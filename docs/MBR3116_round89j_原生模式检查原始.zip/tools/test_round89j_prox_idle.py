import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import round89j_prox_idle as probe


class Port:
    def __init__(self):
        self.writes = []

    def write(self, data):
        self.writes.append(data)

    def flush(self):
        pass

    def close(self):
        pass


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.originals = {a: (probe.BASE / f"chip_{a:02x}.bin").read_bytes() for a in (0x40, 0x41, 0x42)}
        self.cfg = (probe.BASE / "controller_config.bin").read_bytes()
        self.report = {"restore_verified": False}
        self.port = Port()

    def test_documented_patch_and_threshold_order(self):
        original = self.originals[probe.ADDRESS]
        desired = probe.make_patch(original)
        spec = json.loads((probe.ROOT / "Nyanithm_firmware_hw_v1/docs/MBR3116_round89i_Proximity实验规格.json").read_text(encoding="utf-8"))
        changes = [{"offset": hex(i), "original": original[i], "planned": desired[i]} for i in range(128) if original[i] != desired[i]]
        self.assertEqual(changes, spec["predicted_changed_bytes"])
        invalid = bytearray(original)
        invalid[0x2A:0x2C] = (100).to_bytes(2, "little")
        invalid[126:128] = probe.crc(invalid).to_bytes(2, "little")
        with self.assertRaisesRegex(RuntimeError, "base threshold"):
            probe.make_patch(invalid)

    def test_restore_does_not_need_candidate_readback(self):
        with patch.object(probe, "program", return_value=["done"]) as write, \
             patch.object(probe, "read_chip", side_effect=lambda p, a: self.originals[a]), \
             patch.object(probe.live, "config_read", return_value=(self.cfg, "")):
            probe.restore(self.port, self.originals, self.cfg, self.report)
        write.assert_called_once_with(self.port, self.originals[probe.ADDRESS])
        self.assertTrue(self.report["restore_verified"])

    def test_failed_program_or_readback_retries_original(self):
        for failure in ("program", "read_chip"):
            with self.subTest(failure=failure):
                report = {"restore_verified": False}
                count = {"program": 0, "read_chip": 0}

                def program(p, table):
                    count["program"] += 1
                    self.assertEqual(table, self.originals[probe.ADDRESS])
                    if failure == "program" and count["program"] == 1:
                        raise RuntimeError("response timeout")
                    return ["done"]

                def read_chip(p, address):
                    count["read_chip"] += 1
                    if failure == "read_chip" and count["read_chip"] == 1:
                        raise RuntimeError("short response")
                    return self.originals[address]

                with patch.object(probe, "program", side_effect=program), \
                     patch.object(probe, "read_chip", side_effect=read_chip), \
                     patch.object(probe.live, "config_read", return_value=(self.cfg, "")):
                    probe.restore(self.port, self.originals, self.cfg, report)
                self.assertEqual(count["program"], 2)
                self.assertTrue(report["restore_verified"])
                self.assertIn("error", report["restore_attempts"][0])

    def test_unrestored_mismatch_is_not_success(self):
        with patch.object(probe, "program", return_value=["done"]), \
             patch.object(probe, "read_chip", side_effect=lambda p, a: self.originals[a]), \
             patch.object(probe.live, "config_read", return_value=(b"changed", "")):
            with self.assertRaisesRegex(RuntimeError, "could not verify"):
                probe.restore(self.port, self.originals, self.cfg, self.report)
        self.assertFalse(self.report["restore_verified"])
        self.assertEqual(len(self.report["restore_attempts"]), 2)

    def test_invalid_samples_cannot_pass(self):
        probe.validate_samples([{"error": "", "raw": 3000, "baseline": 3000}] * 10)
        for rows in ([], [{"error": "timeout"}] * 10, [{"error": "", "raw": 0, "baseline": 1}] * 10):
            with self.assertRaisesRegex(RuntimeError, "missing or invalid"):
                probe.validate_samples(rows)

    def test_candidate_timeout_still_checks_restoration_after_reboot(self):
        def snapshot(folder):
            self.assertIn(b"\xb9", self.port.writes)
            for a, table in self.originals.items():
                (folder / f"chip_{a:02x}.bin").write_bytes(table)
            (folder / "controller_config.bin").write_bytes(self.cfg)

        with tempfile.TemporaryDirectory() as directory, \
             patch.object(probe, "OUT", Path(directory) / "output"), \
             patch.object(probe, "ARCHIVE", Path(directory) / "archive"), \
             patch.object(probe.shutil, "copy2"), \
             patch.object(probe, "connect_checked", return_value=(self.port, SimpleNamespace(serial_number="test"))), \
             patch.object(probe.live, "connect"), \
             patch.object(probe.live, "version", return_value="BID=round89g"), \
             patch.object(probe.live, "tail", return_value=""), \
             patch.object(probe.live, "config_read", return_value=(self.cfg, "")), \
             patch.object(probe, "read_chip", side_effect=lambda p, a: self.originals[a]), \
             patch.object(probe, "samples", return_value=[{"error": "", "raw": 3000, "baseline": 3000}] * 20), \
             patch.object(probe, "program", side_effect=[RuntimeError("candidate response timeout"), ["done"]]), \
             patch.object(probe.live, "snapshot", side_effect=snapshot) as final_check:
            with self.assertRaisesRegex(RuntimeError, "experiment failed; original configuration verified after reboot"):
                probe.main()
            final_check.assert_called_once()
            result = json.loads((probe.OUT / "probe.json").read_text())
        self.assertTrue(result["restoration_completed"])
        self.assertFalse(result["completed"])
        self.assertIn("candidate response timeout", result["error"])

    def test_reboot_open_race_retries_but_wrong_identity_does_not(self):
        with patch.object(probe, "connect_checked", side_effect=[probe.serial.SerialException("device removed"), (self.port, "info")]) as connect, \
             patch.object(probe.time, "sleep"):
            self.assertEqual(probe.connect_reboot_ready(), (self.port, "info"))
            self.assertEqual(connect.call_count, 2)
        with patch.object(probe, "connect_checked", side_effect=RuntimeError("unexpected firmware")) as connect:
            with self.assertRaisesRegex(RuntimeError, "unexpected firmware"):
                probe.connect_reboot_ready()
            self.assertEqual(connect.call_count, 1)


if __name__ == "__main__":
    unittest.main()
