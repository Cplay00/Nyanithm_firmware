"""Offline-only verification of the frozen round90o deployment evidence ZIP.

No serial dependency, extraction, device access, or firmware/config writing.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if len(set(names)) != len(names) or z.testzip() is not None:
            raise ValueError('duplicate ZIP members or CRC failure')
        manifest = json.loads(z.read('manifest.json'))
        if set(names) != set(manifest['files']) | {'manifest.json'}:
            raise ValueError('package member set differs from manifest')
        for name, expected in manifest['files'].items():
            if sha(z.read(name)) != expected:
                raise ValueError(f'package member hash differs: {name}')
        report = json.loads(z.read('deployment.json'))
        if not report['completed'] or report['beta13_deployed']:
            raise ValueError('unexpected deployment outcome')
        before = z.read('before/controller_config.bin')
        after = z.read('after/controller_config.bin')
        checksum = 0
        for byte in before:
            checksum ^= byte
        if before != after or len(before) != 128 or before[:2] != b'\x88\x02' or checksum:
            raise ValueError('controller config equality/length/magic/checksum failed')
        if sha(before) != report['before']['controller_config_sha256']:
            raise ValueError('config hash differs from live report')
        native_checks, gain_changes = 0, {}
        for address in ('5a', '5b', '5c'):
            a = z.read(f'before/mpr_{address}.bin')
            b = z.read(f'after/mpr_{address}.bin')
            if len(a) != 128 or len(b) != 128:
                raise ValueError('incomplete register image')
            for register in list(range(0x2B, 0x5F)) + list(range(0x73, 0x80)):
                if a[register] != b[register]:
                    raise ValueError(f'static control differs: {address} {register:#x}')
                native_checks += 1
            if any(a[:4]) or any(b[:4]):
                raise ValueError('nonzero sampled touch/OOR status')
            changes = [{'register': f'0x{i:02X}', 'before': a[i], 'after': b[i]}
                       for i in range(0x5F, 0x73) if a[i] != b[i]]
            if changes != report['native_parameter_comparison'][f'0x{address}']['startup_retunable_cdc_cdt_changes']:
                raise ValueError('gain comparison does not reproduce live bytes')
            gain_changes[address] = changes
        for stage, filename, expected_hash, signature in (
                ('recovery', 'firmware/Nyanithm_beta11_round90g.uf2',
                 '4412c8af403cba32125cc7135628b6c193d278cbfeeac944022ccfcad35f34d1',
                 b'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g'),
                ('deployed', 'firmware/Nyanithm_beta12_round90m.uf2',
                 'd9e760c66dd45645a32df2133d7dffbcd8b067b0f2f9e2ac365c57ed3b369e9c',
                 b'NYANFW1;1.6.6-beta12;hw_v1;BID=round90m')):
            data = z.read(filename)
            if sha(data) != expected_hash or len(data) % 512:
                raise ValueError(f'{stage} UF2 hash/length failed')
            addresses, payloads = set(), []
            for offset in range(0, len(data), 512):
                m0, m1, flags, target, size, block, count, family = struct.unpack_from('<8I', data, offset)
                if ((m0, m1, flags, family) != (0x0A324655, 0x9E5D5157, 0x2000, 0xE48BFF56)
                        or size != 256 or block != offset // 512 or count != len(data) // 512
                        or target in addresses or target < 0x10000000 or target + size > 0x101FF000
                        or struct.unpack_from('<I', data, offset + 508)[0] != 0x0AB16F30):
                    raise ValueError(f'{stage} UF2 metadata/address failed')
                addresses.add(target)
                payloads.append(data[offset + 32:offset + 288])
            if signature not in b''.join(payloads):
                raise ValueError(f'{stage} UF2 identity failed')
        normal = report['final_normal']
        frames = normal['idle_frames']
        if (normal['raw_status'] != 'RAW=0' or not normal['serial_closed'] or len(frames) != 30
                or any(len(f) != 33 or any(f[:32]) for f in frames)):
            raise ValueError('ordinary input / idle / serial closure check failed')
        return {'zip_members': len(names), 'member_hashes_verified': len(manifest['files']),
                'controller_config_bytes_equal': 128, 'static_mpr_register_comparisons': native_checks,
                'native_idle_images': 6, 'native_idle_on_or_oor': 0, 'normal_idle_zero_frames': 30,
                'gain_changes': gain_changes, 'beta12_signature_verified': True,
                'beta13_deployed': False, 'gameplay_acceptance': report['gameplay_acceptance'],
                'source_archives_not_in_zip': manifest['source_archives_local_backup_only']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = verify(args.package)
    text = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.out:
        args.out.write_text(text, encoding='utf-8')
    print(text, end='')


if __name__ == '__main__':
    main()
