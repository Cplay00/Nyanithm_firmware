Round90d verified local evidence. Read manifest.json and source/logs first.
Historical JSONs are not new measurements. Hardware helpers are records of executed operations, not an automatic replay entrypoint; snapshot/flash scripts expect their original firmware and device identity.
Offline replays preserve workspace-relative paths and need the included production source.
No new anti-hover classifier was deployed. User feedback: normal feel, hover remains.
