/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2026 Catium2006
 */

#ifndef __I2C_PORT_H__
#define __I2C_PORT_H__

#include <hardware/i2c.h>
#include <i2c_config.h>

int i2c_write(uint8_t port, uint8_t addr, uint8_t* src, size_t len, bool nostop);
int i2c_read(uint8_t port, uint8_t addr, uint8_t* dst, size_t len, bool nostop);
int i2c_write_read(uint8_t port, uint8_t addr, uint8_t* wr, size_t wr_len, uint8_t* rd, size_t rd_len);
int i2c_write_stop_read(uint8_t port, uint8_t addr, uint8_t reg, uint8_t* rd, size_t rd_len);

void initI2CBus(uint8_t port, uint gpio_sda, uint gpio_scl, uint baudrate);

void scanI2CBus(uint8_t port);

bool findI2CDevice(uint8_t port, uint8_t address, uint32_t timeout_ms = 10);

#endif
