"""Replay existing counterexamples in new directories; never overwrite inputs."""
import contextlib
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

import round89x_analyze_trace as amplitude
import round89z_analyze as spatial

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90d_replay_20261003'
OUT.mkdir(exist_ok=False)
inputs = {}
reports = {}
for name, folder, analyzer in (
    ('instantaneous', 'round89x_trace_20261002', amplitude.analyze),
    ('spatial', 'round89z_trace_20261002', spatial.analyze),
):
    destination = OUT / name
    destination.mkdir()
    for path in sorted((ROOT / '_dev_tools' / folder).glob('*.json')):
        inputs[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
        shutil.copy2(path, destination / path.name)
    with (destination / 'replay_console.txt').open('w', encoding='utf-8') as stream, contextlib.redirect_stdout(stream):
        reports[name] = analyzer(destination)

result_path = OUT / 'temporal.json'
subprocess.run([sys.executable, str(ROOT / '_dev_tools/round90b_candidate_check.py'),
                '--plan', str(ROOT / '_dev_tools/round90b_candidate_20261002.json'),
                '--events', str(ROOT / '_dev_tools/round90b_stress_20261002'),
                '--out', str(result_path), '--stress'], check=True)
temporal = json.loads(result_path.read_text(encoding='utf-8'))
assert len(temporal['counterexamples']) == 2 and temporal['qualified'] == 2 and temporal['inconclusive'] == 2
assert len(temporal['excluded_jobs']) == 2
for name, sha in inputs.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha
summary = {
    'input_sha256': inputs,
    'instantaneous_jobs': len(reports['instantaneous']['jobs']),
    'instantaneous_shared_nonzero_vectors': reports['instantaneous']['overlap'],
    'spatial_groups': len(reports['spatial']['groups']),
    'spatial_qualified_frames': sum(g['qualified'] for g in reports['spatial']['groups']),
    'temporal_qualified': temporal['qualified'], 'temporal_inconclusive': temporal['inconclusive'],
    'temporal_counterexamples': temporal['counterexamples'], 'temporal_excluded_jobs': len(temporal['excluded_jobs']),
    'interpretation': 'Historical records replayed; no new hardware gesture, accuracy percentage or independent scan rate inferred.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in summary.items() if k not in ('input_sha256', 'instantaneous_shared_nonzero_vectors')}, ensure_ascii=False, indent=2))
