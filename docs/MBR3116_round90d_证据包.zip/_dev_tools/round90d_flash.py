"""Reuse the bounded, identity-checked UF2 updater; keep current config/NVRAM."""
import round89c_flash_probe as probe
from round89g_latency_probe import connect_target

probe.live.connect = connect_target
probe.OUT = probe.WORKSPACE / '_dev_tools/round90d_flash_20261003'
probe.UF2 = probe.WORKSPACE / 'Nyanithm_firmware_hw_v1/build_round90d/Nyanithm.uf2'
probe.EXPECTED_SHA256 = 'd39a458f35a5532f5d64d5fb42345b271411aeeca7746ed540e2ecddbdb55530'
probe.SIGNATURE = 'NYANFW1;1.6.6-beta9;hw_v1;BID=round90d'
probe.BASELINE_BUILD_ID = 'round90b'
probe.DEVICE_BACKUP = probe.WORKSPACE / '_dev_archive/round90d_flash_before_20261003'
if __name__ == '__main__':
    probe.main()
