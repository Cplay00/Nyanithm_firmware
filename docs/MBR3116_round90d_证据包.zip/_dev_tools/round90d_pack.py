"""Verify and archive round90d evidence; no device or persistent-config operations."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'Nyanithm_firmware_hw_v1'
DOCS = REPO / 'docs'
PREFIX = 'MBR3116_round90d_'
FILES = ('controller_config.bin', 'chip_40.bin', 'chip_41.bin', 'chip_42.bin')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    idle = read_json(ROOT / '_dev_tools/round90d_idle_20261003/idle_map.json')
    assert idle['completed'] and idle['user_confirmed_clear_20cm']
    valid = [row for row in idle['rows'] if row['valid']]
    mapped = [row for row in valid if row['lane'] is not None]
    assert len(idle['rows']) == 72 and len(valid) == 71 and len(mapped) == 63
    lanes = {}
    for row in mapped:
        lanes.setdefault(row['lane'], []).append(row['cp_pf'])
    assert sorted(lanes) == list(range(1, 33))
    assert all(len(set(values)) == 1 for values in lanes.values())
    assert min(min(v) for v in lanes.values()) == 11 and max(max(v) for v in lanes.values()) == 33
    assert all(row['diff'] == 0 for row in valid)
    assert max(abs(row['raw_minus_baseline']) for row in valid) == 2

    baseline = ROOT / '_dev_archive/round90d_before_20261003'
    after_diag = ROOT / '_dev_tools/round90d_after_diagnostics_20261003'
    flashed = ROOT / '_dev_tools/round90d_flash_20261003'
    flash = read_json(flashed / 'flash_probe.json')
    assert flash['completed'] and flash['controller_config_equal'] and all(flash['chips_equal'].values())
    assert flash['raw_status_final'] == 'RAW=0' and flash['profile_after'][2] == 0
    assert flash['signature'] == 'NYANFW1;1.6.6-beta9;hw_v1;BID=round90d'
    final_path = ROOT / '_dev_tools/round90d_final_state_20261003.json'
    final = read_json(final_path)
    assert final['usb_serial'] == '5303284739002C9C' and flash['signature'] in final['version']
    assert final['raw_status'] == 'RAW=0' and final['history']['state'] == 0 and final['history']['pending'] == 0
    config_sha = {}
    for name in FILES:
        original = (baseline / name).read_bytes()
        assert all((folder / name).read_bytes() == original for folder in (after_diag, flashed / 'before', flashed / 'after'))
        config_sha[name] = sha(baseline / name)
    uf2 = REPO / 'build_round90d/Nyanithm.uf2'
    assert uf2.stat().st_size == 196096 and sha(uf2) == flash['uf2_sha256']
    assert sha(baseline / 'round90b.uf2') == '2c59f8be0289a2bacbca40a7fadc59d83e32d48f76a278c9e7a0667dd2335d18'

    checks = ROOT / '_dev_tools/round90d_checks_20261003'
    for name, marker in (
        ('migration_before.txt', 'All 138 tests PASSED'),
        ('migration_after.txt', 'All 138 tests PASSED'),
        ('driver_before.txt', '21/21 production driver tests passed'),
        ('driver_after.txt', '27/27 production driver tests passed'),
        ('driver_regression_before_fix.txt', 'reg == expectedRegister && count == expectedSize'),
    ):
        assert marker in (checks / name).read_text(encoding='utf-8-sig')
    assert '42/42 scenarios, 72794 checks' in (ROOT / '_dev_tools/round90d_pipeline_console.txt').read_text(encoding='utf-8-sig')
    pipeline = read_json(ROOT / '_dev_tools/round90d_pipeline_20261003/results.json')
    # The integration harness hashes C++ read_text(), which normalizes CRLF.
    # Its header hashes instead use exact bytes; match each recorded convention.
    for name, key in (('src/hw_devices.cpp', 'source_sha256'), ('src/cy8cmbr3116.cpp', 'driver_sha256')):
        assert hashlib.sha256((REPO / name).read_text(encoding='utf-8').encode()).hexdigest() == pipeline[key]
    for name, expected in pipeline['header_sha256'].items():
        assert sha(Path(name)) == expected
    assert '28/28 production-reader scenarios passed' in (ROOT / '_dev_tools/round90d_readers_console.txt').read_text(encoding='utf-8-sig')
    assert 'UF2: 196096 bytes' in (ROOT / '_dev_tools/round90d_build_console.txt').read_text(encoding='utf-8-sig')
    replay = read_json(ROOT / '_dev_tools/round90d_replay_20261003/summary.json')
    assert replay['temporal_qualified'] == 2 and len(replay['temporal_counterexamples']) == 2
    for name, expected in replay['input_sha256'].items():
        assert sha(ROOT / name) == expected

    feedback_path = ROOT / '_dev_tools/round90d_gameplay_feedback_20261003.json'
    if not feedback_path.exists():
        save(feedback_path, {
            'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
            'question': '已刷入round90d读取修复，请在游戏中试轻触、慢触、快速连打、多指、滑动，反馈手感变化和隔空。',
            'user_reply_exact': '手感正常，隔空仍存在',
            'firmware': flash['signature'],
            'interpretation': 'Qualitative user gameplay feedback; no counted trials or measured physical-contact-to-HID latency.',
        })

    review_path = ROOT / '_dev_tools/round90d_readonly_review_20261003.txt'
    assert review_path.is_file()
    patch_path = ROOT / '_dev_tools/round90d_firmware_diff.patch'
    result = subprocess.run(['git', '-C', str(REPO), 'diff', '--',
                             'include/share/nyanithm_shared.h', 'src/cy8cmbr3116.cpp',
                             'tools/test_mbr3116_difference_counts.py'], check=True, capture_output=True)
    patch_path.write_bytes(result.stdout)
    source_before = ROOT / '_dev_tools/round90d_source_before_20261003'
    source_before.mkdir(exist_ok=True)
    # Full source archives contain previous evidence ZIPs; keep them in the
    # existing local backup and include only the three affected baseline files.
    with zipfile.ZipFile(baseline / 'source.zip') as old_source:
        for name in ('src/cy8cmbr3116.cpp', 'include/share/nyanithm_shared.h', 'tools/test_mbr3116_difference_counts.py'):
            destination = source_before / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(old_source.read(name))

    included = set()
    for folder in (
        baseline, after_diag, flashed, checks, source_before,
        ROOT / '_dev_tools/round90d_idle_20261003',
        ROOT / '_dev_tools/round90d_pipeline_20261003',
        ROOT / '_dev_tools/round90d_replay_20261003',
        ROOT / '_dev_tools/round90b_stress_20261002',
    ):
        included.update(path for path in folder.rglob('*') if path.is_file() and path.suffix not in ('.exe', '.obj') and path.name != 'source.zip')
    included.update((uf2, feedback_path, review_path, patch_path, final_path))
    included.add(ROOT / '_dev_tools/round90b_candidate_20261002.json')
    included.update(ROOT / '_dev_tools' / name for name in (
        'round90d_build_console.txt', 'round90d_flash_console.txt',
        'round90d_pipeline_console.txt', 'round90d_readers_console.txt', 'round90d_replay_console.txt'))
    # Preserve actual changed source and the production test inputs.
    for folder in (REPO / 'src', REPO / 'include'):
        included.update(path for path in folder.rglob('*') if path.is_file())
    included.update(REPO / 'tools' / name for name in (
        'test_round50_migration.py', 'test_mbr3116_difference_counts.py',
        'test_mbr_distance_pipeline.py', 'test_touch_snapshot_readers.py', 'build_firmware.ps1'))
    # Keep local helper imports recursively so offline analyses remain inspectable.
    pending = [ROOT / '_dev_tools' / name for name in (
        'round90d_readonly.py', 'round90d_replay.py', 'round90d_flash.py', 'round90d_pack.py')]
    visited = set()
    while pending:
        path = pending.pop()
        if path in visited:
            continue
        visited.add(path)
        included.add(path)
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig'))):
            names = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module] if isinstance(node, ast.ImportFrom) else []
            for name in names:
                if name:
                    local = ROOT / '_dev_tools' / (name.split('.')[0] + '.py')
                    if local.is_file() and local not in visited:
                        pending.append(local)
    file_map = {path.relative_to(ROOT).as_posix(): {'size': path.stat().st_size, 'sha256': sha(path)} for path in sorted(included)}
    manifest = {
        'date': '2026-10-03', 'baseline_head': '20b4af4', 'firmware': flash['signature'],
        'full_source_backup_local_only': {'path': str(baseline / 'source.zip'), 'sha256': sha(baseline / 'source.zip'),
                                          'reason': 'Full baseline archive retains prior evidence ZIPs; affected old files are included separately.'},
        'usb_serial': '5303284739002C9C', 'persistent_config_writes': False,
        'config_sha256_before_after': config_sha, 'profile_enabled': False,
        'idle': {'observations': 72, 'valid': 71, 'mapped_valid': 63,
                 'lane_cp_pf': {str(k): lanes[k][0] for k in sorted(lanes)},
                 'errors': [row for row in idle['rows'] if not row['valid']],
                 'max_diff': 0, 'max_abs_raw_minus_baseline': 2,
                 'unmapped_cp_pf': sorted(set(row['cp_pf'] for row in valid if row['lane'] is None))},
        'tests': {'migration_before_after': [138, 138], 'driver_before': 21, 'driver_after': 27,
                  'old_driver_fails_new_regression': True, 'pipeline_scenarios': 42,
                  'pipeline_checks': 72794, 'reader_scenarios': 28, 'tested_source_hashes_match': True},
        'flash': flash, 'final_device_state': final, 'gameplay': read_json(feedback_path),
        'limits': ['Hover remains; no new classifier deployed.',
                   'Profile-off legacy failure handling can still form a new HID ON.',
                   'No worst-case end-to-end timing measurement.',
                   'No live snapshot of the replacement MPR modules.',
                   'CDC probe was uncontrolled and its gate error counter excludes profile-off reads.'],
        'files': file_map,
    }
    package = DOCS / (PREFIX + '证据包.zip')
    with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(included):
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        archive.writestr('README.txt', 'Round90d verified local evidence. Read manifest.json and source/logs first.\nHistorical JSONs are not new measurements. Hardware helpers are records of executed operations, not an automatic replay entrypoint; snapshot/flash scripts expect their original firmware and device identity.\nOffline replays preserve workspace-relative paths and need the included production source.\nNo new anti-hover classifier was deployed. User feedback: normal feel, hover remains.\n')
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None
        for name, entry in file_map.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == entry['sha256']
    manifest['archive'] = {'filename': package.name, 'size': package.stat().st_size, 'sha256': sha(package), 'verified_entries': len(file_map)}
    save(DOCS / (PREFIX + '证据核对.json'), manifest)
    print(json.dumps({'archive': manifest['archive'], 'config_equal_4_of_4': True,
                      'tests_verified': manifest['tests'], 'gameplay': manifest['gameplay']['user_reply_exact']}, ensure_ascii=True, indent=2))


if __name__ == '__main__':
    main()
