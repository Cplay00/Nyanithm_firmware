#include <touch_snapshot.h>
#define SYNC_COUNTER0_ADDRESS 0xb9
#define SYNC_COUNTER1_ADDRESS 0xdb

#include <stdint.h>
#include <stddef.h>
#include <mbr_distance_gate.h>
#include <pico/error.h>

extern "C" __declspec(dllimport) void* __stdcall GetStdHandle(unsigned long);
extern "C" __declspec(dllimport) int __stdcall WriteFile(void*, const void*, unsigned long, unsigned long*, void*);
extern "C" __declspec(dllimport) char* __stdcall GetCommandLineA();
extern "C" __declspec(dllimport) void __stdcall ExitProcess(unsigned int);
extern "C" void* memset(void* destination, int value, size_t count) {
    volatile unsigned char* bytes = static_cast<volatile unsigned char*>(destination);
    for (size_t i = 0; i < count; ++i) bytes[i] = static_cast<unsigned char>(value);
    return destination;
}
extern "C" void* memcpy(void* destination, const void* source, size_t count) {
    volatile unsigned char* out = static_cast<volatile unsigned char*>(destination);
    const volatile unsigned char* in = static_cast<const volatile unsigned char*>(source);
    for (size_t i = 0; i < count; ++i) out[i] = in[i];
    return destination;
}
extern "C" int memcmp(const void* left, const void* right, size_t count) {
    const unsigned char* a = static_cast<const unsigned char*>(left);
    const unsigned char* b = static_cast<const unsigned char*>(right);
    for (size_t i = 0; i < count; ++i) if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
    return 0;
}
namespace std { using ::memset; using ::memcpy; using ::memcmp; }
static unsigned checks = 0;
static void writeText(const char* text) {
    unsigned long size = 0, written = 0;
    while (text[size]) ++size;
    WriteFile(GetStdHandle(static_cast<unsigned long>(-11)), text, size, &written, nullptr);
}
static void writeNumber(unsigned value) {
    char digits[11]; unsigned count = 0;
    do { digits[count++] = static_cast<char>('0' + value % 10); value /= 10; } while (value);
    for (unsigned i = 0; i < count / 2; ++i) {
        char tmp = digits[i]; digits[i] = digits[count - i - 1]; digits[count - i - 1] = tmp;
    }
    unsigned long written = 0;
    WriteFile(GetStdHandle(static_cast<unsigned long>(-11)), digits, count, &written, nullptr);
}
static void check(bool condition, const char* expression, unsigned line) {
    ++checks;
    if (!condition) {
        writeText("FAIL line "); writeNumber(line); writeText(": "); writeText(expression); writeText("\n");
        ExitProcess(1);
    }
}
#define CHECK(expression) check((expression), #expression, __LINE__)
static uint32_t fakeNow = 100;
static uint8_t readOrder[64];
static unsigned readOrderCount = 0;
static uint32_t get_absolute_time() { return fakeNow; }
static uint32_t to_ms_since_boot(uint32_t time) { return time; }

int i2c_write_stop_read(uint8_t, uint8_t, uint8_t, uint8_t*, size_t);
class CY8CMBR3116 {
public:
    uint8_t i2c_port = 1, DEVICE_I2C_ADDRESS = 0;
    uint16_t hardwareBits = 0;
    uint16_t counts[16] = {0};
    unsigned coherentReads = 0, legacyReads = 0, statusReads = 0;
    uint32_t delayMs = 0;
    bool readFails = false, statusFails = false;
    unsigned tornReadsRemaining = 0;
    unsigned genericFailuresRemaining = 0;
    uint8_t get_BUTTON_STAT(uint8_t* result) {
        ++statusReads;
        if (statusFails) return 1;
        result[0] = hardwareBits & 0xFF; result[1] = hardwareBits >> 8;
        return 0;
    }
    uint8_t get_DIFFERENCE_COUNT_SENSOR(uint16_t* result) {
        ++legacyReads;
        if (readFails) return 1;
        for (unsigned i = 0; i < 16; ++i) result[i] = counts[i];
        return 0;
    }
    int fakeReadRegisters(uint8_t address, uint8_t count, uint8_t* result) {
        CHECK(address == SYNC_COUNTER0_ADDRESS);
        CHECK(count == SYNC_COUNTER1_ADDRESS - SYNC_COUNTER0_ADDRESS + 1);
        ++coherentReads;
        CHECK(readOrderCount < 64);
        readOrder[readOrderCount++] = DEVICE_I2C_ADDRESS;
        fakeNow += delayMs;
        if (readFails) return PICO_ERROR_TIMEOUT;
        if (genericFailuresRemaining) { --genericFailuresRemaining; return PICO_ERROR_GENERIC; }
        result[0] = 7;
        for (unsigned i = 0; i < 16; ++i) {
            result[1 + 2 * i] = counts[i] & 0xFF;
            result[2 + 2 * i] = counts[i] >> 8;
        }
        result[count - 2] = 0;  // GPO_DATA is not a difference count.
        result[count - 1] = tornReadsRemaining ? 8 : 7;
        if (tornReadsRemaining) --tornReadsRemaining;
        return count;
    }
    uint8_t requestDataFromAddress(uint8_t address, uint8_t count, uint8_t* result);
    struct DifferenceReadInfo { uint8_t ioFailures = 0, syncMismatches = 0, sync = 0; };
    bool readDifferenceCounts(uint16_t result[16], DifferenceReadInfo* info = nullptr,
                              bool singleAttempt = false);
};
class MPR121 {
public:
    uint16_t hardwareBits = 0;
    uint16_t differences[12] = {0};
    unsigned dataReads = 0;
    uint16_t touched() { return hardwareBits; }
    uint16_t filteredData(uint8_t) { ++dataReads; return 1000; }
    uint16_t baselineData(uint8_t electrode) { ++dataReads; return 1000 + differences[electrode]; }
};
controller_config ControllerConfig = {};
CY8CMBR3116 MBR3116A, MBR3116B, MBR3116C, MBR3116D, MBR3116E;
int i2c_write_stop_read(uint8_t port, uint8_t address, uint8_t reg, uint8_t* result, size_t count) {
    CHECK(port == 1);
    CY8CMBR3116* chips[] = {&MBR3116A, &MBR3116B, &MBR3116C, &MBR3116D, &MBR3116E};
    for (CY8CMBR3116* chip : chips)
        if (chip->DEVICE_I2C_ADDRESS == address) return chip->fakeReadRegisters(reg, static_cast<uint8_t>(count), result);
    CHECK(false);
    return PICO_ERROR_INVALID_ARG;
}
MPR121 mpr0, mpr1, mpr2;
#define GET_BIT(UNUM, BIT) (UNUM & (1 << BIT))


#line 648 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/cy8cmbr3116.cpp"
uint8_t CY8CMBR3116::requestDataFromAddress(uint8_t registerAddress, uint8_t count, uint8_t* resultBuffer) {
    // MBR3 can NACK while waking; bound retries without repeating a timeout.
    for (uint8_t attempt = 0; attempt < 3; ++attempt) {
        int ret = i2c_write_stop_read(i2c_port, DEVICE_I2C_ADDRESS, registerAddress, resultBuffer, count);
        if (ret == count) return 0;
        if (ret != PICO_ERROR_GENERIC) return 1;
    }
    return 1;
}


#line 530 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/cy8cmbr3116.cpp"
bool CY8CMBR3116::readDifferenceCounts(uint16_t resultBuffer[16], DifferenceReadInfo* info,
                                     bool singleAttempt) {
    DifferenceReadInfo local{};
    if (!info) info = &local;
    *info = DifferenceReadInfo{};
    if (resultBuffer == nullptr) return false;

    // Infineon CY8CMBR3xxx_ReadDiffCounts: SYNC0, 16 little-endian
    // differences, GPO_DATA, SYNC1. Bound retries to limit scan-loop latency.
    constexpr uint8_t SNAPSHOT_SIZE = SYNC_COUNTER1_ADDRESS - SYNC_COUNTER0_ADDRESS + 1;
    const uint8_t maxAttempts = singleAttempt ? 1 : 2;
    uint8_t snapshot[SNAPSHOT_SIZE];
    for (uint8_t attempt = 0; attempt < maxAttempts; attempt++) {
        if (requestDataFromAddress(SYNC_COUNTER0_ADDRESS, SNAPSHOT_SIZE, snapshot) != 0) {
            ++info->ioFailures;
            return false;
        }
        if (snapshot[0] != snapshot[SNAPSHOT_SIZE - 1]) {
            ++info->syncMismatches;
            continue;
        }

        // Publish only after the whole transfer and both sync bytes validate.
        // Disabled sensors have undefined values; callers filter their mapping.
        for (uint8_t sensor = 0; sensor < 16; sensor++) {
            resultBuffer[sensor] = (uint16_t)snapshot[1 + sensor * 2]
                | ((uint16_t)snapshot[2 + sensor * 2] << 8);
        }
        info->sync = snapshot[0];
        return true;
    }
    return false;
}


#line 166 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static const uint8_t V1_LANE_M[32] = {
    1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1,
    0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2
};
static const uint8_t V1_LANE_E[32] = {
    11, 0, 10, 1, 9, 2, 8, 3, 11, 4, 10, 5, 9, 6, 8, 7,
    7, 0, 6, 1, 5, 2, 4, 3, 3, 4, 2, 5, 1, 6, 0, 7
};
static const uint8_t V2_LANE_M[32] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
static const uint8_t V2_LANE_E[32] = {
    4, 0, 5, 1, 6, 2, 7, 3, 8, 15, 9, 14, 10, 13, 11, 12,
    12, 11, 13, 10, 14, 9, 15, 8, 3, 7, 2, 6, 1, 5, 0, 4
};
static int16_t laneTable[3][16];  // -1 = electrode not mapped to a lane

static void buildLaneTable() {
    for (int m = 0; m < 3; m++)
        for (int e = 0; e < 16; e++) laneTable[m][e] = -1;
    bool v2 = (ControllerConfig.hwVer == 3 || ControllerConfig.hwVer == 4);
    const uint8_t* lm = v2 ? V2_LANE_M : V1_LANE_M;
    const uint8_t* le = v2 ? V2_LANE_E : V1_LANE_E;
    for (uint8_t lane = 0; lane < 32; lane++) {
        uint8_t m = lm[lane], e = le[lane];
        if (m < 3 && e < 16) laneTable[m][e] = lane;
    }
}

static uint8_t electrodeBaseTouchTh(uint8_t m, uint8_t e) {
    // round64: config-driven per-lane touch threshold. laneTable maps the
    // physical electrode back to its slider lane (game view); 0 = inherit the
    // global th_touch. This replaces the round46 unified-threshold skeleton:
    // the old per-electrode override table (round45b) is superseded by the
    // v1.6 per-key config fields.
    int16_t lane = laneTable[m][e];
    if (lane >= 0 && ControllerConfig.thTouchKey[lane] != 0) {
        return ControllerConfig.thTouchKey[lane];
    }
    return 0;  // inherit global ControllerConfig.th_touch
}

static uint8_t electrodeBaseReleaseTh(uint8_t m, uint8_t e) {
    // round64: release twin of electrodeBaseTouchTh. MPR121 only (MBR has no
    // per-sensor release register). 0 = inherit global th_release.
    int16_t lane = laneTable[m][e];
    if (lane >= 0 && ControllerConfig.thReleaseKey[lane] != 0) {
        return ControllerConfig.thReleaseKey[lane];
    }
    return 0;  // inherit global ControllerConfig.th_release
}




#line 370 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
uint8_t touchData[4];
uint8_t touchData32[32];
uint16_t rawTouch[3] = {0, 0, 0};  // non-static for CMD_DEBUG_CHAIN access  // raw 16-bit touch data for stuck-key detection
uint16_t hwTouch[3] = {0, 0, 0};   // round45p: pre-verification hardware touch snapshot for CMD_DEBUG_CHAIN (zero I2C overhead)
uint32_t lastTouchedMs[3][12] = {0};  // round45m: last touch timestamp per electrode (baseline correction skips recently-touched)

TouchInputSnapshot publishedTouchState{};
MbrTouchTrace publishedMbrTrace{};
volatile uint32_t touchStateGen = 0;

// round46: telemetry shared from Core0 to Core1 (CMD_DEBUG_TELEMETRY = 0xC1)
uint8_t  g_verifyFail[36] = {0};          // per-electrode I2C verification rejections
uint32_t g_loopMinUs = 0xFFFFFFFF, g_loopMaxUs = 0, g_loopSumUs = 0, g_loopCount = 0;




uint8_t pressureSnap[32] = {0};


#line 399 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static const uint32_t MBR_DISTANCE_POLL_MS = 5;
static const uint32_t MBR_DISTANCE_MAX_READ_AGE_MS = 15;
volatile uint32_t g_mbrDistanceReadFailures = 0;
struct MbrDistanceSample {
    bool retryNeeded = false;
    uint16_t counts[16] = {0};
    uint32_t readStartedMs = 0;
    bool attempted = false;
    bool valid = false;
    MbrTraceChip quality{};
};
static MbrDistanceSample mbrDistanceSamples[3];
static MbrDistanceGateState mbrDistanceStates[3][16];
static bool mbrDistanceEnabledForFrame = false;
static bool mbrDistanceResetForFrame = false;
static bool mbrButtonValid[3] = {};
static uint32_t mbrButtonStartMs[3] = {}, mbrButtonEndMs[3] = {};




#line 417 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static void prepareMbrDistanceGate() {
    static uint8_t previousProfile[8] = {0};
    static uint8_t previousLayout = 0;
    bool useMbr = (ControllerConfig.cfg0 & CFG0_BIT_MBR3116) ||
                  ControllerConfig.hwVer == 3 || ControllerConfig.hwVer == 4;
    bool enabled = useMbr && mbrDistanceGateEnabled(ControllerConfig);
    mbrDistanceResetForFrame = false;
    if (enabled != mbrDistanceEnabledForFrame ||
        (enabled && (previousLayout != ControllerConfig.hwVer ||
         std::memcmp(previousProfile, &ControllerConfig.mbrDistanceMagic,
                     sizeof(previousProfile)) != 0))) {
        mbrDistanceResetForFrame = true;
        for (uint8_t m = 0; m < 3; m++) {
            mbrDistanceSamples[m] = MbrDistanceSample{};
            for (uint8_t e = 0; e < 16; e++) mbrDistanceStates[m][e] = MbrDistanceGateState{};
        }
        std::memcpy(previousProfile, &ControllerConfig.mbrDistanceMagic, sizeof(previousProfile));
        previousLayout = ControllerConfig.hwVer;
    }
    mbrDistanceEnabledForFrame = enabled;
    for (uint8_t m = 0; m < 3; ++m) {
        mbrDistanceSamples[m].quality.flags &= ~MBR_TRACE_READ_THIS_FRAME;
        mbrButtonValid[m] = false;
        mbrButtonStartMs[m] = mbrButtonEndMs[m] = 0;
    }
}


#line 444 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static bool mbrDistanceReadAttempt(uint8_t m, CY8CMBR3116* chip) {
    MbrDistanceSample& sample = mbrDistanceSamples[m];
    uint32_t now = to_ms_since_boot(get_absolute_time());
    CY8CMBR3116::DifferenceReadInfo info{};
    sample.valid = chip->readDifferenceCounts(sample.counts, &info, true);
    MbrTraceChip& quality = sample.quality;
    quality.ioFailures += info.ioFailures;
    quality.syncMismatches += info.syncMismatches;
    quality.attemptEndMs = to_ms_since_boot(get_absolute_time());
    quality.flags |= MBR_TRACE_ATTEMPTED | MBR_TRACE_READ_THIS_FRAME;
    quality.flags &= ~MBR_TRACE_VALID;
    if (sample.valid) {
        quality.flags |= MBR_TRACE_VALID | MBR_TRACE_HAS_GOOD | MBR_TRACE_COHERENT;
        quality.goodStartMs = now;
        quality.goodEndMs = quality.attemptEndMs;
        quality.sync = info.sync;
        quality.rangeMask = 0;
        for (uint8_t e = 0; e < 16; ++e) {
            if (sample.counts[e] <= 255) quality.rangeMask |= 1u << e;
        }
        for (uint8_t e = 0; e < 16; e++) {
            int16_t lane = laneTable[m][e];
            if (lane >= 0) pressureSnap[lane] = sample.counts[e] > 255 ? 255 : sample.counts[e];
        }
    }
    return !sample.valid && info.ioFailures == 0 && info.syncMismatches == 1;
}


#line 472 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static void mbrDistanceReadSample(uint8_t m, CY8CMBR3116* chip) {
    MbrDistanceSample& sample = mbrDistanceSamples[m];
    sample.retryNeeded = false;
    uint32_t now = to_ms_since_boot(get_absolute_time());
    if (!sample.attempted || now - sample.readStartedMs >= MBR_DISTANCE_POLL_MS) {
        sample.readStartedMs = now;
        sample.attempted = true;
        ++sample.quality.readCalls;
        sample.quality.attemptStartMs = now;
        sample.retryNeeded = mbrDistanceReadAttempt(m, chip);
        if (!sample.valid && !sample.retryNeeded) ++g_mbrDistanceReadFailures;
    }
}


#line 487 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static void mbrDistanceRetrySample(uint8_t m, CY8CMBR3116* chip) {
    MbrDistanceSample& sample = mbrDistanceSamples[m];
    if (!sample.retryNeeded) return;
    sample.retryNeeded = false;
    mbrDistanceReadAttempt(m, chip);
    if (!sample.valid) ++g_mbrDistanceReadFailures;
}


#line 495 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static uint16_t readMbrButtons(uint8_t m, CY8CMBR3116* chip) {
    uint16_t value = 0;
    mbrButtonStartMs[m] = to_ms_since_boot(get_absolute_time());
    mbrButtonValid[m] = chip->get_BUTTON_STAT((uint8_t*)&value) == 0;
    mbrButtonEndMs[m] = to_ms_since_boot(get_absolute_time());
    return mbrButtonValid[m] ? value : 0;
}


#line 505 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static uint16_t mbrDistanceAllowedMask(uint8_t m, uint16_t hardwareBits, uint32_t now) {
    const MbrDistanceSample& sample = mbrDistanceSamples[m];
    bool usable = sample.valid && now - sample.readStartedMs <= MBR_DISTANCE_MAX_READ_AGE_MS;
    uint16_t allowed = 0;
    for (uint8_t e = 0; e < 16; e++) {
        bool mapped = laneTable[m][e] >= 0;
        if (mbrDistanceGateUpdate(ControllerConfig, sample.counts[e], usable && mapped,
                                  (hardwareBits & (1u << e)) != 0, mbrDistanceStates[m][e])) {
            allowed |= 1u << e;
        }
    }
    return allowed;
}


#line 595 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
void updateTouch_v2() {
    // round50: full optimization pipeline migrated from updateTouch_v1/MPR121
    uint16_t t0 = 0, t1 = 0;
    t0 = readMbrButtons(0, &MBR3116D);
    t1 = readMbrButtons(1, &MBR3116E);

    hwTouch[0] = t0; hwTouch[1] = t1; hwTouch[2] = 0;  // round50: pre-verification snapshot

    uint16_t distanceAllowed[2] = {0xFFFF, 0xFFFF};
    if (mbrDistanceEnabledForFrame) {
        mbrDistanceReadSample(0, &MBR3116D);
        mbrDistanceReadSample(1, &MBR3116E);
        mbrDistanceRetrySample(0, &MBR3116D);
        mbrDistanceRetrySample(1, &MBR3116E);
        uint32_t sampledAt = to_ms_since_boot(get_absolute_time());
        distanceAllowed[0] = mbrDistanceAllowedMask(0, t0, sampledAt);
        distanceAllowed[1] = mbrDistanceAllowedMask(1, t1, sampledAt);
        t0 &= distanceAllowed[0]; t1 &= distanceAllowed[1];
    }

    // round84: per-GAME-LANE stretched snapshot of the previous cycle. The
    // gate-anchoring check (laneNeighborConfirmed) is lane-space, so the
    // stretched bits from both chips are projected through laneTable once
    // per cycle -- cross-chip boundaries (e.g. lane 15/16) anchor naturally.
    static bool prevLaneStretched[32] = {0};

    static uint16_t prevStretched[2] = {0, 0};  // round50: slide-aware spatial filtering
    static const uint8_t CONFIRM_CYCLES_V2 = 2;
    static uint8_t confirmReq[2][16] = {0};
    static uint8_t verifiedCount[2][16] = {0};
    static uint32_t lastTouchedMsV2[2][16] = {0};
    static bool fastOkV2[2][16] = {0};  // round80: strong flick first-cycle output flag
    if (mbrDistanceResetForFrame) {
        std::memset(prevLaneStretched, 0, sizeof(prevLaneStretched));
        std::memset(prevStretched, 0, sizeof(prevStretched));
        std::memset(confirmReq, 0, sizeof(confirmReq));
        std::memset(verifiedCount, 0, sizeof(verifiedCount));
        std::memset(lastTouchedMsV2, 0, sizeof(lastTouchedMsV2));
        std::memset(fastOkV2, 0, sizeof(fastOkV2));
    }
    uint32_t nowVer = to_ms_since_boot(get_absolute_time());
    // round64: per-lane MBR thresholds. base_k defaults to 80 (=round50
    // MBR3116_VERIFY_TH); amplitude tiers are relative offsets off it, so
    // per-key values only tighten; native BUTTON_STAT remains a separate gate.
        static const uint16_t MBR_VERIFY_BASE = 80;
        static const uint16_t MBR_TIER_OFFSET_MEDIUM = 40;
        static const uint16_t MBR_TIER_OFFSET_STRONG = 120;
        static const uint16_t MBR_TIER_OFFSET_SKIP = 220;
        // round80: preserve the legacy strong-signal fast path. Native button
        // DIFF is 0..255, and 200 is a count threshold, not evidence of contact
        // or a fixed height. The legacy +220 skip tier is retained for default-
        // off compatibility; round89a rejects invalid values above 255.
        static const uint16_t MBR_FLICK_FAST_TH = 200;
        // round84: gate value granted to a slide-edge lane whose GAME-LANE
        // neighbor confirmed last cycle (see laneNeighborConfirmed below).
        // = MBR_TIER_OFFSET_MEDIUM, so the relaxed gate coincides with the
        // existing medium-amplitude tier boundary.
        static const uint16_t MBR_NEIGHBOR_GATE_MARGIN = 40;
        uint16_t verifyBaseK[2][16];
        for (uint8_t m = 0; m < 2; m++) {
            for (uint8_t e = 0; e < 16; e++) {
                int16_t lane = laneTable[m][e];
                uint16_t base = (lane >= 0 && ControllerConfig.thTouchKey[lane] != 0)
                                    ? ControllerConfig.thTouchKey[lane]
                                    : MBR_VERIFY_BASE;
                // round64: MBR can only tighten. The chip's hardware gate is
                // 128; a config value <=128 can never be stricter than that, so
                // keep the round50 verify baseline (80) for those to avoid
                // silently relaxing the software gate.
                verifyBaseK[m][e] = (base > MBR_VERIFY_BASE) ? base : MBR_VERIFY_BASE;
            }
        }
    {   // round50: software verification
        uint16_t raw[2] = {t0, t1};
        CY8CMBR3116* chips[2] = {&MBR3116D, &MBR3116E};
        uint16_t diffCounts[2][16];
        bool diffRead[2] = {false, false};
        bool diffOk[2] = {false, false};
        bool diffRetried[2] = {false, false};
        for (uint8_t m = 0; m < 2; m++) {
            for (uint8_t e = 0; e < 16; e++) {
                if (mbrDistanceEnabledForFrame && !(distanceAllowed[m] & (1u << e))) {
                    verifiedCount[m][e] = 0;
                    confirmReq[m][e] = CONFIRM_CYCLES_V2;
                    fastOkV2[m][e] = false;
                    lastTouchedMsV2[m][e] = 0;
                    continue;
                }
                if (raw[m] & (1 << e)) {
                    if (verifiedCount[m][e] < 2) {
                        if (!diffRead[m]) {
                            if (mbrDistanceEnabledForFrame) {
                                diffOk[m] = mbrDistanceSamples[m].valid;
                                std::memcpy(diffCounts[m], mbrDistanceSamples[m].counts, sizeof(diffCounts[m]));
                            } else {
                                diffOk[m] = (chips[m]->get_DIFFERENCE_COUNT_SENSOR(diffCounts[m]) == 0);
                                if (!diffOk[m]) {
                                    diffRetried[m] = true;
                                    diffOk[m] = (chips[m]->get_DIFFERENCE_COUNT_SENSOR(diffCounts[m]) == 0);
                                }
                            }
                            diffRead[m] = true;
                        }
                        if (!diffOk[m]) {
                            confirmReq[m][e] = CONFIRM_CYCLES_V2;
                        } else {
                            uint16_t diff = diffCounts[m][e];
                            uint16_t baseK = verifyBaseK[m][e];
                            // round80: hover-rejection gate (mbrTouchGate, 0=off).
                            // Legacy new-touch verification only: no physical
                            // distance guarantee, and held/release/sticky state
                            // is untouched. The opt-in round89a gate has already
                            // applied a continuous per-electrode hard rejection.
                            // round84: confirmed-neighbor anchoring. A slide's
                            // trailing/leading edge sweeps weak signal into a
                            // lane next to one that JUST confirmed -- spatial
                            // continuity for legacy slide behavior. A hovering
                            // finger next to real contact can share this anchor.
                            // Anchor is the GAME LANE (k +/- 1 via laneTable),
                            // never "any electrode on the same chip": 3116
                            // electrodes are physically shuffled (v2 puts tc1/2
                            // and tc15/16 on one chip), a same-chip rule would
                            // let a hover on one side slip through while the
                            // other side is held. This relaxation cannot bypass
                            // the opt-in continuous gate applied before this loop.
                            uint16_t rejectTh = baseK;
                            if (ControllerConfig.mbrTouchGate > rejectTh) rejectTh = ControllerConfig.mbrTouchGate;
                            int16_t lane = laneTable[m][e];
                            bool laneNeighborConfirmed = false;
                            if (lane >= 0) {
                                laneNeighborConfirmed =
                                    (lane > 0 && prevLaneStretched[lane - 1]) ||
                                    (lane < 31 && prevLaneStretched[lane + 1]);
                            }
                            if (laneNeighborConfirmed && rejectTh > baseK + MBR_NEIGHBOR_GATE_MARGIN) {
                                rejectTh = baseK + MBR_NEIGHBOR_GATE_MARGIN;
                            }
                            bool neighborWasActive = (e > 0 && (prevStretched[m] & (1 << (e - 1)))) ||
                                                     (e < 15 && (prevStretched[m] & (1 << (e + 1))));
                            if (diff < rejectTh) {
                                raw[m] &= ~(1 << e);
                                verifiedCount[m][e] = 0;
                                confirmReq[m][e] = CONFIRM_CYCLES_V2;
                                fastOkV2[m][e] = false;
                                if (g_verifyFail[m * 16 + e] < 255) g_verifyFail[m * 16 + e]++;
                            } else if (verifiedCount[m][e] == 0 && !diffRetried[m] &&
                                       diff >= MBR_FLICK_FAST_TH) {
                                // round80: strong flick fast path -- first-cycle
                                // output restores the old firmware's zero-latency
                                // behavior for isolated flick taps. The isolated
                                // +1 penalty is waived via fastOkV2 in the confirm
                                // loop, still guarded by the 40ms release-bounce
                                // window there. Gate interplay: with mbrTouchGate
                                // >= 200 the reject check above lifts the effective
                                // fast threshold to the gate value (expected).
                                verifiedCount[m][e] = 2;
                                confirmReq[m][e] = 1;
                                fastOkV2[m][e] = true;
                            } else if (verifiedCount[m][e] == 0 && !diffRetried[m] &&
                                       (diff >= (uint16_t)(baseK + MBR_TIER_OFFSET_SKIP) || neighborWasActive)) {
                                verifiedCount[m][e] = 2;
                                confirmReq[m][e] = 1;
                            } else {
                                verifiedCount[m][e]++;
                                if (diff >= (uint16_t)(baseK + MBR_TIER_OFFSET_STRONG))      confirmReq[m][e] = 1;
                                else if (diff >= (uint16_t)(baseK + MBR_TIER_OFFSET_MEDIUM)) confirmReq[m][e] = 2;
                                else                                                         confirmReq[m][e] = 3;
                            }
                        }
                    }
                } else {
                    if (verifiedCount[m][e] != 0) {
                        if (lastTouchedMsV2[m][e] == 0 || (nowVer - lastTouchedMsV2[m][e]) > 50) {
                            verifiedCount[m][e] = 0;
                            confirmReq[m][e] = CONFIRM_CYCLES_V2;
                            fastOkV2[m][e] = false;
                        }
                    }
                }
            }
        }
        t0 = raw[0]; t1 = raw[1];
    }
    rawTouch[0] = t0; rawTouch[1] = t1; rawTouch[2] = 0;
    {   // round50: pulse stretching + sticky touch + dip tolerance + spatial filtering
        static const uint32_t STRETCH_MS_V2 = 5;
        static const uint8_t DIP_TOLERANCE_CYCLES_V2 = 3;
        static const uint8_t STICKY_THRESHOLD_V2 = 15;
        static const uint8_t STICKY_GRACE_MAX_V2 = 15;
        static const uint8_t STICKY_GRACE_SHORT_V2 = 12;
        static uint8_t touchCount[2][16] = {0};
        static uint32_t lastConfirmed[2][16] = {0};
        static uint8_t dipGrace[2][16] = {0};
        static uint8_t stickyGrace[2][16] = {0};
        if (mbrDistanceResetForFrame) {
            std::memset(touchCount, 0, sizeof(touchCount));
            std::memset(lastConfirmed, 0, sizeof(lastConfirmed));
            std::memset(dipGrace, 0, sizeof(dipGrace));
            std::memset(stickyGrace, 0, sizeof(stickyGrace));
        }
        uint16_t raw[2] = {t0, t1};
        uint16_t stretched[2] = {0, 0};
        uint32_t now = to_ms_since_boot(get_absolute_time());
        for (uint8_t m = 0; m < 2; m++) {
            for (uint8_t e = 0; e < 16; e++) {
                if (mbrDistanceEnabledForFrame && !(distanceAllowed[m] & (1u << e))) {
                    touchCount[m][e] = 0;
                    lastConfirmed[m][e] = 0;
                    dipGrace[m][e] = 0;
                    stickyGrace[m][e] = 0;
                    continue;
                }
                bool isTouched = (raw[m] >> e) & 1;
                if (isTouched) {
                    lastTouchedMsV2[m][e] = now;
                    dipGrace[m][e] = DIP_TOLERANCE_CYCLES_V2;
                    if (touchCount[m][e] < 255) touchCount[m][e]++;
                    // round50fix: match v1 stickyGrace logic (duration-based, no decrement during touch)
                    if (touchCount[m][e] >= STICKY_THRESHOLD_V2) {
                        stickyGrace[m][e] = (touchCount[m][e] >= 50) ? STICKY_GRACE_MAX_V2
                                                                      : STICKY_GRACE_SHORT_V2;
                    }
                    uint8_t reqCycles = confirmReq[m][e] ? confirmReq[m][e] : CONFIRM_CYCLES_V2;
                    // round50fix: spatial penalty - isolated electrode needs +1 confirm cycle
                    bool hasNeighbor = ((e > 0 && (prevStretched[m] & (1 << (e - 1)))) ||
                                        (e < 15 && (prevStretched[m] & (1 << (e + 1)))));
                    // round80: waive the isolated +1 for strong flick signals
                    // (fastOkV2, set only when diff >= MBR_FLICK_FAST_TH on a
                    // first-sighting verify) unless we are within 40ms of the
                    // last confirmed touch -- a residual-signal re-enhancement
                    // right after release must not double-fire as a new tap.
                    bool fastExempt = fastOkV2[m][e] &&
                        (lastConfirmed[m][e] == 0 || (now - lastConfirmed[m][e]) >= 40);
                    if (!hasNeighbor && !fastExempt) reqCycles += 1;
                    if (touchCount[m][e] >= reqCycles) {
                        lastConfirmed[m][e] = now;
                        stretched[m] |= (1 << e);
                    } else if (touchCount[m][e] >= STICKY_THRESHOLD_V2 && stickyGrace[m][e] > 0) {
                        stickyGrace[m][e]--;
                        stretched[m] |= (1 << e);
                    } else if (lastConfirmed[m][e] != 0 && touchCount[m][e] >= 3 && dipGrace[m][e] > 0) {
                        dipGrace[m][e]--;
                        stretched[m] |= (1 << e);
                    }
                } else {
                    if (touchCount[m][e] >= STICKY_THRESHOLD_V2 && stickyGrace[m][e] > 0) {
                        stickyGrace[m][e]--;
                        stretched[m] |= (1 << e);
                    } else if (lastConfirmed[m][e] != 0 && touchCount[m][e] >= 3 && dipGrace[m][e] > 0) {
                        dipGrace[m][e]--;
                        stretched[m] |= (1 << e);
                    } else {
                        touchCount[m][e] = 0;
                        stickyGrace[m][e] = 0;
                        if (lastConfirmed[m][e] != 0 && (now - lastConfirmed[m][e]) < STRETCH_MS_V2) {
                            stretched[m] |= (1 << e);
                        }
                    }
                }
            }
        }
        t0 = stretched[0]; t1 = stretched[1];
    }
    prevStretched[0] = t0; prevStretched[1] = t1;

    // round84: project this cycle's stretched bits into lane space for next
    // cycle's laneNeighborConfirmed gate anchoring.
    for (uint8_t lane = 0; lane < 32; lane++) {
        uint8_t lm = V2_LANE_M[lane], le = V2_LANE_E[lane];
        uint16_t bits = (lm == 0) ? t0 : t1;
        prevLaneStretched[lane] = (bits >> le) & 1;
    }

    touchData32[0] = GET_BIT(t1, 4) ? 128 : 0;
    touchData32[1] = GET_BIT(t1, 0) ? 128 : 0;

    touchData32[2] = GET_BIT(t1, 5) ? 128 : 0;
    touchData32[3] = GET_BIT(t1, 1) ? 128 : 0;

    touchData32[4] = GET_BIT(t1, 6) ? 128 : 0;
    touchData32[5] = GET_BIT(t1, 2) ? 128 : 0;

    touchData32[6] = GET_BIT(t1, 7) ? 128 : 0;
    touchData32[7] = GET_BIT(t1, 3) ? 128 : 0;

    //

    touchData32[8] = GET_BIT(t1, 8) ? 128 : 0;
    touchData32[9] = GET_BIT(t1, 15) ? 128 : 0;

    touchData32[10] = GET_BIT(t1, 9) ? 128 : 0;
    touchData32[11] = GET_BIT(t1, 14) ? 128 : 0;

    touchData32[12] = GET_BIT(t1, 10) ? 128 : 0;
    touchData32[13] = GET_BIT(t1, 13) ? 128 : 0;

    touchData32[14] = GET_BIT(t1, 11) ? 128 : 0;
    touchData32[15] = GET_BIT(t1, 12) ? 128 : 0;

    //

    touchData32[16] = GET_BIT(t0, 12) ? 128 : 0;
    touchData32[17] = GET_BIT(t0, 11) ? 128 : 0;

    touchData32[18] = GET_BIT(t0, 13) ? 128 : 0;
    touchData32[19] = GET_BIT(t0, 10) ? 128 : 0;

    touchData32[20] = GET_BIT(t0, 14) ? 128 : 0;
    touchData32[21] = GET_BIT(t0, 9) ? 128 : 0;

    touchData32[22] = GET_BIT(t0, 15) ? 128 : 0;
    touchData32[23] = GET_BIT(t0, 8) ? 128 : 0;

    //

    touchData32[24] = GET_BIT(t0, 3) ? 128 : 0;
    touchData32[25] = GET_BIT(t0, 7) ? 128 : 0;

    touchData32[26] = GET_BIT(t0, 2) ? 128 : 0;
    touchData32[27] = GET_BIT(t0, 6) ? 128 : 0;

    touchData32[28] = GET_BIT(t0, 1) ? 128 : 0;
    touchData32[29] = GET_BIT(t0, 5) ? 128 : 0;

    touchData32[30] = GET_BIT(t0, 0) ? 128 : 0;
    touchData32[31] = GET_BIT(t0, 4) ? 128 : 0;

    // round50: set touchData[0..3] AFTER touchData32[] (same fix as round45t in v1)
    touchData[0] = *(0 + (uint8_t*)(&t0));
    touchData[1] = *(1 + (uint8_t*)(&t0));
    touchData[2] = *(0 + (uint8_t*)(&t1));
    touchData[3] = *(1 + (uint8_t*)(&t1));
}


#line 929 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
void updateTouch_v1() {

    uint16_t t0 = 0, t1 = 0, t2 = 0;  // round50: init to 0 for I2C error safety
    if (ControllerConfig.cfg0 & CFG0_BIT_MBR3116) {
        t0 = readMbrButtons(0, &MBR3116A);
        t1 = readMbrButtons(1, &MBR3116B);
        t2 = readMbrButtons(2, &MBR3116C);
    } else {
        t0 = mpr0.touched();
        t1 = mpr1.touched();
        t2 = mpr2.touched();
    }

    // round45p: save pre-verification hardware touch snapshot for CMD_DEBUG_CHAIN
    hwTouch[0] = t0; hwTouch[1] = t1; hwTouch[2] = t2;

    uint16_t distanceAllowed[3] = {0xFFFF, 0xFFFF, 0xFFFF};
    if (mbrDistanceEnabledForFrame) {
        mbrDistanceReadSample(0, &MBR3116A);
        mbrDistanceReadSample(1, &MBR3116B);
        mbrDistanceReadSample(2, &MBR3116C);
        mbrDistanceRetrySample(0, &MBR3116A);
        mbrDistanceRetrySample(1, &MBR3116B);
        mbrDistanceRetrySample(2, &MBR3116C);
        uint32_t sampledAt = to_ms_since_boot(get_absolute_time());
        distanceAllowed[0] = mbrDistanceAllowedMask(0, t0, sampledAt);
        distanceAllowed[1] = mbrDistanceAllowedMask(1, t1, sampledAt);
        distanceAllowed[2] = mbrDistanceAllowedMask(2, t2, sampledAt);
        t0 &= distanceAllowed[0]; t1 &= distanceAllowed[1]; t2 &= distanceAllowed[2];
    }

    // round84: per-GAME-LANE stretched snapshot of the previous cycle (MBR
    // branch only -- the MPR branch keeps its behavior untouched this round).
    // Projected after the shared stretch stage from the STRETCHED bits
    // (incl. sticky-held lanes); cross-chip lane borders (e.g. 15/16) anchor
    // naturally through lane space.
    static bool prevLaneStretched[32] = {0};

    // round45u: previous cycle's stretched output for slide-aware spatial filtering.
    // Used to detect slide transitions: if neighbor was active (including sticky-maintained),
    // current cell is part of a slide, not an isolated noise spike.
    static uint16_t prevStretched[3] = {0, 0, 0};

    // Save raw 16-bit touch data for stuck-key detection (before stretching)
    // Verify touches against actual sensor data. Only verify the first 2 cycles
    // of a new touch (sustained touches skip I2C reads to minimize latency).
   // Filters false touches from MPR121 timing mismatch, baseline drift, noise.
   static const uint8_t  CONFIRM_CYCLES = 2;  // round36: 3->2, software verification handles noise filtering
    static uint8_t confirmReq[3][12] = {0};     // round45: amplitude-tier confirmation cycles (1=fast, 2=normal, 3=strict)
   static uint8_t verifiedCount[3][12] = {0};     // round50: shared MPR121/MBR3116 verification
   static bool fastOk[3][12] = {0};  // round80: strong flick first-cycle output flag (shared MPR/MBR)
    if (mbrDistanceResetForFrame) {
        std::memset(prevLaneStretched, 0, sizeof(prevLaneStretched));
        std::memset(prevStretched, 0, sizeof(prevStretched));
        std::memset(confirmReq, 0, sizeof(confirmReq));
        std::memset(verifiedCount, 0, sizeof(verifiedCount));
        std::memset(lastTouchedMs, 0, sizeof(lastTouchedMs));
        std::memset(fastOk, 0, sizeof(fastOk));
    }
   uint32_t nowVer = to_ms_since_boot(get_absolute_time());  // round45r: sticky dip verification preservation
   if (!(ControllerConfig.cfg0 & CFG0_BIT_MBR3116)) {
        uint16_t raw[3] = {t0, t1, t2};
        MPR121* mprs[3] = {&mpr0, &mpr1, &mpr2};
        // round64: per-lane software thresholds. sw_th_k = per-key value if
        // configured (non-zero), else the global th_touch; floor of 4 kept so
        // verify thresholds never collapse to 0.
        uint8_t sw_th_k[3][12];
        uint8_t verify_th_k[3][12];
        // round80: strong flick fast path base. User empirical data: MPR diff
        // is contact-area proportional (finger 30-50, palm ~130) and never
        // reaches the 255 cap natively. 50 raw (=100 on the x2 report scale)
        // covers firm finger/palm taps while keeping >=3.5x margin over the
        // worst observed idle-noise pulses (diff>=14, round47b). max() with
        // sw+4 (the confirmReq=1 tier boundary) preserves per-key tightened
        // thresholds -- the fast path never bypasses a user-raised gate.
        static const uint8_t MPR_FLICK_FAST_BASE = 50;
        for (uint8_t m = 0; m < 3; m++) {
            for (uint8_t e = 0; e < 12; e++) {
                uint8_t base = electrodeBaseTouchTh(m, e);
                uint8_t sw = (base != 0) ? base : ControllerConfig.th_touch;
                if (sw < 4) sw = 4;
                sw_th_k[m][e] = sw;
                verify_th_k[m][e] = (sw > 1) ? (sw - 1) : 1;  // round41: -1 LSB tolerance
            }
        }
      for (uint8_t m = 0; m < 3; m++) {
            for (uint8_t e = 0; e < 12; e++) {
                if (raw[m] & (1 << e)) {
                    if (verifiedCount[m][e] < 2) {
                        // New touch - verify with sensor data
                        uint16_t filt = mprs[m]->filteredData(e);
                       if (filt == 0) {
                            // round47b-patch: I2C read error - re-read once before trusting.
                            // Old code directly trusted hardware (verifiedCount++), which lets
                            // a hardware false touch through if I2C fails 2 cycles in a row.
                            // Now: re-read; if still 0, skip this electrode this cycle (don't
                            // increment verifiedCount, don't clear raw - let next cycle retry).
                            uint16_t filt2 = mprs[m]->filteredData(e);
                            if (filt2 == 0) {
                                // Genuine I2C failure - don't trust, don't reject, just skip
                                confirmReq[m][e] = CONFIRM_CYCLES;
                            } else {
                                // First read was glitch, second OK - use filt2
                                filt = filt2;
                                uint16_t base = mprs[m]->baselineData(e);
                                int16_t diff = (int16_t)base - (int16_t)filt;
                            if (diff < static_cast<int16_t>(verify_th_k[m][e])) {
                                    raw[m] &= ~(1 << e);
                                    verifiedCount[m][e] = 0;
                                    confirmReq[m][e] = CONFIRM_CYCLES;
                                    fastOk[m][e] = false;
                                    if (g_verifyFail[m * 12 + e] < 255) g_verifyFail[m * 12 + e]++;
                                } else {
                                    // round47b-patch: intentionally no strong-signal fast-path
                                    // (diff>=sw_th+6 skip). First read was 0 (I2C unstable),
                                    // so require full 2-cycle verification.
                                    verifiedCount[m][e]++;
                                    if (diff >= (int16_t)(sw_th_k[m][e] + 4))      confirmReq[m][e] = 1;
                                    else if (diff >= (int16_t)(sw_th_k[m][e] + 2)) confirmReq[m][e] = 2;
                                    else                                        confirmReq[m][e] = 3;
                                }
                            }
                       } else {
                            uint16_t base = mprs[m]->baselineData(e);
                            int16_t diff = (int16_t)base - (int16_t)filt;
                               if (diff < static_cast<int16_t>(verify_th_k[m][e])) {
                               raw[m] &= ~(1 << e);
                               verifiedCount[m][e] = 0;
                               confirmReq[m][e] = CONFIRM_CYCLES;
                               fastOk[m][e] = false;
                               if (g_verifyFail[m * 12 + e] < 255) g_verifyFail[m * 12 + e]++;  // round46: telemetry
                           } else {
                                // round45o: skip second verification for very strong signals (saves 1 cycle ~2ms for flick notes)
                                // round45u: slide transition acceleration - if neighbor was active
                                // in previous cycle, skip 2nd verification (slide, not noise)
                                bool neighborWasActive = (e > 0 && (prevStretched[m] & (1 << (e-1)))) ||
                                                          (e < 11 && (prevStretched[m] & (1 << (e+1))));
                                // round80: strong flick fast path -- first-cycle output
                                // for isolated firm taps (see MPR_FLICK_FAST_BASE). The
                                // isolated +1 penalty is waived via fastOk in the confirm
                                // loop, still guarded by the 40ms release-bounce window.
                                // The sw+6/neighbor slide path below stays NON-exempt:
                                // it fires on weak slide signals where the penalty is
                                // the only noise filter.
                                uint8_t fastTh = MPR_FLICK_FAST_BASE;
                                if (sw_th_k[m][e] + 4 > fastTh) fastTh = sw_th_k[m][e] + 4;
                                if (diff >= (int16_t)fastTh) {
                                    verifiedCount[m][e] = 2;
                                    confirmReq[m][e] = 1;
                                    fastOk[m][e] = true;
                                } else if (diff >= (int16_t)(sw_th_k[m][e] + 6) || neighborWasActive) {
                                    verifiedCount[m][e] = 2;  // skip second I2C verification cycle
                                    confirmReq[m][e] = 1;     // fastest confirmation
                                } else {
                                    verifiedCount[m][e]++;
                                    if (diff >= (int16_t)(sw_th_k[m][e] + 4))      confirmReq[m][e] = 1;  // strong signal: fastest
                                    else if (diff >= (int16_t)(sw_th_k[m][e] + 2)) confirmReq[m][e] = 2;  // medium
                                    else                                         confirmReq[m][e] = 3;  // weak/edge: strict, anti-false-touch
                                }
                           }
                        }
                    }
                   // else: sustained touch, already verified, skip I2C
               } else {
                   // round45r: preserve verification if recently touched (sticky dip recovery).
                   // When touch returns from sticky dip, verifiedCount is still 2 -> skip re-verification.
                   // This prevents miss when re-verification would fail due to weak signal or I2C timing mismatch.
                     // 50ms window covers max sticky dip (18 cycles ~47ms at
                     // 2.7ms/cycle), while fast re-taps (release <50ms ago)
                     // skip re-verification for zero-latency re-trigger.
                     if (lastTouchedMs[m][e] == 0 || (nowVer - lastTouchedMs[m][e]) > 50) {
                       verifiedCount[m][e] = 0;
                       confirmReq[m][e] = CONFIRM_CYCLES;
                       fastOk[m][e] = false;
                   }
                   // else: keep verifiedCount, instant re-trigger when touch returns
               }
            }
        }
        t0 = raw[0]; t1 = raw[1]; t2 = raw[2];
    } else {
        // round50: MBR3116 software verification (migrated from MPR121 optimization).
        // Uses get_DIFFERENCE_COUNT_SENSOR() to verify chip's touch decision against
        // actual signal strength. Catches I2C errors, false positives from timing
        // mismatch between BUTTON_STAT and DIFFERENCE_COUNT reads.
        // MBR3116 hardware threshold is 128 (config); verify threshold 80 gives
        // ~37% margin for I2C read timing skew (equivalent to MPR121's sw_th-1).
        uint16_t raw[3] = {t0, t1, t2};
        CY8CMBR3116* chips[3] = {&MBR3116A, &MBR3116B, &MBR3116C};
        uint8_t maxElec[3] = {12, 12, 8};  // electrodes used per chip in v1 layout
        // round64: per-lane MBR thresholds. base_k defaults to 80 (=round50
        // MBR3116_VERIFY_TH); amplitude tiers are relative offsets off it, so
        // per-key values only tighten; native BUTTON_STAT remains a separate gate.
        static const uint16_t MBR_VERIFY_BASE = 80;
        static const uint16_t MBR_TIER_OFFSET_MEDIUM = 40;
        static const uint16_t MBR_TIER_OFFSET_STRONG = 120;
        static const uint16_t MBR_TIER_OFFSET_SKIP = 220;
        // round80: preserve the legacy strong-signal fast path. Native button
        // DIFF is 0..255, and 200 is a count threshold, not evidence of contact
        // or a fixed height. The legacy +220 skip tier is retained for default-
        // off compatibility; round89a rejects invalid values above 255.
        static const uint16_t MBR_FLICK_FAST_TH = 200;
        // round84: gate value granted to a slide-edge lane whose GAME-LANE
        // neighbor confirmed last cycle (mirror of the v2 layout change).
        static const uint16_t MBR_NEIGHBOR_GATE_MARGIN = 40;
        uint16_t verifyBaseK[3][16];
        for (uint8_t m = 0; m < 3; m++) {
            for (uint8_t e = 0; e < 16; e++) {
                int16_t lane = laneTable[m][e];
                uint16_t base = (lane >= 0 && ControllerConfig.thTouchKey[lane] != 0)
                                    ? ControllerConfig.thTouchKey[lane]
                                    : MBR_VERIFY_BASE;
                // round64: MBR can only tighten. The chip's hardware gate is
                // 128; a config value <=128 can never be stricter than that, so
                // keep the round50 verify baseline (80) for those to avoid
                // silently relaxing the software gate.
                verifyBaseK[m][e] = (base > MBR_VERIFY_BASE) ? base : MBR_VERIFY_BASE;
            }
        }
        uint16_t diffCounts[3][16];
        bool diffRead[3] = {false, false, false};
        bool diffOk[3] = {false, false, false};
        bool diffRetried[3] = {false, false, false};
        for (uint8_t m = 0; m < 3; m++) {
            for (uint8_t e = 0; e < maxElec[m]; e++) {
                if (mbrDistanceEnabledForFrame && !(distanceAllowed[m] & (1u << e))) {
                    verifiedCount[m][e] = 0;
                    confirmReq[m][e] = CONFIRM_CYCLES;
                    fastOk[m][e] = false;
                    lastTouchedMs[m][e] = 0;
                    continue;
                }
                if (raw[m] & (1 << e)) {
                    if (verifiedCount[m][e] < 2) {
                        // New touch - verify with sensor difference count
                        if (!diffRead[m]) {
                            if (mbrDistanceEnabledForFrame) {
                                diffOk[m] = mbrDistanceSamples[m].valid;
                                std::memcpy(diffCounts[m], mbrDistanceSamples[m].counts, sizeof(diffCounts[m]));
                            } else {
                                diffOk[m] = (chips[m]->get_DIFFERENCE_COUNT_SENSOR(diffCounts[m]) == 0);
                                if (!diffOk[m]) {
                                    // round47b-patch: I2C error - re-read once before trusting
                                    diffRetried[m] = true;
                                    diffOk[m] = (chips[m]->get_DIFFERENCE_COUNT_SENSOR(diffCounts[m]) == 0);
                                }
                            }
                            diffRead[m] = true;
                        }
                        if (!diffOk[m]) {
                            // I2C failure - don't trust, don't reject, skip this cycle
                            confirmReq[m][e] = CONFIRM_CYCLES;
                        } else {
                            uint16_t diff = diffCounts[m][e];
                            uint16_t baseK = verifyBaseK[m][e];
                            // round80: hover-rejection gate (mbrTouchGate, 0=off).
                            // Legacy new-touch verification only: no physical
                            // distance guarantee, and held/release/sticky state
                            // is untouched. The opt-in round89a gate has already
                            // applied a continuous per-electrode hard rejection.
                            // round84: confirmed-neighbor anchoring (v2 mirror --
                            // see the full rationale there). Anchor is the GAME
                            // LANE (k +/- 1 via laneTable), never "any electrode
                            // on the same chip"; v1 mixes electrode orders across
                            // chips A/B/C, so the same shuffle hazard applies.
                            uint16_t rejectTh = baseK;
                            if (ControllerConfig.mbrTouchGate > rejectTh) rejectTh = ControllerConfig.mbrTouchGate;
                            int16_t lane = laneTable[m][e];
                            bool laneNeighborConfirmed = false;
                            if (lane >= 0) {
                                laneNeighborConfirmed =
                                    (lane > 0 && prevLaneStretched[lane - 1]) ||
                                    (lane < 31 && prevLaneStretched[lane + 1]);
                            }
                            if (laneNeighborConfirmed && rejectTh > baseK + MBR_NEIGHBOR_GATE_MARGIN) {
                                rejectTh = baseK + MBR_NEIGHBOR_GATE_MARGIN;
                            }
                            // round45u: slide transition acceleration
                            bool neighborWasActive = (e > 0 && (prevStretched[m] & (1 << (e - 1)))) ||
                                                     (e + 1 < maxElec[m] && (prevStretched[m] & (1 << (e + 1))));
                            if (diff < rejectTh) {
                                // False touch - signal insufficient
                                raw[m] &= ~(1 << e);
                                verifiedCount[m][e] = 0;
                                confirmReq[m][e] = CONFIRM_CYCLES;
                                fastOk[m][e] = false;
                                if (g_verifyFail[m * 12 + e] < 255) g_verifyFail[m * 12 + e]++;
                            } else if (verifiedCount[m][e] == 0 && !diffRetried[m] &&
                                       diff >= MBR_FLICK_FAST_TH) {
                                // round80: strong flick fast path -- first-cycle
                                // output restores the old firmware's zero-latency
                                // behavior for isolated flick taps. The isolated
                                // +1 penalty is waived via fastOk in the confirm
                                // loop, still guarded by the 40ms release-bounce
                                // window there. Gate interplay: with mbrTouchGate
                                // >= 200 the reject check above lifts the effective
                                // fast threshold to the gate value (expected).
                                verifiedCount[m][e] = 2;
                                confirmReq[m][e] = 1;
                                fastOk[m][e] = true;
                            } else if (verifiedCount[m][e] == 0 && !diffRetried[m] &&
                                       (diff >= (uint16_t)(baseK + MBR_TIER_OFFSET_SKIP) || neighborWasActive)) {
                                // Very strong signal or slide - skip 2nd verification
                                verifiedCount[m][e] = 2;
                                confirmReq[m][e] = 1;
                            } else {
                                verifiedCount[m][e]++;
                                if (diff >= (uint16_t)(baseK + MBR_TIER_OFFSET_STRONG))      confirmReq[m][e] = 1;
                                else if (diff >= (uint16_t)(baseK + MBR_TIER_OFFSET_MEDIUM)) confirmReq[m][e] = 2;
                                else                                                         confirmReq[m][e] = 3;
                            }
                        }
                    }
                    // else: sustained touch, skip I2C reads to minimize latency
                } else {
                    // round45r: preserve verification if recently touched (sticky dip recovery)
                    if (verifiedCount[m][e] != 0) {
                        if (lastTouchedMs[m][e] == 0 || (nowVer - lastTouchedMs[m][e]) > 50) {
                            verifiedCount[m][e] = 0;
                            confirmReq[m][e] = CONFIRM_CYCLES;
                            fastOk[m][e] = false;
                        }
                    }
                }
            }
        }
        t0 = raw[0]; t1 = raw[1]; t2 = raw[2];
    }
    rawTouch[0] = t0;
    rawTouch[1] = t1;
    rawTouch[2] = t2;

    // Touch pulse stretching: extend brief touches so the game's 300-500Hz
    // polling reliably samples fast-swipe notes (big-slide / zigzag / X-pattern).
    // Touch is output ONLY after CONFIRM_CYCLES consecutive cycles of sustained
    // contact, filtering 1-cycle random noise (autoconfig disabled, no periodic noise).
    // After release, the touch is held for STRETCH_MS so game polling catches it.
    static const uint32_t STRETCH_MS = 5;              // round47: 3->5ms. After a confirmed touch releases, the output
    // is held for 5ms so the game's 300-500Hz (2-3.3ms) polling samples at least one
    // "pressed" frame during the release transition. Does NOT cover main-loop stalls
    // (those freeze all output, not just stretch); it only smooths normal-speed releases.
    static const uint8_t  DIP_TOLERANCE_CYCLES = 3;     // round45n: 2->3, more pre-sticky dip tolerance
    static const uint8_t  STICKY_THRESHOLD = 15;        // round45n: touchCount to enter sticky mode (~15ms sustained touch)
   static const uint8_t  STICKY_GRACE_MAX = 15;        // round45n: sticky dip tolerance cycles (~15ms, >>dipGrace for sustained holds)
    static const uint8_t  STICKY_GRACE_SHORT = 12;      // round47: 8->12 (lock-hand tolerance ~32ms; round45p comment said faster release, but miss risk > release latency)
   static uint8_t  touchCount[3][12] = {0};
   static uint32_t lastConfirmed[3][12] = {0};
   static uint8_t  dipGrace[3][12] = {0};
   static uint8_t  stickyGrace[3][12] = {0};           // round45n: sticky-mode dip grace counter
    if (mbrDistanceResetForFrame) {
        std::memset(touchCount, 0, sizeof(touchCount));
        std::memset(lastConfirmed, 0, sizeof(lastConfirmed));
        std::memset(dipGrace, 0, sizeof(dipGrace));
        std::memset(stickyGrace, 0, sizeof(stickyGrace));
    }
   uint16_t raw[3] = {t0, t1, t2};
   uint16_t stretched[3] = {0, 0, 0};
   uint32_t now = to_ms_since_boot(get_absolute_time());
   for (uint8_t m = 0; m < 3; m++) {
       for (uint8_t e = 0; e < 12; e++) {
           if (mbrDistanceEnabledForFrame && !(distanceAllowed[m] & (1u << e))) {
               touchCount[m][e] = 0;
               lastConfirmed[m][e] = 0;
               dipGrace[m][e] = 0;
               stickyGrace[m][e] = 0;
               continue;
           }
           bool isTouched = (raw[m] >> e) & 1;
           if (isTouched) {
               lastTouchedMs[m][e] = now;
               dipGrace[m][e] = DIP_TOLERANCE_CYCLES;
               if (touchCount[m][e] < 255) touchCount[m][e]++;
                // round45n: replenish sticky grace for sustained touches
                if (touchCount[m][e] >= STICKY_THRESHOLD) {
                     // round45p: adaptive grace - short holds get less (faster release),
                     // long holds (touchCount>=50, ~130ms) get maximum tolerance.
                     stickyGrace[m][e] = (touchCount[m][e] >= 50) ? STICKY_GRACE_MAX
                                       : STICKY_GRACE_SHORT;
                }
                uint8_t reqCycles = confirmReq[m][e] ? confirmReq[m][e] : CONFIRM_CYCLES;
                // round45j: spatial consistency - isolated electrode (no same-MPR neighbor touched)
                // needs more confirm cycles to filter isolated noise (real touches span 1-3 adjacent cells)
                // round45u: use prevStretched (includes sticky-maintained touches) for neighbor check.
                // During slide transition, cell A's hardware bit=0 but sticky keeps it active.
                // Using raw[m] would treat cell B as isolated -> extra confirm delay -> slide miss.
                bool hasNeighbor = ((e > 0 && (prevStretched[m] & (1 << (e-1)))) || (e < 11 && (prevStretched[m] & (1 << (e+1)))));
                // round47b-patch: spatial penalty applies to ALL reqCycles (including 1).
                // Old code skipped strong signals (reqCycles==1) -> 1-cycle noise pulse on
                // high-idle-noise electrodes (M2E0 cell17: diff>=14 -> confirmReq=1 -> instant
                // output) passed through. Now isolated electrodes always need >=2 cycles.
                // Cost: isolated strong flick tap +1 cycle (~2.7ms) - acceptable.
                // round80: waive for strong flick signals (fastOk, set only when
                // diff >= MBR_FLICK_FAST_TH / MPR fast threshold on a first-sighting
                // verify -- orders of magnitude above the round47b noise spectrum)
                // unless within 40ms of the last confirmed touch: a residual-signal
                // re-enhancement right after release must not double-fire as a new tap.
                bool fastExempt = fastOk[m][e] &&
                    (lastConfirmed[m][e] == 0 || (now - lastConfirmed[m][e]) >= 40);
                if (!hasNeighbor && !fastExempt) reqCycles += 1;
                if (touchCount[m][e] >= reqCycles) {
                    lastConfirmed[m][e] = now;
                    stretched[m] |= (1 << e);
                }
            } else {
                // round45n: sticky touch - once sustained (touchCount>=STICKY_THRESHOLD),
                // tolerate much longer dips (STICKY_GRACE_MAX cycles) WITHOUT clearing touchCount.
                // Critical: touchCount preserved during sticky dips => instant re-trigger
                // when hardware touch returns (no re-verify/re-confirm delay = no miss).
                if (touchCount[m][e] >= STICKY_THRESHOLD && stickyGrace[m][e] > 0) {
                    stickyGrace[m][e]--;
                    stretched[m] |= (1 << e);
                } else if (lastConfirmed[m][e] != 0 && touchCount[m][e] >= 3 && dipGrace[m][e] > 0) {
                    // round45n: pre-sticky dipGrace (touchCount>=3, was >=4) for building-up touches
                    dipGrace[m][e]--;
                    stretched[m] |= (1 << e);
                } else {
                    touchCount[m][e] = 0;
                    stickyGrace[m][e] = 0;
                    if (lastConfirmed[m][e] != 0 &&
                        (now - lastConfirmed[m][e]) < STRETCH_MS) {
                        stretched[m] |= (1 << e);
                    }
                }
            }
        }
    }
    t0 = stretched[0];
    t1 = stretched[1];
    t2 = stretched[2];

    // round45u: save stretched output for next cycle's slide-aware spatial filtering
    prevStretched[0] = t0;
    prevStretched[1] = t1;
    prevStretched[2] = t2;

    // round84: project this cycle's stretched bits into lane space for next
    // cycle's laneNeighborConfirmed gate anchoring (MBR only -- the MPR branch
    // is untouched this round). Uses the STRETCHED bits (incl. sticky-held
    // lanes), matching the v2 projection exactly: anchor semantics must stay
    // identical across layouts.
    if (ControllerConfig.cfg0 & CFG0_BIT_MBR3116) {
        for (uint8_t lane = 0; lane < 32; lane++) {
            uint8_t lm = V1_LANE_M[lane], le = V1_LANE_E[lane];
            uint16_t bits = (lm == 0) ? t0 : ((lm == 1) ? t1 : t2);
            prevLaneStretched[lane] = (bits >> le) & 1;
        }
    }

    touchData32[0] = GET_BIT(t1, 11) ? 128 : 0;
    touchData32[1] = GET_BIT(t1, 0) ? 128 : 0;

    touchData32[2] = GET_BIT(t1, 10) ? 128 : 0;
    touchData32[3] = GET_BIT(t1, 1) ? 128 : 0;

    touchData32[4] = GET_BIT(t1, 9) ? 128 : 0;
    touchData32[5] = GET_BIT(t1, 2) ? 128 : 0;

    touchData32[6] = GET_BIT(t1, 8) ? 128 : 0;
    touchData32[7] = GET_BIT(t1, 3) ? 128 : 0;

    touchData32[8] = GET_BIT(t0, 11) ? 128 : 0;
    touchData32[9] = GET_BIT(t1, 4) ? 128 : 0;

    touchData32[10] = GET_BIT(t0, 10) ? 128 : 0;
    touchData32[11] = GET_BIT(t1, 5) ? 128 : 0;

    touchData32[12] = GET_BIT(t0, 9) ? 128 : 0;
    touchData32[13] = GET_BIT(t1, 6) ? 128 : 0;

    touchData32[14] = GET_BIT(t0, 8) ? 128 : 0;
    touchData32[15] = GET_BIT(t1, 7) ? 128 : 0;

    touchData32[16] = GET_BIT(t0, 7) ? 128 : 0;
    touchData32[17] = GET_BIT(t2, 0) ? 128 : 0;

    touchData32[18] = GET_BIT(t0, 6) ? 128 : 0;
    touchData32[19] = GET_BIT(t2, 1) ? 128 : 0;

    touchData32[20] = GET_BIT(t0, 5) ? 128 : 0;
    touchData32[21] = GET_BIT(t2, 2) ? 128 : 0;

    touchData32[22] = GET_BIT(t0, 4) ? 128 : 0;
    touchData32[23] = GET_BIT(t2, 3) ? 128 : 0;

    touchData32[24] = GET_BIT(t0, 3) ? 128 : 0;
    touchData32[25] = GET_BIT(t2, 4) ? 128 : 0;

    touchData32[26] = GET_BIT(t0, 2) ? 128 : 0;
    touchData32[27] = GET_BIT(t2, 5) ? 128 : 0;

    touchData32[28] = GET_BIT(t0, 1) ? 128 : 0;
    touchData32[29] = GET_BIT(t2, 6) ? 128 : 0;

    touchData32[30] = GET_BIT(t0, 0) ? 128 : 0;
    touchData32[31] = GET_BIT(t2, 7) ? 128 : 0;

    // round45t: set touchData[0..3] AFTER touchData32[] to fix cross-core race condition.
    // Previously touchData[0..2] were set BEFORE touchData32[], so Core1 HID could read
    // a mix of old/new bytes (phantom touch / micro-dropout). Now all 4 bytes are set
    // in a quick burst after touchData32[] is complete, minimizing the race window.
    // HID slider 24-31: derive from touchData32[24-31] to match CDC physical mapping.
    // Previous ((t0 & 0x0f00) >> 8) | ((t1 & 0x0f00) >> 4) used mpr0/mpr1 ELE8-11
    // which are physically at slider 0-15, causing in-game sticky keys on 24-31.
    touchData[0] = t0;
    touchData[1] = t1;
    touchData[2] = t2;
    touchData[3] = 0;
    for (uint8_t i = 0; i < 8; i++) {
        if (touchData32[24 + i]) touchData[3] |= (1 << i);
    }
}


#line 1591 "D:/Opencode,OCCM/Items/Nyanithm_Firmware/Nyanithm_firmware_hw_v1/src/hw_devices.cpp"
static MbrTouchTrace buildMbrTouchTrace() {
    MbrTouchTrace trace{};
    trace.tag = CMD_MBR_TOUCH_TRACE;
    trace.version = MBR_TRACE_VERSION;
    trace.frameId = (touchStateGen + 2u) / 2u;
    trace.publishedMs = to_ms_since_boot(get_absolute_time());
    std::memcpy(trace.slider, touchData32, sizeof(touchData32));
    std::memcpy(trace.hardware, hwTouch, sizeof(hwTouch));
    std::memcpy(trace.verified, rawTouch, sizeof(rawTouch));
    bool useMbr = (ControllerConfig.cfg0 & CFG0_BIT_MBR3116) ||
                  ControllerConfig.hwVer == 3 || ControllerConfig.hwVer == 4;
    if (useMbr) {
        trace.chipCount = (ControllerConfig.hwVer == 3 || ControllerConfig.hwVer == 4) ? 2 : 3;
        if (mbrDistanceEnabledForFrame) trace.flags |= MBR_TRACE_PROFILE;
        for (uint8_t m = 0; m < trace.chipCount; ++m) {
            if (mbrDistanceEnabledForFrame) {
                trace.chips[m] = mbrDistanceSamples[m].quality;
                for (uint8_t e = 0; e < 16; ++e) {
                    int16_t lane = laneTable[m][e];
                    if (lane >= 0) trace.counts[lane] = mbrDistanceSamples[m].counts[e];
                }
            }
            trace.chips[m].buttonStartMs = mbrButtonStartMs[m];
            trace.chips[m].buttonEndMs = mbrButtonEndMs[m];
            if (mbrButtonValid[m]) trace.chips[m].flags |= MBR_TRACE_BUTTON_VALID;
        }
    }
    return trace;
}


#line 1 "host_pipeline_scenarios.cpp"


static bool isV2() { return ControllerConfig.hwVer == 3 || ControllerConfig.hwVer == 4; }
static unsigned chipCount() { return isV2() ? 2 : 3; }
static CY8CMBR3116& chip(unsigned index) {
    if (isV2()) return index == 0 ? MBR3116D : MBR3116E;
    return index == 0 ? MBR3116A : (index == 1 ? MBR3116B : MBR3116C);
}
static unsigned laneChip(unsigned lane) { return (isV2() ? V2_LANE_M : V1_LANE_M)[lane]; }
static unsigned laneElectrode(unsigned lane) { return (isV2() ? V2_LANE_E : V1_LANE_E)[lane]; }
static void setLane(unsigned lane, uint16_t difference, bool hardware = true) {
    CY8CMBR3116& device = chip(laneChip(lane));
    unsigned electrode = laneElectrode(lane);
    device.counts[electrode] = difference;
    if (hardware) device.hardwareBits |= 1u << electrode;
    else device.hardwareBits &= ~(1u << electrode);
}
static void clearDevices() {
    for (unsigned m = 0; m < chipCount(); ++m) {
        chip(m).hardwareBits = 0;
        for (unsigned e = 0; e < 16; ++e) chip(m).counts[e] = 0;
    }
}
static void profile(bool enabled = true) {
    ControllerConfig.mbrDistanceMagic = MBR_DISTANCE_PROFILE_MAGIC;
    ControllerConfig.mbrDistanceVersion = MBR_DISTANCE_PROFILE_VERSION;
    ControllerConfig.mbrDistanceFlags = enabled ? MBR_DISTANCE_FLAG_ENABLED : 0;
    ControllerConfig.mbrDistanceZero = 100;
    ControllerConfig.mbrDistanceFull = 200;
    ControllerConfig.mbrDistanceOnPercent = 80;
    ControllerConfig.mbrDistanceOffPercent = 50;
    ControllerConfig.mbrDistanceCheck = mbrDistanceProfileCheck(ControllerConfig);
}
static void initialize(bool v2, bool enabled = true) {
    CY8CMBR3116* devices[] = {&MBR3116A, &MBR3116B, &MBR3116C, &MBR3116D, &MBR3116E};
    for (unsigned i = 0; i < 5; ++i) {
        devices[i]->i2c_port = 1;
        devices[i]->DEVICE_I2C_ADDRESS = 0x40 + i;
    }
    ControllerConfig.hwVer = v2 ? 3 : 1;
    ControllerConfig.cfg0 = CFG0_BIT_MBR3116;
    ControllerConfig.th_touch = 6;
    ControllerConfig.th_release = 3;
    ControllerConfig.mbrTouchGate = 130;
    if (enabled) profile();
    buildLaneTable();
}
static void frame(uint32_t elapsed = 5) {
    readOrderCount = 0;
    fakeNow += elapsed;
    prepareMbrDistanceGate();
    if (isV2()) updateTouch_v2(); else updateTouch_v1();
    MbrTouchTrace trace = buildMbrTouchTrace();
    CHECK(trace.tag == CMD_MBR_TOUCH_TRACE && trace.version == MBR_TRACE_VERSION);
    if (!(ControllerConfig.cfg0 & CFG0_BIT_MBR3116) && !isV2()) {
        CHECK(trace.chipCount == 0 && trace.flags == 0);
        return;
    }
    CHECK(trace.chipCount == chipCount());
    CHECK((trace.flags & MBR_TRACE_PROFILE) == (mbrDistanceEnabledForFrame ? MBR_TRACE_PROFILE : 0));
    for (unsigned m = 0; m < chipCount(); ++m) {
        CHECK(trace.hardware[m] == hwTouch[m] && trace.verified[m] == rawTouch[m]);
        CHECK((trace.chips[m].flags & MBR_TRACE_BUTTON_VALID) == (chip(m).statusFails ? 0 : MBR_TRACE_BUTTON_VALID));
        if (mbrDistanceEnabledForFrame) {
            const MbrDistanceSample& sample = mbrDistanceSamples[m];
            CHECK(trace.chips[m].goodStartMs == sample.quality.goodStartMs);
            CHECK((trace.chips[m].flags & MBR_TRACE_VALID) == (sample.valid ? MBR_TRACE_VALID : 0));
            for (unsigned e = 0; e < 16; ++e) {
                int lane = laneTable[m][e];
                if (lane >= 0) CHECK(trace.counts[lane] == sample.counts[e]);
            }
        } else {
            CHECK(!(trace.chips[m].flags & MBR_TRACE_HAS_GOOD));
            CHECK(trace.chips[m].readCalls == 0);
        }
    }
    for (unsigned lane = 0; lane < 32; ++lane) CHECK(trace.slider[lane] == touchData32[lane]);
}
static void output(unsigned lane, bool active) { CHECK((touchData32[lane] != 0) == active); }
static unsigned coherentReads() {
    unsigned count = 0;
    for (unsigned m = 0; m < chipCount(); ++m) count += chip(m).coherentReads;
    return count;
}
static unsigned legacyReads() {
    unsigned count = 0;
    for (unsigned m = 0; m < chipCount(); ++m) count += chip(m).legacyReads;
    return count;
}
static void held(unsigned lane = 0) {
    setLane(lane, 250);
    for (unsigned i = 0; i < 20; ++i) { frame(); output(lane, true); }
}
static void reConfirm(unsigned lane = 0) {
    setLane(lane, 190);
    frame(); output(lane, false);
    frame(); output(lane, false);
    frame(); output(lane, true);
}
static void legacySequence() {
    ControllerConfig.mbrTouchGate = 220;
    held();
    setLane(0, 120); frame(); output(0, true);  // Historic held-touch bypass remains.
    setLane(1, 150);
    for (unsigned i = 0; i < 4; ++i) frame();
    output(1, true);  // Historic confirmed game-lane neighbour relaxation remains.
    CHECK(coherentReads() == 0);
    CHECK(legacyReads() > 0);
    CHECK(g_mbrDistanceReadFailures == 0);
}
static void runScenario(unsigned scenario, bool v2) {
    initialize(v2, scenario != 9);
    switch (scenario) {
    case 0:  // Sustained strict OFF defeats sticky, dip, stretch and verification retention.
        held();
        setLane(0, 150); frame(); output(0, false);
        setLane(0, 170); frame(); output(0, false);
        reConfirm();
        CHECK(legacyReads() == 0);
        break;
    case 1:  // A confirmed neighbour cannot relax the strict global ON boundary.
        ControllerConfig.mbrTouchGate = 220;
        held(); setLane(1, 170);
        for (unsigned i = 0; i < 4; ++i) { frame(); output(0, true); output(1, false); }
        setLane(0, 150); frame(); output(0, false); output(1, false);
        setLane(0, 170); frame(); output(0, false); output(1, false);
        break;
    case 2:  // Native OFF clears immediately even while a high count is cached.
        held(); setLane(0, 250, false); frame(1); output(0, false);
        reConfirm();
        break;
    case 3: {  // Failed gate reads count once; cache/profile changes preserve the total.
        held(); chip(laneChip(0)).readFails = true;
        frame(); output(0, false); CHECK(!mbrDistanceSamples[laneChip(0)].valid);
        CHECK(g_mbrDistanceReadFailures == 1);
        frame(1); output(0, false); CHECK(g_mbrDistanceReadFailures == 1);
        frame(4); output(0, false); CHECK(g_mbrDistanceReadFailures == 2);
        profile(false); frame(1); CHECK(g_mbrDistanceReadFailures == 2);
        unsigned legacyBefore = legacyReads();
        profile(); frame(1); CHECK(g_mbrDistanceReadFailures == 3);
        chip(laneChip(0)).readFails = false;
        reConfirm(); CHECK(legacyReads() == legacyBefore);
        CHECK(g_mbrDistanceReadFailures == 3);
        chip(laneChip(0)).genericFailuresRemaining = 2;
        frame(); output(0, true); CHECK(g_mbrDistanceReadFailures == 3);
        chip(laneChip(0)).genericFailuresRemaining = 3;
        frame(); output(0, false); CHECK(g_mbrDistanceReadFailures == 4);
        g_mbrDistanceReadFailures = 0xFFFFFFFFu;
        chip(laneChip(0)).readFails = true;
        frame(); CHECK(g_mbrDistanceReadFailures == 0);
        break;
    }
    case 4: {  // The 5ms cache is used; a due read applies the low count immediately.
        setLane(0, 250); frame(0); output(0, true);
        unsigned readCount = coherentReads();
        setLane(0, 150); frame(4); output(0, true); CHECK(coherentReads() == readCount);
        frame(1); output(0, false); CHECK(coherentReads() == readCount + chipCount());
        CHECK(legacyReads() == 0);
        break;
    }
    case 5: {  // Host-read age is inclusive at 15ms, rejected at 16ms.
        setLane(0, 250); prepareMbrDistanceGate();
        unsigned m = laneChip(0), e = laneElectrode(0);
        mbrDistanceReadSample(m, &chip(m));
        uint32_t start = mbrDistanceSamples[m].readStartedMs;
        CHECK(mbrDistanceAllowedMask(m, 1u << e, start + 15) == (1u << e));
        CHECK(mbrDistanceAllowedMask(m, 1u << e, start + 16) == 0);
        CHECK(!mbrDistanceStates[m][e].active);
        CHECK(mbrDistanceAllowedMask(m, 1u << e, start + 15) == (1u << e));
        break;
    }
    case 6: {  // Later chip blocks for 17ms: an earlier sample must not be authorized.
        unsigned lane = v2 ? 16 : 30;
        CHECK(laneChip(lane) == 0);
        setLane(lane, 250); chip(1).delayMs = 17;
        frame(); output(lane, false);
        CHECK(fakeNow - mbrDistanceSamples[0].readStartedMs == 17);
        CHECK(hwTouch[0] != 0); CHECK(rawTouch[0] == 0);
        chip(1).delayMs = 0;
        frame(); output(lane, true);
        break;
    }
    case 7: {  // Changed profile cannot inherit an active state in its new hysteresis band.
        held(); unsigned readsBefore = coherentReads();
        ControllerConfig.mbrDistanceOnPercent = 95;  // New OFF=150, ON=195.
        ControllerConfig.mbrDistanceCheck = mbrDistanceProfileCheck(ControllerConfig);
        setLane(0, 190); frame(1); output(0, false);
        CHECK(mbrDistanceResetForFrame);
        CHECK(coherentReads() == readsBefore + chipCount());
        frame(); output(0, false);
        setLane(0, 250); frame(); output(0, true);
        break;
    }
    case 8:  // Layout version changes clear cached samples and all downstream held states.
        held();
        ControllerConfig.hwVer = v2 ? 4 : 2;
        buildLaneTable(); setLane(0, 190);
        frame(1); CHECK(mbrDistanceResetForFrame); output(0, false);
        frame(); output(0, false); frame(); output(0, true);
        // Then change physical layout too, as normal hardware re-initialization does.
        clearDevices(); ControllerConfig.hwVer = v2 ? 1 : 3; buildLaneTable();
        clearDevices(); setLane(0, 190);
        frame(); CHECK(mbrDistanceResetForFrame); output(0, false);
        frame(); output(0, false); frame(); output(0, true);
        break;
    case 9:  // Legacy zero-reserved configuration, including a stray enable bit.
        CHECK(!mbrDistanceGateEnabled(ControllerConfig));
        ControllerConfig.mbrDistanceFlags = MBR_DISTANCE_FLAG_ENABLED;
        CHECK(!mbrDistanceGateEnabled(ControllerConfig));
        legacySequence();
        break;
    case 10:  // Signed but deliberately disabled profile follows the legacy pipeline.
        profile(false); CHECK(mbrDistanceProfileValid(ControllerConfig));
        legacySequence();
        break;
    case 11:  // Real forward and inverse tables agree for all 32 output lanes.
        for (unsigned lane = 0; lane < 32; ++lane) {
            clearDevices(); frame();
            setLane(lane, 250); frame();
            for (unsigned other = 0; other < 32; ++other) output(other, other == lane);
            CHECK(pressureSnap[lane] == 250);
            CHECK(laneTable[laneChip(lane)][laneElectrode(lane)] == static_cast<int>(lane));
            setLane(lane, 0); frame(); output(lane, false);
        }
        if (!v2) {
            clearDevices(); chip(2).hardwareBits = 0xFF00;
            for (unsigned e = 8; e < 16; ++e) chip(2).counts[e] = 250;
            frame();
            for (unsigned lane = 0; lane < 32; ++lane) output(lane, false);
            CHECK(mbrDistanceAllowedMask(2, 0xFF00, fakeNow) == 0);
        }
        CHECK(legacyReads() == 0);
        break;
    case 12: {  // Exercise the actual driver SYNC check and its bounded retry.
        held(); CY8CMBR3116& device = chip(laneChip(0));
        const uint32_t goodTime = mbrDistanceSamples[laneChip(0)].quality.goodStartMs;
        unsigned previousReads = device.coherentReads;
        device.tornReadsRemaining = 2;
        frame(); output(0, false); CHECK(device.coherentReads == previousReads + 2);
        CHECK(g_mbrDistanceReadFailures == 1);
        const MbrTraceChip& failed = mbrDistanceSamples[laneChip(0)].quality;
        CHECK(failed.goodStartMs == goodTime && failed.syncMismatches == 2 && failed.ioFailures == 0);
        CHECK(!(failed.flags & MBR_TRACE_VALID) && (failed.flags & MBR_TRACE_HAS_GOOD));
        previousReads = device.coherentReads; device.tornReadsRemaining = 1;
        frame(); output(0, true); CHECK(device.coherentReads == previousReads + 2);
        CHECK(g_mbrDistanceReadFailures == 1);
        CHECK(device.tornReadsRemaining == 0);
        CHECK(mbrDistanceSamples[laneChip(0)].quality.syncMismatches == 3);
        CHECK(mbrDistanceSamples[laneChip(0)].quality.flags & MBR_TRACE_VALID);
        CHECK(!device.readDifferenceCounts(nullptr));
        break;
    }
    case 13:  // A non-button-scale count above 255 is rejected, although display clamps.
        held(); setLane(0, 256); frame(); output(0, false);
        CHECK(pressureSnap[0] == 255);
        CHECK(buildMbrTouchTrace().counts[0] == 256);
        CHECK(!(mbrDistanceSamples[laneChip(0)].quality.rangeMask & (1u << laneElectrode(0))));
        reConfirm();
        break;
    case 14:  // BUTTON_STAT transport failure is native OFF despite a valid count sample.
        held(); chip(laneChip(0)).statusFails = true;
        frame(1); output(0, false); CHECK(hwTouch[laneChip(0)] == 0);
        chip(laneChip(0)).statusFails = false;
        reConfirm();
        break;
    case 15:  // Disable/re-enable does not inherit verification, sticky or neighbour state.
        held(); ControllerConfig.mbrTouchGate = 220;
        profile(false); setLane(0, 120); frame(1);
        CHECK(mbrDistanceResetForFrame); output(0, false);
        ControllerConfig.mbrTouchGate = 130; profile();
        reConfirm();
        break;
    case 16: {  // Each chip gets its first burst before any deferred SYNC retry.
        setLane(0, 250);
        for (unsigned m = 0; m < chipCount(); ++m) {
            chip(m).tornReadsRemaining = 1;
            chip(m).delayMs = 1;
        }
        frame(); output(0, true);
        CHECK(readOrderCount == 2 * chipCount());
        for (unsigned m = 0; m < chipCount(); ++m) {
            CHECK(readOrder[m] == chip(m).DEVICE_I2C_ADDRESS);
            CHECK(readOrder[m + chipCount()] == chip(m).DEVICE_I2C_ADDRESS);
            const MbrTraceChip& q = mbrDistanceSamples[m].quality;
            CHECK(q.readCalls == 1 && q.syncMismatches == 1 && q.ioFailures == 0);
            CHECK(q.goodStartMs > q.attemptStartMs && q.goodEndMs == q.attemptEndMs);
            CHECK(q.flags & MBR_TRACE_VALID);
            CHECK(!mbrDistanceSamples[m].retryNeeded);
        }
        break;
    }
    case 17: {  // All second bursts torn: no third burst, stale good data never permits ON.
        held();
        for (unsigned m = 0; m < chipCount(); ++m) chip(m).tornReadsRemaining = 2;
        frame(); output(0, false);
        CHECK(readOrderCount == 2 * chipCount());
        CHECK(g_mbrDistanceReadFailures == chipCount());
        for (unsigned m = 0; m < chipCount(); ++m) {
            CHECK(!mbrDistanceSamples[m].valid && !mbrDistanceSamples[m].retryNeeded);
            CHECK(mbrDistanceSamples[m].quality.syncMismatches == 2);
        }
        break;
    }
    case 18: {  // Transport failures do not enter deferred SYNC retries.
        setLane(0, 250);
        chip(0).readFails = true;
        chip(1).tornReadsRemaining = 1;
        frame();
        CHECK(readOrderCount == chipCount() + 1);
        CHECK(chip(0).coherentReads == 1 && chip(1).coherentReads == 2);
        CHECK(g_mbrDistanceReadFailures == 1);
        CHECK(mbrDistanceSamples[0].quality.ioFailures == 1);
        CHECK(!mbrDistanceSamples[0].valid && mbrDistanceSamples[1].valid);
        break;
    }
    case 19: {  // Successful late retry does not bypass the whole-poll 15ms age budget.
        unsigned lane = v2 ? 16 : 30;
        CHECK(laneChip(lane) == 0);
        setLane(lane, 250);
        chip(0).tornReadsRemaining = 1; chip(1).delayMs = 17;
        frame(); output(lane, false);
        CHECK(mbrDistanceSamples[0].valid);
        CHECK(mbrDistanceSamples[0].quality.goodStartMs == fakeNow);
        CHECK(fakeNow - mbrDistanceSamples[0].readStartedMs == 17);
        break;
    }
    default: CHECK(false);
    }
    if (scenario != 3 && scenario != 12 && scenario != 17 && scenario != 18) CHECK(g_mbrDistanceReadFailures == 0);
}
static void runMpr(bool withProfile) {
    initialize(false, withProfile); ControllerConfig.cfg0 = 0;
    MPR121* mprs[3] = {&mpr0, &mpr1, &mpr2};
    unsigned m = V1_LANE_M[0], e = V1_LANE_E[0];
    mprs[m]->differences[e] = 60; mprs[m]->hardwareBits = 1u << e;
    for (unsigned i = 0; i < 20; ++i) { frame(); output(0, true); }
    CHECK(!mbrDistanceEnabledForFrame);
    CHECK(coherentReads() == 0); CHECK(legacyReads() == 0);
    CHECK(g_mbrDistanceReadFailures == 0);
    mprs[m]->differences[e] = 1; frame(); output(0, true);  // Existing sustained verification.
    mprs[m]->hardwareBits = 0; frame(1); output(0, true);  // Existing sticky release.
    CHECK(mprs[m]->dataReads == 2);
}
extern "C" void mbrPipelineTestEntry() {
    const char* command = GetCommandLineA();
    unsigned number = 999;
    for (unsigned i = 0; command[i]; ++i) {
        if (command[i] == '=' && i >= 6 && command[i - 1] == 'e' && command[i - 2] == 's') {
            number = 0;
            while (command[++i] >= '0' && command[i] <= '9') number = number * 10 + command[i] - '0';
            break;
        }
    }
    if (number < 40) runScenario(number / 2, (number & 1) != 0);
    else if (number < 42) runMpr(number == 41);
    else CHECK(false);
    writeText("PASS checks="); writeNumber(checks); writeText("\n");
    ExitProcess(0);
}
