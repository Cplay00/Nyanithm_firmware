import argparse
import hashlib
import json
import time
from pathlib import Path

import round89_live as live


WS = Path(__file__).resolve().parents[1]
ORIGINAL = WS / "_dev_archive/round89c_device_before_20261001"
CANDIDATE = WS / "_dev_tools/round89_live_20261001/ath_ab_prepared/chip_40_ath_off.bin"


def validate_crc(table):
    if len(table) != 128:
        raise RuntimeError("invalid table size")
    crc = 0xFFFF
    for value in table[:126]:
        crc ^= value << 8
        for _ in range(8):
            crc = (((crc << 1) ^ 0x1021) if crc & 0x8000 else crc << 1) & 0xFFFF
    if crc != int.from_bytes(table[126:128], "little"):
        raise RuntimeError("invalid table CRC")


def read_chip(port, address):
    live.split(port, 0xC6, [address])
    return live.exact(port, 128, 5)


def burn(port, table):
    live.tail(port, 0.05)
    live.split(port, 0xBA, bytes([0x40]) + table)
    data = bytearray()
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        data.extend(port.read(port.in_waiting or 1))
        if not data.endswith(b"\n"):
            continue
        lines = bytes(data).decode("ascii", "replace").splitlines()
        if "done" in lines:
            if "programing 3116 chip" not in lines:
                raise RuntimeError(f"unexpected burn response: {lines}")
            return lines
        if any("failed" in line or "aborted" in line or "unknown command" in line for line in lines):
            raise RuntimeError(f"burn rejected: {lines}")
    raise RuntimeError(f"burn response timeout: {bytes(data)!r}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["apply", "restore"])
    args = parser.parse_args()
    out = WS / "_dev_tools/round89c_live_20261001" / f"ath_{args.action}_{time.strftime('%H%M%S')}"
    out.mkdir(parents=True, exist_ok=False)
    original = (ORIGINAL / "chip_40.bin").read_bytes()
    candidate = CANDIDATE.read_bytes()
    for table in (original, candidate):
        validate_crc(table)
    offsets = [index for index in range(128) if original[index] != candidate[index]]
    if offsets != [0x4F, 0x7E, 0x7F] or candidate[0x4F] != original[0x4F] & ~8:
        raise RuntimeError("candidate changes more than ATH_EN and CRC")
    expected, desired = (original, candidate) if args.action == "apply" else (candidate, original)
    report = {"action": args.action, "address": "0x40", "changed_offsets": offsets,
              "source": "TRM 001-91082 Rev E 1.5.60 DEVICE_CFG2 bit 3", "completed": False}
    port, info = live.connect()
    entered, attempted = False, False
    try:
        report["version"] = live.version(port)
        if info.serial_number != "5303284739002C9C" or "BID=round89c" not in report["version"]:
            raise RuntimeError("unexpected device")
        port.write(b"\xb3")
        entered = True
        live.tail(port, 0.25)
        controller, _ = live.config_read(port)
        if controller != (ORIGINAL / "controller_config.bin").read_bytes():
            raise RuntimeError("controller profile changed")
        before = {address: read_chip(port, address) for address in (0x40, 0x41, 0x42)}
        for address, table in before.items():
            (out / f"chip_{address:02x}_before.bin").write_bytes(table)
        if before[0x40] != expected:
            raise RuntimeError("0x40 does not match the expected A/B side")
        for address in (0x41, 0x42):
            if before[address] != (ORIGINAL / f"chip_{address:02x}.bin").read_bytes():
                raise RuntimeError(f"unexpected 0x{address:02x} config")
        attempted = True
        report["burn_response"] = burn(port, desired)
        after = {address: read_chip(port, address) for address in (0x40, 0x41, 0x42)}
        for address, table in after.items():
            (out / f"chip_{address:02x}_after.bin").write_bytes(table)
        if after[0x40] != desired or any(after[address] != before[address] for address in (0x41, 0x42)):
            raise RuntimeError("post-burn readback mismatch")
        report["device_cfg2"] = [before[0x40][0x4F], after[0x40][0x4F]]
        report["readback_sha256"] = {hex(address): hashlib.sha256(table).hexdigest() for address, table in after.items()}
        port.write(b"\xce")
        report["command_log"] = live.exact(port, live.exact(port, 1)[0]).hex()
        report["completed"] = True
    except Exception as error:
        report["error"] = repr(error)
        if attempted:
            try:
                report["rollback_response"] = burn(port, original)
                report["rollback_equal"] = read_chip(port, 0x40) == original
            except Exception as rollback_error:
                report["rollback_error"] = repr(rollback_error)
        raise
    finally:
        if entered:
            port.write(b"\xb9")
            port.flush()
        port.close()
        (out / "result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    time.sleep(1.5)
    port, _ = live.connect()
    try:
        port.write(b"\xb3")
        live.tail(port, 0.25)
        report["after_reboot_equal"] = read_chip(port, 0x40) == desired
        check, _ = live.config_read(port)
        report["controller_equal_after_reboot"] = check == controller
        if not report["after_reboot_equal"] or not report["controller_equal_after_reboot"]:
            raise RuntimeError("reboot readback mismatch")
    finally:
        port.write(b"\xb9")
        port.flush()
        port.close()
        (out / "result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
