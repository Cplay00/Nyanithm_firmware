"""Strict target snapshots and user-confirmed idle C7 map; no persistent writes."""
import argparse
import contextlib
import hashlib
import json
import re
import shutil
import subprocess
import time
from pathlib import Path

import round89_live as live
import round90a_history as history
from round89c_ath_ab import validate_crc
from round89g_latency_probe import connect_target

ROOT = Path(__file__).resolve().parents[1]
FILES = ('controller_config.bin', 'chip_40.bin', 'chip_41.bin', 'chip_42.bin')
live.connect = connect_target


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def take_snapshot(out):
    out.mkdir(parents=True, exist_ok=False)
    port, info = history.checked()
    try:
        state = history.status(port)
        if state['state'] != 0 or state['pending']:
            raise RuntimeError('Requires disabled event history')
        save(out / 'identity_before.json', {'serial': info.serial_number, 'history': state})
    finally:
        port.close()
    with (out / 'console.txt').open('w', encoding='utf-8') as stream, contextlib.redirect_stdout(stream):
        live.snapshot(out)
    report = json.loads((out / 'snapshot.json').read_text(encoding='utf-8'))
    assert history.SIGNATURE in report['version'] and report['usb_serial'] == '5303284739002C9C'
    assert bytes.fromhex(report['probe'])[:3] == bytes([0xbc, 0, 14])
    assert report['raw_status'] == 'RAW=0'
    cfg = (out / FILES[0]).read_bytes()
    assert cfg[2] == 2 and cfg[3] & 2
    for name in FILES[1:]:
        validate_crc((out / name).read_bytes())
    report['verified_sha256'] = {name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in FILES}
    save(out / 'checked.json', report)
    return report


def reconnect():
    deadline = time.monotonic() + 15
    while True:
        try:
            return history.checked()
        except (OSError, RuntimeError) as error:
            if time.monotonic() >= deadline:
                raise
            if isinstance(error, RuntimeError) and not str(error).startswith('target enumeration:'):
                raise
            time.sleep(.15)


def lane_mapping():
    source = (ROOT / 'Nyanithm_firmware_hw_v1/src/hw_devices.cpp').read_text(encoding='utf-8-sig')
    arrays = []
    for name in ('V1_LANE_M', 'V1_LANE_E'):
        match = re.search(r'\b' + name + r'\[32\]\s*=\s*\{([^}]+)\}', source)
        values = [int(value) for value in re.findall(r'\b\d+\b', match.group(1))]
        assert len(values) == 32
        arrays.append(values)
    pairs = [(0x40 + m, e) for m, e in zip(*arrays)]
    assert len(set(pairs)) == 32
    return {pair: lane + 1 for lane, pair in enumerate(pairs)}


def idle_map(out, baseline):
    assert (baseline / 'checked.json').is_file(), 'Verified current snapshot required'
    out.mkdir(parents=True, exist_ok=False)
    report = {'user_confirmed_clear_20cm': True, 'operations': 'C7 volatile SENSOR_ID selection only; no config/NVRAM programming',
              'semantics': 'Sequential diagnostic observations; not simultaneous samples or measured scan frequency. CP is integer-pF native debug data.', 'rows': []}
    port, info = reconnect()
    entered = False
    mapping = lane_mapping()
    try:
        report['serial'] = info.serial_number
        report['version'] = live.version(port)
        port.write(b'\xb3')
        entered = True
        report['config_entry'] = live.tail(port, .3)
        cfg, _ = live.config_read(port)
        assert cfg == (baseline / FILES[0]).read_bytes()
        sensors = []
        for address in (0x40, 0x41, 0x42):
            live.split(port, 0xc6, [address])
            table = live.exact(port, 128)
            assert table == (baseline / f'chip_{address:02x}.bin').read_bytes()
            enabled = int.from_bytes(table[:2], 'little')
            sensors.extend((address, sensor) for sensor in range(16) if enabled & (1 << sensor))
        for repeat in range(2):
            for address, sensor in (sensors if repeat == 0 else list(reversed(sensors))):
                started = time.perf_counter()
                live.split(port, 0xc7, [address, sensor])
                first = live.exact(port, 1)
                row = {'repeat': repeat + 1, 'address': address, 'sensor': sensor, 'lane': mapping.get((address, sensor))}
                if first == b'\xc7':
                    data = first + live.exact(port, 10)
                    assert data[1:3] == bytes([address, sensor])
                    row.update(valid=True, hex=data.hex(), sync=data[3], cp_pf=data[4],
                               diff=int.from_bytes(data[5:7], 'little'), baseline=int.from_bytes(data[7:9], 'little'),
                               raw=int.from_bytes(data[9:11], 'little'))
                    row['raw_minus_baseline'] = row['raw'] - row['baseline']
                else:
                    error = first + port.read_until(b'\n')
                    row.update(valid=False, response=error.decode('ascii', 'replace'))
                    report['rows'].append(row)
                    if error != b'3116 debug fail\n':
                        raise RuntimeError('Unexpected C7 reply; stop without another command')
                    continue
                row['host_transaction_ms'] = (time.perf_counter() - started) * 1000
                report['rows'].append(row)
        report['completed'] = True
    finally:
        if entered:
            port.write(b'\xb9')
            port.flush()
        port.close()
        save(out / 'idle_map.json', report)
    port, _ = reconnect()
    try:
        report['history_after'] = history.status(port)
        port.write(b'\xb1')
        report['input_after'] = list(live.exact(port, 33))
    finally:
        port.close()
    save(out / 'idle_map.json', report)
    valid = [r for r in report['rows'] if r['valid']]
    print(json.dumps({'samples': len(report['rows']), 'valid': len(valid), 'cp_pf_range': [min(r['cp_pf'] for r in valid), max(r['cp_pf'] for r in valid)],
                      'max_diff': max(r['diff'] for r in valid), 'max_abs_raw_minus_baseline': max(abs(r['raw_minus_baseline']) for r in valid),
                      'input_after': report['input_after'], 'history_state': report['history_after']['state']}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['snapshot', 'idlemap'])
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--idle-confirmed', action='store_true')
    args = parser.parse_args()
    if args.action == 'idlemap':
        assert args.idle_confirmed and args.baseline
        idle_map(args.out.resolve(), args.baseline.resolve())
        return
    report = take_snapshot(args.out.resolve())
    firmware = ROOT / 'Nyanithm_firmware_hw_v1/build_round90b/Nyanithm.uf2'
    assert hashlib.sha256(firmware.read_bytes()).hexdigest() == '2c59f8be0289a2bacbca40a7fadc59d83e32d48f76a278c9e7a0667dd2335d18'
    shutil.copy2(firmware, args.out / 'round90b.uf2')
    subprocess.run(['git', '-C', str(ROOT / 'Nyanithm_firmware_hw_v1'), 'archive', '--format=zip', '-o', str(args.out.resolve() / 'source.zip'), 'HEAD'], check=True)
    print(json.dumps({'serial': report['usb_serial'], 'version': report['version'], 'probe': report['probe'], 'profile': report['profile'],
                      'sha256': report['verified_sha256'], 'source_and_matching_local_uf2_backed_up': True}, indent=2))


if __name__ == '__main__':
    main()
