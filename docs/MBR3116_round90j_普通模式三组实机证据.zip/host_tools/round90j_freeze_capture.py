"""Freeze real capture; verify integrity only and replay without device libraries."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_dev_tools/round90j_normal_20261004'
REPO = ROOT / 'Nyanithm_firmware_hw_v1'
PACKET = REPO / 'docs/MBR3116_round90j_普通模式三组实机证据.zip'
if PACKET.exists():
    raise RuntimeError('frozen real packet exists; do not overwrite')
assert (OUT / 'capture_audit.json').read_bytes() == (OUT / 'capture_audit_portable.json').read_bytes()
audit = json.loads((OUT / 'capture_audit.json').read_text(encoding='utf-8'))
jobs = audit['capture']['jobs']
assert len(jobs) == 3 and {j['mode'] for j in jobs} == {'finger_contact', 'slow_contact', 'four_contact'}
assert all(j['user_confirmed'] is True and j['mock'] is False and j['errors'] == 0 for j in jobs)
assert audit['capture']['total_rows'] == 5784
ended = json.loads((OUT / 'actions/session_closed.json').read_text(encoding='utf-8'))
assert ended['serial_released'] and not ended['reset_sent'] and not ended['config_mode_entered'] and not ended['mock']
progress = []
for item in jobs:
    job = json.loads((OUT / 'actions' / (item['id']+'.json')).read_text(encoding='utf-8'))
    identity = job['identity']
    assert identity['usb_serial'] == '5303284739002C9C'
    assert 'NYANFW1;1.6.6-beta11;hw_v1;BID=round90g' in identity['firmware']
    assert identity['probe'] == 'bc0700050502' and identity['raw_status'] == 'RAW=0'
    assert not identity['configuration_live_read'] and not identity['configuration_commands_sent']
    assert job['serial_released_after_capture'] and job['hands_away_confirmed']
    headers = []
    for key in ('telemetry_before', 'telemetry_after'):
        raw = bytes.fromhex(job[key]['raw_hex'])
        assert len(raw) == 528
        values = struct.unpack_from('<10I', raw)
        assert values[0] == job[key]['uptime_ms'] and values[1] == job[key]['served_count']
        assert values[2] == job[key]['edge_count'] and values[8] == job[key]['loop_count']
        headers.append(values)
    assert headers[1][0] > headers[0][0] and headers[1][8] > headers[0][8]
    assert headers[1][1]-headers[0][1] == item['rows']
    progress.append({'mode': item['mode'], 'telemetry_exact_528_bytes': True,
                     'uptime_and_loop_counters_progressed': True, 'served_delta_equals_host_B1_rows': True})
mapping_path = ROOT / '_dev_tools/round90i_same32_20261004/source_mapping.json'
mapping = json.loads(mapping_path.read_text(encoding='utf-8'))
assert hashlib.sha256((REPO / 'src/hw_devices.cpp').read_bytes()).hexdigest() == mapping['source_sha256']
completion = {'scope': 'integrity only; mechanism/outcome analysis deferred', 'jobs': jobs,
              'total_pairs': 5784, 'valid_phase_pairs': sum(j['valid_phase_rows'] for j in jobs),
              'identity_checked_each_job': True, 'serial_released': True, 'live_access_this_finalization': False,
              'config_live_read': False, 'direct_HID': False, 'telemetry_integrity': progress}
(OUT / 'capture_completion.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(OUT / 'user_feedback.json').write_text(json.dumps({'user_text': '三组普通模式已完成',
    'scope': 'completion confirmation; not a quantitative game result'}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
files = {'source_mapping.json': mapping_path.read_bytes()}
for path in sorted((OUT / 'actions').iterdir()):
    if path.is_file():
        files['actions/' + path.name] = path.read_bytes()
for name in ('capture_audit.json', 'capture_audit_portable.json', 'capture_completion.json', 'user_feedback.json', 'done.png'):
    files[name] = (OUT / name).read_bytes()
for name in ('round90j_normal_page.py', 'round90j_check_capture.py', 'round89h_timed_capture.py', 'round90i_same32_page.html', 'round90j_freeze_capture.py'):
    files['host_tools/' + name] = (ROOT / '_dev_tools' / name).read_bytes()
for name in ('chuni_io.cpp', 'hw_devices.cpp'):
    files['firmware_source/' + name] = (REPO / 'src' / name).read_bytes()
manifest = {'scope': 'real normal-mode action capture; no baseline writer attribution or cure claim',
            'files': {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
with zipfile.ZipFile(PACKET, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    archive.writestr('REPLAY.txt', 'Integrity replay, standard-library Python only:\npython host_tools/round90j_check_capture.py --folder actions --mapping source_mapping.json --out replay.json\nCompare replay.json byte-for-byte with capture_audit.json. This is not outcome analysis.\n')
replay = OUT / 'real_packet_replay'
if replay.exists():
    raise RuntimeError('replay directory exists; inspect before retry')
with zipfile.ZipFile(PACKET) as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == expected for name, expected in manifest['files'].items())
    archive.extractall(replay)
run = subprocess.run([sys.executable, '-I', 'host_tools/round90j_check_capture.py', '--folder', 'actions',
                      '--mapping', 'source_mapping.json', '--out', 'replay.json'], cwd=replay,
                     capture_output=True, text=True, encoding='utf-8')
assert run.returncode == 0, run.stderr
assert (replay / 'replay.json').read_bytes() == (OUT / 'capture_audit.json').read_bytes()
report = {'members': len(files)+2, 'bytes': PACKET.stat().st_size,
          'sha256': hashlib.sha256(PACKET.read_bytes()).hexdigest(), 'zip_and_member_hashes_verified': True,
          'isolated_stdlib_replay_byte_equal': True, 'completion': completion}
(REPO / 'docs/MBR3116_round90j_实机封存核查.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
